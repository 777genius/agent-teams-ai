# Disposable P1 native capture feasibility

Source worktree is frozen donor `7805dbf49d298f21bbb489faa99fe79a1116c17a`.
This directory is an experiment, not a provider implementation or new runtime.

Three official native paths executed a scripted localhost-model tool call against
an initially dirty TEST file. Exact bytes and real native failure evidence are
retained in the receipts selected by `evidence.ts`.

- Claude SDK 0.3.305: awaited PreToolUse captured before bytes and held execution;
  PostToolUseFailure observed partial bytes after native Bash exit 7. A supported
  user post-hook changed the file again before final capture. Session/tool IDs
  bind observations to an immutable fixture task/window. A subsequent external
  edit invalidated the final revision hash.
- Codex 0.162.0: prepared input baseline plus matched actual commandExecution
  item/started/completed, thread/turn/native item IDs, failed status and exit 7,
  with exact final bytes in an exclusive TEST input window.
- OpenCode 1.18.35: prepared input baseline plus authored native bash toolpart,
  session/message/call identity, native timing and metadata.exit=7, with exact
  final bytes. Toolpart `completed` does not mean the shell succeeded.

All captured direct native children closed. Only TEST-owned roots were used and
only dummy auth was supplied. No real account qualification is claimed.

The selected Codex/OpenCode window proofs do not establish production attribution
for overlapping writers. Unknown overlap must remain gap/nonreviewable. Background
eventual capture, D/Host wiring, packed consumer, task ledger/review and full M13
acceptance remain separate work. No universal synchronous hook or capture-failure
denial policy is introduced.

Verification used `/opt/homebrew/opt/node@24/bin/node` (24.21.0):

```sh
/opt/homebrew/opt/node@24/bin/node node_modules/typescript/bin/tsc -p tsconfig.json
env -i HOME="$PWD/home" PATH=/opt/homebrew/opt/node@24/bin:/usr/bin:/bin /opt/homebrew/opt/node@24/bin/node claude-capture.ts
env -i HOME="$PWD/home" PATH=/opt/homebrew/opt/node@24/bin:/usr/bin:/bin /opt/homebrew/opt/node@24/bin/node codex-capture.ts
env -i HOME="$PWD/home" PATH=/opt/homebrew/opt/node@24/bin:/usr/bin:/bin /opt/homebrew/opt/node@24/bin/node opencode-capture.ts
```

Each native run creates a new UUID TEST subdirectory. Dependency pins are the
selected frozen SDK/types/compiler versions; the local lock records integrity.
Installation requires only this standalone directory, not engine/PG workspaces:
`pnpm --ignore-workspace install --ignore-scripts --store-dir ./pnpm-store`.
