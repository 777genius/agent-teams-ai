import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { randomUUID, createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { once } from 'node:events';
import { command } from './model.ts';
type R = Record<string, unknown>;
const record = (v: unknown): R => v !== null && typeof v === 'object' ? v as R : {};
const root = resolve(`opencode-run-${randomUUID()}`); const workspace = join(root, 'workspace'); const file = join(workspace, 'tracked.txt');
for (const name of ['workspace', 'home', 'tmp', 'config', 'data', 'cache']) { await mkdir(join(root, name), { recursive: true, mode: 0o700 }); }
const before = 'initial-dirty-user-bytes\n'; await writeFile(file, before);
await writeFile(join(workspace, 'AGENTS.md'), '# TEST disposable capture workspace\n');
const binding = Object.freeze({ task: 'TEST-opencode-task', window: randomUUID(), member: 'TEST-opencode', generation: randomUUID(), workspace });
const modelRequests: R[] = [];
const model = createServer((request, response) => {
  void (async () => {
    assert.match(request.url ?? '', /\/v1\/chat\/completions$/);
    const chunks: Buffer[] = []; let bytes = 0;
    for await (const chunk of request) { const value = Buffer.from(chunk as Uint8Array); bytes += value.length; assert.ok(bytes < 2_000_000); chunks.push(value); }
    const body = record(JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown); modelRequests.push(body); assert.ok(modelRequests.length <= 8);
    const offered = Array.isArray(body.tools) ? body.tools.map(record).find(tool => record(tool.function).name === 'bash') : undefined;
    const messages = Array.isArray(body.messages) ? body.messages.map(record) : [];
    const hasResult = messages.some(message => message.role === 'tool' && message.tool_call_id === 'TEST-open-bash');
    const call = offered && !hasResult;
    const delta = call ? { role: 'assistant', tool_calls: [{ index: 0, id: 'TEST-open-bash', type: 'function', function: { name: 'bash', arguments: JSON.stringify({ command, description: 'TEST partial write then failed exit' }) } }] }
      : { role: 'assistant', content: 'CAPTURE_DONE' };
    response.writeHead(200, { 'content-type': 'text/event-stream' });
    const event = (value: R, finish: string | null) => ({ id: `TEST-open-${modelRequests.length}`, object: 'chat.completion.chunk', created: 1700000000, model: 'TEST-model', choices: [{ index: 0, delta: value, finish_reason: finish }] });
    response.write(`data: ${JSON.stringify(event(delta, null))}\n\n`);
    response.write(`data: ${JSON.stringify(event({}, call ? 'tool_calls' : 'stop'))}\n\n`); response.end('data: [DONE]\n\n');
  })().catch(error => { response.writeHead(500); response.end(String(error)); });
});
await new Promise<void>(resolve => model.listen(0, '127.0.0.1', resolve)); const modelAddress = model.address(); assert.ok(modelAddress && typeof modelAddress !== 'string');
const reserve = createServer(); await new Promise<void>(resolve => reserve.listen(0, '127.0.0.1', resolve)); const reserved = reserve.address(); assert.ok(reserved && typeof reserved !== 'string');
const port = reserved.port; await new Promise<void>(resolve => reserve.close(() => resolve()));
const config = { autoupdate: false, share: 'disabled', enabled_providers: ['TEST-local'], model: 'TEST-local/TEST-model', small_model: 'TEST-local/TEST-model',
  permission: { '*': 'deny', bash: 'allow' }, provider: { 'TEST-local': { npm: '@ai-sdk/openai-compatible', name: 'TEST local',
    options: { baseURL: `http://127.0.0.1:${modelAddress.port}/v1`, apiKey: 'TEST-LOCAL-ONLY' }, models: { 'TEST-model': { name: 'TEST-model', limit: { context: 200000, output: 2000 } } } } } };
const binary = '/opt/homebrew/lib/node_modules/opencode-ai/node_modules/opencode-darwin-arm64/bin/opencode';
const child = spawn(binary, ['serve', '--hostname', '127.0.0.1', '--port', String(port)], { cwd: workspace,
  env: { HOME: join(root, 'home'), TMPDIR: join(root, 'tmp'), XDG_CONFIG_HOME: join(root, 'config'), XDG_DATA_HOME: join(root, 'data'), XDG_CACHE_HOME: join(root, 'cache'),
    PATH: '/opt/homebrew/opt/node@24/bin:/usr/bin:/bin', SHELL: '/bin/sh', OPENCODE_CONFIG_CONTENT: JSON.stringify(config),
    OPENCODE_DISABLE_MODELS_FETCH: '1', OPENCODE_DISABLE_AUTOUPDATE: '1', OPENCODE_DISABLE_TELEMETRY: '1', OPENCODE_DISABLE_SHARE: '1', NO_COLOR: '1' }, stdio: ['ignore', 'pipe', 'pipe'] });
const closed = once(child, 'close'); let stdout = '', stderr = '';
child.stdout.on('data', value => { stdout = (stdout + String(value)).slice(-5000); }); child.stderr.on('data', value => { stderr = (stderr + String(value)).slice(-10000); });
const base = `http://127.0.0.1:${port}`;
const http = async (path: string, method = 'GET', body?: R) => { const response = await fetch(base + path, { method, headers: { 'content-type': 'application/json', 'x-opencode-directory': workspace }, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(15_000) }); if (!response.ok) { throw new Error(`${path}:${response.status}:${await response.text()}`); } return response.json() as Promise<unknown>; };
const timer = setTimeout(() => child.kill('SIGTERM'), 60_000);
try {
  let ready = false;
  for (let i = 0; i < 100; i++) { try { await http('/global/health'); ready = true; break; } catch { if (child.exitCode !== null || child.signalCode !== null) { throw new Error('native failed: ' + stderr); } await new Promise(resolve => setTimeout(resolve, 100)); } }
  assert.equal(ready, true, 'native server ready');
  const session = record(await http('/session', 'POST', { title: 'TEST native capture' })); const sessionId = session.id; assert.equal(typeof sessionId, 'string');
  const result = await http(`/session/${sessionId}/message`, 'POST', { model: { providerID: 'TEST-local', modelID: 'TEST-model' }, agent: 'build', parts: [{ type: 'text', text: 'TEST_CAPTURE supplied native Bash call' }] });
  const messages = await http(`/session/${sessionId}/message`); assert.ok(Array.isArray(messages));
  const parts = messages.flatMap(raw => { const message = record(raw); return Array.isArray(message.parts) ? message.parts.map(record) : []; });
  const tool = parts.find(part => part.type === 'tool' && part.tool === 'bash' && part.callID === 'TEST-open-bash'); assert.ok(tool, 'native authored tool part anchor');
  const state = record(tool.state); assert.equal(record(state.input).command, command);
  assert.equal(record(state.metadata).exit, 7, 'failed native shell outcome retained despite completed toolpart status');
  assert.equal(await readFile(file, 'utf8'), 'native-partial\n');
  const receipt = { proof: 'actual-native-OpenCode-capture', version: '1.18.35', binary, binarySha256: createHash('sha256').update(await readFile(binary)).digest('hex'), sourceDonor: '7805dbf49d298f21bbb489faa99fe79a1116c17a',
    binding, sessionId, before, final: await readFile(file, 'utf8'), nativeToolPart: tool, result, modelRequests: modelRequests.length,
    limitations: ['Exclusive TEST input window+native authored bash part; no production overlap attribution or D/host M13 closure', 'Native toolpart completed status is not shell success; metadata.exit=7 is preserved'] };
  assert.ok(state.status === 'completed' || state.status === 'error');
  await writeFile(join(root, 'receipt.json'), JSON.stringify(receipt, null, 2));
  await writeFile(join(root, 'messages.json'), JSON.stringify(messages, null, 2));
  console.log(JSON.stringify({ pass: true, receipt: join(root, 'receipt.json'), toolStatus: state.status, metadata: state.metadata }));
} finally {
  clearTimeout(timer); if (child.exitCode === null && child.signalCode === null) { child.kill('SIGTERM'); } await closed;
  model.closeAllConnections(); await new Promise<void>(resolve => model.close(() => resolve()));
  await writeFile(join(root, 'stderr.log'), stderr); await writeFile(join(root, 'stdout.log'), stdout);
  const receiptPath = join(root, 'receipt.json');
  try { const receipt = record(JSON.parse(await readFile(receiptPath, 'utf8')) as unknown); receipt.cleanup = { directChildClosed: child.exitCode !== null || child.signalCode !== null, pid: child.pid, code: child.exitCode, signal: child.signalCode }; await writeFile(receiptPath, JSON.stringify(receipt, null, 2)); } catch { /* Failed attempts retain source and diagnostics. */ }
}
