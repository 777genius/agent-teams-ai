// Finite native app-server sequence; Responses shapes reused from retained SQPit8 fixture.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { randomUUID, createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import { command } from './model.ts';
type R = Record<string, unknown>;
const record = (v: unknown): R => v !== null && typeof v === 'object' ? v as R : {};
const root = resolve(`codex-run-${randomUUID()}`); const workspace = join(root, 'workspace'); const file = join(workspace, 'tracked.txt');
for (const name of ['workspace', 'home', 'codex-home', 'tmp', 'config', 'data', 'cache']) { await mkdir(join(root, name), { recursive: true, mode: 0o700 }); }
const before = 'initial-dirty-user-bytes\n'; await writeFile(file, before);
await writeFile(join(workspace, 'AGENTS.md'), '# TEST disposable capture project\n');
const binding = Object.freeze({ task: 'TEST-codex-task', window: randomUUID(), member: 'TEST-codex', generation: randomUUID(), workspace });
const modelRequests: R[] = []; const native: R[] = []; let toolOffered: R | undefined;
const server = createServer((request, response) => {
  void (async () => {
    assert.equal(request.method, 'POST'); assert.match(request.url ?? '', /\/v1\/responses$/);
    const chunks: Buffer[] = []; let bytes = 0;
    for await (const chunk of request) { const value = Buffer.from(chunk as Uint8Array); bytes += value.length; assert.ok(bytes < 2_000_000); chunks.push(value); }
    const body = record(JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown); modelRequests.push(body); assert.ok(modelRequests.length <= 2);
    const tools = (Array.isArray(body.tools) ? body.tools : []).flatMap(raw => { const tool = record(raw); return tool.type === 'namespace' && Array.isArray(tool.tools) ? tool.tools.map(rawChild => ({ ...record(rawChild), namespace: tool.name })) : [tool]; });
    const selected = tools.find(tool => tool.name === 'exec_command'); assert.ok(selected, 'native shell tool offered'); toolOffered = selected;
    const id = `TEST-response-${modelRequests.length}`;
    const output = modelRequests.length === 1 ? { type: 'function_call', call_id: 'TEST-codex-native-shell', name: selected.name,
      ...(selected.namespace ? { namespace: selected.namespace } : {}), arguments: JSON.stringify({ cmd: command, yield_time_ms: 1000, max_output_tokens: 1000 }) }
      : { type: 'message', role: 'assistant', id: 'TEST-message-final', content: [{ type: 'output_text', text: 'CAPTURE_DONE' }] };
    const events = [{ type: 'response.created', response: { id } }, { type: 'response.output_item.done', item: output },
      { type: 'response.completed', response: { id, usage: { input_tokens: 1, input_tokens_details: null, output_tokens: 1, output_tokens_details: null, total_tokens: 2 } } }];
    response.writeHead(200, { 'content-type': 'text/event-stream' }); response.end(events.map(event => `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`).join(''));
  })().catch(error => { response.writeHead(500); response.end(String(error)); });
});
await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve)); const address = server.address(); assert.ok(address && typeof address !== 'string');
const config = `model = "mock-model"
model_provider = "TEST_fixture"
approval_policy = "never"
sandbox_mode = "workspace-write"
web_search = "disabled"
check_for_update_on_startup = false
cli_auth_credentials_store = "file"
project_doc_max_bytes = 0
[analytics]
enabled = false
[otel]
exporter = "none"
metrics_exporter = "none"
[features]
code_mode = false
apps = false
plugins = false
remote_models = false
shell_snapshot = false
skip_host_skill_discovery = true
enable_request_compression = false
multi_agent = false
[shell_environment_policy]
inherit = "none"
set = { HOME = ${JSON.stringify(join(root, 'home'))}, TMPDIR = ${JSON.stringify(join(root, 'tmp'))}, PATH = "/usr/bin:/bin" }
[model_providers.TEST_fixture]
name = "TEST local fixture"
base_url = "http://127.0.0.1:${address.port}/v1"
env_key = "TEST_CODEX_FIXTURE_KEY"
wire_api = "responses"
requires_openai_auth = false
supports_websockets = false
request_max_retries = 0
stream_max_retries = 0
`;
await writeFile(join(root, 'codex-home/config.toml'), config, { mode: 0o600 });
const binary = '/Users/belief/.codex/packages/standalone/releases/0.162.0-aarch64-apple-darwin/bin/codex';
const child = spawn(binary, ['app-server', '--listen', 'stdio://'], { cwd: workspace, env: { HOME: join(root, 'home'), CODEX_HOME: join(root, 'codex-home'), TMPDIR: join(root, 'tmp'),
  XDG_CONFIG_HOME: join(root, 'config'), XDG_DATA_HOME: join(root, 'data'), XDG_CACHE_HOME: join(root, 'cache'), PATH: '/usr/bin:/bin', SHELL: '/bin/sh', TEST_CODEX_FIXTURE_KEY: 'TEST-LOCAL-ONLY' }, stdio: ['pipe', 'pipe', 'pipe'] });
const closed = once(child, 'close'); let stderr = ''; child.stderr.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-5000); });
const pending = new Map<number, { resolve: (v: R) => void; reject: (e: Error) => void }>(); let sequence = 0;
child.once('close', () => { for (const waiter of pending.values()) { waiter.reject(new Error('native stopped: ' + stderr)); } pending.clear(); });
const lines = createInterface({ input: child.stdout });
lines.on('line', line => { const frame = record(JSON.parse(line) as unknown); native.push(frame); assert.ok(native.length < 2000);
  if (typeof frame.id === 'number' && !frame.method) { const promise = pending.get(frame.id); if (promise) { pending.delete(frame.id); frame.error ? promise.reject(new Error(JSON.stringify(frame.error))) : promise.resolve(record(frame.result)); } }
  else if (frame.id !== undefined && frame.method) { child.stdin.write(JSON.stringify({ id: frame.id, error: { code: -32000, message: 'TEST no approval expected' } }) + '\n'); }
});
const request = (method: string, params: R) => new Promise<R>((resolve, reject) => { const id = ++sequence; pending.set(id, { resolve, reject }); child.stdin.write(JSON.stringify({ id, method, params }) + '\n'); });
const timeout = setTimeout(() => child.kill('SIGTERM'), 60_000);
try {
  await request('initialize', { clientInfo: { name: 'TEST_capture', version: '1' }, capabilities: { experimentalApi: true } });
  child.stdin.write('{"method":"initialized"}\n');
  const thread = await request('thread/start', { cwd: workspace, model: 'mock-model', approvalPolicy: 'never', sandbox: 'workspace-write' });
  const threadId = record(thread.thread).id; assert.equal(typeof threadId, 'string');
  const turn = await request('turn/start', { threadId, input: [{ type: 'text', text: 'TEST_CAPTURE native partial write', text_elements: [] }] });
  const turnId = record(turn.turn).id; assert.equal(typeof turnId, 'string');
  await new Promise<void>((resolve, reject) => { const interval = setInterval(() => { if (native.some(frame => frame.method === 'turn/completed' && (record(frame.params).turnId ?? record(record(frame.params).turn).id) === turnId)) { clearInterval(interval); resolve(); } else if (child.exitCode !== null || child.signalCode !== null) { clearInterval(interval); reject(new Error('native stopped before terminal: ' + stderr)); } }, 20); });
  const started = native.filter(frame => frame.method === 'item/started').map(frame => record(record(frame.params).item)).find(item => item.type === 'commandExecution');
  const completed = native.filter(frame => frame.method === 'item/completed').map(frame => record(record(frame.params).item)).find(item => item.type === 'commandExecution');
  assert.ok(started && completed, 'real native command execution anchors'); assert.equal(started.id, completed.id);
  assert.equal(completed.exitCode, 7); assert.equal(await readFile(file, 'utf8'), 'native-partial\n');
  const final = await readFile(file, 'utf8');
  const receipt = { proof: 'actual-native-Codex-capture', version: '0.162.0', binary, binarySha256: createHash('sha256').update(await readFile(binary)).digest('hex'), sourceDonor: '7805dbf49d298f21bbb489faa99fe79a1116c17a',
    binding, threadId, turnId, before, final, started, completed, modelRequests: modelRequests.length, tool: toolOffered?.name,
    limitations: ['Exclusive TEST window+native command anchor proof; not production overlapping-write attribution', 'Not D/host integration or full M13 closure; no user post-hook required for this selected path'] };
  await writeFile(join(root, 'receipt.json'), JSON.stringify(receipt, null, 2));
  await writeFile(join(root, 'native-wire.json'), JSON.stringify(native, null, 2));
  console.log(JSON.stringify({ pass: true, receipt: join(root, 'receipt.json'), exitCode: completed.exitCode, tool: toolOffered?.name }));
} finally {
  clearTimeout(timeout); child.stdin.end(); if (child.exitCode === null && child.signalCode === null) { child.kill('SIGTERM'); }
  await closed; lines.close(); server.closeAllConnections(); await new Promise<void>(resolve => server.close(() => resolve())); await writeFile(join(root, 'stderr.log'), stderr);
  const receiptPath = join(root, 'receipt.json');
  try { const receipt = record(JSON.parse(await readFile(receiptPath, 'utf8')) as unknown); receipt.cleanup = { directChildClosed: child.exitCode !== null || child.signalCode !== null, pid: child.pid, code: child.exitCode, signal: child.signalCode }; await writeFile(receiptPath, JSON.stringify(receipt, null, 2)); } catch { /* Failed attempts retain source and diagnostics. */ }
}
