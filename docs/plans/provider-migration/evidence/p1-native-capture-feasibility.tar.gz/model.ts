// Finite localhost Anthropic fixture, adapted from frozen 7805dbf local-anthropic-fixture.ts.
import { createServer } from 'node:http';
import type { ServerResponse } from 'node:http';
export const command = "printf '%s\\n' 'native-partial' > tracked.txt; exit 7";
type RecordValue = Record<string, unknown>;
const record = (v: unknown): RecordValue => v !== null && typeof v === 'object' ? v as RecordValue : {};
export async function modelFixture() {
  const requests: RecordValue[] = [];
  const emitResponse = (response: ServerResponse, index: number, block: RecordValue, stop: string) => {
    response.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
    const emit = (type: string, value: RecordValue) => response.write(`event: ${type}\ndata: ${JSON.stringify({ type, ...value })}\n\n`);
    emit('message_start', { message: { id: `msg_capture_${index}`, type: 'message', role: 'assistant', model: 'claude-sonnet-4-6', content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 10, output_tokens: 0 } } });
    emit('content_block_start', { index: 0, content_block: block.type === 'text' ? { type: 'text', text: '' } : { ...block, input: {} } });
    emit('content_block_delta', { index: 0, delta: block.type === 'text' ? { type: 'text_delta', text: block.text } : { type: 'input_json_delta', partial_json: JSON.stringify(block.input) } });
    emit('content_block_stop', { index: 0 });
    emit('message_delta', { delta: { stop_reason: stop, stop_sequence: null }, usage: { output_tokens: 10 } });
    emit('message_stop', {}); response.end();
  };
  const server = createServer((request, response) => {
    void (async () => {
      if (request.url?.includes('count_tokens')) { response.end('{"input_tokens":10}'); return; }
      if (!request.url?.startsWith('/v1/messages')) { response.writeHead(404); response.end(); return; }
      const chunks: Buffer[] = []; let bytes = 0;
      for await (const chunk of request) { const value = Buffer.from(chunk as Uint8Array); bytes += value.length; if (bytes > 2_000_000) { throw new Error('fixture request bound'); } chunks.push(value); }
      const body = record(JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown);
      requests.push(body);
      const messages = Array.isArray(body.messages) ? body.messages : [];
      const results = messages.flatMap(value => { const content = record(value).content; return Array.isArray(content) ? content.map(record).filter(block => block.type === 'tool_result') : []; });
      if (results.length) { emitResponse(response, requests.length, { type: 'text', text: 'CAPTURE_DONE' }, 'end_turn'); return; }
      const tools = Array.isArray(body.tools) ? body.tools.map(record) : [];
      if (!tools.some(tool => tool.name === 'Bash')) { throw new Error('native Bash not exposed'); }
      emitResponse(response, requests.length, { type: 'tool_use', id: 'tool_CAPTURE_BASH', name: 'Bash', input: { command, description: 'Disposable TEST partial write with failed exit' } }, 'tool_use');
    })().catch(error => { response.writeHead(500); response.end(JSON.stringify({ error: { type: 'api_error', message: String(error) } })); });
  });
  await new Promise<void>((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const address = server.address(); if (!address || typeof address === 'string') { throw new Error('fixture address missing'); }
  return { url: `http://127.0.0.1:${address.port}`, requests, close: () => new Promise<void>((resolve, reject) => { server.closeAllConnections(); server.close(error => error ? reject(error) : resolve()); }) };
}
