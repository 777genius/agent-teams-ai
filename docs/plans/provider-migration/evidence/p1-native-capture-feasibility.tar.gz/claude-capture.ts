import assert from 'node:assert/strict';
import { randomUUID, createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { spawn } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { query } from '@anthropic-ai/claude-agent-sdk';
import type { HookCallback } from '@anthropic-ai/claude-agent-sdk';
import { modelFixture } from './model.ts';

const root = resolve(`claude-run-${randomUUID()}`);
const workspace = join(root, 'workspace');
const file = join(workspace, 'tracked.txt');
for (const path of ['workspace', 'home', 'config', 'tmp']) { await mkdir(join(root, path), { recursive: true, mode: 0o700 }); }
const before = 'initial-dirty-user-bytes\n';
await writeFile(file, before);
const binding = Object.freeze({ task: 'TEST-task-capture', window: randomUUID(), member: 'TEST-claude', generation: randomUUID(), workspace });
const nativeSession = randomUUID();
const observations: Record<string, unknown>[] = [];
const children: ChildProcess[] = [];
const launchCommands: string[] = [];
let diagnosticTail = '';
const model = await modelFixture();
const bytes = () => readFile(file, 'utf8');
let failureHookSeen = false;
let toolErrorSeen = false;
const pre: HookCallback = async (input, toolUseID) => {
  if (input.hook_event_name !== 'PreToolUse' || input.tool_name !== 'Bash') { return {}; }
  assert.equal(input.session_id, nativeSession); assert.equal(toolUseID, 'tool_CAPTURE_BASH');
  assert.equal(await bytes(), before);
  await new Promise(resolve => setTimeout(resolve, 250));
  assert.equal(await bytes(), before, 'native effect is held while preimage callback awaits');
  observations.push({ phase: 'before', binding, nativeSession: input.session_id, toolUseID, bytes: await bytes() });
  return {};
};
const failed: HookCallback = async (input, toolUseID) => {
  if (input.hook_event_name !== 'PostToolUseFailure' || input.tool_name !== 'Bash') { return {}; }
  assert.equal(input.session_id, nativeSession); assert.equal(toolUseID, 'tool_CAPTURE_BASH');
  assert.equal(await bytes(), 'native-partial\n');
  observations.push({ phase: 'failed-tool', binding, nativeSession: input.session_id, toolUseID, bytes: await bytes(), nativeError: input.error });
  // A supported user post-hook changes the file, then final capture observes it.
  await writeFile(file, 'post-hook-final\n');
  observations.push({ phase: 'final', binding, nativeSession: input.session_id, toolUseID, bytes: await bytes() });
  failureHookSeen = true; return {};
};
const environment = { HOME: join(root, 'home'), CLAUDE_CONFIG_DIR: join(root, 'config'), TMPDIR: join(root, 'tmp'),
  PATH: '/opt/homebrew/opt/node@24/bin:/usr/bin:/bin', ANTHROPIC_API_KEY: 'TEST-LOCALHOST-ONLY-NOT-A-REAL-KEY', ANTHROPIC_BASE_URL: model.url,
  CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', CLAUDE_CODE_DISABLE_AUTO_MEMORY: '1', DISABLE_AUTOUPDATER: '1', DISABLE_ERROR_REPORTING: '1', DISABLE_TELEMETRY: '1', NO_COLOR: '1', TERM: 'dumb' };
const controller = new AbortController();
const timer = setTimeout(() => controller.abort(), 60_000);
let terminal: unknown;
try {
  const session = query({ prompt: 'TEST_CAPTURE execute the one supplied native Bash call in this disposable project.', options: {
    cwd: workspace, sessionId: nativeSession, model: 'claude-sonnet-4-6', env: environment, tools: ['Bash'], allowedTools: ['Bash'],
    settingSources: [], permissionMode: 'default', strictMcpConfig: true, mcpServers: {}, persistSession: true, maxTurns: 3,
    abortController: controller, hooks: { PreToolUse: [{ hooks: [pre] }], PostToolUseFailure: [{ hooks: [failed] }] },
    spawnClaudeCodeProcess: options => { const child = spawn(options.command, options.args, { cwd: options.cwd, env: environment, stdio: ['pipe', 'pipe', 'pipe'], signal: options.signal }); children.push(child); launchCommands.push(options.command); child.stderr.on('data', chunk => { diagnosticTail = (diagnosticTail + String(chunk)).slice(-4000); }); return child; },
  } });
  for await (const event of session) {
    if (event.type === 'user' && Array.isArray(event.message.content)) {
      for (const block of event.message.content) { if (block.type === 'tool_result' && block.tool_use_id === 'tool_CAPTURE_BASH') { toolErrorSeen = block.is_error === true; } }
    }
    if (event.type === 'result') { terminal = event.subtype; }
  }
  assert.equal(failureHookSeen, true); assert.equal(toolErrorSeen, true);
  assert.equal(await bytes(), 'post-hook-final\n'); assert.equal(model.requests.length, 2);
  // Deliberate unknown attribution is kept nonreviewable, rather than guessing from path/time.
  await writeFile(file, 'external-edit\n');
  const finalDigest = createHash('sha256').update('post-hook-final\n').digest('hex');
  const currentDigest = createHash('sha256').update(await bytes()).digest('hex');
  assert.notEqual(currentDigest, finalDigest, 'external edit invalidates native final revision');
  const gap = { binding, reviewable: currentDigest === finalDigest, reason: 'external-write-invalidates-final-revision', finalDigest, currentDigest };
  assert.equal(gap.reviewable, false);
  const receipt = { proof: 'actual-native-Claude-SDK-capture', sdk: '0.3.305', sourceDonor: '7805dbf49d298f21bbb489faa99fe79a1116c17a', node: process.version,
    model: 'localhost-scripted', auth: 'dummy-isolated', nativeSession, binding, observations, toolErrorSeen, terminal, externalEditGap: gap,
    nativeExecutables: await Promise.all(launchCommands.map(async command => ({ command, sha256: createHash('sha256').update(await readFile(command)).digest('hex') }))),
    limitations: ['Direct native capability proof, not integrated D/Host/M13 acceptance', 'External final-revision conflict is proven; automatic concurrent-write attribution remains unwired'] };
  await writeFile(join(root, 'receipt.json'), JSON.stringify(receipt, null, 2));
  console.log(JSON.stringify({ pass: true, receipt: join(root, 'receipt.json'), phases: observations.map(value => value.phase), toolErrorSeen }));
} finally {
  clearTimeout(timer); controller.abort();
  for (const child of children) { if (child.exitCode === null && child.signalCode === null) { child.kill('SIGTERM'); } }
  await Promise.all(children.map(child => child.exitCode !== null || child.signalCode !== null ? Promise.resolve() : new Promise<void>(resolve => child.once('exit', () => resolve()))));
  await model.close();
  const receiptPath = join(root, 'receipt.json');
  try { const receipt = JSON.parse(await readFile(receiptPath, 'utf8')) as Record<string, unknown>; receipt.cleanup = { directChildrenClosed: children.every(child => child.exitCode !== null || child.signalCode !== null), children: children.map(child => ({ pid: child.pid, code: child.exitCode, signal: child.signalCode })) }; await writeFile(receiptPath, JSON.stringify(receipt, null, 2)); } catch { await writeFile(join(root, 'diagnostic.log'), diagnosticTail); }
}
