import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const sources = ['model.ts', 'claude-capture.ts', 'codex-capture.ts', 'opencode-capture.ts', 'evidence.ts', 'package.json', 'pnpm-lock.yaml', 'tsconfig.json'];
const receipts = [
  'claude-run-6cf1bff6-0b14-40fd-9c3f-de93774c5f86/receipt.json',
  'codex-run-ba678f3b-012a-41a6-a91b-2d598d2fcd41/receipt.json',
  'opencode-run-476f2bf3-9c88-48ba-8051-110c8d73d3ce/receipt.json',
];
for (const path of receipts) {
  const value = JSON.parse(await readFile(path, 'utf8')) as Record<string, unknown>;
  const cleanup = value.cleanup as Record<string, unknown>;
  assert.ok(cleanup.directChildClosed === true || cleanup.directChildrenClosed === true, `captured child must close: ${path}`);
}
const manifest = { sourceDonor: '7805dbf49d298f21bbb489faa99fe79a1116c17a', frontendPlan: 'b6a038388',
  scope: 'P1 native capture capability feasibility only; not D/Host integration, complete P1 or M13 closure',
  checks: { strictTypeScript: 'PASS: Node24.21.0 node_modules/typescript/bin/tsc -p tsconfig.json', nativeClaude: 'PASS', nativeCodex: 'PASS', nativeOpenCode: 'PASS' },
  source: await Promise.all(sources.map(async path => ({ path, sha256: createHash('sha256').update(await readFile(path)).digest('hex') }))),
  evidence: await Promise.all(receipts.map(async path => ({ path, sha256: createHash('sha256').update(await readFile(path)).digest('hex') }))),
  reuse: [
    { source: '7805dbf:experiments/interactive-provider-contract/harness/local-anthropic-fixture.ts', use: 'finite Anthropic SSE shapes, rewritten for native Bash capture' },
    { source: '/private/tmp/TEST-codex-native-local-responses-capture-SQPit8/responses-fixture.ts', sha256: createHash('sha256').update(await readFile('/private/tmp/TEST-codex-native-local-responses-capture-SQPit8/responses-fixture.ts')).digest('hex'), use: 'read-only retained finite Responses event/profile shapes; no runtime source or PG imported' },
  ],
  invariants: ['Fresh isolated TEST roots; HOME/config/data/cache own', 'Only dummy credentials and localhost model fixtures', 'Official native SDK/CLI executes the tool', 'No production/release checkout or provider donor source edits', 'Only captured direct children stopped, no shared-host discovery/kill'],
  remaining: ['D capability integration and packed Host evidence', 'Automatic attribution under concurrent/external edits; preserve gap/nonreviewable', 'Background execution eventual capture and product hook denominator qualification', 'P6 task ledger/review/apply and UI acceptance', 'Real account/auth/model and OS egress/containment qualification'] };
await writeFile('evidence-manifest.json', JSON.stringify(manifest, null, 2));
console.log(JSON.stringify({ manifest: resolve('evidence-manifest.json'), sha256: createHash('sha256').update(await readFile('evidence-manifest.json')).digest('hex') }));
