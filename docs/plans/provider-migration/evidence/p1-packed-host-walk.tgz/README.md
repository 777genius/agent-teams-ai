# P1 external packed host + provider walking slice

This standalone TEST consumer installs only the supplied Host, provider D and
contracts tarballs plus their declared dependencies. It has no source aliases or
engine/PG/custody/fork package. Exact artifact digests and closure are in the receipt
and evidence manifest. Owning source commits/metadata gates were provisional.

`host-child.ts` is a TEST composition entry that injects a small method registry
into the packed `createHostServer`. Those methods invoke the packed public
`createClaudeDriverFactory` and its real Session SPI. The default host CLI remains
handshake-only. No Team or persistence behavior is fabricated by the proof.

`walk.ts` launches that real host subprocess under the staged official Node24.21.0,
then drives handshake/open/two sequential inputs/close over stdio JSON-RPC. Each
input receives actual native MCP tool, tool-result, complete text and one terminal
observation with exact input/operation/session IDs. The official SDK/Claude native
process uses dummy auth and a finite localhost Anthropic fixture. Four inference
requests produce exactly two read-only MCP calls, one per marker. The second turn
contains the first turn's history.

Session close confirms cleanup. EOF performs the real host disposal; captured
SDK/native children exit and the owned MCP PID is absent. No shared processes are
stopped. Every run creates fresh isolated HOME/config/tmp/workspace roots.

The receipt proves this technical P1 composition only. Team/state/recovery/review,
P4/P8/Desktop UI, full M13, real account/auth/model and containment qualification
remain separate.

Install with the pinned pnpm and an isolated HOME; this directory's
`pnpm-workspace.yaml` is needed because pnpm11 reads overrides there, not from the
package.json pnpm field. Do not pass `--ignore-workspace`, which skips the local
override for the unpublished contracts package. No install scripts are required:

```sh
pnpm install --ignore-scripts --store-dir ./pnpm-store
```

Verification used the exact staged Node path recorded in `walk.ts`:

```sh
/path/to/selected-node node_modules/typescript/bin/tsc -p tsconfig.json
env -i HOME="$PWD/home" PATH=/path/to/selected-node-directory:/usr/bin:/bin /path/to/selected-node walk.ts
/path/to/selected-node evidence.ts
```

This is a Darwin arm64 tuple. Reproduction on another machine must explicitly
select its compatible Node artifact in the TEST composition; it is not a claim
that another OS or binary tuple is qualified. The archive contains the original
input tarballs, typed source, lockfile, exact selected receipt and RPC observations.

The native proof used contracts tarball `d6a2351a...b404f`. A later final tarball
`269f80a7...cf4151` changes only its package test runner metadata by adding
`--test-concurrency=1`. `final-check.ts` independently compares every archive member,
checks identical dist/declarations against the final installed package, verifies D
resolves that final contracts instance, and records the separate final consumer
strict typecheck/closure. Successful native effects were not repeated. The original
native receipt and original tarball remain unchanged; see `final-install-receipt.json`.
