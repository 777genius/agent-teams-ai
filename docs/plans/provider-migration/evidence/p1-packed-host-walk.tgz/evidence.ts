import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, relative } from 'node:path';
const hash = async (path: string) => createHash('sha256').update(await readFile(path)).digest('hex');
const receiptPath = (await readFile('latest-receipt.txt', 'utf8')).trim();
assert.ok(receiptPath.startsWith(resolve('runs') + '/'));
const receipt = JSON.parse(await readFile(receiptPath, 'utf8')) as { status: string; artifactHashes: { host: string; provider: string; contracts: string }; childReceipt: { nativeLaunch: string[]; directChildrenClosed: boolean }; hostClosed: { code: number }; mcpClosed: boolean };
assert.equal(receipt.status, 'PASS'); assert.equal(receipt.hostClosed.code, 0); assert.equal(receipt.mcpClosed, true); assert.equal(receipt.childReceipt.directChildrenClosed, true);
assert.equal(receipt.artifactHashes.host, await hash('artifacts/host.tgz'));
assert.equal(receipt.artifactHashes.provider, '93d6ecaf571c3496924cf9c68cc3c2055e1ae4f097fbb62ec132d2a01b06a893');
assert.equal(receipt.artifactHashes.contracts, 'd6a2351a672efe91d359356c4ed56b6b8aa28dbf5e05a0557de2716dea7b404f');
const source = ['walk.ts', 'host-child.ts', 'fixture.ts', 'evidence.ts', 'README.md', 'package.json', 'pnpm-workspace.yaml', 'pnpm-lock.yaml', 'tsconfig.json'];
const manifest = { status: 'PASS', scope: 'P1 packed Host + D + contracts technical conversation composition',
  source: await Promise.all(source.map(async path => ({ path, sha256: await hash(path) }))),
  receipt: { path: relative(process.cwd(), receiptPath), sha256: await hash(receiptPath) },
  artifacts: await Promise.all(['artifacts/host.tgz', 'artifacts/provider.tgz', 'artifacts/contracts-final.tgz'].map(async path => ({ path, sha256: await hash(path) }))),
  nativeExecutables: await Promise.all(receipt.childReceipt.nativeLaunch.map(async path => ({ path, sha256: await hash(path) }))),
  exactSourceCommits: 'Not asserted: owning artifact commits/metadata gates provisional; exact tarball digests are the authority of this proof',
  checks: { strictTypeScript: 'PASS (skipLibCheck:false)', packedInstall: 'PASS (only local-file overrides for unpublished contracts)',
    nativeWalkingSlice: 'PASS: host handshake/open, two sequential submit/text/tool/tool-result/result, close, EOF disposal',
    modelRequests: 4, nativeMcpCalls: 2, closure: 'No engine/PG/custody/fork package', cleanup: 'Host, captured SDK/native children and MCP closed' },
  excluded: ['Team/product persistence/recovery/review', 'Desktop UI/P4/P8/full P1 completion', 'Real Claude account/auth/model qualification', 'Escaped descendants/network containment'],
  fixtureReuse: 'Finite SSE + stdio MCP patterns from frozen 7805dbf SDK fixture; real packed D/factory and host are used without source aliases' };
await writeFile('evidence-manifest.json', JSON.stringify(manifest, null, 2));
console.log(JSON.stringify({ manifest: resolve('evidence-manifest.json'), sha256: await hash('evidence-manifest.json') }));
