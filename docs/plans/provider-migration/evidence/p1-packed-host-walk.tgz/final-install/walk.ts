import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile, readdir, lstat } from 'node:fs/promises';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import type { Event, CloseReceipt, Reply, Handoff } from '@agent-teams/provider-session-contracts';
import type { HostHandshake, JsonValue } from '@agent-teams/legacy-agent-host';
import { startModel, record } from './fixture.ts';
const root = resolve('runs', randomUUID());
for (const name of ['workspace', 'home', 'config', 'tmp']) { await mkdir(join(root, name), { recursive: true, mode: 0o700 }); }
const selectedNode = '/Users/belief/.codex/worktrees/provider-migration-two-stage-plan/old-agent-teams-frontend/resources/legacy-agent-host/node/v24.21.0/darwin-arm64/node';
const fixture = resolve('fixture.ts'); const childEntry = resolve('host-child.ts');
const model = await startModel();
const child = spawn(selectedNode, [childEntry, root, model.url, selectedNode, fixture], { cwd: process.cwd(),
  env: { HOME: join(root, 'home'), TMPDIR: join(root, 'tmp'), PATH: `${dirname(selectedNode)}:/usr/bin:/bin`, NO_COLOR: '1', TERM: 'dumb' }, stdio: ['pipe', 'pipe', 'pipe'] });
const closed = once(child, 'close'); const events: Event[] = []; const frames: unknown[] = []; let diagnostic = ''; let totalBytes = 0;
child.stderr.on('data', chunk => { diagnostic = (diagnostic + String(chunk)).slice(-4000); });
const pending = new Map<number, { resolve: (value: unknown) => void; reject: (error: Error) => void; timer: ReturnType<typeof setTimeout> }>(); let sequence = 0;
child.once('close', () => { for (const wait of pending.values()) { clearTimeout(wait.timer); wait.reject(new Error('host exited before reply: ' + diagnostic)); } pending.clear(); });
const lines = createInterface({ input: child.stdout });
lines.on('line', line => { totalBytes += Buffer.byteLength(line); assert.ok(totalBytes < 2_000_000); assert.ok(Buffer.byteLength(line) < 1_000_000); const frame = record(JSON.parse(line) as unknown); frames.push(frame);
  if (typeof frame.id === 'number') { const wait = pending.get(frame.id); if (wait) { pending.delete(frame.id); clearTimeout(wait.timer); frame.error ? wait.reject(new Error(JSON.stringify(frame.error))) : wait.resolve(frame.result); } }
  else if (frame.method === 'session.event') { events.push(frame.params as Event); }
});
const rpc = (method: string, params: JsonValue = {}) => new Promise<unknown>((resolve, reject) => { const id = ++sequence;
  const timer = setTimeout(() => { pending.delete(id); reject(new Error(`RPC timeout ${method}`)); }, 30_000); pending.set(id, { resolve, reject, timer });
  child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n'); });
async function terminal(operation: string) { const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) { const value = events.find((event): event is Event & { kind: 'result' } => event.kind === 'result' && event.operationRef === operation); if (value) { return value; } if (child.exitCode !== null || child.signalCode !== null) { throw new Error('Host exited during input: ' + diagnostic); } await new Promise(resolve => setTimeout(resolve, 10)); }
  throw new Error('Provider terminal deadline');
}
let receipt: Record<string, unknown> | undefined;
try {
  const handshake = await rpc('host.handshake', { protocolVersion: 1 }) as HostHandshake;
  assert.equal(handshake.protocolVersion, 1); assert.ok(handshake.capabilities.includes('TEST.packed.provider'));
  const opened = record(await rpc('session.open')); assert.equal(opened.sessionRef, 'TEST-packed-session');
  const handoffs: Handoff[] = [];
  for (const label of ['ONE', 'TWO'] as const) {
    const inputId = `TEST-input-${label}`, operationRef = `TEST-operation-${label}`;
    const handoff = await rpc('session.submit', { inputId, operationRef, content: `HOST_${label}` }) as Reply<Handoff>;
    assert.equal(handoff.ok, true); if (!handoff.ok) { throw new Error('Native handoff failed'); }
    assert.equal(handoff.value.inputId, inputId); assert.equal(handoff.value.operationRef, operationRef); assert.equal(handoff.value.providerAcceptance, 'unknown'); handoffs.push(handoff.value);
    assert.equal((await terminal(operationRef)).outcome, 'succeeded');
    const own = events.filter(event => event.operationRef === operationRef);
    assert.ok(own.every(event => event.inputId === inputId && event.sessionRef === 'TEST-packed-session'));
    assert.ok(own.some(event => event.kind === 'tool' && event.name === 'mcp__fixture__ping' && event.toolRef === `tool_HOST_${label}`));
    assert.ok(own.some(event => event.kind === 'tool-result' && event.toolRef === `tool_HOST_${label}` && !event.isError));
    assert.ok(own.some(event => event.kind === 'text' && event.text === `DONE_HOST_${label}` && event.phase === 'complete'));
    assert.equal(own.filter(event => event.kind === 'result').length, 1);
  }
  const close = await rpc('session.close') as CloseReceipt; assert.deepEqual(close, { logicallyClosed: true, cleanup: 'confirmed' });
  const calls = (await readFile(join(root, 'mcp-calls.jsonl'), 'utf8')).trim().split('\n').map(line => record(JSON.parse(line) as unknown));
  assert.deepEqual(calls.map(value => value.marker), ['HOST_ONE', 'HOST_TWO']);
  assert.equal(model.observations.length, 4); assert.ok(model.observations.filter(value => value.marker === 'HOST_TWO').every(value => value.priorTurn));
  child.stdin.end(); await Promise.race([closed, new Promise<never>((_, reject) => setTimeout(() => reject(new Error('host exit deadline')), 5000).unref())]);
  assert.equal(child.exitCode, 0);
  const childReceipt = record(JSON.parse(await readFile(join(root, 'child-receipt.json'), 'utf8')) as unknown);
  assert.equal(childReceipt.directChildrenClosed, true); assert.equal(record(childReceipt.hostClosed).cleanup, 'completed');
  assert.equal(childReceipt.hostNode, selectedNode);
  const mcpPid = Number((await readFile(join(root, 'mcp.pid'), 'utf8')).trim()); assert.equal(calls[0]?.pid, mcpPid);
  assert.throws(() => process.kill(mcpPid, 0), { code: 'ESRCH' }, 'owned MCP child closed with SDK session');
  const packages = (await readdir('node_modules/.pnpm')).filter(name => name !== 'node_modules');
  assert.ok(packages.some(name => name.startsWith('@agent-teams+legacy-agent-host@'))); assert.ok(packages.some(name => name.startsWith('@agent-teams+provider-session-contracts@')));
  assert.ok(!packages.some(name => /agent-execution|filesystem-custody|(^|\+)pg@|postgres|claude-devtools|agent_teams_orchestrator/.test(name)), 'no engine/PG/custody/fork package in closure');
  const entries = { host: import.meta.resolve('@agent-teams/legacy-agent-host'), provider: import.meta.resolve('@agent-teams/provider-implementations/claude'), contracts: import.meta.resolve('@agent-teams/provider-session-contracts') };
  assert.ok(Object.values(entries).every(value => fileURLToPath(value).startsWith(resolve('node_modules'))));
  const hash = async (path: string) => createHash('sha256').update(await readFile(path)).digest('hex');
  receipt = { status: 'PASS', scope: 'P1 external packed host subprocess + public D Session SPI technical walking slice only', root,
    artifactHashes: { host: await hash('artifacts/host.tgz'), provider: await hash('artifacts/provider.tgz'), contracts: await hash('artifacts/contracts-final.tgz') },
    artifactProvenance: 'Provisional tarballs pending owning refs/metadata gates; exact bytes independently hashed',
    selectedNode: { path: selectedNode, sha256: await hash(selectedNode), version: process.version }, entries, packageClosure: packages,
    handshake, opened, handoffs, events, close, modelObservations: model.observations, mcpCalls: calls, childReceipt,
    mcpClosed: true, hostClosed: { pid: child.pid, code: child.exitCode, signal: child.signalCode },
    limitations: ['TEST injected host method registry; default host CLI is handshake-only', 'No Team/state/recovery/review or UI acceptance', 'Real provider auth/model unavailable and not qualified', 'Only captured direct-child + MCP cleanup proven; not escaped-descendant containment'] };
  await writeFile(join(root, 'receipt.json'), JSON.stringify(receipt, null, 2));
  await writeFile(join(root, 'host-rpc-frames.json'), JSON.stringify(frames, null, 2));
  await writeFile('latest-receipt.txt', join(root, 'receipt.json') + '\n');
  console.log(JSON.stringify({ pass: true, receipt: join(root, 'receipt.json'), modelRequests: model.observations.length, mcpCalls: calls.length, hostClosed: true }));
} finally {
  if (child.exitCode === null && child.signalCode === null) { child.stdin.end(); await Promise.race([closed, new Promise(resolve => setTimeout(resolve, 3000))]); if (child.exitCode === null && child.signalCode === null) { child.kill('SIGTERM'); await closed; } }
  for (const wait of pending.values()) { clearTimeout(wait.timer); } lines.close(); await model.close();
  await writeFile(join(root, 'host-stderr.log'), diagnostic);
  if (!receipt) { await writeFile(join(root, 'incomplete-observations.json'), JSON.stringify({ events, frames, modelObservations: model.observations }, null, 2)); }
}
