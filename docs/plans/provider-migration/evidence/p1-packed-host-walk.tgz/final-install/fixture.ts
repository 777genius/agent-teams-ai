// Finite localhost Anthropic + read-only MCP fixture, based on frozen 7805dbf SDK fixture.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { appendFileSync, writeFileSync } from 'node:fs';
import { createInterface } from 'node:readline';
import type { ServerResponse } from 'node:http';
type R = Record<string, unknown>;
export const record = (v: unknown): R => v !== null && typeof v === 'object' && !Array.isArray(v) ? v as R : {};
export async function startModel() {
  const observations: { marker: string; toolResult: boolean; priorTurn: boolean }[] = [];
  let sequence = 0;
  const send = (response: ServerResponse, block: R, stop: string) => {
    sequence++;
    response.writeHead(200, { 'content-type': 'text/event-stream' });
    const emit = (type: string, payload: R) => response.write(`event: ${type}\ndata: ${JSON.stringify({ type, ...payload })}\n\n`);
    emit('message_start', { message: { id: `msg_host_fixture_${sequence}`, type: 'message', role: 'assistant', model: 'claude-sonnet-4-6', content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 10, output_tokens: 0 } } });
    emit('content_block_start', { index: 0, content_block: block.type === 'text' ? { type: 'text', text: '' } : { ...block, input: {} } });
    emit('content_block_delta', { index: 0, delta: block.type === 'text' ? { type: 'text_delta', text: block.text } : { type: 'input_json_delta', partial_json: JSON.stringify(block.input) } });
    emit('content_block_stop', { index: 0 }); emit('message_delta', { delta: { stop_reason: stop, stop_sequence: null }, usage: { output_tokens: 10 } }); emit('message_stop', {}); response.end();
  };
  const server = createServer((request, response) => { void (async () => {
    if (request.url?.includes('count_tokens')) { response.end('{"input_tokens":10}'); return; }
    assert.equal(request.method, 'POST'); assert.ok(request.url?.startsWith('/v1/messages')); assert.ok(observations.length < 4);
    const chunks: Buffer[] = []; let bytes = 0;
    for await (const raw of request) { const chunk = Buffer.from(raw as Uint8Array); bytes += chunk.length; assert.ok(bytes < 2_000_000); chunks.push(chunk); }
    const body = record(JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown);
    const messages = Array.isArray(body.messages) ? body.messages.map(record) : [];
    let marker = ''; let toolResult = false;
    for (const message of messages.toReversed()) {
      if (message.role !== 'user') { continue; }
      const blocks = Array.isArray(message.content) ? message.content.map(record) : [];
      if (blocks.some(block => block.type === 'tool_result')) { toolResult = true; }
      const text = typeof message.content === 'string' ? message.content : blocks.filter(block => block.type === 'text').map(block => block.text).join('\n');
      const match = /HOST_(ONE|TWO)/.exec(text); if (match) { marker = match[0]; break; }
    }
    assert.ok(marker); observations.push({ marker, toolResult, priorTurn: marker === 'HOST_TWO' && JSON.stringify(messages).includes('HOST_ONE') });
    if (toolResult) { send(response, { type: 'text', text: `DONE_${marker}` }, 'end_turn'); }
    else { const tools = Array.isArray(body.tools) ? body.tools.map(record) : []; const ping = tools.find(tool => typeof tool.name === 'string' && tool.name.endsWith('__ping')); assert.ok(ping);
      send(response, { type: 'tool_use', id: `tool_${marker}`, name: ping.name, input: { marker } }, 'tool_use'); }
  })().catch(error => { if (!response.headersSent) { response.writeHead(400); } response.end(String(error)); }); });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve)); const address = server.address(); assert.ok(address && typeof address !== 'string');
  return { url: `http://127.0.0.1:${address.port}`, observations, close: () => new Promise<void>(resolve => { server.closeAllConnections(); server.close(() => resolve()); }) };
}
if (process.argv[2] === '--mcp') {
  const calls = process.argv[3]; const pidFile = process.argv[4]; assert.ok(calls && pidFile);
  writeFileSync(pidFile, String(process.pid), { mode: 0o600 });
  const input = createInterface({ input: process.stdin });
  input.on('line', line => { const request = record(JSON.parse(line) as unknown); if (!Object.hasOwn(request, 'id')) { return; }
    let result: unknown = {};
    if (request.method === 'initialize') { result = { protocolVersion: record(request.params).protocolVersion, capabilities: { tools: {} }, serverInfo: { name: 'TEST-host-MCP', version: '1' } }; }
    if (request.method === 'tools/list') { result = { tools: [{ name: 'ping', description: 'Read-only TEST echo', inputSchema: { type: 'object', properties: { marker: { type: 'string' } }, required: ['marker'], additionalProperties: false } }] }; }
    if (request.method === 'tools/call') { const params = record(request.params); assert.equal(params.name, 'ping'); const marker = record(params.arguments).marker; assert.ok(marker === 'HOST_ONE' || marker === 'HOST_TWO'); appendFileSync(calls, JSON.stringify({ name: 'ping', marker, pid: process.pid }) + '\n'); result = { content: [{ type: 'text', text: `PONG_${marker}` }] }; }
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: request.id, result }) + '\n');
  });
}
