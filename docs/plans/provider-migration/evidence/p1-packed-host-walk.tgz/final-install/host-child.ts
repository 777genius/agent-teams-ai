import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { createHostServer, HostRpcError } from '@agent-teams/legacy-agent-host';
import type { JsonValue } from '@agent-teams/legacy-agent-host';
import { createClaudeDriverFactory } from '@agent-teams/provider-implementations/claude';
import type { ClaudeConfig } from '@agent-teams/provider-implementations/claude';
import type { Session, Input, CloseReceipt } from '@agent-teams/provider-session-contracts';
import { record } from './fixture.ts';
const root = process.argv[2], modelUrl = process.argv[3], selectedNode = process.argv[4], fixture = process.argv[5];
assert.ok(root && modelUrl && selectedNode && fixture); assert.match(modelUrl, /^http:\/\/127\.0\.0\.1:[0-9]+$/);
const children: ChildProcess[] = []; const nativeLaunch: string[] = [];
let diagnostic = ''; let driver: Session | undefined; let reading: Promise<void> | undefined; let closeReceipt: CloseReceipt | undefined;
const environment = { HOME: join(root, 'home'), CLAUDE_CONFIG_DIR: join(root, 'config'), TMPDIR: join(root, 'tmp'),
  PATH: `${dirname(selectedNode)}:/usr/bin:/bin`, ANTHROPIC_API_KEY: 'TEST-LOCALHOST-ONLY-NOT-A-REAL-KEY', ANTHROPIC_BASE_URL: modelUrl,
  CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', CLAUDE_CODE_DISABLE_AUTO_MEMORY: '1', DISABLE_AUTOUPDATER: '1', DISABLE_ERROR_REPORTING: '1', DISABLE_TELEMETRY: '1', NO_COLOR: '1', TERM: 'dumb' };
const config: ClaudeConfig = {
  sessionRef: 'TEST-packed-session', trustedBinding: 'TEST-packed-member', cwd: join(root, 'workspace'), model: 'claude-sonnet-4-6', accountBinding: 'TEST-dummy-account', configRevision: 'TEST-config-1',
  environment, nativeTools: [], autoAllowedTools: ['mcp__fixture__ping'], mcpServers: { fixture: { type: 'stdio', command: selectedNode, args: [fixture, '--mcp', join(root, 'mcp-calls.jsonl'), join(root, 'mcp.pid')], env: { HOME: environment.HOME, PATH: environment.PATH } } },
  requiredTools: { fixture: ['ping'] }, probe: async () => true, sessionExists: async () => false,
  limits: { queuedInputs: 2, inputBytes: 4096, outputEvents: 400, outputBytes: 1_000_000, pendingInteractions: 2, timeoutMs: 20_000 },
  custody: { launch(options) { const child = spawn(options.command, options.args, { cwd: options.cwd, env: environment, stdio: ['pipe', 'pipe', 'pipe'], signal: options.signal }); children.push(child); nativeLaunch.push(options.command); child.stderr.on('data', chunk => { diagnostic = (diagnostic + String(chunk)).slice(-4000); }); return child; },
    async confirmStopped() { const deadline = Date.now() + 3000; while (Date.now() < deadline) { if (children.every(child => child.exitCode !== null || child.signalCode !== null)) { return true; } await new Promise(resolve => setTimeout(resolve, 20)); } return false; } },
};
const factory = createClaudeDriverFactory({ capabilities: ['session.conversation'], resolveConfiguration: async request => request.sessionId === config.sessionRef ? config : undefined, readCheckpoint: async () => undefined });
const json = (value: unknown): JsonValue => JSON.parse(JSON.stringify(value)) as JsonValue;
async function close() { if (driver) { closeReceipt = await driver.close(); await reading; } }
const server = createHostServer({ input: process.stdin, output: process.stdout, buildId: 'TEST-packed-host-provider', capabilities: ['TEST.packed.provider'], methods: {
  'session.open': { lane: 'work', async handle() {
    if (driver) { throw new HostRpcError(-32010, 'Already open'); }
    const opened = await factory.open({ tenantId: 'TEST-tenant', projectId: 'TEST-project', sessionId: config.sessionRef, generation: 1, configRevision: config.configRevision, requiredCapabilities: ['session.conversation'] }); driver = opened.driver;
    reading = (async () => { for await (const event of opened.driver.observe()) { assert.equal(server.notifyData('session.event', json(event)), true, 'bounded event notification admitted'); } })();
    return { sessionRef: driver.sessionRef, capabilities: [...opened.capabilities] };
  } },
  'session.submit': { lane: 'work', async handle(params) { if (!driver) { throw new HostRpcError(-32010, 'Not open'); } const value = record(params); if (typeof value.inputId !== 'string' || typeof value.operationRef !== 'string' || typeof value.content !== 'string') { throw new HostRpcError(-32602, 'Invalid input'); }
    const input: Input = { inputId: value.inputId, operationRef: value.operationRef, content: value.content }; return json(await driver.submit(input)); } },
  'session.close': { lane: 'control', async handle() { await close(); return json(closeReceipt); } },
}, onDispose: close });
const closed = await server.closed;
await writeFile(join(root, 'child-receipt.json'), JSON.stringify({ hostPid: process.pid, hostNode: process.execPath, hostClosed: closed, closeReceipt, nativeLaunch, children: children.map(child => ({ pid: child.pid, code: child.exitCode, signal: child.signalCode })), directChildrenClosed: children.every(child => child.exitCode !== null || child.signalCode !== null) }, null, 2));
if (diagnostic) { await writeFile(join(root, 'native-stderr.log'), diagnostic); }
// EOF handling is owned by the real host; do not fabricate a successful provider outcome.
