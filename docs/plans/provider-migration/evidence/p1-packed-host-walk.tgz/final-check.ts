import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, readdir, writeFile, realpath } from 'node:fs/promises';
import { join } from 'node:path';
const sha = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
const original = 'artifacts/contracts-final.tgz', final = 'artifacts/contracts-frozen.tgz';
assert.equal(sha(await readFile(original)), 'd6a2351a672efe91d359356c4ed56b6b8aa28dbf5e05a0557de2716dea7b404f');
assert.equal(sha(await readFile(final)), '269f80a74b6d9f42d8018b78948e3178cd09c42c2ecd5441e34d0c7e77cf4151');
const entries = (archive: string) => execFileSync('/usr/bin/tar', ['-tzf', archive], { encoding: 'utf8' }).trim().split('\n').sort();
assert.deepEqual(entries(original), entries(final));
const changed: string[] = []; const dist: { path: string; sha256: string }[] = [];
for (const path of entries(original)) {
  if (path.endsWith('/')) { continue; }
  const before = execFileSync('/usr/bin/tar', ['-xOf', original, path]);
  const after = execFileSync('/usr/bin/tar', ['-xOf', final, path]);
  if (!before.equals(after)) { changed.push(path); }
  if (path.startsWith('package/dist/')) { assert.ok(before.equals(after)); dist.push({ path, sha256: sha(after) }); }
}
assert.deepEqual(changed, ['package/package.json']);
const pkg = (archive: string) => JSON.parse(execFileSync('/usr/bin/tar', ['-xOf', archive, 'package/package.json'], { encoding: 'utf8' })) as { scripts: { test: string } };
const before = pkg(original), after = pkg(final); const testBefore = before.scripts.test, testAfter = after.scripts.test;
assert.notEqual(testBefore, testAfter); after.scripts.test = testBefore; assert.deepEqual(after, before);
assert.equal(testAfter.replace(' --test-concurrency=1', ''), testBefore);
const packages = (await readdir('final-install/node_modules/.pnpm')).filter(name => name !== 'node_modules');
assert.ok(!packages.some(name => /agent-execution|filesystem-custody|(^|\+)pg@|postgres|claude-devtools|agent_teams_orchestrator/.test(name)));
const installed = 'final-install/node_modules/@agent-teams/provider-session-contracts';
for (const item of dist) { assert.equal(sha(await readFile(join(installed, item.path.slice('package/'.length)))), item.sha256); }
const provider = await realpath('final-install/node_modules/@agent-teams/provider-implementations');
assert.equal(await realpath(join(provider, '..', 'provider-session-contracts')), await realpath(installed), 'D resolves the final contracts instance');
const sourceFiles = ['host-child.ts', 'fixture.ts', 'walk.ts', 'tsconfig.json'];
for (const path of sourceFiles) { assert.equal(sha(await readFile(path)), sha(await readFile('final-install/' + path))); }
const receipt = { status: 'PASS', scope: 'Final contracts install/strict-consumer metadata delta only; no native effects executed',
  nativeProofContracts: sha(await readFile(original)), finalContracts: sha(await readFile(final)), archiveFileSetEqual: true,
  onlyChangedArchiveMember: changed, packageMetadataDelta: { scriptsTestBefore: testBefore, scriptsTestAfter: testAfter },
  distAndDeclarationsByteIdentical: dist, installedFinalBytesVerified: true, dResolvesFinalContracts: true, closure: packages,
  strictTypecheck: 'PASS with identical walking-slice sources and skipLibCheck:false against final installed packages',
  nativeReceipt: (await readFile('latest-receipt.txt', 'utf8')).trim(), noNativeRerun: true };
await writeFile('final-install-receipt.json', JSON.stringify(receipt, null, 2));
console.log(JSON.stringify({ pass: true, receipt: 'final-install-receipt.json', onlyChangedArchiveMember: changed, distAndDeclarationsByteIdentical: true }));
