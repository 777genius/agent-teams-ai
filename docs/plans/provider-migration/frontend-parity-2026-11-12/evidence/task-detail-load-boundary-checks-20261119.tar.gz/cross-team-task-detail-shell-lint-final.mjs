import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root = '/workspace/scratch/f45fed8e9067/agent-teams-ai';
const audit = path.dirname(import.meta.filename);
const require = createRequire(path.join(root, 'package.json'));
const { ESLint } = require('eslint');
const plan = JSON.parse(readFileSync(path.join(audit, 'cross-team-task-detail-shell-r1-plan-v2.json'), 'utf8'));
const sourceFiles = plan.ownership.coexistence_audit.filter((file) => /\.tsx?$/.test(file));
const cases = [
  { name: 'exact-shell-public-entrypoint', specifier: '@features/team-task-detail/renderer/shell', allowed: true },
  { name: 'existing-full-public-entrypoint', specifier: '@features/team-task-detail/renderer', allowed: true },
  { name: 'shell-descendant', specifier: '@features/team-task-detail/renderer/shell/private', allowed: false },
  { name: 'existing-feature-internal', specifier: '@features/team-task-detail/renderer/hooks/useTaskDetailTabLabel', allowed: false },
  { name: 'unrelated-feature-internal', specifier: '@features/localization/renderer/private', allowed: false },
];
const results = [];
const selected = process.argv.slice(2);
if (selected.join(',') !== 'eslint.fast.config.js,eslint.config.js') throw new Error('Final check requires both unchanged actual lint configs.');
for (const config of selected) {
  const eslint = new ESLint({ cwd: root, overrideConfigFile: path.join(root, config) });
  const files = await eslint.lintFiles(sourceFiles);
  const probes = [];
  for (const candidate of cases) {
    const [result] = await eslint.lintText(
      `import { useTaskDetailFileLink } from '${candidate.specifier}';\nvoid useTaskDetailFileLink;\n`,
      { filePath: path.join(root, 'src/renderer/components/chat/viewers/useResolvedViewerTeamContext.ts') },
    );
    const restrictions = result.messages.filter((message) => message.ruleId === 'no-restricted-imports');
    probes.push({ ...candidate, restrictions, fatalErrorCount: result.fatalErrorCount, pass: result.fatalErrorCount === 0 && (candidate.allowed ? restrictions.length === 0 : restrictions.length > 0) });
  }
  const result = { config, configSha256: createHash('sha256').update(readFileSync(path.join(root, config))).digest('hex'), files: files.map((file) => ({ path: path.relative(root, file.filePath), errorCount: file.errorCount, warningCount: file.warningCount, fatalErrorCount: file.fatalErrorCount, messages: file.messages })), probes };
  result.pass = result.files.every((file) => file.errorCount === 0 && file.fatalErrorCount === 0) && probes.every((probe) => probe.pass);
  results.push(result);
  console.log(JSON.stringify({ config, pass: result.pass, errors: result.files.reduce((n, file) => n + file.errorCount, 0), warnings: result.files.reduce((n, file) => n + file.warningCount, 0), probes: probes.map((probe) => ({ name: probe.name, pass: probe.pass, restrictions: probe.restrictions.length })) }));
}
const receipt = { kind: 'task-detail-shell-actual-lint-after-test-findings-fixed', node: process.version, sourceFiles: sourceFiles.map((file) => ({ path: file, sha256: createHash('sha256').update(readFileSync(path.join(root, file))).digest('hex') })), results, pass: results.every((result) => result.pass) };
writeFileSync(path.join(audit, 'cross-team-task-detail-shell-lint-final.json'), `${JSON.stringify(receipt, null, 2)}\n`);
process.exitCode = receipt.pass ? 0 : 1;
