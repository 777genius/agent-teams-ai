import hashlib
import io
import json
import os
import pathlib
import stat
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/82d3f9ba6b85/toolchain')
ARCHIVE = ROOT / 'node-v24.21.0-linux-x64.tar.xz'
TARGET = ROOT / 'node24/bin/node'
MEMBER = 'node-v24.21.0-linux-x64/bin/node'
ARCHIVE_SHA = 'fd8e59d5a511510f6a298afb548f18c7d2b1be404d8b4a27d94fbe49f56cb2d6'
NODE_SHA = '7fde7b8afa198da66257f42ee2001d874c7355631e6d1579a5fb5ef1f246df4c'
REPO = pathlib.Path('/workspace/scratch/c714f5bce554/agent-teams-reconciled-local')
OUT = pathlib.Path('/workspace/scratch/c714f5bce554/ui-node-restoration-receipt.json')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def untouched_source():
    assert git('rev-parse', 'HEAD') == '47d9f29602bae778f20ae8cc133ca332e458e59a'
    assert git('status', '--porcelain') == ''
    assert list(pathlib.Path('/workspace/scratch/c714f5bce554/ui-regression-evidence').iterdir()) == []
    return {'actualLocalHead': git('rev-parse', 'HEAD'), 'gitStatus': '', 'attemptFiles': [], 'sourceOverlayWritten': False}


def file_row(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    return {'path': str(path), 'bytes': info.st_size, 'mode': oct(stat.S_IMODE(info.st_mode)),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


assert not OUT.exists(), 'single documented restoration receipt'
before = untouched_source()
assert not os.path.lexists(TARGET), 'never overwrite a concurrently appearing target'
for ancestor in [pathlib.Path('/workspace'), pathlib.Path('/workspace/scratch'), ROOT.parent, ROOT]:
    assert ancestor.is_dir() and not ancestor.is_symlink(), str(ancestor)
assert ARCHIVE.is_file() and not ARCHIVE.is_symlink()
archive = ARCHIVE.read_bytes()
assert len(archive) == 31890184 and hashlib.sha256(archive).hexdigest() == ARCHIVE_SHA
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:xz') as handle:
    member = handle.getmember(MEMBER)
    assert member.isfile() and not member.issym() and not member.islnk()
    assert member.size == 126595440 and member.mode == 0o755
    payload = handle.extractfile(member).read()
assert len(payload) == 126595440 and hashlib.sha256(payload).hexdigest() == NODE_SHA
created = []
for directory in [ROOT / 'node24', ROOT / 'node24/bin']:
    if os.path.lexists(directory):
        assert directory.is_dir() and not directory.is_symlink(), str(directory)
    else:
        directory.mkdir(mode=0o755)
        created.append(str(directory))
staging = TARGET.parent / '.node-c714-recovery-218d95.tmp'
assert not os.path.lexists(TARGET) and not os.path.lexists(staging)
fd = os.open(staging, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o755)
try:
    os.fchmod(fd, 0o755)
    with os.fdopen(fd, 'wb') as output:
        output.write(payload)
        output.flush()
        os.fsync(output.fileno())
    staged = file_row(staging)
    assert staged['bytes'] == 126595440 and staged['sha256'] == NODE_SHA and staged['mode'] == '0o755'
    os.link(staging, TARGET, follow_symlinks=False)
finally:
    staging.unlink()
after = file_row(TARGET)
assert after['bytes'] == 126595440 and after['sha256'] == NODE_SHA and after['mode'] == '0o755'
receipt = {'kind': 'one-original-runtime-file-byte-restoration-before-first-red',
           'source': {'archive': str(ARCHIVE), 'bytes': len(archive), 'sha256': ARCHIVE_SHA,
                      'member': MEMBER, 'memberBytes': len(payload), 'memberSha256': NODE_SHA, 'memberMode': '0o755'},
           'destinationWasAbsent': True, 'createdDirectories': created, 'temporarySiblingRemoved': not staging.exists(),
           'before': before, 'after': after, 'sourceStateAfter': untouched_source(),
           'nodeOrProviderInvocations': [], 'readOnlyGitQueries': ['rev-parse HEAD', 'status --porcelain'],
           'versionCalls': 0, 'downloads': 0, 'builds': 0, 'installs': 0,
           'productTestAttempts': 0, 'note': 'Exact prior pinned bytes at the same required path; no alternative runtime or test-budget reset.'}
with OUT.open('x') as handle:
    handle.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
