import datetime, hashlib, json, os, pathlib, subprocess, sys, tarfile, tempfile

p = pathlib.Path(__file__).parent
d = json.loads((p / 'dependency-plan.json').read_text())
m = json.loads((p / 'validation-manifest.json').read_text())
s = json.loads((p / 'manifest.json').read_text())
r1 = json.loads((p / 'r1-metadata.json').read_text())
root = pathlib.Path(m['cwd'])
phase = sys.argv[1]
assert phase in ('baseline', 'red', 'green', 'postflight')

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def git(*args, env=None):
    return subprocess.run(['git', *args], cwd=root, env=env, check=True, capture_output=True).stdout

assert sha((p / 'dependency-plan.json').read_bytes()) == r1['dependencyPlanSha256']
assert sha((p / 'validation-manifest.json').read_bytes()) == r1['validationManifestSha256']
publication = json.loads((p / 'publication.json').read_text())
assert publication['fullReadbackVerified'] and publication['tree'] == r1['expectedTree']
for key in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[key + 'Path']).read_bytes()) == d[key + 'Sha256']
assert blob((root / r1['planPath']).read_bytes()) == r1['planBlob']
expected_paths = [r1['planPath']]
for f in s['files']:
    changed = phase in ('green', 'postflight') or phase == 'red' and f['path'].endswith('.test.ts')
    expected = f['candidate'] if changed else f['preimage']
    assert blob((root / f['path']).read_bytes()) == expected, f['path']
    if changed: expected_paths.append(f['path'])
for name, expected in d['checkedConfigurations'].items():
    assert blob((root / name).read_bytes()) == expected['blob'], name
for name, expected in {'tsconfig.host-selected.json': '5be6147040fff092e041b8c8008c7257bf1cdfb2', 'tsconfig.app-selected.json': 'a007e3f6390e17c4fccac697902ad415097967d8'}.items():
    assert blob((p / name).read_bytes()) == expected, name
for item in d['links']:
    link = root / item['path']
    assert link.is_symlink() and os.readlink(link) == item['target'], item['path']
    assert pathlib.Path(item['sourcePath']).resolve() == pathlib.Path(item['sourceTarget']).resolve(), item['sourcePath']
    if 'packageManifestSha256' in item:
        assert sha((link / 'package.json').read_bytes()) == item['packageManifestSha256'], item['path']
    if 'targetFileSha256' in item:
        assert sha(link.read_bytes()) == item['targetFileSha256'], item['path']
for name in d['directories']:
    directory = root / name
    assert directory.is_dir() and not directory.is_symlink(), name
assert os.readlink(d['scratchConfigLink']['path']) == d['scratchConfigLink']['target']
for name in d['skippedTransientDirectories'] + d['skippedTransientFiles']:
    assert not (root / 'node_modules' / name).is_symlink(), name
closure_path = pathlib.Path(d['retainedPrivateClosureManifest'])
assert sha(closure_path.read_bytes()) == d['retainedPrivateClosureManifestSha256']
closure = json.loads(closure_path.read_text())
packages = []
archive_shas = {'@agent-teams/provider-implementations': '24040cc82613d8472bbead0643bd6eb1a8132227019a825bf0815af396c56267', '@agent-teams/provider-session-contracts': '0ea08bacd3f19a54c065cfaebbe8ae0fb3a8e6770886402f435a96e97867d2bc'}
for item in closure['packages']:
    assert os.readlink(item['path']) == item['selectedTarget']
    target = pathlib.Path(item['selectedTarget'])
    archive = pathlib.Path(item['archive'])
    assert sha(archive.read_bytes()) == archive_shas[item['packageName']]
    public_archive = root / 'vendor/provider-migration/host-logs-thinking-9423f600' / archive.name
    assert public_archive.read_bytes() == archive.read_bytes()
    inventory = {}
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if not member.isfile(): continue
            name = member.name.removeprefix('package/')
            assert name not in inventory and not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
            expected = tar.extractfile(member).read()
            actual = (target / name).read_bytes()
            assert actual == expected, name
            inventory[name] = sha(actual)
    actual_files = {str(f.relative_to(target)) for f in target.rglob('*') if f.is_file() and not f.is_symlink()}
    assert actual_files == set(inventory)
    assert len(inventory) == item['regularMemberCount']
    packages.append({'path': str(target), 'regularMembers': len(inventory), 'archiveSha256': archive_shas[item['packageName']], 'allPayloadBytesEqualArchive': True, 'publicArchiveBytesEqual': True, 'extraRegularFiles': 0})
for item in closure['dependencies']:
    assert pathlib.Path(item['path']).resolve() == pathlib.Path(item['target']).resolve()
    assert sha((pathlib.Path(item['path']) / 'package.json').read_bytes()) == item['manifestSha256']
with tempfile.TemporaryDirectory(prefix='public-read-frozen-index-', dir=p) as temp:
    env = dict(os.environ, GIT_INDEX_FILE=str(pathlib.Path(temp) / 'index'))
    git('read-tree', s['publicTree'], env=env)
    git('add', '-u', '--', '.', env=env)
    tree = git('write-tree', env=env).decode().strip()
delta = git('diff-tree', '--no-commit-id', '--name-only', '-r', s['publicTree'], tree).decode().splitlines()
assert sorted(delta) == sorted(expected_paths), delta
git('diff-tree', '--check', s['publicTree'], tree)
for key in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[key + 'Path']).read_bytes()) == d[key + 'Sha256']
dist = {}
for folder in ('agent-teams-controller/dist', 'packages/legacy-agent-host/dist', 'packages/task-change-ledger/dist'):
    for f in sorted((root / folder).rglob('*')):
        if f.is_file(): dist[str(f.relative_to(root))] = sha(f.read_bytes())
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'phase': phase, 'tree': tree, 'publishedR1': publication['commit'], 'publishedR1Tree': publication['tree'], 'planBlob': r1['planBlob'], 'sourcePaths': delta, 'normalIndexSha256': d['originalIndexSha256'], 'canonicalIndexSha256': d['canonicalIndexSha256'], 'dependencyLinks': len(d['links']), 'packages': packages, 'allFiveEdgesAndBothHostLinksUnchanged': True, 'distInventory': dist, 'distInventorySha256': sha(json.dumps(dist, sort_keys=True, separators=(',', ':')).encode())}
v = p / 'validation'; v.mkdir(exist_ok=True)
if phase != 'baseline':
    receipt = json.loads((v / 'baseline-host-build.json').read_text())
    assert receipt['exitCode'] == 0 and not receipt['timedOut']
    assert receipt['distAfter'] == dist
    assert sha((v / 'baseline-host-build.log').read_bytes()) == receipt['logSha256']
    result['buildReceipt'] = str(v / 'baseline-host-build.json')
if phase == 'postflight':
    before = json.loads((v / 'green-preflight.json').read_text())
    assert before['tree'] == tree and before['distInventory'] == dist
    result['sourceAndDistUnchanged'] = True
name = 'postflight.json' if phase == 'postflight' else phase + '-preflight.json'
assert not (v / name).exists()
(v / name).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: value for k, value in result.items() if k != 'distInventory'}))
