import datetime, hashlib, json, os, pathlib, signal, subprocess, sys, time

p = pathlib.Path(__file__).parent
v = p / 'validation'
m = json.loads((p / 'validation-manifest.json').read_text())
d = json.loads((p / 'dependency-plan.json').read_text())
r1 = json.loads((p / 'r1-metadata.json').read_text())
s = json.loads((p / 'manifest.json').read_text())
root = pathlib.Path(m['cwd'])
phase, label, key = sys.argv[1:]
assert key in m['allowedKeys']
assert phase == 'baseline' and key in ('controllerBuild', 'hostBuild') or phase == 'red' and key in ('v2Tests', 'taskTests') or phase == 'green' and key in ('v2Tests', 'hostTests', 'appTests', 'hostTypes', 'appTypes', 'scriptTypes', 'lint', 'sourceSize', 'provisioning')
pre = json.loads((v / (phase + '-preflight.json')).read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def dist_inventory():
    result = {}
    for folder in ('agent-teams-controller/dist', 'packages/legacy-agent-host/dist', 'packages/task-change-ledger/dist'):
        for file in sorted((root / folder).rglob('*')):
            if file.is_file(): result[str(file.relative_to(root))] = sha(file.read_bytes())
    return result
assert sha((p / 'validation-manifest.json').read_bytes()) == r1['validationManifestSha256']
assert sha((p / 'dependency-plan.json').read_bytes()) == r1['dependencyPlanSha256']
assert blob((root / r1['planPath']).read_bytes()) == r1['planBlob']
for f in s['files']:
    changed = phase == 'green' or phase == 'red' and f['path'].endswith('.test.ts')
    assert blob((root / f['path']).read_bytes()) == (f['candidate'] if changed else f['preimage']), f['path']
for f, expected in d['checkedConfigurations'].items():
    assert blob((root / f).read_bytes()) == expected['blob'], f
for index in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[index + 'Path']).read_bytes()) == d[index + 'Sha256']
for item in d['links']:
    assert os.readlink(root / item['path']) == item['target'], item['path']
before = dist_inventory()
prior = None
if phase != 'baseline': prior = v / 'baseline-host-build.json'
elif key == 'hostBuild': prior = v / 'baseline-controller-build.json'
if prior:
    receipt = json.loads(prior.read_text())
    assert receipt['exitCode'] == 0 and not receipt['timedOut']
    assert before == receipt['distAfter'] and sha(prior.with_suffix('.log').read_bytes()) == receipt['logSha256']
else:
    assert before == pre['distInventory']
env = dict(os.environ)
for name in m['unset']: env.pop(name, None)
env.update(m['set'])
env['PATH'] = m['prependPath'] + os.pathsep + env.get('PATH', '')
log = v / (label + '.log'); assert not log.exists()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.monotonic(); timedout = False
with log.open('wb') as output:
    proc = subprocess.Popen(m[key], cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = proc.wait(timeout=m['perCommandTimeoutSeconds'])
    except subprocess.TimeoutExpired:
        timedout = True; os.killpg(proc.pid, signal.SIGKILL); code = proc.wait()
raw = log.read_bytes(); after = dist_inventory()
result = {'label': label, 'phase': phase, 'command': m[key], 'cwd': str(root), 'sourceTree': pre['tree'], 'publishedR1': pre['publishedR1'], 'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsedSeconds': round(time.monotonic() - begin, 3), 'exitCode': code, 'timedOut': timedout, 'logSha256': sha(raw), 'logBytes': len(raw), 'dependencyPlanSha256': r1['dependencyPlanSha256'], 'unset': m['unset'], 'set': m['set'], 'prependPath': m['prependPath'], 'priorBuildReceipt': str(prior) if prior else None, 'distBefore': before, 'distAfter': after, 'distBeforeSha256': sha(json.dumps(before, sort_keys=True, separators=(',', ':')).encode()), 'distAfterSha256': sha(json.dumps(after, sort_keys=True, separators=(',', ':')).encode())}
(v / (label + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: value for k, value in result.items() if k not in ('distBefore', 'distAfter')}), flush=True)
print('\n'.join(raw.decode(errors='replace').splitlines()[-70:]), flush=True)
if phase != 'baseline': assert before == after, 'Check changed built output'
sys.exit(code if code >= 0 else 128 - code)
