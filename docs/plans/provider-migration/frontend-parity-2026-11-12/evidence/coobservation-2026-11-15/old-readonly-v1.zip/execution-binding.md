
### Exact public execution binding for the Task comment read-only four-path cut

Actual delivery parent `eba491c50fda418f8fc96fb743089b5b1532c1eb`, complete tree `d2dbbf4bf2a897879368a12685b4b3783cc9052f`, on `fix/frontend-parity-public-c2f5ff7c`, follows the completed read8, public7, Desktop3 and I3866 additions. Preserve the entire Plan29 prefix `74ccffd9026863cbe4329de417d3689e011cd6b0` (1390567 bytes) and every unrelated leaf. All four preimages match that full tree and root-owned `/workspace/scratch/c2f5ff7c30ee/agent-teams-public-0660`; detached local HEAD is not the latest delivery source. The original reviewed source R1 `193ef575a20007128c318d2afef83c25a57fe311` (10934 bytes) above remains exact. Root source manifest `69d78811b88b1b20cd578370e656cb238da4cfb9` binds all four images and original proposal manifest. Patch SHA256 `e9092de4dd7c34e6e175817f4116566568ca7f89f8b3c7a37a60c9d6e02ac530` and old-case preservation proof `477fa42c27aef1d38f5b6776fd45b18c42ddc130` remain exact.

Publish this documentation-only child, immediately normally push with expected parent, and fully read back whole Plan/tree/sole-parent/ref before selected-config link creation, source application or project execution. No primary PR update or workflow action is included in this local phase. Source approval alone does not replace this execution R1/R2.

Execution manifest `309eabd29e577c2d320a8181bda63ca94fdd5abe` (5642 bytes; SHA256 `a68fcde219ba8d0e966a58c0a7a8c82447805574569f2c4a81a1e6b1c3c3a958`) selects exactly five serial outer commands: same three full Vitest files with two test images for RED, then both product images for GREEN, selected strict types, fast lint four paths and unchanged source-size guard. Explicit redPaths select the two TSX files. Preserve actual failures; unexpected setup/import/type/lint failure stops the sequence. No count/pass is asserted prospectively. Exact argv:

```json
{
  "tests": [
    "/workspace/scratch/82d3f9ba6b85/toolchain/node24/bin/node",
    "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/pnpm/bin/pnpm.mjs",
    "exec",
    "vitest",
    "run",
    "--config",
    "vitest.config.ts",
    "test/renderer/components/team/dialogs/TaskCommentInput.test.tsx",
    "test/features/team-task-detail/renderer/taskDetailSession.integration.test.tsx",
    "src/renderer/components/team/messages/MessageComposer.pendingSend.test.tsx",
    "--maxWorkers=1"
  ],
  "types": [
    "/workspace/scratch/82d3f9ba6b85/toolchain/node24/bin/node",
    "/workspace/scratch/c2f5ff7c30ee/agent-teams-public-0660/node_modules/@typescript/native/bin/tsc",
    "--singleThreaded",
    "--project",
    "/workspace/scratch/c2f5ff7c30ee/public-task-comment-readonly-integration/tsconfig.selected.json"
  ],
  "lint": [
    "/workspace/scratch/82d3f9ba6b85/toolchain/node24/bin/node",
    "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/pnpm/bin/pnpm.mjs",
    "lint:fast:files",
    "--",
    "src/renderer/components/team/dialogs/TaskCommentInput.tsx",
    "src/renderer/components/ui/MentionableTextarea.tsx",
    "test/renderer/components/team/dialogs/TaskCommentInput.test.tsx",
    "test/features/team-task-detail/renderer/taskDetailSession.integration.test.tsx"
  ],
  "sourceSize": [
    "/workspace/scratch/82d3f9ba6b85/toolchain/node24/bin/node",
    "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/pnpm/bin/pnpm.mjs",
    "guard:source-file-size"
  ]
}
```

Pinned Node 24.21.0 / pnpm 11.25 / TS 7.0.2, unchanged root happy-dom config/setup/15,000 ms per-test limit, one worker, and original serial 180-second subprocess-group ceilings apply. Unset LEGACY_PROVIDER_SOURCE_TEST, OWNED_PROCESS_VENDOR_TEST_GO, NODE_OPTIONS and NODE_PATH; use pinned Node PATH/AGENT_BACKEND_TEST_NODE and pnpm_config_verify_deps_before_run=false. Original disposable HOME behavior stays in test/setup; no shell HOME repurposing. Config `4a2aa8506ab9a139132c83caacdf501788dafbbc` (1224 bytes) extends original strict options with four changed roots, six existing ambient declarations and include:[], with no changed option/stub/alias/error exclusion. Scratch public-task-comment-readonly-integration/node_modules links only to existing isolated public node_modules after full publication readback. No install, broader/workspace/scripts compile, lint-fix, extra retry, Host build, native/GUI/provider/StageM invocation or deadline change is proposed.

Actual reusable renderer imports use null projectPath and original UI/localization fixtures without file suggestions, URL/open-external or notification-start action. The existing hook suite retains mocked API/draft persistence and finite File objects; pendingSend retains its mocked transport/store/draft fixtures. These selected paths execute no Host/SDK/native driver/provider or external request. The unchanged third suite, config/setup and ambient sources have exact manifest pins. Happy-dom same-element/focus/handler results do not qualify Chromium physical input timing or original Cross-team E2E.

Dependency plan `2da688a52fc62d1ca94c4495133e9afdd74c17fd`, SHA256 `2ea2ae8bc157ad4f93a4449b66b965e09fba17e788c583180758038e1e077787`, stays byte-identical to completed read8. Audit all 133 links, six rebound workspace aliases, five real directories, all 253+12 provider regular payloads against exact approved 9423 archives, five original dependency edges, both Host links and checked manifests before/after. Shared Vite transient paths and stale workspace-state stay excluded. Preserve public normal index SHA256 7a2489dc3aa3880dae0e6203dd4fbadc31b59b4f634a7a773638b6297ee228c4 and private normal index SHA256 161fc5143f7e03fc593d16afa0d4bb588e230fb3667602302bc7019f225fe92a. Only temporary indexes construct complete tracked source trees; no author/private/shared dependency write is included.

Retain public7 successful Host/ledger build receipt SHA256 a7cb56eaf66454cd5dc4706bfc2b5e96fc6319ac66b1de136809acca8165bdd4, log SHA256 d6efa218a38b23ad8285a933ae787d9bcd6d542c54df4d1e1c3e04bf0f5e0789, actual source tree 88e629173edbda5883be953d12778336deb251e8. All 1,504 controller/Host/ledger output files remain byte for byte unchanged, inventory SHA256 f6f6335efc3c44cfbd7c2d93a1beba1fe2e061c6005bc930e04cb61b7c70f5b9. These outputs are context only: later Desktop/I386/renderer source is not asserted equal to the build tree, no new Host qualification follows, and selected frontend tests do not use Host runtime.

Audit `89674468d24ecd82f56f8f3b7789342e520e89b7` (SHA256 `52d32875c8efd029ff75c5522738f5fe2ef8c2eb683bef4b4260b98fcf6d529d`) and runner `3a282e583bcd8b9dac0a089662e4853e60c4257a` (SHA256 `58b396fe2c794675e3e8895479503daf09053e3130bcaa637188a50cb13e6749`) bind publication, exact source/argv/config hashes, dependency closure and outputs. RED tracked delta is exactly published Plan plus two tests; GREEN is that Plan plus four images. Postflight requires every GREEN receipt to match exact source/argv/publication/log and unchanged output inventory. Both ordinary indexes remain exact; logs/receipts use exclusive names; timeout/signal never qualifies. Both scripts were only Python-syntax parsed before publication, with no project command or setup link. An initial scratch preparation Python syntax typo executed no statements and changed no repository/source or validation result; this corrected preparation only constructs reviewable R1 artifacts.

After actual finite results and independent R2, publish exactly four source/test paths plus factual Plan append, with immediate ordinary expected-head push/full payload readback. A later #1192 advance needs fresh head lease and preservation of useful original CI, with no manual rerun/dispatch/cancel/Ready/merge/base change/new PR. StageM helper6b6c7003960eb4075d74ca449d303602e99ef83e/test0727339627757c3a96d54da2933eb7c1b60685f7 stay exact. Original one-click Cross-team actions/geometry/current-owner/20-second wait/cleanup still require resulting-source CI. Original 15-second provider gates, P08/P09, I386/full native-policy HOLD, M16/upgrade, Stage1 and real-vendor exclusions remain.
