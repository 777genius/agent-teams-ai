import datetime, hashlib, json, os, pathlib, subprocess, sys, tarfile, tempfile

p = pathlib.Path(__file__).parent
d = json.loads((p / 'dependency-plan.json').read_text())
m = json.loads((p / 'validation-manifest.json').read_text())
s = json.loads((p / 'manifest.json').read_text())
r1 = json.loads((p / 'r1-metadata.json').read_text())
root = pathlib.Path(m['cwd'])
phase = sys.argv[1]
assert phase in ('baseline', 'red', 'green', 'postflight')

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def git(*args, env=None):
    return subprocess.run(['git', *args], cwd=root, env=env, check=True, capture_output=True).stdout

assert sha((p / 'dependency-plan.json').read_bytes()) == r1['dependencyPlanSha256']
assert sha((p / 'validation-manifest.json').read_bytes()) == r1['validationManifestSha256']
assert sha((p / 'manifest.json').read_bytes()) == r1['sourceManifestSha256']
assert sha((p / 'audit-source.py').read_bytes()) == r1['auditScriptSha256']
assert sha((p / 'run-validation.py').read_bytes()) == r1['runnerScriptSha256']
publication = json.loads((p / 'publication.json').read_text())
assert publication['fullReadbackVerified'] and publication['tree'] == r1['expectedTree']
for key in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[key + 'Path']).read_bytes()) == d[key + 'Sha256']
assert set(m['redPaths']).issubset({f['path'] for f in s['files']})
for doc in r1['documentationFiles']:
    assert blob((root / doc['path']).read_bytes()) == doc['blob']
expected_paths = [doc['path'] for doc in r1['documentationFiles']]
for f in s['files']:
    changed = phase in ('green', 'postflight') or phase == 'red' and f['path'] in m['redPaths']
    expected = f['candidate'] if changed else f['preimage']
    assert blob((root / f['path']).read_bytes()) == expected, f['path']
    if changed: expected_paths.append(f['path'])
for name, expected in d['checkedConfigurations'].items():
    assert blob((root / name).read_bytes()) == expected['blob'], name
for item in m['scratchFilePins']:
    assert blob((p / item['path']).read_bytes()) == item['blob'], item['path']
for item in m['unchangedSourcePins']:
    assert blob((root / item['path']).read_bytes()) == item['blob'], item['path']
for item in d['links']:
    link = root / item['path']
    assert link.is_symlink() and os.readlink(link) == item['target'], item['path']
    assert pathlib.Path(item['sourcePath']).resolve() == pathlib.Path(item['sourceTarget']).resolve(), item['sourcePath']
    if 'packageManifestSha256' in item:
        assert sha((link / 'package.json').read_bytes()) == item['packageManifestSha256'], item['path']
    if 'targetFileSha256' in item:
        assert sha(link.read_bytes()) == item['targetFileSha256'], item['path']
for name in d['directories']:
    directory = root / name
    assert directory.is_dir() and not directory.is_symlink(), name
assert os.readlink(d['scratchConfigLink']['path']) == d['scratchConfigLink']['target']
if m.get('scratchConfigLink'):
    assert os.readlink(m['scratchConfigLink']['path']) == m['scratchConfigLink']['target']
for reference in s.get('references', []):
    if reference['path'].startswith(('tools/', 'scripts/')):
        assert blob((root / reference['path']).read_bytes()) == reference['gitBlob'], reference['path']
for name in d['skippedTransientDirectories'] + d['skippedTransientFiles']:
    assert not (root / 'node_modules' / name).is_symlink(), name
closure_path = pathlib.Path(d['retainedPrivateClosureManifest'])
assert sha(closure_path.read_bytes()) == d['retainedPrivateClosureManifestSha256']
closure = json.loads(closure_path.read_text())
packages = []
archive_shas = {'@agent-teams/provider-implementations': '24040cc82613d8472bbead0643bd6eb1a8132227019a825bf0815af396c56267', '@agent-teams/provider-session-contracts': '0ea08bacd3f19a54c065cfaebbe8ae0fb3a8e6770886402f435a96e97867d2bc'}
for item in closure['packages']:
    assert os.readlink(item['path']) == item['selectedTarget']
    target = pathlib.Path(item['selectedTarget'])
    archive = pathlib.Path(item['archive'])
    assert sha(archive.read_bytes()) == archive_shas[item['packageName']]
    public_archive = root / 'vendor/provider-migration/host-logs-thinking-9423f600' / archive.name
    assert public_archive.read_bytes() == archive.read_bytes()
    inventory = {}
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if not member.isfile(): continue
            name = member.name.removeprefix('package/')
            assert name not in inventory and not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
            expected = tar.extractfile(member).read()
            actual = (target / name).read_bytes()
            assert actual == expected, name
            inventory[name] = sha(actual)
    actual_files = {str(f.relative_to(target)) for f in target.rglob('*') if f.is_file() and not f.is_symlink()}
    assert actual_files == set(inventory)
    assert len(inventory) == item['regularMemberCount']
    packages.append({'path': str(target), 'regularMembers': len(inventory), 'archiveSha256': archive_shas[item['packageName']], 'allPayloadBytesEqualArchive': True, 'publicArchiveBytesEqual': True, 'extraRegularFiles': 0})
for item in closure['dependencies']:
    assert pathlib.Path(item['path']).resolve() == pathlib.Path(item['target']).resolve()
    assert sha((pathlib.Path(item['path']) / 'package.json').read_bytes()) == item['manifestSha256']
with tempfile.TemporaryDirectory(prefix='bounded-source-index-', dir=p) as temp:
    env = dict(os.environ, GIT_INDEX_FILE=str(pathlib.Path(temp) / 'index'))
    git('read-tree', r1['parentTree'], env=env)
    git('add', '-u', '--', '.', env=env)
    tree = git('write-tree', env=env).decode().strip()
delta = git('diff-tree', '--no-commit-id', '--name-only', '-r', r1['parentTree'], tree).decode().splitlines()
assert sorted(delta) == sorted(expected_paths), delta
git('diff-tree', '--check', r1['parentTree'], tree)
for key in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[key + 'Path']).read_bytes()) == d[key + 'Sha256']
dist = {}
for folder in ('agent-teams-controller/dist', 'packages/legacy-agent-host/dist', 'packages/task-change-ledger/dist'):
    for f in sorted((root / folder).rglob('*')):
        if f.is_file(): dist[str(f.relative_to(root))] = sha(f.read_bytes())
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'phase': phase, 'tree': tree, 'publishedR1': publication['commit'], 'publishedR1Tree': publication['tree'], 'planBlob': r1['planBlob'], 'sourcePaths': delta, 'normalIndexSha256': d['originalIndexSha256'], 'canonicalIndexSha256': d['canonicalIndexSha256'], 'dependencyLinks': len(d['links']), 'packages': packages, 'allFiveEdgesAndBothHostLinksUnchanged': True, 'distInventory': dist, 'distInventorySha256': sha(json.dumps(dist, sort_keys=True, separators=(',', ':')).encode())}
v = p / 'validation'; v.mkdir(exist_ok=True)
build = m['retainedBuild']
receipt_path = pathlib.Path(build['receiptPath'])
assert sha(receipt_path.read_bytes()) == build['receiptSha256']
receipt = json.loads(receipt_path.read_text())
assert receipt['exitCode'] == 0 and not receipt['timedOut']
assert receipt['sourceTree'] == build['sourceTree']
assert receipt['distAfter'] == dist
assert sha(receipt_path.with_suffix('.log').read_bytes()) == receipt['logSha256'] == build['logSha256']
result['retainedBuildReceipt'] = str(receipt_path)
if phase == 'postflight':
    before = json.loads((v / 'green-preflight.json').read_text())
    assert before['tree'] == tree and before['distInventory'] == dist
    for item in m['phaseSequence']:
        if item['phase'] != 'green': continue
        check_path = v / (item['label'] + '.json')
        check = json.loads(check_path.read_text())
        assert check['exitCode'] == 0 and not check['timedOut']
        assert check['sourceTree'] == tree and check['command'] == m[item['key']]
        assert check['publishedR1'] == publication['commit']
        assert check['distBefore'] == dist == check['distAfter']
        assert sha(check_path.with_suffix('.log').read_bytes()) == check['logSha256']
    result['sourceAndDistUnchanged'] = True
name = 'postflight.json' if phase == 'postflight' else phase + '-preflight.json'
assert not (v / name).exists()
(v / name).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: value for k, value in result.items() if k != 'distInventory'}))
