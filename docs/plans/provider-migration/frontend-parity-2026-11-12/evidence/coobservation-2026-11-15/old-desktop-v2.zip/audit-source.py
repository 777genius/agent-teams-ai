import datetime, hashlib, json, os, pathlib, subprocess, sys, tarfile, tempfile

p = pathlib.Path(__file__).parent
d = json.loads((p / 'dependency-plan.json').read_text())
m = json.loads((p / 'validation-manifest.json').read_text())
s = json.loads((p / 'manifest.json').read_text())
r1 = json.loads((p / 'r1-metadata.json').read_text())
root = pathlib.Path(m['cwd'])
phase = sys.argv[1]
assert phase in ('baseline', 'red', 'green', 'postflight')
assert r1.get('bindingComplete') is True, 'Root must bind the actual future parent and retained build before any phase'
assert all(isinstance(r1.get(key), str) and r1[key] for key in ('parent', 'parentTree', 'expectedTree', 'planBlob'))

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def git(*args, env=None):
    return subprocess.run(['git', *args], cwd=root, env=env, check=True, capture_output=True).stdout

assert sha((p / 'dependency-plan.json').read_bytes()) == r1['dependencyPlanSha256']
assert sha((p / 'validation-manifest.json').read_bytes()) == r1['validationManifestSha256']
assert sha((p / 'manifest.json').read_bytes()) == r1['sourceManifestSha256']
assert sha((p / 'candidate.patch').read_bytes()) == s['patchSha256']
assert sha((p / 'audit-source.py').read_bytes()) == r1['auditScriptSha256']
assert sha((p / 'run-validation.py').read_bytes()) == r1['runnerScriptSha256']
publication = json.loads((p / 'publication.json').read_text())
assert publication['fullReadbackVerified'] and publication['tree'] == r1['expectedTree']
assert publication['parent'] == r1['parent'] and publication['tree']
for key in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[key + 'Path']).read_bytes()) == d[key + 'Sha256']
assert blob((root / r1['planPath']).read_bytes()) == r1['planBlob']
expected_paths = [r1['planPath']]
for f in s['files']:
    changed = phase in ('green', 'postflight') or phase == 'red' and f['path'].endswith('.test.ts')
    expected = f['candidate'] if changed else f['preimage']
    assert blob((root / f['path']).read_bytes()) == expected, f['path']
    if changed: expected_paths.append(f['path'])
for name, expected in d['checkedConfigurations'].items():
    assert blob((root / name).read_bytes()) == expected['blob'], name
assert blob((root / m['originalScriptConfig']['path']).read_bytes()) == m['originalScriptConfig']['blob']
assert m['additionalConfigLinkRequired'] is False
for item in d['links']:
    link = root / item['path']
    assert link.is_symlink() and os.readlink(link) == item['target'], item['path']
    assert pathlib.Path(item['sourcePath']).resolve() == pathlib.Path(item['sourceTarget']).resolve(), item['sourcePath']
    if 'packageManifestSha256' in item:
        assert sha((link / 'package.json').read_bytes()) == item['packageManifestSha256'], item['path']
    if 'targetFileSha256' in item:
        assert sha(link.read_bytes()) == item['targetFileSha256'], item['path']
for name in d['directories']:
    directory = root / name
    assert directory.is_dir() and not directory.is_symlink(), name
assert os.readlink(d['scratchConfigLink']['path']) == d['scratchConfigLink']['target']
for name in d['skippedTransientDirectories'] + d['skippedTransientFiles']:
    assert not (root / 'node_modules' / name).is_symlink(), name
closure_path = pathlib.Path(d['retainedPrivateClosureManifest'])
assert sha(closure_path.read_bytes()) == d['retainedPrivateClosureManifestSha256']
closure = json.loads(closure_path.read_text())
packages = []
archive_shas = {'@agent-teams/provider-implementations': '24040cc82613d8472bbead0643bd6eb1a8132227019a825bf0815af396c56267', '@agent-teams/provider-session-contracts': '0ea08bacd3f19a54c065cfaebbe8ae0fb3a8e6770886402f435a96e97867d2bc'}
for item in closure['packages']:
    assert os.readlink(item['path']) == item['selectedTarget']
    target = pathlib.Path(item['selectedTarget'])
    archive = pathlib.Path(item['archive'])
    assert sha(archive.read_bytes()) == archive_shas[item['packageName']]
    public_archive = root / 'vendor/provider-migration/host-logs-thinking-9423f600' / archive.name
    assert public_archive.read_bytes() == archive.read_bytes()
    inventory = {}
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if not member.isfile(): continue
            name = member.name.removeprefix('package/')
            assert name not in inventory and not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
            expected = tar.extractfile(member).read()
            actual = (target / name).read_bytes()
            assert actual == expected, name
            inventory[name] = sha(actual)
    actual_files = {str(f.relative_to(target)) for f in target.rglob('*') if f.is_file() and not f.is_symlink()}
    assert actual_files == set(inventory)
    assert len(inventory) == item['regularMemberCount']
    packages.append({'path': str(target), 'regularMembers': len(inventory), 'archiveSha256': archive_shas[item['packageName']], 'allPayloadBytesEqualArchive': True, 'publicArchiveBytesEqual': True, 'extraRegularFiles': 0})
for item in closure['dependencies']:
    assert pathlib.Path(item['path']).resolve() == pathlib.Path(item['target']).resolve()
    assert sha((pathlib.Path(item['path']) / 'package.json').read_bytes()) == item['manifestSha256']
with tempfile.TemporaryDirectory(prefix='public-desktop-frozen-index-', dir=p) as temp:
    env = dict(os.environ, GIT_INDEX_FILE=str(pathlib.Path(temp) / 'index'))
    git('read-tree', r1['parentTree'], env=env)
    git('add', '-u', '--', '.', env=env)
    tree = git('write-tree', env=env).decode().strip()
delta = git('diff-tree', '--no-commit-id', '--name-only', '-r', r1['parentTree'], tree).decode().splitlines()
assert sorted(delta) == sorted(expected_paths), delta
git('diff-tree', '--check', r1['parentTree'], tree)
for key in ('originalIndex', 'canonicalIndex'):
    assert sha(pathlib.Path(d[key + 'Path']).read_bytes()) == d[key + 'Sha256']
dist = {}
for folder in ('agent-teams-controller/dist', 'packages/legacy-agent-host/dist', 'packages/task-change-ledger/dist'):
    for f in sorted((root / folder).rglob('*')):
        if f.is_file(): dist[str(f.relative_to(root))] = sha(f.read_bytes())
controller = m['retainedControllerBuild']
controller_receipt_path = pathlib.Path(controller['receiptPath'])
assert sha(controller_receipt_path.read_bytes()) == controller['receiptSha256']
controller_receipt = json.loads(controller_receipt_path.read_text())
assert controller_receipt['exitCode'] == 0 and not controller_receipt['timedOut']
assert controller_receipt['sourceTree'] == controller['sourceTree']
assert controller_receipt['publishedR1'] == controller['publishedR1']
assert sha(pathlib.Path(controller['logPath']).read_bytes()) == controller['logSha256'] == controller_receipt['logSha256']
controller_dist = {key: value for key, value in dist.items() if key.startswith('agent-teams-controller/dist/')}
assert controller_dist and controller_dist == {key: value for key, value in controller_receipt['distAfter'].items() if key.startswith('agent-teams-controller/dist/')}
assert sha(json.dumps(controller_dist, sort_keys=True, separators=(',', ':')).encode()) == controller['distInventorySha256']
host = m['retainedHostBuild']
assert all(isinstance(host.get(key), str) and host[key] for key in ('receiptSha256', 'logSha256', 'sourceTree', 'publishedR1', 'distInventorySha256'))
host_path = pathlib.Path(host['receiptPath'])
assert sha(host_path.read_bytes()) == host['receiptSha256']
host_receipt = json.loads(host_path.read_text())
assert host_receipt['phase'] == 'green-build' and host_receipt['exitCode'] == 0 and not host_receipt['timedOut']
assert host_receipt['sourceTree'] == host['sourceTree'] and host_receipt['publishedR1'] == host['publishedR1']
assert host_receipt['command'] == host['command']
assert sha(pathlib.Path(host['logPath']).read_bytes()) == host['logSha256'] == host_receipt['logSha256']
assert host_receipt['distAfter'] == dist
assert sha(json.dumps(dist, sort_keys=True, separators=(',', ':')).encode()) == host['distInventorySha256']
assert any(key.startswith('packages/legacy-agent-host/dist/') for key in dist)
assert any(key.startswith('packages/task-change-ledger/dist/') for key in dist)
build_delta = git('diff-tree', '--no-commit-id', '--name-only', '-r', host['sourceTree'], r1['parentTree']).decode().splitlines()
assert set(build_delta).issubset(set(host['allowedSourceDeltaToParent'])), build_delta
assert host['allowedSourceDeltaToParent'] == [r1['planPath']]
prior = m['retainedPublic7Postflight']; prior_path = pathlib.Path(prior['path'])
assert isinstance(prior['sha256'], str) and isinstance(prior['expectedTree'], str)
assert sha(prior_path.read_bytes()) == prior['sha256']
prior_receipt = json.loads(prior_path.read_text())
assert prior_receipt['tree'] == prior['expectedTree'] == host['sourceTree'] and prior_receipt['sourceAndDistUnchanged']
assert prior_receipt['distInventory'] == dist and prior_receipt['publishedR1'] == host['publishedR1']
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'phase': phase, 'tree': tree, 'publishedR1': publication['commit'], 'publishedR1Tree': publication['tree'], 'parent': r1['parent'], 'parentTree': r1['parentTree'], 'planBlob': r1['planBlob'], 'sourcePaths': delta, 'normalIndexSha256': d['originalIndexSha256'], 'canonicalIndexSha256': d['canonicalIndexSha256'], 'dependencyLinks': len(d['links']), 'packages': packages, 'allFiveEdgesAndBothHostLinksUnchanged': True, 'retainedControllerReceipt': str(controller_receipt_path), 'controllerDistUnchanged': True, 'retainedHostBuildReceipt': str(host_path), 'retainedHostSourceDeltaToParent': build_delta, 'retainedPublic7Postflight': str(prior_path), 'distInventory': dist, 'distInventorySha256': sha(json.dumps(dist, sort_keys=True, separators=(',', ':')).encode())}
v = p / 'validation'; v.mkdir(exist_ok=True)
if phase == 'postflight':
    before = json.loads((v / 'green-preflight.json').read_text())
    assert before['tree'] == tree and before['distInventory'] == dist
    for item in m['phaseSequence']:
        if item['phase'] != 'green': continue
        receipt_path = v / (item['label'] + '.json')
        check = json.loads(receipt_path.read_text())
        assert check['exitCode'] == 0 and not check['timedOut'] and check['sourceTree'] == tree
        assert check['publishedR1'] == publication['commit'] and check['command'] == m[item['key']]
        assert check['distBefore'] == dist == check['distAfter']
        assert sha(receipt_path.with_suffix('.log').read_bytes()) == check['logSha256']
    result['sourceAndDistUnchanged'] = True
name = 'postflight.json' if phase == 'postflight' else phase + '-preflight.json'
assert not (v / name).exists()
(v / name).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'distInventory'}))
