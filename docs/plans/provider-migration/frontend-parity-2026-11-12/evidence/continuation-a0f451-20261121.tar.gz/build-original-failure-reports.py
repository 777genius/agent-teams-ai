from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

WORK = Path('/workspace/scratch/0475591abfcd')
REPO = Path('/workspace/scratch/38cae95a211b/agent-teams-ai')
HEAD = 'a0f451bff29e8100695bc90c2ee6e23108fb7133'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def read(path): return json.loads(path.read_text())
def source_pins(paths):
    return {path: hashlib.sha256(subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=REPO)).hexdigest()
            for path in paths}
def rows(path): return [json.loads(line) for line in path.read_text().splitlines()]
def data(row): return json.loads(row['message'][row['message'].index('{'):])
def millis(value): return round(datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp() * 1000)

root = WORK / 'retained-original-a0'
fixture = root / 'extracted/TEST-desktop-backend-uwWEWL'
receipt = read(fixture / 'desktop-backend-receipt.json')
snapshot = receipt['retainedOriginalFailureDiagnostics']
files = {row['path']: row for row in snapshot['files']}
text_verified = []
for name, row in files.items():
    payload = row.get('payload', {})
    if 'text' in payload:
        assert hashlib.sha256(payload['text'].encode()).hexdigest() == row['sha256']
        text_verified.append(name)
config = json.loads(files['config.json']['payload']['text'])
freshness = json.loads(files['launch-freshness.json']['payload']['text'])
replica = files['.member-work-sync/sqlite-fallback-replica.json']['payload']['value']
alice = files['members/alice/.member-work-sync/journal.jsonl']['payload']['rows']
refusals = [{'time': row['t'], **data(row)} for row in rows(fixture / 'userData/logs/app-errors.ndjson')
            if row['message'].startswith('Native Stop release refused ')]
target = {'teamName': snapshot['teamName'], 'runId': freshness['runId']}
digest = hashlib.sha256(json.dumps(target, separators=(',', ':')).encode()).hexdigest()
assert refusals[0]['attempt'] == 1 and refusals[0]['targetDigest'] == digest
assert all(row['targetDigest'] == digest for row in refusals)
assert [member['name'] for member in config['members']] == ['team-lead']
assert any(row.get('reason') == 'member_spawned' for row in alice)
assert max(row['timestamp'] for row in alice) < refusals[0]['time']
report = {
    'kind': 'original-a0-retained-Main-Stop-first-refusal', 'head': HEAD,
    'artifact': read(root / 'safe-extraction.json'), 'runId': 44842174363, 'jobId': 136653011800,
    'receiptSha256': sha(fixture / 'desktop-backend-receipt.json'),
    'sourceInventory': {'file': 'original-source-pins.json', 'sha256': sha(root / 'original-source-pins.json'),
                        'before': 1935, 'after': 1935, 'matchesGitHead': True},
    'status': receipt['status'], 'failure': receipt['failure'],
    'target': target, 'targetDigestVerified': True, 'firstRefusal': refusals[0],
    'laterShutdownRefusals': refusals[1:],
    'originalStopClicks': sum(row.get('action') == 'mouseClick' and row.get('label') == 'original Main Stop exactly once'
                             for row in receipt['retainedOriginalUiProof']['steps']),
    'snapshot': {'status': snapshot['status'], 'files': len(files), 'directories': len(snapshot['directories']),
                 'totalReadBytes': snapshot['totalReadBytes'], 'payloadBytes': snapshot['payloadBytes'],
                 'rawTextHashesVerified': text_verified,
                 'projectedPayloadLimit': 'Secret-bearing JSON/JSONL are redacted projections; raw file SHA is captured metadata, not reconstructed bytes.',
                 'members': [m['name'] for m in config['members']],
                 'memberMetadataCount': len(json.loads(files['members.meta.json']['payload']['text'])['members']),
                 'replicaState': replica['state'],
                 'statusRows': [{'memberName': row.get('memberName'), 'state': row.get('state'),
                                 'evaluatedAt': row.get('evaluatedAt')} for row in replica['snapshot']['statuses']],
                 'pendingCollections': {key: len(replica['snapshot'][key]) for key in
                                        ('reportIntents', 'outboxItems', 'filesToArchive')},
                 'aliceJournal': [{key: row[key] for key in ('event', 'reason', 'timestamp') if key in row} for row in alice],
                 'absentLaunchFiles': [name for name in ('launch-state.json', 'launch-summary.json', 'launch-stopped.json')
                                      if files[name]['status'] == 'absent']},
    'interpretation': [
        'Original complete() reached proof-census after verified original process release; census refused before publication.',
        'The qualified solo WorkSync directory walk rejects members/alice/.member-work-sync before reading replica bytes.',
        'Exact hydration prompt contains an inline Alice teaching example; finite helper and actual Main stream regressions independently reproduce the false heartbeat.',
        'Strict census, owner facts, history and original single Stop are preserved; no source release success is claimed.'
    ],
    'originalSourcePins': source_pins([
        'src/main/services/team/provisioning/LegacyNativeStopRelease.ts',
        'src/main/services/team/provisioning/LegacyNativeStopPublication.ts',
        'src/main/services/team/provisioning/LegacyNativeStopWorkSyncCensus.ts',
        'src/main/services/team/provisioning/TeamProvisioningNativeTeammateMessages.ts',
        'src/shared/utils/userTurnProvenance.ts',
        'tools/owned-process-broker/fixtures/retainedLegacyHydrationPrompt.txt',
        'tools/owned-process-broker/fixtures/retainedLegacyBootstrapPeer.mjs']),
    'cleanup': {'originalPeerAbsent': receipt['retainedOriginalUiProof']['peerAbsentAfterCleanup'],
                'appExitCode': receipt['cleanup']['appExitCode'], 'remaining': receipt['cleanup']['remaining'],
                'hostExitCode': receipt['cleanup']['hostExitCode']},
    'limits': ['Snapshot is bounded and sequential, not atomic.',
               'Later shutdown callbacks are not another UI Stop or successful release.',
               'Actual original E2E must pass on the eventual fixed source.']
}
assert report['originalStopClicks'] == 1
dump(root / 'first-refusal-report.json', report)
print(json.dumps({'report': str(root / 'first-refusal-report.json'), 'sha256': sha(root / 'first-refusal-report.json'),
                  'firstRefusal': refusals[0], 'rawTextHashesVerified': len(text_verified)}))

root = WORK / 'management-original-a0'
fixture = root / 'extracted/TEST-desktop-backend-VRv1lX'
receipt = read(fixture / 'desktop-backend-receipt.json')
settings = read(root / 'extracted/TEST-desktop-backend-ynqidi/desktop-backend-receipt.json')
log = rows(fixture / 'userData/logs/app-errors.ndjson')
phases = [{'time': row['t'], **data(row)} for row in log if row['namespace'] == 'Host:OpenCodeProbe']
close = [{'time': row['t'], **data(row)} for row in log if row['namespace'] == 'Host:OpenCodeProbeClose']
envelope_path = fixture / ('hoststore/management-commands/' + phases[0]['commandHash'] + '.json')
envelope = read(envelope_path)
envelope_body = {k: v for k, v in envelope.items() if k != 'digest'}
assert hashlib.sha256(json.dumps(envelope_body, separators=(',', ':'), ensure_ascii=False, sort_keys=True).encode()).hexdigest() == envelope['digest']
cutoff = envelope['expiresAt']
models = read(fixture / 'mixed-models.json')
commands = read(fixture / 'hoststore/teams/test-created-native-mixed/.host-owner/state.json')['rosterCommands']
live = [row for row in commands if 'liveMembership' in row]
assert len(live) == 1 and live[0]['liveMembership']['cutoff'] == cutoff
report = {
    'kind': 'original-a0-Linux-V2-management-and-live-add', 'head': HEAD,
    'artifact': read(root / 'safe-extraction.json'), 'runId': 44842174363, 'jobId': 136653011933,
    'sourceInventory': {'file': 'original-source-pins.json', 'sha256': sha(root / 'original-source-pins.json'),
                        'settingsBeforeAfter': 1947, 'liveAddBeforeAfter': 1935, 'matchesGitHead': True},
    'settings': {'status': settings['status'], 'modelRequests': len(settings['finiteModel']['requests']),
                 'modelFailures': settings['finiteModel']['failures'],
                 'finiteModelCompleteAfterCleanup': settings['finiteModelCompleteAfterCleanup'],
                 'cleanup': settings['cleanup']},
    'liveAdd': {'status': receipt['status'], 'failure': receipt['failure'],
                'singleOriginalAddClick': sum(row.get('action') == 'mouseClick' and row.get('label') == 'one original live Add'
                                              for row in receipt['liveMembershipProof']['steps']),
                'singleOriginalRosterCommand': live[0]['commandId'],
                'liveMembershipPhase': live[0]['liveMembership']['phase'],
                'productionCutoff': cutoff, 'productionCutoffIso': datetime.fromtimestamp(cutoff / 1000, timezone.utc).isoformat(),
                'envelopeHashVerified': True,
                'probe': {key: envelope[key] for key in ('phase', 'ok', 'resourceHeld', 'readinessRetired', 'kind', 'purpose', 'expiresAt')},
                'phases': phases, 'closeDiagnostics': close,
                'remainingAtProbeRunMs': cutoff - millis(phases[0]['time']),
                'remainingAtLastPhaseMs': cutoff - millis(phases[-1]['time']),
                'credentialToAttestationMs': next(x['elapsedMs'] for x in phases if x['phase'] == 'attestation') -
                                           next(x['elapsedMs'] for x in phases if x['phase'] == 'credential'),
                'closeDiagnosticAfterCutoffMs': millis(close[0]['time']) - cutoff,
                'modelCounts': {provider: {key: len(value) if isinstance(value, list) else value
                                          for key, value in model.items()}
                                for provider, model in models['providers'].items()},
                'finiteInitialPeersAbsent': receipt['finiteInitialPeersAfterCleanup']['absent'],
                'cleanup': receipt['cleanup']},
    'interpretation': [
        'OpenCode Settings subflow passed; the later original live Add remained held.',
        'The original model probe reached attestation with 6987 ms left, without attestation-returned or model request.',
        'The first retained close-result unconfirmed record follows the original producer cutoff by 14 ms; this is timing evidence, not proof of one inner failed predicate.',
        'The TEST original Add observation runs for 90 seconds and failed later; extending that observation or production deadline is not a justified fix.',
        'The new bounded catalog admission marks will distinguish currentness, native custody and HTTP admission at their original boundaries.'
    ],
    'originalSourcePins': source_pins([
        'scripts/legacy-agent-host/desktop-live-membership-ui-smoke.ts',
        'packages/legacy-agent-host/src/composition/executeLiveRosterMembership.ts',
        'packages/legacy-agent-host/src/management/ModelProbeOwner.ts',
        'packages/legacy-agent-host/src/management/identity.ts',
        'packages/legacy-agent-host/src/adapters/providers/OpenCodeV2ModelProbe.ts']),
    'limits': ['No live Add, restore or later membership action passed.',
               'No genuine Claude/Codex execution; initial peers are finite TEST processes.',
               'Settings success does not qualify the combined job or a production release.']
}
assert report['liveAdd']['singleOriginalAddClick'] == 1
dump(root / 'original-report.json', report)
print(json.dumps({'report': str(root / 'original-report.json'), 'sha256': sha(root / 'original-report.json'),
                  'settings': settings['status'], 'liveAdd': receipt['status'],
                  'remainingAtLastPhaseMs': report['liveAdd']['remainingAtLastPhaseMs']}))
