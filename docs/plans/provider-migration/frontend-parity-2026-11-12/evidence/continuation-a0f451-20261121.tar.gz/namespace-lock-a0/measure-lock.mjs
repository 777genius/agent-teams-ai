import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire, syncBuiltinESMExports } from 'node:module';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
const repo='/workspace/scratch/38cae95a211b/agent-teams-ai';
const out='/workspace/scratch/0475591abfcd/namespace-lock-a0';
const require=createRequire(repo+'/package.json');
const lockPath=require.resolve('agent-teams-controller/src/internal/fileLock.js');
const original=fs.readFileSync(lockPath,'utf8');
const before=`function statOrMissing(name) {
  try {
    return fs.lstatSync(name);
  } catch (error) {
    if (codeOf(error) === 'ENOENT') return null;
    throw error;
  }
}`;
assert.equal(original.split(before).length,2);
const candidate=original.replace(before,`function statOrMissing(name) {
  return fs.lstatSync(name, { throwIfNoEntry: false }) ?? null;
}`);
let row;
const trailer=`
const __tryAcquire = tryAcquire;
tryAcquire = function (...args) { const result = __tryAcquire(...args); globalThis.__lockObserve('tryAcquire', result); return result; };
const __sleepSync = sleepSync;
sleepSync = function (ms) { globalThis.__lockObserve('sleep', ms); return __sleepSync(ms); };
`;
globalThis.__lockObserve=(name,value)=>{if(row){row[name]=(row[name]??0)+1;if(name==='tryAcquire'&&value===false)row.contention=(row.contention??0)+1;}};
function load(source){const module={exports:{}};new Function('require','module','exports',source+trailer)(require,module,module.exports);return module.exports;}
const variants={baseline:load(original),noThrow:load(candidate)};
let variant='baseline';
require.cache[lockPath]={id:lockPath,filename:lockPath,loaded:true,exports:{
 withFileLockSync:(...args)=>variants[variant].withFileLockSync(...args),
 withFileLock:(...args)=>variants[variant].withFileLock(...args),
 acquireFileLockSync:(...args)=>variants[variant].acquireFileLockSync(...args),
}};
const saved=new Map();
for(const name of ['lstatSync','readdirSync','openSync','closeSync','readFileSync','writeSync','mkdirSync','renameSync','linkSync','unlinkSync','rmdirSync']){
 const native=fs[name];saved.set(name,native);
 fs[name]=function(...args){if(row){row.fs[name]=(row.fs[name]??0)+1;}try{return native.apply(fs,args);}catch(e){if(row){row.errors[e.code]=(row.errors[e.code]??0)+1;}throw e;}};
}
syncBuiltinESMExports();
const {TeamOwnerStore}=await import(repo+'/packages/legacy-agent-host/dist/adapters/team/TeamOwnerStore.js');
const scratch=fs.mkdtempSync(out+'/TEST-lock-');
const root=path.join(scratch,'Users','runner','work','agent-teams-ai','agent-teams-ai','TEST-desktop-backend','hoststore');
fs.mkdirSync(root,{recursive:true});
const store=new TeamOwnerStore(root,'TEST-team');
fs.writeFileSync(path.join(store.directory,'state.json'),'{}');
for(const category of ['teams','tasks']) for(let n=0;n<6;n++){
 const sub=path.join(root,category,'TEST-team','TEST-records-'+n);fs.mkdirSync(sub,{recursive:true});
 for(let i=0;i<24;i++)fs.writeFileSync(path.join(sub,'TEST-'+i+'.json'),'{}');
}
const rows=[];
try{
 for(const mode of ['lock','fenced']){
  const action=mode==='lock'?()=>variants[variant].withFileLockSync(path.join(store.directory,'authority'),()=>{}, {createParent:false})
    :()=>store.fenced(()=>{assert.deepEqual(store.read('state.json'),{});});
  for(const v of ['baseline','noThrow','noThrow','baseline','baseline','noThrow','noThrow','baseline']){
   variant=v;for(let i=0;i<10;i++)action();
   const observation={mode,variant:v,samples:100,fs:{},errors:{}};row=observation;
   const start=performance.now(),cpu=process.cpuUsage();for(let i=0;i<100;i++)action();
   row=undefined;const used=process.cpuUsage(cpu);observation.wallMs=performance.now()-start;observation.cpuMs=(used.user+used.system)/1000;rows.push(observation);
  }
 }
 const summaries=[];
 for(const mode of ['lock','fenced'])for(const v of ['baseline','noThrow']){
  const xs=rows.filter(x=>x.mode===mode&&x.variant===v);const sorted=xs.map(x=>x.wallMs).sort((a,b)=>a-b);
  summaries.push({mode,variant:v,batches:xs.length,samples:xs.reduce((a,b)=>a+b.samples,0),medianBatchMs:(sorted[1]+sorted[2])/2,
    meanCpuMs:xs.reduce((a,b)=>a+b.cpuMs,0)/xs.length,fs:xs[0].fs,errors:xs[0].errors,tryAcquire:xs[0].tryAcquire,sleeps:xs[0].sleep??0,contention:xs[0].contention??0});
 }
 const result={kind:'FINITE_ACTUAL_CONTROLLER_EXPECTED_MISSING_STAT_COST',node:process.version,platform:process.platform,source:{path:lockPath,sha256:createHash('sha256').update(original).digest('hex')},candidateSha256:createHash('sha256').update(candidate).digest('hex'),summaries,rows,
  limitations:['Finite synthetic TEST filesystem, real source implementation, no original native run replay.','No promise that Linux timing equals original Darwin.','Candidate changes only lstat expected ENOENT handling; every lstat call remains fresh.','All lock protocol primitives, retry logic and deadlines remain byte-identical; lexical wrappers record only completed attempts/sleeps.']};
 fs.writeFileSync(out+'/measurement.json',JSON.stringify(result,null,2)+'\n');fs.writeFileSync(out+'/candidate-fileLock.js',candidate);
 console.log(JSON.stringify(summaries,null,2));
}finally{row=undefined;for(const[name,fn]of saved)fs[name]=fn;syncBuiltinESMExports();fs.rmSync(scratch,{recursive:true,force:true});delete globalThis.__lockObserve;}
