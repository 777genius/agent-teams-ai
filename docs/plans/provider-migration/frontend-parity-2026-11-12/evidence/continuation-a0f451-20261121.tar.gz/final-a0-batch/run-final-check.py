from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

repo = Path('/workspace/scratch/38cae95a211b/agent-teams-ai')
out = Path('/workspace/scratch/0475591abfcd/final-a0-batch')
node = '/workspace/scratch/38cae95a211b/toolchain/node-v24.21.0-linux-x64/bin/node'
corepack = '/workspace/scratch/38cae95a211b/toolchain/node-v24.21.0-linux-x64/lib/node_modules/corepack/dist/corepack.js'
env = {**os.environ, 'COREPACK_ENABLE_NETWORK': '0', 'PATH': str(Path(node).parent) + ':' + os.environ['PATH']}
changed = sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines() + subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()))
code = [f for f in changed if Path(f).suffix in {'.ts','.tsx','.js','.mjs','.cjs'}]
pins = {f: hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in code}
kind = sys.argv[1]
checks = {
 'main-ts7': [node, 'node_modules/@typescript/native/bin/tsc', '--noEmit', '-p', str(out/'tsconfig.json')],
 'main-integration': [node, corepack, 'pnpm', 'exec', 'vitest', 'run', '--maxWorkers=1', '--reporter=json', '--outputFile='+str(out/'main-integration-vitest.json'),
   'test/main/services/team/TeamProvisioningOpenCodeStoppedBusyWatchdog.test.ts',
   'test/main/services/team/TeamProvisioningServiceRelay.test.ts',
   'src/main/services/team/provisioning/__tests__/TeamProvisioningOpenCodeRuntimeRecoveryFlow.test.ts',
   'src/main/services/team/provisioning/__tests__/TeamProvisioningOpenCodePromptDeliveryWatchdogSchedulerFactory.test.ts',
   'src/main/services/team/opencode/delivery/__tests__/OpenCodePromptDeliveryWatchdogScheduler.test.ts',
   'src/main/services/team/opencode/delivery/__tests__/OpenCodePromptDeliveryWatchdogScheduler.cancellation.test.ts'],
 'fast-lint': [node, 'node_modules/eslint/bin/eslint.js', '--config', 'eslint.fast.config.js'] + [f for f in code if f != 'agent-teams-controller/src/internal/fileLock.js'],
 'source-size': [node, 'scripts/ci/check-source-file-size.mjs'],
 'architecture': [node, 'scripts/ci/check-team-provisioning-architecture.mjs'],
 'diff-check': ['git', 'diff', '--check'],
}
argv = checks[kind]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
with (out/(kind+'.log')).open('w') as log:
 result = subprocess.run(argv,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
report = {'kind':kind, 'startedAt':started,'argv':argv,'exitCode':result.returncode,'seconds':time.monotonic()-t0,'sourcePins':pins,'sourcesUnchangedDuringCheck':all((repo/f).exists() and hashlib.sha256((repo/f).read_bytes()).hexdigest()==h for f,h in pins.items())}
(out/(kind+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['argv','sourcePins']}))
if result.returncode:
 print((out/(kind+'.log')).read_text()[-3500:])
sys.exit(result.returncode)
