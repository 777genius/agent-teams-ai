import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';

const repo = '/workspace/scratch/38cae95a211b/agent-teams-ai';
const directory = '/workspace/scratch/0475591abfcd/darwin-a0-native-v2';
const relative = 'agent-teams-controller/src/internal/fileLock.js';
const require = createRequire(join(repo, 'package.json'));
const baseline = execFileSync('git', ['show', 'HEAD:' + relative], { cwd: repo, encoding: 'utf8' });
const candidate = fs.readFileSync(join(repo, relative), 'utf8');
assert.equal(candidate, baseline.replace('return fs.lstatSync(name);',
  'return fs.lstatSync(name, { throwIfNoEntry: false }) ?? null;'));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
function load(source, filesystem = fs) {
  const module = { exports: {} };
  new Function('require', 'module', 'exports', source + '\nmodule.exports.statOrMissing = statOrMissing;')(
    name => name === 'fs' ? filesystem : require(name), module, module.exports);
  return module.exports;
}
const modules = { baseline: load(baseline), candidate: load(candidate) };
const root = fs.mkdtempSync(join(directory, 'TEST-lock-review-'));
const results = [];
const shape = result => result === null ? null : {
  file: result.isFile(), directory: result.isDirectory(), link: result.isSymbolicLink(),
  dev: result.dev, ino: result.ino, mode: result.mode, size: result.size,
  nlink: result.nlink, uid: result.uid, gid: result.gid,
};
function observe(callback) {
  try { return { result: shape(callback()) }; }
  catch (error) { return { error: { name: error.name, code: error.code, syscall: error.syscall } }; }
}
function differential(name, path, expected) {
  const before = observe(() => modules.baseline.statOrMissing(path));
  const after = observe(() => modules.candidate.statOrMissing(path));
  assert.deepEqual(after, before, name);
  expected(after);
  results.push({ case: name, baseline: before, candidate: after, pass: true });
}
try {
  const file = join(root, 'file'), dir = join(root, 'dir'), link = join(root, 'link'),
    dangling = join(root, 'dangling'), loop = join(root, 'loop'), denied = join(root, 'denied');
  fs.writeFileSync(file, 'TEST bytes');
  fs.mkdirSync(dir);
  fs.symlinkSync(file, link);
  fs.symlinkSync(join(root, 'absent'), dangling);
  fs.symlinkSync(loop, loop);
  fs.mkdirSync(denied);
  fs.writeFileSync(join(denied, 'child'), 'TEST private child');
  for (const [name, path] of [['missing-leaf', join(root, 'missing')],
    ['missing-ancestor', join(root, 'missing', 'child')]]) {
    differential(name, path, result => assert.equal(result.result, null));
  }
  for (const [name, path] of [['regular-file', file], ['buffer-path', Buffer.from(file)],
    ['file-url', pathToFileURL(file)]]) {
    differential(name, path, result => assert.equal(result.result.file, true));
  }
  differential('directory', dir, result => assert.equal(result.result.directory, true));
  for (const [name, path] of [['symlink-no-follow', link], ['dangling-symlink', dangling],
    ['self-loop-leaf-no-follow', loop]]) {
    differential(name, path, result => assert.equal(result.result.link, true));
  }
  differential('native-enotdir', join(file, 'child'), result => assert.equal(result.error.code, 'ENOTDIR'));
  differential('native-eloop', join(loop, 'child'), result => assert.equal(result.error.code, 'ELOOP'));
  fs.chmodSync(denied, 0);
  try {
    assert.notEqual(process.getuid(), 0, 'real EACCES must run as non-root');
    differential('native-eacces', join(denied, 'child'), result => assert.equal(result.error.code, 'EACCES'));
  } finally { fs.chmodSync(denied, 0o700); }
  differential('nul-refusal', 'TEST\0bad', result => assert.equal(result.error.code, 'ERR_INVALID_ARG_VALUE'));
  differential('type-refusal', undefined, result => assert.equal(result.error.code, 'ERR_INVALID_ARG_TYPE'));
  for (const code of ['EACCES', 'EPERM', 'EIO', 'ENOTDIR', 'ELOOP']) {
    const original = Object.assign(new Error('TEST exact filesystem refusal'), { code });
    for (const [name, source] of Object.entries({ baseline, candidate })) {
      const module = load(source, { ...fs, lstatSync: () => { throw original; } });
      let observed;
      try { module.statOrMissing(file); } catch (error) { observed = error; }
      assert.equal(observed, original, name + ' exact error identity ' + code);
    }
    results.push({ case: 'exact-error-identity-' + code, baseline: 'same object', candidate: 'same object', pass: true });
  }
  for (const [name, source] of Object.entries({ baseline, candidate })) {
    const module = load(source, { ...fs, lstatSync: () => {
      throw Object.assign(new Error('TEST expected missing'), { code: 'ENOENT' });
    } });
    assert.equal(module.statOrMissing(file), null, name + ' existing ENOENT fallback');
  }
  results.push({ case: 'enoent-fallback-null', baseline: null, candidate: null, pass: true });
  for (const [name, module] of Object.entries(modules)) {
    const resource = join(root, 'TEST-authority-' + name);
    const expected = { test: 'original callback result' };
    assert.equal(module.withFileLockSync(resource, () => {
      assert.equal(fs.lstatSync(resource + '.lock').isFile(), true);
      return expected;
    }, { createParent: false }), expected);
    assert.equal(fs.existsSync(resource + '.lock'), false);
    const original = new Error('TEST callback refusal');
    let observed;
    try { module.withFileLockSync(resource, () => { throw original; }, { createParent: false }); }
    catch (error) { observed = error; }
    assert.equal(observed, original);
    assert.equal(fs.existsSync(resource + '.lock'), false);
    const release = module.acquireFileLockSync(resource, { createParent: false });
    release(); release();
    assert.equal(fs.existsSync(resource + '.lock'), false);
  }
  results.push({ case: 'ordinary-protocol-callback-release', baseline: 'pass', candidate: 'pass', pass: true });
  const report = {
    kind: 'INDEPENDENT_CONTROLLER_MISSING_STAT_COMPATIBILITY_REVIEW',
    node: process.version, platform: process.platform, uid: process.getuid(),
    baselineSha256: digest(baseline), candidateSha256: digest(candidate),
    changedProductionLines: 1, unrelatedProductionBytesIdentical: true,
    behavioralRedClaimed: false, originalNativeE2EQualified: false,
    results, summary: { cases: results.length, passed: results.length, failed: 0 },
  };
  fs.writeFileSync(join(directory, 'r2-lock-review.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ ...report, results: undefined }));
} finally { fs.rmSync(root, { recursive: true, force: true }); }
