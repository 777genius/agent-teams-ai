import assert from 'node:assert/strict';
import { channel } from 'node:diagnostics_channel';
import fs from 'node:fs';
const base = '/workspace/scratch/38cae95a211b/agent-teams-ai/packages/legacy-agent-host/node_modules/@agent-teams/provider-implementations/dist/features/provider-session-implementation/adapters/opencode-protocol/';
const { createOpenCodeV2ExecutionTransport } = await import(base + 'v2-execution-transport.js');
const { readOpenCodeV2NativeCut } = await import(base + 'v2-native-cut.js');
const endpoint = 'http://127.0.0.1:43123', directory = '/TEST-read-cut', sessionID = 'ses_TEST';
const cancellation = new AbortController();
const observed = [], requests = [];
let logs = 0, cleanDisposal = false;
const diagnostic = channel('agent-teams:opencode-v2:read-cut-failed');
const listener = value => observed.push(value);
diagnostic.subscribe(listener);
const session = JSON.stringify({ data: { id: sessionID, location: { directory },
  time: { created: 1 }, agent: 'TEST', model: { providerID: 'TEST', id: 'TEST' } } });
const log = 'data: ' + JSON.stringify({ type: 'log.synced', aggregateID: sessionID, seq: 0 }) + '\n\n';
const transport = createOpenCodeV2ExecutionTransport({ endpoint, directory, nativeSessionId: sessionID,
  version: '2.1.4', deadline: Date.now() + 120_000, signal: cancellation.signal,
  readPassword: () => 'TEST-NOT-A-REAL-CREDENTIAL',
  fetchImpl: async (input, init) => {
    const path = new URL(input instanceof Request ? input.url : String(input)).pathname;
    requests.push(path);
    assert.equal(init.method ?? (input instanceof Request ? input.method : 'GET'), 'GET');
    if (path.endsWith('/log')) {
      if (++logs === 2) return new Response(new ReadableStream({ start(controller) {
        setImmediate(() => { controller.enqueue(new TextEncoder().encode(log)); cancellation.abort(); controller.close(); });
      } }), { headers: { 'content-type': 'text/event-stream' } });
      return new Response(log, { headers: { 'content-type': 'text/event-stream' } });
    }
    return new Response(path.endsWith('/message') ? JSON.stringify({ data: [], cursor: { previous: null, next: null } }) : session,
      { headers: { 'content-type': 'application/json' } });
  },
});
try {
  await assert.rejects(readOpenCodeV2NativeCut(transport, { endpoint, directory, sessionID, pin: '2.1.4' },
    { nativeInputID: 'msg_TEST', beforeCursor: null, text: 'TEST read-only capture' }),
  { message: 'invalid_native_read_response' });
  assert.equal(observed.length, 1);
  assert.equal(observed[0].stage, 'after-log');
  assert.equal(observed[0].reason, 'deadline');
  assert.equal(observed[0].deadlineExpired, false);
  assert.equal(observed[0].aborted, false);
  assert.equal(observed[0].finalReason, 'invalid_native_read_response');
  assert.equal(cancellation.signal.aborted, true);
  await transport.dispose(); cleanDisposal = true;
  const report = { kind: 'FINITE_ORIGINAL_TRANSPORT_LIFECYCLE_CANCELLATION_CHARACTERIZATION',
    result: 'PASS', node: process.version, nativeExecutions: 0, actualNetworkRequests: 0,
    originalProductionBytesUsed: true, deadlinesExtended: false, lifecycleCancelled: true,
    cleanDisposal, requests, observed,
    conclusion: 'The exact native failure signature can occur under lifecycle cancellation while the cut deadline and its own signal remain current. It does not establish premature cut timeout.',
    limitations: ['Injected in-memory fetch only; does not prove actual Darwin cleanup ordering.',
      'Original passive trace and scenario timestamps have independent epochs and cannot be subtracted directly.'] };
  fs.writeFileSync('/workspace/scratch/0475591abfcd/darwin-a0-native-v2/cut-cancellation-review.json', JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report));
} finally { diagnostic.unsubscribe(listener); if (!cleanDisposal) await transport.dispose(); }
