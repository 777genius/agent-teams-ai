// @vitest-environment node
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { OpenCodePromptDeliveryWatchdogScheduler } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/opencode/delivery/OpenCodePromptDeliveryWatchdogScheduler';
import { INBOX_RELAY_IN_FLIGHT_TIMEOUT_MS } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningInboxRelayCandidates';
import { relayOpenCodeMemberInboxMessagesWithPorts, type RelayOpenCodeMemberInboxMessagesPorts } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningOpenCodeMemberInboxRelay';

const cleanups: (() => void)[] = [];
beforeEach(() => vi.useFakeTimers());
afterEach(async () => {
  for (const cleanup of cleanups.splice(0)) cleanup();
  await vi.advanceTimersByTimeAsync(0);
  vi.clearAllTimers();
  vi.useRealTimers();
});

it.each([false, true])('actual relay continuation after caller timeout remains cancellable: cancel=%s', async (cancelled) => {
  const recipient = Promise.withResolvers<boolean>();
  cleanups.push(() => recipient.resolve(true));
  const ports: RelayOpenCodeMemberInboxMessagesPorts = {
    inFlight: new Map(),
    readInboxMessages: vi.fn().mockResolvedValue([]),
    scheduleOpenCodeMemberInboxDeliveryWake: vi.fn(),
    isOpenCodeRuntimeRecipient: vi.fn(() => recipient.promise),
    resolveOpenCodeMemberDeliveryIdentity: vi.fn().mockResolvedValue({ ok: false, reason: 'TEST-finite-boundary' }),
    createOpenCodePromptDeliveryLedger: vi.fn(() => { throw new Error('not reached'); }),
    requeueOpenCodeRuntimeManifestWatermarkDeliveryIfNeeded: vi.fn(),
    requeueOpenCodeNoAssistantTerminalDeliveryIfNeeded: vi.fn(),
    applyDestinationProof: vi.fn(),
    isOpenCodeDeliveryResponseReadCommitAllowed: vi.fn(),
    markInboxMessagesRead: vi.fn(),
    logOpenCodePromptDeliveryEvent: vi.fn(),
    readTaskRefInferenceTasks: vi.fn(),
    resolveOpenCodeInboxAttachmentPayloads: vi.fn(),
    resolveCurrentOpenCodeRuntimeRunId: vi.fn(),
    markOpenCodePromptLedgerFailedTerminal: vi.fn(),
    deliverOpenCodeMemberMessage: vi.fn(),
    suppressRuntimeInactiveWarning: () => false,
    logWarning: vi.fn(),
    logDiagnostic: vi.fn(),
    nowIso: () => '2026-01-01T00:00:00.000Z',
    getErrorMessage: String,
  };
  let forwarded: (() => boolean) | undefined;
  const scheduler = new OpenCodePromptDeliveryWatchdogScheduler({
    canDeliverToTeamRuntime: () => true,
    recoverBeforeDelivery: async () => false,
    relay: ({ teamName, memberName, messageId, isCurrent }) => {
      forwarded = isCurrent;
      return relayOpenCodeMemberInboxMessagesWithPorts({
        teamName, memberName, relayKey: 'TEST-relay-key',
        options: { onlyMessageId: messageId, source: 'watchdog', isCurrent },
      }, ports);
    },
    getInboxMessages: async () => [],
    resolveIdentity: async () => null,
    isLaneActive: async () => false,
    isRecordNotFoundError: () => false,
    info: () => {}, warn: () => {}, debug: () => {}, diagnostic: () => {}, getErrorMessage: String,
  });
  cleanups.push(() => scheduler.cancelTeam('TEST-team'));
  scheduler.schedule({ teamName: 'TEST-team', memberName: 'TEST-member', messageId: 'TEST-message', delayMs: 500 });
  await vi.advanceTimersByTimeAsync(500);
  expect(scheduler.readStoppedTeamImportFacts('TEST-team')).toEqual({ timers: 0, queued: 0, inFlight: 1 });
  expect(ports.inFlight.size).toBe(1);
  expect(forwarded?.()).toBe(true);
  await vi.advanceTimersByTimeAsync(INBOX_RELAY_IN_FLIGHT_TIMEOUT_MS);
  expect(scheduler.readStoppedTeamImportFacts('TEST-team')).toEqual({ timers: 0, queued: 0, inFlight: 0 });
  // The actual relay owns live work for its separate 240s lease after the 120s caller returns.
  expect(ports.inFlight.size).toBe(1);
  expect(ports.logWarning).toHaveBeenCalledWith(expect.stringContaining('timed out after 120000ms'));
  if (cancelled) scheduler.cancelTeam('TEST-team');
  const currentAtCancelBoundary = forwarded?.();
  recipient.resolve(true);
  await vi.advanceTimersByTimeAsync(0);
  expect(ports.inFlight.size).toBe(0);
  expect(ports.deliverOpenCodeMemberMessage).not.toHaveBeenCalled();
  expect({
    currentAtCancelBoundary,
    identityCalls: vi.mocked(ports.resolveOpenCodeMemberDeliveryIdentity).mock.calls.length,
  }).toEqual({ currentAtCancelBoundary: !cancelled, identityCalls: cancelled ? 0 : 1 });
});
