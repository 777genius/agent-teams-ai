// @vitest-environment node
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { OpenCodePromptDeliveryWatchdogScheduler } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/opencode/delivery/OpenCodePromptDeliveryWatchdogScheduler';
import { INBOX_RELAY_IN_FLIGHT_TIMEOUT_MS } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningInboxRelayCandidates';
import { relayOpenCodeMemberInboxMessagesWithPorts, type RelayOpenCodeMemberInboxMessagesPorts } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningOpenCodeMemberInboxRelay';
const NOW_ISO = '2026-01-01T00:00:00.000Z';
const cleanups: (() => void)[] = [];
beforeEach(() => vi.useFakeTimers());
afterEach(async () => {
  for (const cleanup of cleanups.splice(0)) cleanup();
  await vi.advanceTimersByTimeAsync(0);
  vi.clearAllTimers();
  vi.useRealTimers();
});
function createRelayPorts(
  overrides: Partial<RelayOpenCodeMemberInboxMessagesPorts> = {}
): RelayOpenCodeMemberInboxMessagesPorts {
  return {
    inFlight: new Map(),
    readInboxMessages: vi.fn().mockResolvedValue([]),
    scheduleOpenCodeMemberInboxDeliveryWake: vi.fn(),
    isOpenCodeRuntimeRecipient: vi.fn().mockResolvedValue(true),
    resolveOpenCodeMemberDeliveryIdentity: vi.fn().mockResolvedValue({
      ok: true,
      canonicalMemberName: 'worker',
      laneId: 'lane-worker',
      laneIdentity: { laneId: 'lane-worker', laneKind: 'secondary' },
    }),
    createOpenCodePromptDeliveryLedger: vi.fn(() => ({
      getByInboxMessage: vi.fn().mockResolvedValue(null),
    })) as unknown as RelayOpenCodeMemberInboxMessagesPorts['createOpenCodePromptDeliveryLedger'],
    requeueOpenCodeRuntimeManifestWatermarkDeliveryIfNeeded: vi
      .fn()
      .mockImplementation(({ ledgerRecord: record }) => Promise.resolve(record)),
    requeueOpenCodeNoAssistantTerminalDeliveryIfNeeded: vi
      .fn()
      .mockImplementation(({ ledgerRecord: record }) => Promise.resolve(record)),
    applyDestinationProof: vi.fn().mockRejectedValue(new Error('unused')),
    isOpenCodeDeliveryResponseReadCommitAllowed: vi.fn().mockResolvedValue(false),
    markInboxMessagesRead: vi.fn().mockResolvedValue(undefined),
    logOpenCodePromptDeliveryEvent: vi.fn(),
    readTaskRefInferenceTasks: vi.fn().mockResolvedValue([]),
    resolveOpenCodeInboxAttachmentPayloads: vi.fn().mockResolvedValue({
      ok: true,
      attachments: [],
    }),
    resolveCurrentOpenCodeRuntimeRunId: vi.fn().mockResolvedValue('run-1'),
    markOpenCodePromptLedgerFailedTerminal: vi.fn(),
    deliverOpenCodeMemberMessage: vi.fn().mockResolvedValue({ delivered: true }),
    suppressRuntimeInactiveWarning: vi.fn().mockReturnValue(false),
    logWarning: vi.fn(),
    logDiagnostic: vi.fn(),
    nowIso: () => NOW_ISO,
    getErrorMessage: (error) => (error instanceof Error ? error.message : String(error)),
    ...overrides,
  };
}


it.each([false, true].flatMap((callerTimedOut) => [false, true].map((cancelled) => ({ callerTimedOut, cancelled }))))(
  'actual follow-up admission with production cleanup order: timeout=$callerTimedOut cancel=$cancelled',
  async ({ callerTimedOut, cancelled }) => {
    const identity = { ok: true as const, canonicalMemberName: 'worker', laneId: 'lane-worker', laneIdentity: { laneId: 'lane-worker', laneKind: 'secondary' as const } };
    const tailIdentity = Promise.withResolvers<typeof identity>();
    cleanups.push(() => tailIdentity.resolve(identity));
    const rows = ['row-a','row-b'].map((messageId) => ({ from: 'user', to: 'worker', text: messageId, timestamp: NOW_ISO, read: false, messageId }));
    const ports = createRelayPorts({
      readInboxMessages: vi.fn().mockResolvedValue(rows),
      resolveOpenCodeMemberDeliveryIdentity: vi.fn().mockResolvedValueOnce(identity).mockImplementation(() => tailIdentity.promise),
      deliverOpenCodeMemberMessage: vi.fn().mockResolvedValue({ delivered: true, responsePending: true }),
    });
    const scheduler = new OpenCodePromptDeliveryWatchdogScheduler({
      canDeliverToTeamRuntime: () => true,
      recoverBeforeDelivery: async () => false,
      relay: ({ teamName, memberName, messageId, isCurrent }) => relayOpenCodeMemberInboxMessagesWithPorts({
        teamName, memberName, relayKey: 'opencode:TEST-team:worker', options: { onlyMessageId: messageId, source: 'watchdog', isCurrent },
      }, ports),
      getInboxMessages: async () => [], resolveIdentity: async () => null, isLaneActive: async () => false,
      isRecordNotFoundError: () => false, info: () => {}, warn: () => {}, debug: () => {}, diagnostic: () => {}, getErrorMessage: String,
    });
    ports.scheduleOpenCodeMemberInboxDeliveryWake = vi.fn((input) => scheduler.schedule(input));
    cleanups.push(() => scheduler.cancelTeam('TEST-team'));
    scheduler.schedule({ teamName: 'TEST-team', memberName: 'worker', messageId: 'row-a', delayMs: 500 });
    await vi.advanceTimersByTimeAsync(500);
    expect(ports.deliverOpenCodeMemberMessage).toHaveBeenCalledTimes(1);
    expect(ports.resolveOpenCodeMemberDeliveryIdentity).toHaveBeenCalledTimes(2);
    expect(scheduler.readStoppedTeamImportFacts('TEST-team')).toEqual({ timers: 0, queued: 0, inFlight: 1 });
    if (callerTimedOut) await vi.advanceTimersByTimeAsync(INBOX_RELAY_IN_FLIGHT_TIMEOUT_MS);
    expect(ports.inFlight.size).toBe(1);
    if (cancelled) {
      // Same synchronous ordering as Cleanup and TransientRunState in production.
      ports.inFlight.delete('opencode:TEST-team:worker');
      scheduler.cancelTeam('TEST-team');
    }
    tailIdentity.resolve(identity);
    await vi.advanceTimersByTimeAsync(0);
    expect(ports.inFlight.size).toBe(0);
    expect(ports.markInboxMessagesRead).not.toHaveBeenCalled();
    expect(scheduler.readStoppedTeamImportFacts('TEST-team')).toEqual({ timers: cancelled ? 0 : 1, queued: 0, inFlight: 0 });
    expect(ports.scheduleOpenCodeMemberInboxDeliveryWake).toHaveBeenCalledTimes(cancelled ? 0 : 1);
    if (!cancelled) expect(vi.mocked(ports.scheduleOpenCodeMemberInboxDeliveryWake).mock.calls[0][0].isCurrent).toBeUndefined();
  }
);
