// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import {
  OpenCodePromptDeliveryWatchdogScheduler,
  type OpenCodePromptDeliveryWatchdogSchedulerDependencies,
} from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/opencode/delivery/OpenCodePromptDeliveryWatchdogScheduler';
import { OPENCODE_PROMPT_DELIVERY_OBSERVE_DELAY_MS } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/opencode/delivery/OpenCodePromptDeliveryWatchdog';

type Deps = { [K in keyof OpenCodePromptDeliveryWatchdogSchedulerDependencies]: OpenCodePromptDeliveryWatchdogSchedulerDependencies[K] };
const teamName = 'TEST-cancel-boundary', memberName = 'TEST-member';

beforeEach(() => {
  vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date'] });
  vi.setSystemTime(1_000_000);
});
afterEach(() => { vi.clearAllTimers(); vi.useRealTimers(); });

function fixture(overrides: Partial<Deps>) {
  const relayed: string[] = [];
  const deps: Deps = {
    canDeliverToTeamRuntime: () => true,
    recoverBeforeDelivery: async () => false,
    relay: async ({ messageId }) => { relayed.push(messageId); },
    getInboxMessages: async () => [],
    resolveIdentity: async () => ({ ok: true, laneId: 'TEST-lane' }),
    isLaneActive: async () => true,
    isRecordNotFoundError: () => false,
    info: () => {}, warn: () => {}, debug: () => {}, diagnostic: () => {},
    getErrorMessage: String,
    ...overrides,
  };
  const scheduler = new OpenCodePromptDeliveryWatchdogScheduler(deps);
  const facts = () => ({ ...scheduler.readStoppedTeamImportFacts(teamName) });
  const scheduleReplacement = () => scheduler.schedule({
    teamName, memberName, messageId: 'TEST-replacement', delayMs: 500, isCurrent: () => true,
  });
  return { scheduler, relayed, facts, scheduleReplacement };
}

describe('actual scheduler cancellation across original deferred work', () => {
  it.each([false, true])('superseded inbox await respects cancel=%s and retains genuine pending work', async cancelled => {
    const inbox = Promise.withResolvers<readonly { messageId: string; read: boolean }[]>();
    let current = true, reads = 0;
    const f = fixture({ getInboxMessages: () => { reads++; return inbox.promise; } });
    const states: Record<string, unknown> = {};
    try {
      f.scheduler.schedule({ teamName, memberName, messageId: 'TEST-original', delayMs: 500,
        isCurrent: () => current });
      current = false;
      await vi.advanceTimersByTimeAsync(500);
      states.pending = f.facts();
      expect(reads).toBe(1);
      expect(states.pending).toEqual({ timers: 0, queued: 0, inFlight: 1 });
      if (cancelled) f.scheduler.cancelTeam(teamName);
      states.afterCancel = f.facts();
      expect(states.afterCancel, 'cancel cannot certify completion of the original pending read')
        .toEqual({ timers: 0, queued: 0, inFlight: 1 });
      f.scheduleReplacement();
      await vi.advanceTimersByTimeAsync(500);
      states.replacementQueued = f.facts();
      expect(states.replacementQueued).toEqual({ timers: 0, queued: 1, inFlight: 1 });
      inbox.resolve([{ messageId: 'TEST-original', read: false }]);
      await vi.advanceTimersByTimeAsync(0);
      states.afterOriginalSettles = f.facts();
      expect(f.relayed).toContain('TEST-replacement');
      await vi.advanceTimersByTimeAsync(OPENCODE_PROMPT_DELIVERY_OBSERVE_DELAY_MS);
      states.final = f.facts();
      states.relayed = [...f.relayed];
      console.info('TEST watchdog cancellation', JSON.stringify({ boundary: 'inbox', cancelled, states }));
      expect(states.final).toEqual({ timers: 0, queued: 0, inFlight: 0 });
      expect.soft(states.afterOriginalSettles).toEqual({ timers: cancelled ? 0 : 1, queued: 0, inFlight: 0 });
      expect(f.relayed).toEqual(cancelled ? ['TEST-replacement'] : ['TEST-replacement', 'TEST-original']);
    } finally {
      inbox.resolve([]); f.scheduler.cancelTeam(teamName);
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each([false, true])('recovery await respects cancel=%s while a replacement waits for real finally', async cancelled => {
    const recovery = Promise.withResolvers<boolean>();
    let recoveries = 0;
    const f = fixture({
      canDeliverToTeamRuntime: () => false,
      recoverBeforeDelivery: () => ++recoveries === 1 ? recovery.promise : Promise.resolve(true),
    });
    const states: Record<string, unknown> = {};
    try {
      f.scheduler.schedule({ teamName, memberName, messageId: 'TEST-original', delayMs: 500 });
      await vi.advanceTimersByTimeAsync(500);
      states.pending = f.facts();
      expect(recoveries).toBe(1);
      expect(states.pending).toEqual({ timers: 0, queued: 0, inFlight: 1 });
      if (cancelled) f.scheduler.cancelTeam(teamName);
      states.afterCancel = f.facts();
      expect(states.afterCancel).toEqual({ timers: 0, queued: 0, inFlight: 1 });
      f.scheduleReplacement();
      await vi.advanceTimersByTimeAsync(500);
      states.replacementQueued = f.facts();
      expect(states.replacementQueued).toEqual({ timers: 0, queued: 1, inFlight: 1 });
      recovery.resolve(true);
      await vi.advanceTimersByTimeAsync(0);
      states.final = f.facts();
      states.relayed = [...f.relayed];
      console.info('TEST watchdog cancellation', JSON.stringify({ boundary: 'recovery', cancelled, states }));
      expect(states.final).toEqual({ timers: 0, queued: 0, inFlight: 0 });
      expect(f.relayed).toContain('TEST-replacement');
      expect(f.relayed).toEqual(cancelled ? ['TEST-replacement'] : ['TEST-original', 'TEST-replacement']);
    } finally {
      recovery.resolve(false); f.scheduler.cancelTeam(teamName);
      await vi.advanceTimersByTimeAsync(0);
    }
  });
});
