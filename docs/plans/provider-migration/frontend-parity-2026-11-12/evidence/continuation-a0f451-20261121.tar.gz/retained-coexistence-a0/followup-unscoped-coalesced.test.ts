// @vitest-environment node
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { OpenCodePromptDeliveryWatchdogScheduler } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/opencode/delivery/OpenCodePromptDeliveryWatchdogScheduler';
import { relayOpenCodeMemberInboxMessagesWithPorts, type RelayOpenCodeMemberInboxMessagesPorts, type OpenCodeMemberInboxRelayResult } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningOpenCodeMemberInboxRelay';
const NOW_ISO = '2026-01-01T00:00:00.000Z';
const cleanups: (() => void)[] = [];
beforeEach(() => vi.useFakeTimers());
afterEach(async () => {
 for(const cleanup of cleanups.splice(0)) cleanup();
 await vi.advanceTimersByTimeAsync(0); vi.clearAllTimers(); vi.useRealTimers();
});
function createRelayPorts(
  overrides: Partial<RelayOpenCodeMemberInboxMessagesPorts> = {}
): RelayOpenCodeMemberInboxMessagesPorts {
  return {
    inFlight: new Map(),
    readInboxMessages: vi.fn().mockResolvedValue([]),
    scheduleOpenCodeMemberInboxDeliveryWake: vi.fn(),
    isOpenCodeRuntimeRecipient: vi.fn().mockResolvedValue(true),
    resolveOpenCodeMemberDeliveryIdentity: vi.fn().mockResolvedValue({
      ok: true,
      canonicalMemberName: 'worker',
      laneId: 'lane-worker',
      laneIdentity: { laneId: 'lane-worker', laneKind: 'secondary' },
    }),
    createOpenCodePromptDeliveryLedger: vi.fn(() => ({
      getByInboxMessage: vi.fn().mockResolvedValue(null),
    })) as unknown as RelayOpenCodeMemberInboxMessagesPorts['createOpenCodePromptDeliveryLedger'],
    requeueOpenCodeRuntimeManifestWatermarkDeliveryIfNeeded: vi
      .fn()
      .mockImplementation(({ ledgerRecord: record }) => Promise.resolve(record)),
    requeueOpenCodeNoAssistantTerminalDeliveryIfNeeded: vi
      .fn()
      .mockImplementation(({ ledgerRecord: record }) => Promise.resolve(record)),
    applyDestinationProof: vi.fn().mockRejectedValue(new Error('unused')),
    isOpenCodeDeliveryResponseReadCommitAllowed: vi.fn().mockResolvedValue(false),
    markInboxMessagesRead: vi.fn().mockResolvedValue(undefined),
    logOpenCodePromptDeliveryEvent: vi.fn(),
    readTaskRefInferenceTasks: vi.fn().mockResolvedValue([]),
    resolveOpenCodeInboxAttachmentPayloads: vi.fn().mockResolvedValue({
      ok: true,
      attachments: [],
    }),
    resolveCurrentOpenCodeRuntimeRunId: vi.fn().mockResolvedValue('run-1'),
    markOpenCodePromptLedgerFailedTerminal: vi.fn(),
    deliverOpenCodeMemberMessage: vi.fn().mockResolvedValue({ delivered: true }),
    suppressRuntimeInactiveWarning: vi.fn().mockReturnValue(false),
    logWarning: vi.fn(),
    logDiagnostic: vi.fn(),
    nowIso: () => NOW_ISO,
    getErrorMessage: (error) => (error instanceof Error ? error.message : String(error)),
    ...overrides,
  };
}


it.each([false,true])('unscoped full coalesced followup uses production cleanup ordering: cancel=%s', async (cancelled) => {
 const existing=Promise.withResolvers<OpenCodeMemberInboxRelayResult>();
 const identity={ok:true as const,canonicalMemberName:'worker',laneId:'lane-worker',laneIdentity:{laneId:'lane-worker',laneKind:'secondary' as const}};
 const pending=Promise.withResolvers<typeof identity>();
 cleanups.push(()=>pending.resolve(identity));
 const ports=createRelayPorts({
  readInboxMessages:vi.fn().mockResolvedValue([{from:'user',to:'worker',text:'TEST-unread',timestamp:NOW_ISO,read:false,messageId:'row-late'}]),
  resolveOpenCodeMemberDeliveryIdentity:vi.fn(()=>pending.promise),
 });
 const scheduler=new OpenCodePromptDeliveryWatchdogScheduler({
  canDeliverToTeamRuntime:()=>true,recoverBeforeDelivery:async()=>false,relay:async()=>undefined,
  getInboxMessages:async()=>[],resolveIdentity:async()=>null,isLaneActive:async()=>false,isRecordNotFoundError:()=>false,
  info:()=>{},warn:()=>{},debug:()=>{},diagnostic:()=>{},getErrorMessage:String,
 });
 cleanups.push(()=>scheduler.cancelTeam('TEST-team'));
 ports.scheduleOpenCodeMemberInboxDeliveryWake=vi.fn(input=>scheduler.schedule(input));
 const relayKey='opencode:TEST-team:worker';
 ports.inFlight.set(relayKey,existing.promise);
 const call=relayOpenCodeMemberInboxMessagesWithPorts({teamName:'TEST-team',memberName:'worker',relayKey},ports);
 existing.resolve({attempted:0,delivered:0,relayed:0,failed:0});
 await vi.advanceTimersByTimeAsync(0);
 expect(ports.inFlight.has(relayKey)).toBe(false);
 expect(ports.resolveOpenCodeMemberDeliveryIdentity).toHaveBeenCalledTimes(1);
 if(cancelled){
  for(const key of [...ports.inFlight.keys()]) if(key.startsWith('opencode:TEST-team:')) ports.inFlight.delete(key);
  scheduler.cancelTeam('TEST-team');
 }
 pending.resolve(identity);
 await call;
 expect(ports.inFlight.size).toBe(0);
 expect(ports.deliverOpenCodeMemberMessage).not.toHaveBeenCalled();
 expect(scheduler.readStoppedTeamImportFacts('TEST-team')).toEqual({timers:cancelled?0:1,queued:0,inFlight:0});
});
