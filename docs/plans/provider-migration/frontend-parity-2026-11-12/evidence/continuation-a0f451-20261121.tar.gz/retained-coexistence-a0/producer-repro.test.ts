// @vitest-environment node
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { TeamProvisioningService } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/TeamProvisioningService';
import { getOpenCodeRuntimeLaneIndexPath } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/opencode/store/OpenCodeRuntimeManifestEvidenceReader';
import { createTeamProvisioningMemberWorkSyncBusySignals } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningMemberWorkSyncBusySignals';

const paths = vi.hoisted(() => ({ root: '/TEST-unconfigured-watchdog-producer' }));
vi.mock('@main/utils/pathDecoder', async (importOriginal) => ({
  ...(await importOriginal()),
  getClaudeBasePath: () => join(paths.root, 'claude'),
  getTeamsBasePath: () => join(paths.root, 'claude/teams'),
  getTasksBasePath: () => join(paths.root, 'claude/tasks'),
  getAppDataPath: () => join(paths.root, 'app'),
  getBackupsBasePath: () => join(paths.root, 'app/backups'),
}));
vi.mock('/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningAnthropicApiKeyHelperCleanup', () => ({
  createStaleAnthropicTeamApiKeyHelperCleanupRetryOwner: () => ({
    start() {}, stop() {}, getPendingTeamNames: () => [], hasPendingCleanup: () => false,
  }),
}));
class FixtureProvisioning extends TeamProvisioningService {
  cancelWake(team: string) { this.openCodePromptDeliveryWatchdogScheduler.cancelTeam(team); }
}
const cleanups: (() => void)[] = [];
afterEach(() => { for (const cleanup of cleanups.splice(0)) cleanup(); vi.useRealTimers(); });

describe('actual Main stopped-team busy read watchdog producer', () => {
  for (const state of ['stopped', 'degraded', 'active', 'missing'] as const) {
    it(`${state} lane preserves its busy answer without inadmissible wake`, async () => {
      vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
      const root = mkdtempSync(join(tmpdir(), 'TEST-watchdog-producer-'));
      paths.root = root;
      const teamName = 'test-retained-v1', memberName = 'bob', laneId = 'primary';
      const team = join(root, 'claude/teams', teamName);
      const put = (name: string, data: unknown) => {
        mkdirSync(dirname(name), { recursive: true });
        writeFileSync(name, JSON.stringify(data));
      };
      const members = [
        { name: 'team-lead', agentType: 'team-lead', providerId: 'opencode', model: 'TEST-model' },
        { name: memberName, role: 'Developer', providerId: 'opencode', model: 'TEST-model' },
      ];
      put(join(team, 'config.json'), { name: teamName, projectPath: join(root, 'project'), members });
      put(join(team, 'team.meta.json'), { version: 1, cwd: join(root, 'project'), providerId: 'opencode', model: 'TEST-model', skipPermissions: false, createdAt: 1 });
      put(join(team, 'members.meta.json'), { version: 1, members });
      const index = getOpenCodeRuntimeLaneIndexPath(join(root, 'claude/teams'), teamName);
      if (state !== 'missing') put(index, { version: 1, updatedAt: '2026-11-21T00:00:00.000Z', lanes: { [laneId]: { laneId, state, updatedAt: '2026-11-21T00:00:00.000Z' } } });
      const inbox = join(team, 'inboxes', `${memberName}.json`);
      put(inbox, [{ from: 'user', to: memberName, text: 'TEST unread foreground', timestamp: '2026-11-21T00:00:00.000Z', read: false, messageId: 'TEST-foreground', messageKind: 'direct' }]);
      const beforeInbox = readFileSync(inbox, 'utf8');
      const service = new FixtureProvisioning();
      cleanups.push(() => { service.cancelWake(teamName); rmSync(root, { recursive: true, force: true }); });
      expect(service.readStoppedTeamImportRuntimeFacts(teamName).watchdog).toBe(0);
      const signal = createTeamProvisioningMemberWorkSyncBusySignals(service).extraBusySignals[0];
      const busy = await signal.isBusy({ teamName, memberName, nowIso: '2026-11-21T00:00:10.000Z' });
      expect(busy).toMatchObject({ busy: true, reason: 'opencode_foreground_inbox_unread', activeMessageId: 'TEST-foreground' });
      expect(readFileSync(inbox, 'utf8')).toBe(beforeInbox);
      expect(service.isTeamAlive(teamName)).toBe(false);
      const facts = service.readStoppedTeamImportRuntimeFacts(teamName);
      console.info('TEST actual Main producer', JSON.stringify({ state, facts, busy }));
      expect(facts.watchdog).toBe(state === 'stopped' || state === 'degraded' ? 0 : 1);
    });
  }
});
