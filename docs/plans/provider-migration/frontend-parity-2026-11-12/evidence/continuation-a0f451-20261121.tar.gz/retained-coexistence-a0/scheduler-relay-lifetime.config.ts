import base from '/workspace/scratch/38cae95a211b/agent-teams-ai/vitest.config';
export default { ...base, root: '/workspace/scratch/38cae95a211b/agent-teams-ai', test: { ...base.test,
  include: ['/workspace/scratch/0475591abfcd/retained-coexistence-a0/scheduler-relay-lifetime.test.ts'],
  setupFiles: ['/workspace/scratch/38cae95a211b/agent-teams-ai/test/setup.ts'], maxWorkers: 1,
} };
