import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const repo='/workspace/scratch/38cae95a211b/agent-teams-ai';
const head='a0f451bff29e8100695bc90c2ee6e23108fb7133';
const evidence='/workspace/scratch/0475591abfcd/controller-source-coverage';
const {desktopProofSources:current}=await import(pathToFileURL(path.join(repo,'scripts/legacy-agent-host/desktop-proof-sources.ts')).href);
const baselineRoot=fs.mkdtempSync(path.join(os.tmpdir(),'desktop-source-baseline-'));
const files=['desktop-proof-sources.ts','desktop-proof-supplementary-sources.ts','desktop-proof-ui-sources.ts','desktop-proof-integrated-sources.ts','desktop-proof-management-sources.ts','desktop-native-next-prompt-sources.ts'];
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
try {
 for(const name of files)fs.writeFileSync(path.join(baselineRoot,name),cp.execFileSync('git',['show',head+':scripts/legacy-agent-host/'+name],{cwd:repo}));
 const {desktopProofSources:baseline}=await import(pathToFileURL(path.join(baselineRoot,files[0])).href);
 const inputs=JSON.parse(fs.readFileSync(evidence+'/desktop-source-final-additions.json'));
 const required=inputs.needed,added=current.filter(x=>!baseline.includes(x));
 assert.equal(baseline.length,1935);assert.equal(current.length,1966);assert.equal(new Set(current).size,1966);assert.equal(added.length,31);assert.equal(required.length,55);
 assert.deepEqual(current.filter(x=>baseline.includes(x)),baseline);
 for(const f of required){assert(current.includes(f),f);assert(fs.statSync(path.join(repo,f)).isFile(),f);}
 const modified=[...cp.execFileSync('git',['diff','--name-only'],{cwd:repo,encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard'],{cwd:repo,encoding:'utf8'}).trim().split('\n')].filter(f=>/\.(ts|tsx|js|mjs|cjs)$/.test(f));
 for(const f of modified)assert(required.includes(f),'Changed source excluded: '+f);
 const manifest='scripts/legacy-agent-host/desktop-proof-supplementary-sources.ts';
 const report={kind:'finite-Desktop-source-closure-final-root-R1',sourceHead:head,reviewedAt:new Date().toISOString(),manifest,manifestSha256:hash(path.join(repo,manifest)),beforeCount:baseline.length,afterCount:current.length,added,requiredPaths:required,requiredCount:required.length,allRequiredIncluded:true,allRequiredExist:true,unique:true,noRemovals:true,oldRelativeOrderUnchanged:true,requiredPins:Object.fromEntries(required.map(f=>[f,hash(path.join(repo,f))])),remaining:'Independent final manifest wiring R2 and final combined checks; code/test pins frozen.'};
 fs.writeFileSync(evidence+'/desktop-source-final-r1.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({afterCount:current.length,required:required.length,added:added.length,changedCode:modified.length,manifestSha256:report.manifestSha256,reviewSha256:hash(evidence+'/desktop-source-final-r1.json')}));
}finally{fs.rmSync(baselineRoot,{recursive:true,force:true});}
