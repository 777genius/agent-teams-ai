from pathlib import Path
import hashlib
import json
import subprocess

WORK = Path('/workspace/scratch/0475591abfcd')
REPO = Path('/workspace/scratch/38cae95a211b/agent-teams-ai')
HEAD = 'a0f451bff29e8100695bc90c2ee6e23108fb7133'
receipts = sorted((WORK / 'retained-original-a0/extracted').rglob('desktop-backend-receipt.json'))
receipts += sorted((WORK / 'management-original-a0/extracted').rglob('desktop-backend-receipt.json'))
records = [(path, json.loads(path.read_text())) for path in receipts]
paths = sorted({row['path'] for _, obj in records for field in
                ('selectedSourceHashesBeforeApp', 'selectedSourceHashesAfterFlow')
                for row in obj[field]})
requests = ''.join(f'{HEAD}:{path}\n' for path in paths).encode()
result = subprocess.run(['git', 'cat-file', '--batch'], cwd=REPO, input=requests,
                        stdout=subprocess.PIPE, check=True).stdout
offset = 0
actual = {}
for path in paths:
    end = result.index(b'\n', offset)
    header = result[offset:end].decode()
    offset = end + 1
    if header.endswith(' missing'):
        actual[path] = {'missing': True}
        continue
    oid, kind, size = header.split()
    assert kind == 'blob', (path, kind)
    size = int(size)
    content = result[offset:offset + size]
    assert len(content) == size and result[offset + size:offset + size + 1] == b'\n'
    offset += size + 1
    actual[path] = {'gitBlob': oid, 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': size}
assert offset == len(result)
grouped = {}
for path, obj in records:
    scans = {}
    for field in ('selectedSourceHashesBeforeApp', 'selectedSourceHashesAfterFlow'):
        rows = obj[field]
        assert len({x['path'] for x in rows}) == len(rows)
        scans[field] = {'count': len(rows), 'mismatches': [row['path'] for row in rows
                         if actual[row['path']].get('sha256') != row['sha256']]}
    same = obj['selectedSourceHashesBeforeApp'] == obj['selectedSourceHashesAfterFlow']
    report = {'head': HEAD, 'receipt': str(path), 'receiptSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'mode': obj['mode'], 'status': obj['status'], 'claimedSource': obj.get('source'),
              'beforeAfterIdentical': same, 'scans': scans,
              'rows': [{'path': row['path'], 'receiptSha256': row['sha256'], **actual[row['path']]}
                       for row in obj['selectedSourceHashesBeforeApp']]}
    group = path.relative_to(WORK).parts[0]
    grouped.setdefault(group, []).append(report)
    print(json.dumps({k: v for k, v in report.items() if k != 'rows'}))
    assert same and all(not scan['mismatches'] for scan in scans.values())
for group, reports in grouped.items():
    (WORK / group / 'original-source-pins.json').write_text(json.dumps(reports, indent=2) + '\n')
