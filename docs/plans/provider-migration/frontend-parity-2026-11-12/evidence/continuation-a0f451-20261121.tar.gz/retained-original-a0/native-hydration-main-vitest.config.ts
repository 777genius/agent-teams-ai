import base from '/workspace/scratch/38cae95a211b/agent-teams-ai/vitest.config';
export default { ...base, root:'/workspace/scratch/38cae95a211b/agent-teams-ai', test:{ ...base.test, maxWorkers:1, setupFiles:['/workspace/scratch/38cae95a211b/agent-teams-ai/test/setup.ts'], include:['/workspace/scratch/0475591abfcd/retained-original-a0/native-hydration-main-red.test.ts'] } };
