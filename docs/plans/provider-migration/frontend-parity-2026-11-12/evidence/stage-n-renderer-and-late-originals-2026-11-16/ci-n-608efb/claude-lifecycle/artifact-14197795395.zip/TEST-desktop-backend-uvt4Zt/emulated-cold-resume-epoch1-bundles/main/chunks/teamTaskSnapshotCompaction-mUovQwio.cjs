for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const taskHistory = require("./taskHistory-2kbwfqIg.cjs");
const TEAMMATE_PARTICIPANT_COLOR_PALETTE = [
  "blue",
  "saffron",
  "turquoise",
  "brick",
  "indigo",
  "forest",
  "apricot",
  "rose",
  "cerulean",
  "olive",
  "copper",
  "steel"
];
const PARTICIPANT_IDENTITY_COLOR_PALETTE = [
  "green",
  ...TEAMMATE_PARTICIPANT_COLOR_PALETTE
];
const MEMBER_COLOR_PALETTE = [
  // ── First 12: paired with participant avatars 02-13 ──
  ...TEAMMATE_PARTICIPANT_COLOR_PALETTE,
  // ── Next 12: secondary accents after the core distinct set ──
  "gold",
  "emerald",
  "cobalt",
  "crimson",
  "tangerine",
  "denim",
  "cyan",
  "sage",
  "tomato",
  "rust",
  "mustard",
  "canary",
  "teal",
  "arctic",
  "royal",
  // ── Remaining: fill the hue gaps progressively ──
  "green",
  "pink",
  "ruby",
  // 92°
  "sienna",
  // 144°
  "mint",
  // 216°
  "sky",
  // 275°
  "sapphire",
  // 321°
  "yellow",
  // 13°
  "red",
  // 26°
  "orange",
  // 33°
  "coral",
  // 52°
  "scarlet",
  // 65°
  "salmon",
  // 79°
  "amber",
  // 98°
  "peach",
  // 111°
  "bronze",
  // 137°
  "lemon",
  // 157°
  "honey",
  // 170°
  "marigold",
  // 183°
  "sunflower",
  // 196°
  "lime",
  // 209°
  "jade",
  // 236°
  "chartreuse",
  // 249°
  "aqua",
  // 262°
  "azure",
  // 281°
  "seafoam",
  // 295°
  "periwinkle",
  // 327°
  "cornflower"
  // 353°
];
const TEAM_LEAD_MEMBER_COLOR_ID = "team-lead";
const MEMBER_COLOR_HUES_BY_ORDER = [
  240,
  60,
  180,
  0,
  120,
  300,
  30,
  210,
  330,
  90,
  150,
  270,
  15,
  195,
  105,
  285,
  45,
  225,
  135,
  315,
  75,
  255,
  165,
  345,
  7.5,
  187.5,
  97.5,
  277.5,
  37.5,
  217.5,
  127.5,
  307.5,
  67.5,
  247.5,
  157.5,
  337.5,
  22.5,
  202.5,
  112.5,
  292.5,
  52.5,
  232.5,
  142.5,
  322.5,
  82.5,
  262.5,
  172.5,
  352.5,
  11.25,
  191.25,
  101.25,
  281.25,
  41.25,
  221.25,
  131.25
];
const MEMBER_COLOR_HUE = Object.fromEntries(
  MEMBER_COLOR_PALETTE.map((colorName, index) => [colorName, MEMBER_COLOR_HUES_BY_ORDER[index]])
);
const DISALLOWED_MEMBER_COLORS = /* @__PURE__ */ new Set([
  "purple",
  "violet",
  "plum",
  "amethyst",
  "lavender",
  "orchid",
  "magenta",
  "fuchsia",
  "berry"
]);
function hashStringToIndex(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) + hash + str.charCodeAt(i) | 0;
  }
  return Math.abs(hash);
}
function normalizeParticipantIdentityIndex(index) {
  const count = PARTICIPANT_IDENTITY_COLOR_PALETTE.length;
  return (Math.trunc(index) % count + count) % count;
}
function getParticipantIdentityIndexByName(name) {
  return normalizeParticipantIdentityIndex(hashStringToIndex(name.trim().toLowerCase()));
}
function getParticipantIdentityColor(index) {
  return PARTICIPANT_IDENTITY_COLOR_PALETTE[normalizeParticipantIdentityIndex(index)];
}
function getTeammateParticipantIdentityIndex(index) {
  const teammateCount = TEAMMATE_PARTICIPANT_COLOR_PALETTE.length;
  return 1 + (Math.trunc(index) % teammateCount + teammateCount) % teammateCount;
}
function getTeammateParticipantIdentityColor(index) {
  return getParticipantIdentityColor(getTeammateParticipantIdentityIndex(index));
}
function normalizeMemberColorName(colorName) {
  const normalized = colorName.trim().toLowerCase();
  if (!normalized) return MEMBER_COLOR_PALETTE[0];
  if (!DISALLOWED_MEMBER_COLORS.has(normalized)) return normalized;
  return MEMBER_COLOR_PALETTE[hashStringToIndex(normalized) % MEMBER_COLOR_PALETTE.length];
}
function getMemberColorByName(name) {
  const normalized = name.trim().toLowerCase();
  if (normalized === TEAM_LEAD_MEMBER_COLOR_ID || normalized === "lead") {
    return getParticipantIdentityColor(0);
  }
  return getParticipantIdentityColor(getParticipantIdentityIndexByName(normalized));
}
function buildTeamMemberColorMap(members, options = {}) {
  const preferProvidedColors = options.preferProvidedColors ?? true;
  const map = /* @__PURE__ */ new Map();
  const active = members.filter((member) => !member.removedAt);
  const removed = members.filter((member) => member.removedAt);
  const activeLeads = active.filter((member) => taskHistory.isLeadMember(member));
  const activeTeammates = active.filter((member) => !taskHistory.isLeadMember(member));
  if (!preferProvidedColors) {
    for (const [index, member] of activeLeads.entries()) {
      map.set(
        member.name,
        index === 0 ? getParticipantIdentityColor(0) : getMemberColorByName(member.name)
      );
    }
    for (const [index, member] of activeTeammates.entries()) {
      map.set(member.name, getTeammateParticipantIdentityColor(index));
    }
    for (const member of removed) {
      map.set(
        member.name,
        taskHistory.isLeadMember(member) ? getParticipantIdentityColor(0) : getMemberColorByName(member.name)
      );
    }
    map.set("user", "user");
    return map;
  }
  const usedColors = /* @__PURE__ */ new Set();
  let nextPaletteIdx = 0;
  for (const [index, member] of activeLeads.entries()) {
    const color = preferProvidedColors && member.color ? normalizeMemberColorName(member.color) : index === 0 ? getParticipantIdentityColor(0) : getMemberColorByName(member.name);
    map.set(member.name, color);
    usedColors.add(color);
  }
  for (const member of activeTeammates) {
    let color = preferProvidedColors && member.color ? normalizeMemberColorName(member.color) : void 0;
    if (!color || usedColors.has(color)) {
      while (nextPaletteIdx < MEMBER_COLOR_PALETTE.length && usedColors.has(MEMBER_COLOR_PALETTE[nextPaletteIdx])) {
        nextPaletteIdx += 1;
      }
      color = nextPaletteIdx < MEMBER_COLOR_PALETTE.length ? MEMBER_COLOR_PALETTE[nextPaletteIdx] : MEMBER_COLOR_PALETTE[activeTeammates.indexOf(member) % MEMBER_COLOR_PALETTE.length];
      nextPaletteIdx += 1;
    }
    map.set(member.name, color);
    usedColors.add(color);
  }
  for (const member of removed) {
    const color = preferProvidedColors && member.color ? normalizeMemberColorName(member.color) : taskHistory.isLeadMember(member) ? getParticipantIdentityColor(0) : getMemberColorByName(member.name);
    map.set(member.name, color);
  }
  map.set("user", "user");
  return map;
}
const UUID_TASK_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function looksLikeCanonicalTaskId(taskId) {
  return UUID_TASK_ID_PATTERN.test(taskId.trim());
}
function deriveTaskDisplayId(taskId) {
  const normalized = taskId.trim();
  if (!normalized) return normalized;
  return looksLikeCanonicalTaskId(normalized) ? normalized.slice(0, 8).toLowerCase() : normalized;
}
function getTaskDisplayId(task) {
  return task.displayId?.trim() || deriveTaskDisplayId(task.id);
}
function formatTaskDisplayLabel(task) {
  return `#${getTaskDisplayId(task)}`;
}
function normalizeTaskRefs(value) {
  if (!Array.isArray(value)) return void 0;
  const taskRefs = value.filter(
    (entry) => Boolean(entry) && typeof entry === "object"
  ).map((entry) => ({
    taskId: typeof entry.taskId === "string" ? entry.taskId : "",
    displayId: typeof entry.displayId === "string" ? entry.displayId : "",
    teamName: typeof entry.teamName === "string" ? entry.teamName : ""
  })).filter((entry) => entry.taskId && entry.displayId && entry.teamName);
  return taskRefs.length > 0 ? taskRefs : void 0;
}
const SNAPSHOT_COMMENT_TEXT_MAX_CHARS = 120;
const SNAPSHOT_DESCRIPTION_MAX_CHARS = 2e3;
const SNAPSHOT_PROMPT_MAX_CHARS = 2e3;
const SNAPSHOT_HISTORY_NOTE_MAX_CHARS = 500;
const SNAPSHOT_SOURCE_MESSAGE_TEXT_MAX_CHARS = 1e3;
function compactText(value, maxChars) {
  if (typeof value !== "string") {
    return void 0;
  }
  return value.length > maxChars ? value.slice(0, maxChars) : value;
}
function compactComment(comment) {
  return {
    ...comment,
    text: compactText(comment.text, SNAPSHOT_COMMENT_TEXT_MAX_CHARS) ?? ""
  };
}
function compactTeamTaskForSnapshot(task) {
  const compacted = {
    ...task,
    description: compactText(task.description, SNAPSHOT_DESCRIPTION_MAX_CHARS),
    prompt: compactText(task.prompt, SNAPSHOT_PROMPT_MAX_CHARS),
    comments: Array.isArray(task.comments) ? task.comments.map(compactComment) : void 0,
    historyEvents: Array.isArray(task.historyEvents) ? task.historyEvents.map(
      (event) => "note" in event && typeof event.note === "string" ? {
        ...event,
        note: compactText(event.note, SNAPSHOT_HISTORY_NOTE_MAX_CHARS)
      } : event
    ) : void 0,
    sourceMessage: task.sourceMessage ? {
      ...task.sourceMessage,
      text: compactText(task.sourceMessage.text, SNAPSHOT_SOURCE_MESSAGE_TEXT_MAX_CHARS) ?? ""
    } : void 0
  };
  return compacted;
}
exports.MEMBER_COLOR_HUE = MEMBER_COLOR_HUE;
exports.PARTICIPANT_IDENTITY_COLOR_PALETTE = PARTICIPANT_IDENTITY_COLOR_PALETTE;
exports.buildTeamMemberColorMap = buildTeamMemberColorMap;
exports.compactTeamTaskForSnapshot = compactTeamTaskForSnapshot;
exports.deriveTaskDisplayId = deriveTaskDisplayId;
exports.formatTaskDisplayLabel = formatTaskDisplayLabel;
exports.getMemberColorByName = getMemberColorByName;
exports.getTaskDisplayId = getTaskDisplayId;
exports.looksLikeCanonicalTaskId = looksLikeCanonicalTaskId;
exports.normalizeTaskRefs = normalizeTaskRefs;
