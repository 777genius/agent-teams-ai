"use strict";
const electron = require("electron");
const AGENT_BACKEND_CONNECTIONS_CHANNEL = "agentBackend:connections";
const AGENT_BACKEND_INVOKE_CHANNEL = "agentBackend:invoke";
const STOPPED_TEAM_IMPORT_CHANNEL = "agentBackend:stoppedImport";
const AGENT_BACKEND_REVIEW_WATCH_CHANNEL = "agentBackend:reviewWatch";
const AGENT_BACKEND_REVIEW_UNWATCH_CHANNEL = "agentBackend:reviewUnwatch";
const AGENT_BACKEND_REVIEW_FILE_CHANGE_CHANNEL = "agentBackend:reviewFileChange";
function createAgentBackendReviewWatchBridge(ipc) {
  return {
    watchReviewFiles: (request) => ipc.invoke(AGENT_BACKEND_REVIEW_WATCH_CHANNEL, request),
    unwatchReviewFiles: (request) => ipc.invoke(AGENT_BACKEND_REVIEW_UNWATCH_CHANNEL, request),
    onReviewFileChange(callback) {
      const listener = (_event, value) => callback(value);
      ipc.on(AGENT_BACKEND_REVIEW_FILE_CHANGE_CHANNEL, listener);
      return () => {
        ipc.removeListener(AGENT_BACKEND_REVIEW_FILE_CHANGE_CHANNEL, listener);
      };
    }
  };
}
function createAgentBackendBridge(ipc, watch, stoppedImport) {
  return {
    ...watch ? createAgentBackendReviewWatchBridge(watch) : {},
    // No ID creation, retry, backend selection or conversion of UNKNOWN to rejection.
    invoke: (request) => ipc.invoke(AGENT_BACKEND_INVOKE_CHANNEL, request),
    getConnections: () => ipc.invoke(AGENT_BACKEND_CONNECTIONS_CHANNEL),
    ...stoppedImport ? {
      stoppedImport: (request) => stoppedImport.invoke(STOPPED_TEAM_IMPORT_CHANNEL, request)
    } : {}
  };
}
const ANNOUNCEMENTS_CHANNELS = {
  getSnapshot: "announcements:getSnapshot",
  refresh: "announcements:refresh",
  prepareAuto: "announcements:prepareAuto",
  claimAuto: "announcements:claimAuto",
  openManual: "announcements:openManual",
  loadCover: "announcements:loadCover",
  cancelCover: "announcements:cancelCover",
  loadAsset: "announcements:loadAsset",
  cancelAsset: "announcements:cancelAsset",
  dismiss: "announcements:dismiss",
  stateChanged: "announcements:stateChanged"
};
function createAnnouncementsBridge() {
  return {
    getSnapshot: () => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.getSnapshot),
    refresh: () => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.refresh),
    prepareAuto: () => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.prepareAuto),
    claimAuto: (input) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.claimAuto, input),
    openManual: (id) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.openManual, id),
    loadCover: (id, requestId) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.loadCover, id, requestId),
    cancelCover: (requestId) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.cancelCover, requestId),
    loadAsset: (url, requestId) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.loadAsset, url, requestId),
    cancelAsset: (requestId) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.cancelAsset, requestId),
    dismiss: (id) => electron.ipcRenderer.invoke(ANNOUNCEMENTS_CHANNELS.dismiss, id),
    onStateChanged: (listener) => {
      const handler = (_event, snapshot) => listener(snapshot);
      electron.ipcRenderer.on(ANNOUNCEMENTS_CHANNELS.stateChanged, handler);
      return () => {
        electron.ipcRenderer.removeListener(ANNOUNCEMENTS_CHANNELS.stateChanged, handler);
      };
    }
  };
}
const APP_CLOSE_READINESS_REQUEST = "app-close-coordination:readiness-request";
const APP_CLOSE_READINESS_RESPONSE = "app-close-coordination:readiness-response";
const APP_CLOSE_UI_MOUNT_REQUEST = "app-close-coordination:ui-mount-request";
const APP_CLOSE_READINESS_STARTED = "app-close-coordination:readiness-started";
const normalizeBlockers = (value) => {
  if (!Array.isArray(value)) return [];
  return value.filter((item) => typeof item === "string").map((item) => item.trim()).filter(Boolean).slice(0, 10);
};
function createAppCloseCoordinationBridge(ipcRenderer) {
  let readinessHandler = null;
  ipcRenderer.on(
    APP_CLOSE_READINESS_REQUEST,
    (_event, request) => {
      ipcRenderer.send(APP_CLOSE_READINESS_STARTED, { requestId: request.requestId });
      void (async () => {
        const handler = readinessHandler;
        const uiHandlerObserved = handler !== null;
        let ok = true;
        let blockers = [];
        try {
          if (handler) {
            const result = await handler(request);
            ok = result.ok === true;
            blockers = normalizeBlockers(result.blockers);
          }
        } catch (error) {
          ok = false;
          blockers = [error instanceof Error ? error.message : String(error)];
        }
        ipcRenderer.send(APP_CLOSE_READINESS_RESPONSE, {
          requestId: request.requestId,
          ok,
          blockers,
          uiHandlerObserved
        });
      })();
    }
  );
  return {
    requestUiMount: async () => await ipcRenderer.invoke(APP_CLOSE_UI_MOUNT_REQUEST) === true,
    onReadinessRequest: (handler) => {
      readinessHandler = handler;
      return () => {
        if (readinessHandler === handler) readinessHandler = null;
      };
    }
  };
}
const CODEX_ACCOUNT_GET_SNAPSHOT = "codexAccount:getSnapshot";
const CODEX_ACCOUNT_REFRESH_SNAPSHOT = "codexAccount:refreshSnapshot";
const CODEX_ACCOUNT_START_CHATGPT_LOGIN = "codexAccount:startChatgptLogin";
const CODEX_ACCOUNT_CANCEL_CHATGPT_LOGIN = "codexAccount:cancelChatgptLogin";
const CODEX_ACCOUNT_LOGOUT = "codexAccount:logout";
const CODEX_ACCOUNT_SNAPSHOT_CHANGED = "codexAccount:snapshotChanged";
function createCodexAccountBridge({
  ipcRenderer
}) {
  return {
    getCodexAccountSnapshot: () => ipcRenderer.invoke(CODEX_ACCOUNT_GET_SNAPSHOT),
    refreshCodexAccountSnapshot: (options) => ipcRenderer.invoke(CODEX_ACCOUNT_REFRESH_SNAPSHOT, options),
    startCodexChatgptLogin: (options) => options === void 0 ? ipcRenderer.invoke(CODEX_ACCOUNT_START_CHATGPT_LOGIN) : ipcRenderer.invoke(CODEX_ACCOUNT_START_CHATGPT_LOGIN, options),
    cancelCodexChatgptLogin: () => ipcRenderer.invoke(CODEX_ACCOUNT_CANCEL_CHATGPT_LOGIN),
    logoutCodexAccount: () => ipcRenderer.invoke(CODEX_ACCOUNT_LOGOUT),
    onCodexAccountSnapshotChanged: (callback) => {
      ipcRenderer.on(
        CODEX_ACCOUNT_SNAPSHOT_CHANGED,
        callback
      );
      return () => {
        ipcRenderer.removeListener(
          CODEX_ACCOUNT_SNAPSHOT_CHANGED,
          callback
        );
      };
    }
  };
}
const CODEX_RUNTIME_GET_STATUS = "codexRuntime:getStatus";
const CODEX_RUNTIME_INSTALL = "codexRuntime:install";
const CODEX_RUNTIME_PROGRESS = "codexRuntime:progress";
const CODEX_RUNTIME_INVALIDATE_STATUS = "codexRuntime:invalidateStatus";
function createCodexRuntimeInstallerBridge({
  ipcRenderer,
  invokeIpcWithResult: invokeIpcWithResult2
}) {
  return {
    getStatus: () => invokeIpcWithResult2(CODEX_RUNTIME_GET_STATUS),
    install: () => invokeIpcWithResult2(CODEX_RUNTIME_INSTALL),
    invalidateStatus: () => invokeIpcWithResult2(CODEX_RUNTIME_INVALIDATE_STATUS),
    onProgress: (callback) => {
      ipcRenderer.on(
        CODEX_RUNTIME_PROGRESS,
        callback
      );
      return () => {
        ipcRenderer.removeListener(
          CODEX_RUNTIME_PROGRESS,
          callback
        );
      };
    }
  };
}
const DOCUMENT_PREVIEW_READ = "documentPreview:read";
function createDocumentPreviewBridge() {
  return {
    readDocumentPreview: async (filePath) => {
      const result = await electron.ipcRenderer.invoke(
        DOCUMENT_PREVIEW_READ,
        filePath
      );
      if (!result.success || !result.data)
        throw new Error(result.error ?? "Document preview read failed");
      return result.data;
    }
  };
}
const EXTERNAL_AGENT_RUN_CHANNELS = {
  availability: "external-agent-connection:run:availability",
  start: "external-agent-connection:run:start",
  snapshot: "external-agent-connection:run:snapshot",
  cancel: "external-agent-connection:run:cancel"
};
const EXTERNAL_AGENT_CONNECTION_CHANNELS = {
  getInfo: "external-agent-connection:getInfo",
  retry: "external-agent-connection:retry"
};
function createExternalAgentConnectionBridge(ipcRenderer) {
  return {
    getConnectionInfo: () => ipcRenderer.invoke(EXTERNAL_AGENT_CONNECTION_CHANNELS.getInfo),
    retryConnection: () => ipcRenderer.invoke(EXTERNAL_AGENT_CONNECTION_CHANNELS.retry),
    directRun: {
      getAvailability: () => ipcRenderer.invoke(
        EXTERNAL_AGENT_RUN_CHANNELS.availability
      ),
      start: (request) => ipcRenderer.invoke(
        EXTERNAL_AGENT_RUN_CHANNELS.start,
        request
      ),
      getSnapshot: () => ipcRenderer.invoke(
        EXTERNAL_AGENT_RUN_CHANNELS.snapshot
      ),
      cancel: (request) => ipcRenderer.invoke(
        EXTERNAL_AGENT_RUN_CHANNELS.cancel,
        request
      )
    }
  };
}
const GATEWAY_PROVIDER_CHANNELS = {
  listProfiles: "gateway-provider:listProfiles",
  saveProfile: "gateway-provider:saveProfile",
  deleteProfile: "gateway-provider:deleteProfile",
  probeModels: "gateway-provider:probeModels",
  listBindings: "gateway-provider:listBindings",
  bindMember: "gateway-provider:bindMember",
  unbindMember: "gateway-provider:unbindMember"
};
function createGatewayProviderBridge() {
  return {
    listGatewayProfiles: () => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.listProfiles),
    saveGatewayProfile: (request) => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.saveProfile, request),
    deleteGatewayProfile: (id) => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.deleteProfile, id),
    probeGatewayModels: (request) => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.probeModels, request),
    listGatewayBindings: (teamName) => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.listBindings, teamName),
    bindGatewayMember: (request) => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.bindMember, request),
    unbindGatewayMember: (request) => electron.ipcRenderer.invoke(GATEWAY_PROVIDER_CHANNELS.unbindMember, request)
  };
}
const MEMBER_LOG_STREAM_GET = "member-log-stream:getMemberLogStream";
const MEMBER_LOG_STREAM_GET_PREVIEWS = "member-log-stream:getMemberLogPreviews";
const MEMBER_LOG_STREAM_SET_TRACKING = "member-log-stream:setTracking";
const MEMBER_LOG_STREAM_GET_RUNTIME_LOG_TAIL = "member-log-stream:getMemberRuntimeLogTail";
function createEmptyMemberLogStreamResponse(generatedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  return {
    participants: [],
    defaultFilter: "all",
    segments: [],
    source: "member_empty",
    coverage: [],
    warnings: [],
    truncated: false,
    generatedAt,
    metadata: {
      scannedTranscriptFileCount: 0,
      includedTranscriptFileCount: 0,
      droppedSegmentCount: 0,
      droppedChunkCount: 0,
      droppedMessageCount: 0
    }
  };
}
function normalizeMemberLogStreamResponse(response) {
  if (!response) {
    return createEmptyMemberLogStreamResponse();
  }
  return {
    ...createEmptyMemberLogStreamResponse(response.generatedAt),
    ...response,
    participants: Array.isArray(response.participants) ? response.participants : [],
    segments: Array.isArray(response.segments) ? response.segments : [],
    coverage: Array.isArray(response.coverage) ? response.coverage : [],
    warnings: Array.isArray(response.warnings) ? response.warnings : [],
    metadata: {
      ...createEmptyMemberLogStreamResponse(response.generatedAt).metadata,
      ...response.metadata ?? {}
    }
  };
}
function createEmptyMemberLogPreviewResponse(generatedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  return {
    members: [],
    generatedAt
  };
}
function normalizeMemberLogPreviewMember(member) {
  return {
    memberName: typeof member.memberName === "string" ? member.memberName : "",
    items: Array.isArray(member.items) ? member.items : [],
    coverage: Array.isArray(member.coverage) ? member.coverage : [],
    warnings: Array.isArray(member.warnings) ? member.warnings : [],
    truncated: member.truncated === true,
    overflowCount: typeof member.overflowCount === "number" && Number.isFinite(member.overflowCount) ? Math.max(0, Math.floor(member.overflowCount)) : 0,
    generatedAt: typeof member.generatedAt === "string" && member.generatedAt.length > 0 ? member.generatedAt : (/* @__PURE__ */ new Date()).toISOString()
  };
}
function normalizeMemberLogPreviewResponse(response) {
  if (!response) {
    return createEmptyMemberLogPreviewResponse();
  }
  return {
    members: Array.isArray(response.members) ? response.members.map(normalizeMemberLogPreviewMember) : [],
    generatedAt: typeof response.generatedAt === "string" && response.generatedAt.length > 0 ? response.generatedAt : (/* @__PURE__ */ new Date()).toISOString()
  };
}
const MEMBER_RUNTIME_LOG_KINDS = /* @__PURE__ */ new Set(["stdout", "stderr", "events"]);
function normalizeMemberRuntimeLogKind(kind) {
  return MEMBER_RUNTIME_LOG_KINDS.has(kind) ? kind : "stdout";
}
function normalizeOptionalFiniteNumber(value) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : void 0;
}
function createEmptyMemberRuntimeLogTailResponse(kind = "stdout") {
  return {
    kind,
    content: "",
    truncated: false,
    bytesRead: 0,
    missing: true
  };
}
function normalizeMemberRuntimeLogTailResponse(response) {
  if (!response) {
    return createEmptyMemberRuntimeLogTailResponse();
  }
  const kind = normalizeMemberRuntimeLogKind(response.kind);
  const fileSizeBytes = normalizeOptionalFiniteNumber(response.fileSizeBytes);
  const updatedAt = typeof response.updatedAt === "string" && response.updatedAt.length > 0 ? response.updatedAt : void 0;
  return {
    kind,
    content: typeof response.content === "string" ? response.content : "",
    truncated: response.truncated === true,
    bytesRead: normalizeOptionalFiniteNumber(response.bytesRead) ?? 0,
    ...fileSizeBytes !== void 0 ? { fileSizeBytes } : {},
    ...updatedAt !== void 0 ? { updatedAt } : {},
    missing: response.missing === true
  };
}
async function invokeIpcWithResult$1(channel, ...args) {
  const result = await electron.ipcRenderer.invoke(channel, ...args);
  if (!result.success) {
    throw new Error(result.error ?? "Unknown error");
  }
  return result.data;
}
function createMemberLogStreamBridge() {
  return {
    getMemberLogStream: async (teamName, memberName, options) => normalizeMemberLogStreamResponse(
      await invokeIpcWithResult$1(
        MEMBER_LOG_STREAM_GET,
        teamName,
        memberName,
        options
      )
    ),
    getMemberLogPreviews: async (teamName, memberNames, options) => normalizeMemberLogPreviewResponse(
      await invokeIpcWithResult$1(
        MEMBER_LOG_STREAM_GET_PREVIEWS,
        teamName,
        memberNames,
        options
      )
    ),
    getMemberRuntimeLogTail: async (teamName, memberName, options) => normalizeMemberRuntimeLogTailResponse(
      await invokeIpcWithResult$1(
        MEMBER_LOG_STREAM_GET_RUNTIME_LOG_TAIL,
        teamName,
        memberName,
        options
      )
    ),
    setMemberLogStreamTracking: (teamName, enabled) => invokeIpcWithResult$1(MEMBER_LOG_STREAM_SET_TRACKING, teamName, enabled)
  };
}
const MEMBER_WORK_SYNC_GET_STATUS = "member-work-sync:getStatus";
const MEMBER_WORK_SYNC_REFRESH_STATUS = "member-work-sync:refreshStatus";
const MEMBER_WORK_SYNC_GET_METRICS = "member-work-sync:getMetrics";
const MEMBER_WORK_SYNC_REPORT = "member-work-sync:report";
const MEMBER_WORK_SYNC_STOP = "member-work-sync:stop";
const MEMBER_WORK_SYNC_RESUME = "member-work-sync:resume";
const MEMBER_WORK_SYNC_CONTINUE = "member-work-sync:continue";
function createMemberWorkSyncBridge(ipcRenderer) {
  return {
    getStatus: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_GET_STATUS, request),
    refreshStatus: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_REFRESH_STATUS, request),
    getMetrics: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_GET_METRICS, request),
    report: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_REPORT, request),
    stopAutoResume: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_STOP, request),
    resumeAutoResume: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_RESUME, request),
    continueManually: (request) => ipcRenderer.invoke(MEMBER_WORK_SYNC_CONTINUE, request)
  };
}
const ORGANIZATIONS_GET_MAP = "organizations:getMap";
const ORGANIZATIONS_GET_STRUCTURE = "organizations:getStructure";
const ORGANIZATIONS_CREATE_ORGANIZATION = "organizations:createOrganization";
const ORGANIZATIONS_UPSERT_UNIT = "organizations:upsertUnit";
const ORGANIZATIONS_MOVE_UNIT = "organizations:moveUnit";
const ORGANIZATIONS_REMOVE_UNIT = "organizations:removeUnit";
const ORGANIZATIONS_ASSIGN_TEAM = "organizations:assignTeam";
const ORGANIZATIONS_REMOVE_TEAM = "organizations:removeTeam";
const ORGANIZATIONS_UPSERT_RELATION = "organizations:upsertRelation";
const ORGANIZATIONS_DELETE_RELATION = "organizations:deleteRelation";
function createOrganizationsBridge(ipcRenderer) {
  return {
    getOrganizationMap: (request) => ipcRenderer.invoke(ORGANIZATIONS_GET_MAP, request),
    getOrganizationStructure: (request) => ipcRenderer.invoke(ORGANIZATIONS_GET_STRUCTURE, request),
    createOrganization: (request) => ipcRenderer.invoke(ORGANIZATIONS_CREATE_ORGANIZATION, request),
    upsertOrganizationUnit: (request) => ipcRenderer.invoke(ORGANIZATIONS_UPSERT_UNIT, request),
    moveOrganizationUnit: (request) => ipcRenderer.invoke(ORGANIZATIONS_MOVE_UNIT, request),
    removeOrganizationUnit: (request) => ipcRenderer.invoke(ORGANIZATIONS_REMOVE_UNIT, request),
    assignTeamToUnit: (request) => ipcRenderer.invoke(ORGANIZATIONS_ASSIGN_TEAM, request),
    removeTeamFromOrganization: (request) => ipcRenderer.invoke(ORGANIZATIONS_REMOVE_TEAM, request),
    upsertOrganizationRelation: (request) => ipcRenderer.invoke(ORGANIZATIONS_UPSERT_RELATION, request),
    deleteOrganizationRelation: (request) => ipcRenderer.invoke(ORGANIZATIONS_DELETE_RELATION, request)
  };
}
const PROJECT_FOLDER_GET_STATE = "project-folder:get-state";
const PROJECT_FOLDER_CREATE = "project-folder:create";
function createProjectFolderBridge(ipcRenderer) {
  return {
    projectFolder: {
      getState: (request) => ipcRenderer.invoke(PROJECT_FOLDER_GET_STATE, request),
      create: (request) => ipcRenderer.invoke(PROJECT_FOLDER_CREATE, request)
    }
  };
}
const GET_DASHBOARD_RECENT_PROJECTS = "get-dashboard-recent-projects";
function createRecentProjectsBridge() {
  return {
    getDashboardRecentProjects: () => electron.ipcRenderer.invoke(GET_DASHBOARD_RECENT_PROJECTS)
  };
}
const RUNTIME_PROVIDER_MANAGEMENT_VIEW = "runtimeProviderManagement:view";
const RUNTIME_LOCAL_PROVIDER_LIST = "runtimeProviderManagement:localProviderList";
const RUNTIME_LOCAL_PROVIDER_SCAN = "runtimeProviderManagement:localProviderScan";
const RUNTIME_LOCAL_PROVIDER_PROBE = "runtimeProviderManagement:localProviderProbe";
const RUNTIME_LOCAL_PROVIDER_CONFIGURE = "runtimeProviderManagement:localProviderConfigure";
const RUNTIME_PROVIDER_MANAGEMENT_DIRECTORY = "runtimeProviderManagement:directory";
const RUNTIME_PROVIDER_MANAGEMENT_SETUP_FORM = "runtimeProviderManagement:setupForm";
const RUNTIME_PROVIDER_MANAGEMENT_CONNECT = "runtimeProviderManagement:connect";
const RUNTIME_PROVIDER_MANAGEMENT_CONNECT_API_KEY = "runtimeProviderManagement:connectApiKey";
const RUNTIME_PROVIDER_MANAGEMENT_FORGET = "runtimeProviderManagement:forget";
const RUNTIME_PROVIDER_MANAGEMENT_MODELS = "runtimeProviderManagement:models";
const RUNTIME_PROVIDER_MANAGEMENT_CANCEL_MODEL_LOAD = "runtimeProviderManagement:cancelModelLoad";
const RUNTIME_PROVIDER_MANAGEMENT_TEST_MODEL = "runtimeProviderManagement:testModel";
const RUNTIME_PROVIDER_MANAGEMENT_CANCEL_MODEL_TEST = "runtimeProviderManagement:cancelModelTest";
const RUNTIME_PROVIDER_MANAGEMENT_SET_DEFAULT_MODEL = "runtimeProviderManagement:setDefaultModel";
const RUNTIME_PROVIDER_MANAGEMENT_CLEAR_PROJECT_DEFAULT = "runtimeProviderManagement:clearProjectDefault";
const RUNTIME_PROVIDER_MANAGEMENT_CONFIGURE_MODEL_LIMITS = "runtimeProviderManagement:configureModelLimits";
const RUNTIME_PROVIDER_MANAGEMENT_OAUTH_PROGRESS = "runtimeProviderManagement:oauthProgress";
const RUNTIME_PROVIDER_MANAGEMENT_OAUTH_CODE = "runtimeProviderManagement:oauthCode";
const RUNTIME_PROVIDER_MANAGEMENT_OAUTH_CANCEL = "runtimeProviderManagement:oauthCancel";
const RUNTIME_PROVIDER_COMPANION_STATUS = "runtimeProviderManagement:companionStatus";
const RUNTIME_PROVIDER_COMPANION_INSTALL = "runtimeProviderManagement:companionInstall";
const RUNTIME_PROVIDER_COMPANION_CONNECT = "runtimeProviderManagement:companionConnect";
const RUNTIME_PROVIDER_COMPANION_ACTION = "runtimeProviderManagement:companionAction";
const RUNTIME_PROVIDER_COMPANION_PROGRESS = "runtimeProviderManagement:companionProgress";
const RUNTIME_PROVIDER_COMPANION_IDS = ["kiro-cli", "cursor-agent"];
new Set(RUNTIME_PROVIDER_COMPANION_IDS);
function createRuntimeProviderManagementBridge(ipcRenderer) {
  return {
    listLocalProviders: (input) => ipcRenderer.invoke(RUNTIME_LOCAL_PROVIDER_LIST, input),
    scanLocalProviders: (input) => ipcRenderer.invoke(RUNTIME_LOCAL_PROVIDER_SCAN, input),
    probeLocalProvider: (input) => ipcRenderer.invoke(RUNTIME_LOCAL_PROVIDER_PROBE, input),
    configureLocalProvider: (input) => ipcRenderer.invoke(RUNTIME_LOCAL_PROVIDER_CONFIGURE, input),
    getCompanionStatus: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_COMPANION_STATUS, input),
    installAndConnectCompanion: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_COMPANION_INSTALL, input),
    connectCompanion: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_COMPANION_CONNECT, input),
    runCompanionAction: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_COMPANION_ACTION, input),
    onCompanionProgress: (listener) => {
      const handler = (_event, value) => listener(value);
      ipcRenderer.on(RUNTIME_PROVIDER_COMPANION_PROGRESS, handler);
      return () => ipcRenderer.removeListener(RUNTIME_PROVIDER_COMPANION_PROGRESS, handler);
    },
    loadView: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_VIEW, input),
    loadProviderDirectory: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_DIRECTORY, input),
    loadSetupForm: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_SETUP_FORM, input),
    connectProvider: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_CONNECT, input),
    connectWithApiKey: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_CONNECT_API_KEY, input),
    forgetCredential: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_FORGET, input),
    loadModels: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_MODELS, input),
    cancelModelLoad: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_CANCEL_MODEL_LOAD, input),
    testModel: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_TEST_MODEL, input),
    cancelModelTest: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_CANCEL_MODEL_TEST, input),
    setDefaultModel: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_SET_DEFAULT_MODEL, input),
    clearProjectDefaultModel: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_CLEAR_PROJECT_DEFAULT, input),
    configureModelLimits: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_CONFIGURE_MODEL_LIMITS, input),
    submitOAuthCode: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_OAUTH_CODE, input),
    cancelOAuth: (input) => ipcRenderer.invoke(RUNTIME_PROVIDER_MANAGEMENT_OAUTH_CANCEL, input),
    onOAuthProgress: (listener) => {
      const handler = (_event, value) => listener(value);
      ipcRenderer.on(RUNTIME_PROVIDER_MANAGEMENT_OAUTH_PROGRESS, handler);
      return () => ipcRenderer.removeListener(RUNTIME_PROVIDER_MANAGEMENT_OAUTH_PROGRESS, handler);
    }
  };
}
const GROUP_CHAT_CHANNELS = {
  getReaction: "team-group-chats:get-reaction",
  setReaction: "team-group-chats:set-reaction",
  list: "team-group-chats:list",
  create: "team-group-chats:create",
  setArchived: "team-group-chats:set-archived",
  send: "team-group-chats:send"
};
function createTeamGroupChatsBridge() {
  async function invoke(channel, request) {
    const reply = await electron.ipcRenderer.invoke(channel, request);
    if (reply.error)
      throw Object.assign(new Error(reply.error.message), { code: reply.error.code });
    return reply.result;
  }
  return {
    getReaction: (request) => invoke(GROUP_CHAT_CHANNELS.getReaction, request),
    setReaction: (request) => invoke(GROUP_CHAT_CHANNELS.setReaction, request),
    list: (request) => invoke(GROUP_CHAT_CHANNELS.list, request),
    create: (request) => invoke(GROUP_CHAT_CHANNELS.create, request),
    setArchived: (request) => invoke(GROUP_CHAT_CHANNELS.setArchived, request),
    send: (request) => invoke(GROUP_CHAT_CHANNELS.send, request)
  };
}
const TEAM_IMPORT_CHOOSE_FOLDER_AND_PREVIEW = "team-import:choose-folder-and-preview";
const TEAM_IMPORT_CREATE_DRAFT = "team-import:create-draft";
function createTeamImportBridge(ipcRenderer) {
  return {
    chooseFolderAndPreview: () => ipcRenderer.invoke(TEAM_IMPORT_CHOOSE_FOLDER_AND_PREVIEW),
    createDraft: (request) => ipcRenderer.invoke(TEAM_IMPORT_CREATE_DRAFT, request)
  };
}
const TEAM_UPDATE_MEMBER_SETTINGS = "team:updateMemberSettings";
function createTeamMemberSettingsBridge(invoke) {
  return {
    updateMemberSettings: (request) => invoke(TEAM_UPDATE_MEMBER_SETTINGS, request)
  };
}
const SSH_CONNECT = "ssh:connect";
const SSH_DISCONNECT = "ssh:disconnect";
const SSH_GET_STATE = "ssh:getState";
const SSH_TEST = "ssh:test";
const SSH_GET_CONFIG_HOSTS = "ssh:getConfigHosts";
const SSH_RESOLVE_HOST = "ssh:resolveHost";
const SSH_SAVE_LAST_CONNECTION = "ssh:saveLastConnection";
const SSH_GET_LAST_CONNECTION = "ssh:getLastConnection";
const SSH_STATUS = "ssh:status";
const TMUX_GET_STATUS = "tmux:getStatus";
const TMUX_GET_INSTALLER_SNAPSHOT = "tmux:getInstallerSnapshot";
const TMUX_INSTALL = "tmux:install";
const TMUX_CANCEL_INSTALL = "tmux:cancelInstall";
const TMUX_SUBMIT_INSTALLER_INPUT = "tmux:submitInstallerInput";
const TMUX_INVALIDATE_STATUS = "tmux:invalidateStatus";
const TMUX_INSTALLER_PROGRESS = "tmux:progress";
const RENDERER_LOG = "renderer:log";
const RENDERER_BOOT = "renderer:boot";
const RENDERER_HEARTBEAT = "renderer:heartbeat";
const APP_STARTUP_GET_STATUS = "appStartup:getStatus";
const APP_STARTUP_PROGRESS = "appStartup:progress";
const APP_GET_WINDOWS_ELEVATION_STATUS = "app:getWindowsElevationStatus";
const TELEMETRY_GET_SENTRY_CONTEXT = "telemetry:getSentryContext";
const TELEMETRY_GET_SENTRY_STATUS = "telemetry:getSentryStatus";
const CONFIG_GET = "config:get";
const CONFIG_UPDATE = "config:update";
const CONFIG_ADD_IGNORE_REGEX = "config:addIgnoreRegex";
const CONFIG_REMOVE_IGNORE_REGEX = "config:removeIgnoreRegex";
const CONFIG_ADD_IGNORE_REPOSITORY = "config:addIgnoreRepository";
const CONFIG_REMOVE_IGNORE_REPOSITORY = "config:removeIgnoreRepository";
const CONFIG_SNOOZE = "config:snooze";
const CONFIG_CLEAR_SNOOZE = "config:clearSnooze";
const CONFIG_ADD_TRIGGER = "config:addTrigger";
const CONFIG_UPDATE_TRIGGER = "config:updateTrigger";
const CONFIG_REMOVE_TRIGGER = "config:removeTrigger";
const CONFIG_GET_TRIGGERS = "config:getTriggers";
const CONFIG_TEST_TRIGGER = "config:testTrigger";
const CONFIG_SELECT_FOLDERS = "config:selectFolders";
const CONFIG_SELECT_CLAUDE_ROOT_FOLDER = "config:selectClaudeRootFolder";
const CONFIG_GET_CLAUDE_ROOT_INFO = "config:getClaudeRootInfo";
const CONFIG_FIND_WSL_CLAUDE_ROOTS = "config:findWslClaudeRoots";
const CONFIG_OPEN_IN_EDITOR = "config:openInEditor";
const CONFIG_ADD_CUSTOM_PROJECT_PATH = "config:addCustomProjectPath";
const CONFIG_REMOVE_CUSTOM_PROJECT_PATH = "config:removeCustomProjectPath";
const CONFIG_PIN_SESSION = "config:pinSession";
const CONFIG_UNPIN_SESSION = "config:unpinSession";
const CONFIG_HIDE_SESSION = "config:hideSession";
const CONFIG_UNHIDE_SESSION = "config:unhideSession";
const CONFIG_HIDE_SESSIONS = "config:hideSessions";
const CONFIG_UNHIDE_SESSIONS = "config:unhideSessions";
const UPDATER_CHECK = "updater:check";
const UPDATER_DOWNLOAD = "updater:download";
const UPDATER_INSTALL = "updater:install";
const UPDATER_STATUS = "updater:status";
const CONTEXT_LIST = "context:list";
const CONTEXT_GET_ACTIVE = "context:getActive";
const CONTEXT_SWITCH = "context:switch";
const CONTEXT_CHANGED = "context:changed";
const HTTP_SERVER_START = "httpServer:start";
const HTTP_SERVER_STOP = "httpServer:stop";
const HTTP_SERVER_GET_STATUS = "httpServer:getStatus";
const WINDOW_MINIMIZE = "window:minimize";
const WINDOW_MAXIMIZE = "window:maximize";
const WINDOW_CLOSE = "window:close";
const WINDOW_IS_MAXIMIZED = "window:isMaximized";
const WINDOW_IS_FULLSCREEN = "window:isFullScreen";
const WINDOW_FULLSCREEN_CHANGED = "window:fullscreen-changed";
const APP_RELAUNCH = "app:relaunch";
const TEAM_LIST = "team:list";
const TEAM_GET_DATA = "team:getData";
const TEAM_GET_TASK = "team:getTask";
const TEAM_GET_TASK_CHANGE_PRESENCE = "team:getTaskChangePresence";
const TEAM_SET_CHANGE_PRESENCE_TRACKING = "team:setChangePresenceTracking";
const TEAM_SET_TOOL_ACTIVITY_TRACKING = "team:setToolActivityTracking";
const TEAM_SET_TASK_LOG_STREAM_TRACKING = "team:setTaskLogStreamTracking";
const TEAM_GET_CLAUDE_LOGS = "team:getClaudeLogs";
const TEAM_UPDATE_KANBAN = "team:updateKanban";
const TEAM_UPDATE_KANBAN_COLUMN_ORDER = "team:updateKanbanColumnOrder";
const TEAM_SEND_MESSAGE = "team:sendMessage";
const TEAM_GET_OPENCODE_RUNTIME_DELIVERY_STATUS = "team:getOpenCodeRuntimeDeliveryStatus";
const TEAM_GET_MESSAGES_PAGE = "team:getMessagesPage";
const TEAM_GET_MEMBER_ACTIVITY_META = "team:getMemberActivityMeta";
const TEAM_REQUEST_REVIEW = "team:requestReview";
const TEAM_CHANGE = "team:change";
const TEAM_CREATE = "team:create";
const TEAM_LAUNCH = "team:launch";
const TEAM_PREPARE_PROVISIONING = "team:prepareProvisioning";
const TEAM_GET_WORKTREE_GIT_STATUS = "team:getWorktreeGitStatus";
const TEAM_INITIALIZE_GIT_REPOSITORY = "team:initializeGitRepository";
const TEAM_CREATE_INITIAL_GIT_COMMIT = "team:createInitialGitCommit";
const TEAM_PROVISIONING_STATUS = "team:provisioningStatus";
const TEAM_LAUNCH_FAILURE_DIAGNOSTICS = "team:launchFailureDiagnostics";
const TEAM_CANCEL_PROVISIONING = "team:cancelProvisioning";
const TEAM_PROVISIONING_PROGRESS = "team:provisioningProgress";
const TEAM_PROCESS_SEND = "team:processSend";
const TEAM_PROCESS_ALIVE = "team:processAlive";
const TEAM_CREATE_TASK = "team:createTask";
const TEAM_UPDATE_TASK_STATUS = "team:updateTaskStatus";
const TEAM_UPDATE_TASK_OWNER = "team:updateTaskOwner";
const TEAM_UPDATE_TASK_FIELDS = "team:updateTaskFields";
const TEAM_DELETE_TEAM = "team:deleteTeam";
const TEAM_RESTORE = "team:restoreTeam";
const TEAM_PERMANENTLY_DELETE = "team:permanentlyDeleteTeam";
const TEAM_RESTORE_TASK = "team:restoreTask";
const TEAM_ALIVE_LIST = "team:aliveList";
const TEAM_STOP = "team:stop";
const TEAM_FORCE_STOP = "team:forceStop";
const TEAM_GET_QUEUED_USER_MESSAGES = "team:getQueuedUserMessages";
const TEAM_DISCARD_QUEUED_USER_MESSAGES = "team:discardQueuedUserMessages";
const TEAM_CREATE_CONFIG = "team:createConfig";
const TEAM_GET_MEMBER_LOGS = "team:getMemberLogs";
const TEAM_GET_LOGS_FOR_TASK = "team:getLogsForTask";
const TEAM_GET_TASK_ACTIVITY = "team:getTaskActivity";
const TEAM_GET_TASK_ACTIVITY_DETAIL = "team:getTaskActivityDetail";
const TEAM_GET_TASK_LOG_STREAM = "team:getTaskLogStream";
const TEAM_GET_TASK_LOG_STREAM_SUMMARY = "team:getTaskLogStreamSummary";
const TEAM_GET_TASK_EXACT_LOG_SUMMARIES = "team:getTaskExactLogSummaries";
const TEAM_GET_TASK_EXACT_LOG_DETAIL = "team:getTaskExactLogDetail";
const TEAM_UPDATE_CONFIG = "team:updateConfig";
const TEAM_GET_MEMBER_STATS = "team:getMemberStats";
const TEAM_START_TASK = "team:startTask";
const TEAM_START_TASK_BY_USER = "team:startTaskByUser";
const TEAM_GET_ALL_TASKS = "team:getAllTasks";
const TEAM_ADD_TASK_COMMENT = "team:addTaskComment";
const TEAM_GET_PROJECT_BRANCH = "team:getProjectBranch";
const TEAM_SET_PROJECT_BRANCH_TRACKING = "team:setProjectBranchTracking";
const TEAM_PROJECT_BRANCH_CHANGE = "team:projectBranchChange";
const TEAM_ADD_MEMBER = "team:addMember";
const TEAM_REPLACE_MEMBERS = "team:replaceMembers";
const TEAM_REMOVE_MEMBER = "team:removeMember";
const TEAM_RESTORE_MEMBER = "team:restoreMember";
const TEAM_UPDATE_MEMBER_ROLE = "team:updateMemberRole";
const TEAM_GET_ATTACHMENTS = "team:getAttachments";
const TEAM_KILL_PROCESS = "team:killProcess";
const TEAM_LEAD_ACTIVITY = "team:leadActivity";
const TEAM_LEAD_CONTEXT = "team:leadContext";
const TEAM_MEMBER_SPAWN_STATUSES = "team:memberSpawnStatuses";
const TEAM_GET_AGENT_RUNTIME = "team:getAgentRuntime";
const TEAM_RESTART_MEMBER = "team:restartMember";
const TEAM_RETRY_FAILED_OPENCODE_SECONDARY_LANES = "team:retryFailedOpenCodeSecondaryLanes";
const TEAM_SKIP_MEMBER_FOR_LAUNCH = "team:skipMemberForLaunch";
const TEAM_SOFT_DELETE_TASK = "team:softDeleteTask";
const TEAM_GET_DELETED_TASKS = "team:getDeletedTasks";
const TEAM_SET_TASK_CLARIFICATION = "team:setTaskClarification";
const TEAM_SHOW_MESSAGE_NOTIFICATION = "team:showMessageNotification";
const TEAM_ADD_TASK_RELATIONSHIP = "team:addTaskRelationship";
const TEAM_REMOVE_TASK_RELATIONSHIP = "team:removeTaskRelationship";
const TEAM_SAVE_TASK_ATTACHMENT = "team:saveTaskAttachment";
const TEAM_GET_TASK_ATTACHMENT = "team:getTaskAttachment";
const TEAM_DELETE_TASK_ATTACHMENT = "team:deleteTaskAttachment";
const TEAM_TOOL_APPROVAL_EVENT = "team:toolApprovalEvent";
const TEAM_TOOL_APPROVAL_RESPOND = "team:toolApprovalRespond";
const TEAM_VALIDATE_CLI_ARGS = "team:validateCliArgs";
const TEAM_TOOL_APPROVAL_SETTINGS = "team:toolApprovalSettings";
const TEAM_TOOL_APPROVAL_READ_FILE = "team:toolApprovalReadFile";
const TEAM_GET_SAVED_REQUEST = "team:getSavedRequest";
const TEAM_DELETE_DRAFT = "team:deleteDraft";
const CROSS_TEAM_SEND = "crossTeam:send";
const CROSS_TEAM_LIST_TARGETS = "crossTeam:listTargets";
const CROSS_TEAM_GET_OUTBOX = "crossTeam:getOutbox";
const CLI_INSTALLER_GET_STATUS = "cliInstaller:getStatus";
const CLI_INSTALLER_GET_PROVIDER_STATUS = "cliInstaller:getProviderStatus";
const CLI_INSTALLER_VERIFY_PROVIDER_MODELS = "cliInstaller:verifyProviderModels";
const CLI_INSTALLER_INSTALL = "cliInstaller:install";
const CLI_INSTALLER_PROGRESS = "cliInstaller:progress";
const CLI_INSTALLER_INVALIDATE_STATUS = "cliInstaller:invalidateStatus";
const OPENCODE_RUNTIME_GET_STATUS = "openCodeRuntime:getStatus";
const OPENCODE_RUNTIME_INSTALL = "openCodeRuntime:install";
const OPENCODE_RUNTIME_PROGRESS = "openCodeRuntime:progress";
const OPENCODE_RUNTIME_INVALIDATE_STATUS = "openCodeRuntime:invalidateStatus";
const TERMINAL_SPAWN = "terminal:spawn";
const TERMINAL_WRITE = "terminal:write";
const TERMINAL_RESIZE = "terminal:resize";
const TERMINAL_KILL = "terminal:kill";
const TERMINAL_DATA = "terminal:data";
const TERMINAL_EXIT = "terminal:exit";
const REVIEW_GET_AGENT_CHANGES = "review:getAgentChanges";
const REVIEW_GET_TASK_CHANGES = "review:getTaskChanges";
const REVIEW_GET_TEAM_TASK_CHANGE_SUMMARIES = "review:getTeamTaskChangeSummaries";
const REVIEW_INVALIDATE_TASK_CHANGE_SUMMARIES = "review:invalidateTaskChangeSummaries";
const REVIEW_GET_CHANGE_STATS = "review:getChangeStats";
const REVIEW_CHECK_CONFLICT = "review:checkConflict";
const REVIEW_REJECT_HUNKS = "review:rejectHunks";
const REVIEW_REJECT_FILE = "review:rejectFile";
const REVIEW_PREVIEW_REJECT = "review:previewReject";
const REVIEW_APPLY_DECISIONS = "review:applyDecisions";
const REVIEW_EXECUTE_MUTATION = "review:executeMutation";
const REVIEW_RETRY_MUTATION_RECOVERY = "review:retryMutationRecovery";
const REVIEW_RESTORE_HISTORY = "review:restoreHistory";
const REVIEW_GET_FILE_CONTENT = "review:getFileContent";
const REVIEW_WATCH_FILES = "review:watchFiles";
const REVIEW_UNWATCH_FILES = "review:unwatchFiles";
const REVIEW_FILE_CHANGE = "review:fileChange";
const REVIEW_SAVE_EDITED_FILE = "review:saveEditedFile";
const REVIEW_DELETE_EDITED_FILE = "review:deleteEditedFile";
const REVIEW_RESTORE_REJECTED_RENAME = "review:restoreRejectedRename";
const REVIEW_REAPPLY_REJECTED_RENAME = "review:reapplyRejectedRename";
const REVIEW_GET_GIT_FILE_LOG = "review:getGitFileLog";
const REVIEW_LOAD_DECISIONS = "review:loadDecisions";
const REVIEW_SAVE_DECISIONS = "review:saveDecisions";
const REVIEW_CLEAR_DECISIONS = "review:clearDecisions";
const REVIEW_LOAD_DECISION_CONFLICT_CANDIDATES = "review:loadDecisionConflictCandidates";
const REVIEW_RESOLVE_DECISION_CONFLICT_CANDIDATE = "review:resolveDecisionConflictCandidate";
const REVIEW_LOAD_DRAFT_HISTORY = "review:loadDraftHistory";
const REVIEW_SAVE_DRAFT_HISTORY_ENTRY = "review:saveDraftHistoryEntry";
const REVIEW_CLEAR_DRAFT_HISTORY = "review:clearDraftHistory";
const REVIEW_LOAD_DRAFT_HISTORY_CONFLICT_CANDIDATES = "review:loadDraftHistoryConflictCandidates";
const REVIEW_RESOLVE_DRAFT_HISTORY_CONFLICT_CANDIDATE = "review:resolveDraftHistoryConflictCandidate";
const REVIEW_REPLACE_DRAFT_HISTORY_CONFLICT_CANDIDATE = "review:replaceDraftHistoryConflictCandidate";
const EDITOR_OPEN = "editor:open";
const EDITOR_CLOSE = "editor:close";
const EDITOR_READ_DIR = "editor:readDir";
const EDITOR_READ_FILE = "editor:readFile";
const EDITOR_WRITE_FILE = "editor:writeFile";
const EDITOR_CREATE_FILE = "editor:createFile";
const EDITOR_CREATE_DIR = "editor:createDir";
const EDITOR_DELETE_FILE = "editor:deleteFile";
const EDITOR_MOVE_FILE = "editor:moveFile";
const EDITOR_RENAME_FILE = "editor:renameFile";
const EDITOR_SEARCH_IN_FILES = "editor:searchInFiles";
const EDITOR_LIST_FILES = "editor:listFiles";
const EDITOR_GIT_STATUS = "editor:gitStatus";
const EDITOR_WATCH_DIR = "editor:watchDir";
const EDITOR_SET_WATCHED_FILES = "editor:setWatchedFiles";
const EDITOR_SET_WATCHED_DIRS = "editor:setWatchedDirs";
const EDITOR_READ_BINARY_PREVIEW = "editor:readBinaryPreview";
const EDITOR_CHANGE = "editor:change";
const PROJECT_LIST_FILES = "project:listFiles";
const SCHEDULE_LIST = "schedule:list";
const SCHEDULE_GET = "schedule:get";
const SCHEDULE_CREATE = "schedule:create";
const SCHEDULE_UPDATE = "schedule:update";
const SCHEDULE_DELETE = "schedule:delete";
const SCHEDULE_PAUSE = "schedule:pause";
const SCHEDULE_RESUME = "schedule:resume";
const SCHEDULE_TRIGGER_NOW = "schedule:triggerNow";
const SCHEDULE_GET_RUNS = "schedule:getRuns";
const SCHEDULE_GET_RUN_LOGS = "schedule:getRunLogs";
const SCHEDULE_CHANGE = "schedule:change";
const PLUGIN_GET_ALL = "plugin:getAll";
const PLUGIN_GET_README = "plugin:getReadme";
const MCP_REGISTRY_SEARCH = "mcpRegistry:search";
const MCP_REGISTRY_BROWSE = "mcpRegistry:browse";
const MCP_REGISTRY_GET_BY_ID = "mcpRegistry:getById";
const MCP_REGISTRY_GET_INSTALLED = "mcpRegistry:getInstalled";
const MCP_REGISTRY_DIAGNOSE = "mcpRegistry:diagnose";
const PLUGIN_INSTALL = "plugin:install";
const PLUGIN_UNINSTALL = "plugin:uninstall";
const MCP_REGISTRY_INSTALL = "mcpRegistry:install";
const MCP_REGISTRY_UNINSTALL = "mcpRegistry:uninstall";
const MCP_REGISTRY_INSTALL_CUSTOM = "mcpRegistry:installCustom";
const MCP_GITHUB_STARS = "mcpRegistry:githubStars";
const SKILLS_LIST = "skills:list";
const SKILLS_GET_DETAIL = "skills:getDetail";
const SKILLS_PREVIEW_UPSERT = "skills:previewUpsert";
const SKILLS_APPLY_UPSERT = "skills:applyUpsert";
const SKILLS_PREVIEW_IMPORT = "skills:previewImport";
const SKILLS_APPLY_IMPORT = "skills:applyImport";
const SKILLS_DELETE = "skills:delete";
const SKILLS_START_WATCHING = "skills:startWatching";
const SKILLS_STOP_WATCHING = "skills:stopWatching";
const SKILLS_CHANGED = "skills:changed";
const API_KEYS_LIST = "apiKeys:list";
const API_KEYS_SAVE = "apiKeys:save";
const API_KEYS_DELETE = "apiKeys:delete";
const API_KEYS_LOOKUP = "apiKeys:lookup";
const API_KEYS_STORAGE_STATUS = "apiKeys:storageStatus";
function createTeamReadRecoveryBridge(invoke) {
  return {
    getData: (teamName, options) => invoke(
      TEAM_GET_DATA,
      ...options === void 0 ? [teamName] : [teamName, options]
    ),
    getMessagesPage: (teamName, options) => invoke(TEAM_GET_MESSAGES_PAGE, teamName, options),
    getMemberActivityMeta: (teamName) => invoke(TEAM_GET_MEMBER_ACTIVITY_META, teamName),
    getLogsForTask: (teamName, taskId, options) => invoke(TEAM_GET_LOGS_FOR_TASK, teamName, taskId, options)
  };
}
const TERMINAL_WORKSPACE_GET_BOOTSTRAP = "terminalWorkspace:getBootstrap";
const TERMINAL_WORKSPACE_STOP_TEAM = "terminalWorkspace:stopTeam";
function createTerminalWorkspaceBridge(ipcRenderer) {
  return {
    getBootstrap: (request) => ipcRenderer.invoke(
      TERMINAL_WORKSPACE_GET_BOOTSTRAP,
      request
    ),
    stopTeamRuntime: (teamName) => ipcRenderer.invoke(TERMINAL_WORKSPACE_STOP_TEAM, teamName)
  };
}
function createTmuxInstallerBridge({
  ipcRenderer,
  invokeIpcWithResult: invokeIpcWithResult2
}) {
  return {
    getStatus: () => invokeIpcWithResult2(TMUX_GET_STATUS),
    getInstallerSnapshot: () => invokeIpcWithResult2(TMUX_GET_INSTALLER_SNAPSHOT),
    install: () => invokeIpcWithResult2(TMUX_INSTALL),
    cancelInstall: () => invokeIpcWithResult2(TMUX_CANCEL_INSTALL),
    submitInstallerInput: (input) => invokeIpcWithResult2(TMUX_SUBMIT_INSTALLER_INPUT, input),
    invalidateStatus: () => invokeIpcWithResult2(TMUX_INVALIDATE_STATUS),
    onProgress: (callback) => {
      ipcRenderer.on(
        TMUX_INSTALLER_PROGRESS,
        callback
      );
      return () => {
        ipcRenderer.removeListener(
          TMUX_INSTALLER_PROGRESS,
          callback
        );
      };
    }
  };
}
const TOKEN_USAGE_GET_SNAPSHOT = "token-usage:get-snapshot";
const TOKEN_USAGE_REFRESH_SNAPSHOT = "token-usage:refresh-snapshot";
const TOKEN_USAGE_GET_BUDGET_SETTINGS = "token-usage:get-budget-settings";
const TOKEN_USAGE_UPDATE_BUDGET_SETTINGS = "token-usage:update-budget-settings";
const TOKEN_USAGE_SNAPSHOT_CHANGED = "token-usage:snapshot-changed";
const TOKEN_USAGE_GET_BUDGET_STATUS = "token-usage:get-budget-status";
const TOKEN_USAGE_BUDGET_STATUS_CHANGED = "token-usage:budget-status-changed";
function createTokenUsageBridge(ipcRenderer) {
  return {
    getSnapshot: (request) => ipcRenderer.invoke(TOKEN_USAGE_GET_SNAPSHOT, request),
    refreshSnapshot: (request) => ipcRenderer.invoke(TOKEN_USAGE_REFRESH_SNAPSHOT, request),
    getBudgetStatus: () => ipcRenderer.invoke(TOKEN_USAGE_GET_BUDGET_STATUS),
    onBudgetStatusChanged: (callback) => {
      const listener = (_event, status) => callback(status);
      ipcRenderer.on(TOKEN_USAGE_BUDGET_STATUS_CHANGED, listener);
      return () => ipcRenderer.removeListener(TOKEN_USAGE_BUDGET_STATUS_CHANGED, listener);
    },
    getBudgetSettings: () => ipcRenderer.invoke(TOKEN_USAGE_GET_BUDGET_SETTINGS),
    updateBudgetSettings: (settings) => ipcRenderer.invoke(TOKEN_USAGE_UPDATE_BUDGET_SETTINGS, settings),
    onSnapshotChanged: (callback) => {
      const listener = (_event, snapshot) => {
        callback(snapshot);
      };
      ipcRenderer.on(TOKEN_USAGE_SNAPSHOT_CHANGED, listener);
      return () => ipcRenderer.removeListener(TOKEN_USAGE_SNAPSHOT_CHANGED, listener);
    }
  };
}
const WORKSPACE_TRUST_GET_PROJECT_STATUS = "workspace-trust:get-project-status";
const WORKSPACE_TRUST_GET_LAUNCH_STATUS = "workspace-trust:get-launch-status";
function createWorkspaceTrustBridge(ipcRenderer) {
  return {
    workspaceTrust: {
      getLaunchStatus: (request) => ipcRenderer.invoke(WORKSPACE_TRUST_GET_LAUNCH_STATUS, request),
      getProjectStatus: (request) => ipcRenderer.invoke(WORKSPACE_TRUST_GET_PROJECT_STATUS, request)
    }
  };
}
const TEAMMATE_PARTICIPANT_COLOR_PALETTE = [
  "blue",
  "saffron",
  "turquoise",
  "brick",
  "indigo",
  "forest",
  "apricot",
  "rose",
  "cerulean",
  "olive",
  "copper",
  "steel"
];
const MEMBER_COLOR_PALETTE = [
  // ── First 12: paired with participant avatars 02-13 ──
  ...TEAMMATE_PARTICIPANT_COLOR_PALETTE,
  // ── Next 12: secondary accents after the core distinct set ──
  "gold",
  "emerald",
  "cobalt",
  "crimson",
  "tangerine",
  "denim",
  "cyan",
  "sage",
  "tomato",
  "rust",
  "mustard",
  "canary",
  "teal",
  "arctic",
  "royal",
  // ── Remaining: fill the hue gaps progressively ──
  "green",
  "pink",
  "ruby",
  // 92°
  "sienna",
  // 144°
  "mint",
  // 216°
  "sky",
  // 275°
  "sapphire",
  // 321°
  "yellow",
  // 13°
  "red",
  // 26°
  "orange",
  // 33°
  "coral",
  // 52°
  "scarlet",
  // 65°
  "salmon",
  // 79°
  "amber",
  // 98°
  "peach",
  // 111°
  "bronze",
  // 137°
  "lemon",
  // 157°
  "honey",
  // 170°
  "marigold",
  // 183°
  "sunflower",
  // 196°
  "lime",
  // 209°
  "jade",
  // 236°
  "chartreuse",
  // 249°
  "aqua",
  // 262°
  "azure",
  // 281°
  "seafoam",
  // 295°
  "periwinkle",
  // 327°
  "cornflower"
  // 353°
];
const MEMBER_COLOR_HUES_BY_ORDER = [
  240,
  60,
  180,
  0,
  120,
  300,
  30,
  210,
  330,
  90,
  150,
  270,
  15,
  195,
  105,
  285,
  45,
  225,
  135,
  315,
  75,
  255,
  165,
  345,
  7.5,
  187.5,
  97.5,
  277.5,
  37.5,
  217.5,
  127.5,
  307.5,
  67.5,
  247.5,
  157.5,
  337.5,
  22.5,
  202.5,
  112.5,
  292.5,
  52.5,
  232.5,
  142.5,
  322.5,
  82.5,
  262.5,
  172.5,
  352.5,
  11.25,
  191.25,
  101.25,
  281.25,
  41.25,
  221.25,
  131.25
];
Object.fromEntries(
  MEMBER_COLOR_PALETTE.map((colorName, index) => [colorName, MEMBER_COLOR_HUES_BY_ORDER[index]])
);
const WINDOW_ZOOM_FACTOR_CHANGED_CHANNEL = "window:zoom-factor-changed";
const WINDOW_SET_ZOOM_FACTOR_CHANNEL = "window:set-zoom-factor";
const TRIGGER_COLORS = [
  { key: "red", label: "Red", hex: "#ef4444" },
  { key: "orange", label: "Orange", hex: "#f97316" },
  { key: "yellow", label: "Yellow", hex: "#eab308" },
  { key: "green", label: "Green", hex: "#22c55e" },
  { key: "blue", label: "Blue", hex: "#3b82f6" },
  { key: "purple", label: "Purple", hex: "#a855f7" },
  { key: "pink", label: "Pink", hex: "#ec4899" },
  { key: "cyan", label: "Cyan", hex: "#06b6d4" }
];
new Map(TRIGGER_COLORS.map((c) => [c.key, c]));
function parseTeamMemberRestartResult(value) {
  if (!value || typeof value !== "object") throw new Error("Invalid member restart result");
  const result = value;
  if (result.status === "restarted") return { status: "restarted" };
  const keys = ["error", "teamName", "memberName", "predecessorRunId", "successorRunId"];
  if (result.status !== "failed_retained" && result.status !== "failed_restored" || keys.some((key) => typeof result[key] !== "string" || !result[key].trim()) || result.predecessorRunId === result.successorRunId)
    throw new Error("Invalid retained member restart result");
  return {
    status: result.status,
    error: result.error,
    teamName: result.teamName,
    memberName: result.memberName,
    predecessorRunId: result.predecessorRunId,
    successorRunId: result.successorRunId
  };
}
function formatConsoleArg(arg) {
  if (typeof arg === "string") return arg;
  if (arg instanceof Error) return arg.stack ?? arg.message;
  try {
    return JSON.stringify(arg);
  } catch {
    return String(arg);
  }
}
function shouldForwardConsoleText(text) {
  return /^\[[A-Za-z][A-Za-z0-9:_-]{0,79}\](?:\s|$)/.test(text);
}
const MAX_FORWARDED_RENDERER_LOG_CHARS = 16e3;
function installRendererLogForwarding() {
  const originalWarn = console.warn.bind(console);
  const originalError = console.error.bind(console);
  console.warn = (...args) => {
    originalWarn(...args);
    try {
      const text = args.map(formatConsoleArg).join(" ").trim();
      if (!text || !shouldForwardConsoleText(text)) return;
      electron.ipcRenderer.send(RENDERER_LOG, {
        level: "warn",
        message: text.slice(0, MAX_FORWARDED_RENDERER_LOG_CHARS)
      });
    } catch {
    }
  };
  console.error = (...args) => {
    originalError(...args);
    try {
      const text = args.map(formatConsoleArg).join(" ").trim();
      if (!text || !shouldForwardConsoleText(text)) return;
      electron.ipcRenderer.send(RENDERER_LOG, {
        level: "error",
        message: text.slice(0, MAX_FORWARDED_RENDERER_LOG_CHARS)
      });
    } catch {
    }
  };
}
const SENTRY_IPC_NAMESPACE = "sentry-ipc";
function createSentryIpcKey(channel) {
  return `${SENTRY_IPC_NAMESPACE}.${channel}`;
}
function installSentryRendererIpcBridge() {
  window.__SENTRY_IPC__ = window.__SENTRY_IPC__ || {};
  if (window.__SENTRY_IPC__[SENTRY_IPC_NAMESPACE]) {
    return;
  }
  window.__SENTRY_IPC__[SENTRY_IPC_NAMESPACE] = {
    sendRendererStart: () => electron.ipcRenderer.send(createSentryIpcKey("start")),
    sendScope: (scopeJson) => electron.ipcRenderer.send(createSentryIpcKey("scope"), scopeJson),
    sendEnvelope: (envelope) => electron.ipcRenderer.send(createSentryIpcKey("envelope"), envelope),
    sendStatus: (status) => electron.ipcRenderer.send(createSentryIpcKey("status"), status),
    sendStructuredLog: (log) => electron.ipcRenderer.send(createSentryIpcKey("structured-log"), log),
    sendMetric: (metric) => electron.ipcRenderer.send(createSentryIpcKey("metric"), metric)
  };
  electron.contextBridge.exposeInMainWorld("__SENTRY_IPC__", window.__SENTRY_IPC__);
}
const OPEN_CODE_STARTUP_CLEANUP_STATUS = "app:openCodeStartupCleanupStatus";
const OPEN_CODE_STARTUP_CLEANUP_RETRY = "app:retryOpenCodeStartupCleanup";
function createOpenCodeStartupCleanupAPI(ipc) {
  return {
    getOpenCodeCleanupStatus: () => ipc.invoke(OPEN_CODE_STARTUP_CLEANUP_STATUS),
    retryOpenCodeCleanup: () => ipc.invoke(OPEN_CODE_STARTUP_CLEANUP_RETRY)
  };
}
try {
  installSentryRendererIpcBridge();
} catch {
}
async function invokeIpcWithResult(channel, ...args) {
  const result = await electron.ipcRenderer.invoke(channel, ...args);
  if (!result.success) {
    throw new Error(result.error ?? "Unknown error");
  }
  return result.data;
}
installRendererLogForwarding();
electron.ipcRenderer.send(RENDERER_BOOT);
setInterval(() => {
  electron.ipcRenderer.send(RENDERER_HEARTBEAT, Date.now());
}, 1e3);
let currentZoomFactor = 1;
electron.ipcRenderer.on(
  WINDOW_ZOOM_FACTOR_CHANGED_CHANNEL,
  (_event, zoomFactor) => {
    if (typeof zoomFactor === "number" && Number.isFinite(zoomFactor)) {
      currentZoomFactor = zoomFactor;
    }
  }
);
const electronAPI = {
  agentBackend: createAgentBackendBridge(electron.ipcRenderer, electron.ipcRenderer, electron.ipcRenderer),
  externalAgentConnection: createExternalAgentConnectionBridge(electron.ipcRenderer),
  appCloseCoordination: createAppCloseCoordinationBridge(electron.ipcRenderer),
  ...createCodexAccountBridge({
    ipcRenderer: electron.ipcRenderer
  }),
  ...createRecentProjectsBridge(),
  teamGroupChats: createTeamGroupChatsBridge(),
  announcements: createAnnouncementsBridge(),
  gatewayProvider: createGatewayProviderBridge(),
  ...createWorkspaceTrustBridge(electron.ipcRenderer),
  ...createProjectFolderBridge(electron.ipcRenderer),
  teamImport: createTeamImportBridge(electron.ipcRenderer),
  runtimeProviderManagement: createRuntimeProviderManagementBridge(electron.ipcRenderer),
  memberWorkSync: createMemberWorkSyncBridge(electron.ipcRenderer),
  memberLogStream: createMemberLogStreamBridge(),
  organizations: createOrganizationsBridge(electron.ipcRenderer),
  terminalWorkspace: createTerminalWorkspaceBridge(electron.ipcRenderer),
  tokenUsage: createTokenUsageBridge(electron.ipcRenderer),
  telemetry: {
    getSentryContext: () => electron.ipcRenderer.invoke(TELEMETRY_GET_SENTRY_CONTEXT),
    getSentryStatus: () => electron.ipcRenderer.invoke(TELEMETRY_GET_SENTRY_STATUS)
  },
  startup: {
    ...createOpenCodeStartupCleanupAPI(electron.ipcRenderer),
    getStatus: () => electron.ipcRenderer.invoke(APP_STARTUP_GET_STATUS),
    onProgress: (callback) => {
      const listener = (_event, status) => {
        callback(status);
      };
      electron.ipcRenderer.on(APP_STARTUP_PROGRESS, listener);
      return () => {
        electron.ipcRenderer.removeListener(APP_STARTUP_PROGRESS, listener);
      };
    }
  },
  getAppVersion: () => electron.ipcRenderer.invoke("get-app-version"),
  getWindowsElevationStatus: () => electron.ipcRenderer.invoke(APP_GET_WINDOWS_ELEVATION_STATUS),
  getProjects: () => electron.ipcRenderer.invoke("get-projects"),
  getSessions: (projectId) => electron.ipcRenderer.invoke("get-sessions", projectId),
  getSessionsPaginated: (projectId, cursor, limit, options) => electron.ipcRenderer.invoke("get-sessions-paginated", projectId, cursor, limit, options),
  searchSessions: (projectId, query, maxResults) => electron.ipcRenderer.invoke("search-sessions", projectId, query, maxResults),
  searchAllProjects: (query, maxResults) => electron.ipcRenderer.invoke("search-all-projects", query, maxResults),
  getSessionDetail: (projectId, sessionId, options) => electron.ipcRenderer.invoke("get-session-detail", projectId, sessionId, options),
  getSessionMetrics: (projectId, sessionId) => electron.ipcRenderer.invoke("get-session-metrics", projectId, sessionId),
  getWaterfallData: (projectId, sessionId) => electron.ipcRenderer.invoke("get-waterfall-data", projectId, sessionId),
  getSubagentDetail: (projectId, sessionId, subagentId, options) => electron.ipcRenderer.invoke("get-subagent-detail", projectId, sessionId, subagentId, options),
  getSessionGroups: (projectId, sessionId) => electron.ipcRenderer.invoke("get-session-groups", projectId, sessionId),
  getSessionsByIds: (projectId, sessionIds, options) => electron.ipcRenderer.invoke("get-sessions-by-ids", projectId, sessionIds, options),
  // Repository grouping (worktree support)
  getRepositoryGroups: () => electron.ipcRenderer.invoke("get-repository-groups"),
  getWorktreeSessions: (worktreeId) => electron.ipcRenderer.invoke("get-worktree-sessions", worktreeId),
  // Validation methods
  validatePath: (relativePath, projectPath) => electron.ipcRenderer.invoke("validate-path", relativePath, projectPath),
  validateMentions: (mentions, projectPath) => electron.ipcRenderer.invoke("validate-mentions", mentions, projectPath),
  // CLAUDE.md reading methods
  readClaudeMdFiles: (projectRoot) => electron.ipcRenderer.invoke("read-claude-md-files", projectRoot),
  readDirectoryClaudeMd: (dirPath) => electron.ipcRenderer.invoke("read-directory-claude-md", dirPath),
  readMentionedFile: (absolutePath, projectRoot, maxTokens) => electron.ipcRenderer.invoke("read-mentioned-file", absolutePath, projectRoot, maxTokens),
  // Agent config reading
  readAgentConfigs: (projectRoot) => electron.ipcRenderer.invoke("read-agent-configs", projectRoot),
  // Notifications API
  notifications: {
    get: (options) => electron.ipcRenderer.invoke("notifications:get", options),
    markRead: (id) => electron.ipcRenderer.invoke("notifications:markRead", id),
    markAllRead: () => electron.ipcRenderer.invoke("notifications:markAllRead"),
    setViewedTeam: (teamName) => electron.ipcRenderer.invoke("notifications:setViewedTeam", teamName),
    delete: (id) => electron.ipcRenderer.invoke("notifications:delete", id),
    clear: () => electron.ipcRenderer.invoke("notifications:clear"),
    getUnreadCount: () => electron.ipcRenderer.invoke("notifications:getUnreadCount"),
    testNotification: () => electron.ipcRenderer.invoke("notifications:testNotification"),
    onNew: (callback) => {
      electron.ipcRenderer.on(
        "notification:new",
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          "notification:new",
          callback
        );
      };
    },
    onUpdated: (callback) => {
      electron.ipcRenderer.on(
        "notification:updated",
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          "notification:updated",
          callback
        );
      };
    },
    onClicked: (callback) => {
      electron.ipcRenderer.on(
        "notification:clicked",
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          "notification:clicked",
          callback
        );
      };
    }
  },
  // Config API - uses typed helper to unwrap { success, data, error } responses
  config: {
    get: async () => {
      return invokeIpcWithResult(CONFIG_GET);
    },
    update: async (section, data) => {
      return invokeIpcWithResult(CONFIG_UPDATE, section, data);
    },
    addIgnoreRegex: async (pattern) => {
      await invokeIpcWithResult(CONFIG_ADD_IGNORE_REGEX, pattern);
      return invokeIpcWithResult(CONFIG_GET);
    },
    removeIgnoreRegex: async (pattern) => {
      await invokeIpcWithResult(CONFIG_REMOVE_IGNORE_REGEX, pattern);
      return invokeIpcWithResult(CONFIG_GET);
    },
    addIgnoreRepository: async (repositoryId) => {
      await invokeIpcWithResult(CONFIG_ADD_IGNORE_REPOSITORY, repositoryId);
      return invokeIpcWithResult(CONFIG_GET);
    },
    removeIgnoreRepository: async (repositoryId) => {
      await invokeIpcWithResult(CONFIG_REMOVE_IGNORE_REPOSITORY, repositoryId);
      return invokeIpcWithResult(CONFIG_GET);
    },
    snooze: async (minutes) => {
      await invokeIpcWithResult(CONFIG_SNOOZE, minutes);
      return invokeIpcWithResult(CONFIG_GET);
    },
    clearSnooze: async () => {
      await invokeIpcWithResult(CONFIG_CLEAR_SNOOZE);
      return invokeIpcWithResult(CONFIG_GET);
    },
    addTrigger: async (trigger) => {
      await invokeIpcWithResult(CONFIG_ADD_TRIGGER, trigger);
      return invokeIpcWithResult(CONFIG_GET);
    },
    updateTrigger: async (triggerId, updates) => {
      await invokeIpcWithResult(CONFIG_UPDATE_TRIGGER, triggerId, updates);
      return invokeIpcWithResult(CONFIG_GET);
    },
    removeTrigger: async (triggerId) => {
      await invokeIpcWithResult(CONFIG_REMOVE_TRIGGER, triggerId);
      return invokeIpcWithResult(CONFIG_GET);
    },
    getTriggers: async () => {
      return invokeIpcWithResult(CONFIG_GET_TRIGGERS);
    },
    testTrigger: async (trigger) => {
      return invokeIpcWithResult(CONFIG_TEST_TRIGGER, trigger);
    },
    selectFolders: async () => {
      return invokeIpcWithResult(CONFIG_SELECT_FOLDERS);
    },
    selectClaudeRootFolder: async () => {
      return invokeIpcWithResult(
        CONFIG_SELECT_CLAUDE_ROOT_FOLDER
      );
    },
    getClaudeRootInfo: async () => {
      return invokeIpcWithResult(CONFIG_GET_CLAUDE_ROOT_INFO);
    },
    findWslClaudeRoots: async () => {
      return invokeIpcWithResult(CONFIG_FIND_WSL_CLAUDE_ROOTS);
    },
    openInEditor: async () => {
      return invokeIpcWithResult(CONFIG_OPEN_IN_EDITOR);
    },
    pinSession: async (projectId, sessionId) => {
      return invokeIpcWithResult(CONFIG_PIN_SESSION, projectId, sessionId);
    },
    unpinSession: async (projectId, sessionId) => {
      return invokeIpcWithResult(CONFIG_UNPIN_SESSION, projectId, sessionId);
    },
    hideSession: async (projectId, sessionId) => {
      return invokeIpcWithResult(CONFIG_HIDE_SESSION, projectId, sessionId);
    },
    unhideSession: async (projectId, sessionId) => {
      return invokeIpcWithResult(CONFIG_UNHIDE_SESSION, projectId, sessionId);
    },
    hideSessions: async (projectId, sessionIds) => {
      return invokeIpcWithResult(CONFIG_HIDE_SESSIONS, projectId, sessionIds);
    },
    unhideSessions: async (projectId, sessionIds) => {
      return invokeIpcWithResult(CONFIG_UNHIDE_SESSIONS, projectId, sessionIds);
    },
    addCustomProjectPath: async (projectPath) => {
      return invokeIpcWithResult(CONFIG_ADD_CUSTOM_PROJECT_PATH, projectPath);
    },
    removeCustomProjectPath: async (projectPath) => {
      return invokeIpcWithResult(CONFIG_REMOVE_CUSTOM_PROJECT_PATH, projectPath);
    }
  },
  // Deep link navigation
  session: {
    scrollToLine: (sessionId, lineNumber) => electron.ipcRenderer.invoke("session:scrollToLine", sessionId, lineNumber)
  },
  // Zoom factor sync (used for traffic-light-safe layout)
  getZoomFactor: async () => currentZoomFactor,
  setZoomFactor: (factor) => electron.ipcRenderer.invoke(WINDOW_SET_ZOOM_FACTOR_CHANNEL, factor),
  onZoomFactorChanged: (callback) => {
    const listener = (_event, zoomFactor) => {
      if (typeof zoomFactor !== "number" || !Number.isFinite(zoomFactor)) return;
      currentZoomFactor = zoomFactor;
      callback(zoomFactor);
    };
    electron.ipcRenderer.on(WINDOW_ZOOM_FACTOR_CHANGED_CHANNEL, listener);
    return () => {
      electron.ipcRenderer.removeListener(WINDOW_ZOOM_FACTOR_CHANGED_CHANNEL, listener);
    };
  },
  // File change events (real-time updates)
  onFileChange: (callback) => {
    const listener = (_event, data) => callback(data);
    electron.ipcRenderer.on("file-change", listener);
    return () => {
      electron.ipcRenderer.removeListener("file-change", listener);
    };
  },
  // Shell operations
  openPath: (targetPath, projectRoot, userSelectedFromDialog) => electron.ipcRenderer.invoke("shell:openPath", targetPath, projectRoot, userSelectedFromDialog),
  showInFolder: (filePath) => electron.ipcRenderer.invoke("shell:showInFolder", filePath),
  openExternal: (url) => electron.ipcRenderer.invoke("shell:openExternal", url),
  getDiscordMemberCount: () => electron.ipcRenderer.invoke("discord:getMemberCount"),
  // Window controls (when title bar is hidden, e.g. Windows / Linux)
  windowControls: {
    minimize: () => electron.ipcRenderer.invoke(WINDOW_MINIMIZE),
    maximize: () => electron.ipcRenderer.invoke(WINDOW_MAXIMIZE),
    close: () => electron.ipcRenderer.invoke(WINDOW_CLOSE),
    isMaximized: () => electron.ipcRenderer.invoke(WINDOW_IS_MAXIMIZED),
    isFullScreen: () => electron.ipcRenderer.invoke(WINDOW_IS_FULLSCREEN),
    relaunch: () => electron.ipcRenderer.invoke(APP_RELAUNCH)
  },
  onFullScreenChange: (callback) => {
    const listener = (_event, isFullScreen) => callback(isFullScreen);
    electron.ipcRenderer.on(WINDOW_FULLSCREEN_CHANGED, listener);
    return () => {
      electron.ipcRenderer.removeListener(WINDOW_FULLSCREEN_CHANGED, listener);
    };
  },
  onTodoChange: (callback) => {
    const listener = (_event, data) => callback(data);
    electron.ipcRenderer.on("todo-change", listener);
    return () => {
      electron.ipcRenderer.removeListener("todo-change", listener);
    };
  },
  // Updater API
  updater: {
    check: () => electron.ipcRenderer.invoke(UPDATER_CHECK),
    download: () => electron.ipcRenderer.invoke(UPDATER_DOWNLOAD),
    install: () => electron.ipcRenderer.invoke(UPDATER_INSTALL),
    onStatus: (callback) => {
      electron.ipcRenderer.on(
        UPDATER_STATUS,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          UPDATER_STATUS,
          callback
        );
      };
    }
  },
  // SSH API
  ssh: {
    connect: async (config) => {
      return invokeIpcWithResult(SSH_CONNECT, config);
    },
    disconnect: async () => {
      return invokeIpcWithResult(SSH_DISCONNECT);
    },
    getState: async () => {
      return invokeIpcWithResult(SSH_GET_STATE);
    },
    test: async (config) => {
      return invokeIpcWithResult(SSH_TEST, config);
    },
    getConfigHosts: async () => {
      return invokeIpcWithResult(SSH_GET_CONFIG_HOSTS);
    },
    resolveHost: async (alias) => {
      return invokeIpcWithResult(SSH_RESOLVE_HOST, alias);
    },
    saveLastConnection: async (config) => {
      return invokeIpcWithResult(SSH_SAVE_LAST_CONNECTION, config);
    },
    getLastConnection: async () => {
      return invokeIpcWithResult(SSH_GET_LAST_CONNECTION);
    },
    onStatus: (callback) => {
      electron.ipcRenderer.on(
        SSH_STATUS,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          SSH_STATUS,
          callback
        );
      };
    }
  },
  // Context API
  context: {
    list: async () => {
      return invokeIpcWithResult(CONTEXT_LIST);
    },
    getActive: async () => {
      return invokeIpcWithResult(CONTEXT_GET_ACTIVE);
    },
    switch: async (contextId) => {
      return invokeIpcWithResult(CONTEXT_SWITCH, contextId);
    },
    onChanged: (callback) => {
      electron.ipcRenderer.on(
        CONTEXT_CHANGED,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          CONTEXT_CHANGED,
          callback
        );
      };
    }
  },
  // HTTP Server API
  httpServer: {
    start: async () => {
      return invokeIpcWithResult(HTTP_SERVER_START);
    },
    stop: async () => {
      return invokeIpcWithResult(HTTP_SERVER_STOP);
    },
    getStatus: async () => {
      return invokeIpcWithResult(HTTP_SERVER_GET_STATUS);
    }
  },
  teams: {
    ...createTeamMemberSettingsBridge(invokeIpcWithResult),
    readRecovery: createTeamReadRecoveryBridge(
      (channel, ...args) => electron.ipcRenderer.invoke(channel, ...args)
    ),
    list: async () => {
      return invokeIpcWithResult(TEAM_LIST);
    },
    getData: async (teamName, options) => {
      if (options === void 0) {
        return invokeIpcWithResult(TEAM_GET_DATA, teamName);
      }
      return invokeIpcWithResult(TEAM_GET_DATA, teamName, options);
    },
    getTaskChangePresence: async (teamName) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_CHANGE_PRESENCE,
        teamName
      );
    },
    setChangePresenceTracking: async (teamName, enabled) => {
      return invokeIpcWithResult(TEAM_SET_CHANGE_PRESENCE_TRACKING, teamName, enabled);
    },
    setTaskLogStreamTracking: async (teamName, enabled) => {
      return invokeIpcWithResult(TEAM_SET_TASK_LOG_STREAM_TRACKING, teamName, enabled);
    },
    setToolActivityTracking: async (teamName, enabled) => {
      return invokeIpcWithResult(TEAM_SET_TOOL_ACTIVITY_TRACKING, teamName, enabled);
    },
    getClaudeLogs: async (teamName, query) => {
      return invokeIpcWithResult(TEAM_GET_CLAUDE_LOGS, teamName, query);
    },
    deleteTeam: async (teamName) => {
      return invokeIpcWithResult(TEAM_DELETE_TEAM, teamName);
    },
    restoreTeam: async (teamName) => {
      return invokeIpcWithResult(TEAM_RESTORE, teamName);
    },
    permanentlyDeleteTeam: async (teamName) => {
      return invokeIpcWithResult(TEAM_PERMANENTLY_DELETE, teamName);
    },
    getSavedRequest: async (teamName) => {
      return invokeIpcWithResult(TEAM_GET_SAVED_REQUEST, teamName);
    },
    deleteDraft: async (teamName) => {
      return invokeIpcWithResult(TEAM_DELETE_DRAFT, teamName);
    },
    prepareProvisioning: async (cwd, providerId, providerIds, selectedModels, limitContext, modelVerificationMode, selectedModelChecks, context) => {
      return invokeIpcWithResult(
        TEAM_PREPARE_PROVISIONING,
        cwd,
        providerId,
        providerIds,
        selectedModels,
        limitContext,
        modelVerificationMode,
        selectedModelChecks,
        ...context === void 0 ? [] : [context]
      );
    },
    getWorktreeGitStatus: async (projectPath) => {
      return invokeIpcWithResult(TEAM_GET_WORKTREE_GIT_STATUS, projectPath);
    },
    initializeGitRepository: async (projectPath) => {
      return invokeIpcWithResult(
        TEAM_INITIALIZE_GIT_REPOSITORY,
        projectPath
      );
    },
    createInitialGitCommit: async (projectPath) => {
      return invokeIpcWithResult(
        TEAM_CREATE_INITIAL_GIT_COMMIT,
        projectPath
      );
    },
    createTeam: async (request) => {
      return invokeIpcWithResult(TEAM_CREATE, request);
    },
    createTeamResult: (request) => electron.ipcRenderer.invoke(TEAM_CREATE, request),
    launchTeam: async (request) => {
      return invokeIpcWithResult(TEAM_LAUNCH, request);
    },
    getProvisioningStatus: async (runId) => {
      return invokeIpcWithResult(TEAM_PROVISIONING_STATUS, runId);
    },
    getLaunchFailureDiagnostics: async (teamName, runId) => {
      return invokeIpcWithResult(
        TEAM_LAUNCH_FAILURE_DIAGNOSTICS,
        teamName,
        runId
      );
    },
    cancelProvisioning: async (runId) => {
      return invokeIpcWithResult(TEAM_CANCEL_PROVISIONING, runId);
    },
    sendMessage: async (teamName, request) => {
      return invokeIpcWithResult(TEAM_SEND_MESSAGE, teamName, request);
    },
    getOpenCodeRuntimeDeliveryStatus: async (teamName, messageId) => {
      return invokeIpcWithResult(
        TEAM_GET_OPENCODE_RUNTIME_DELIVERY_STATUS,
        teamName,
        messageId
      );
    },
    getMessagesPage: async (teamName, options) => {
      return invokeIpcWithResult(TEAM_GET_MESSAGES_PAGE, teamName, options);
    },
    getMemberActivityMeta: async (teamName) => {
      return invokeIpcWithResult(TEAM_GET_MEMBER_ACTIVITY_META, teamName);
    },
    createTask: async (teamName, request) => {
      return invokeIpcWithResult(TEAM_CREATE_TASK, teamName, request);
    },
    getTask: async (teamName, taskId) => {
      return invokeIpcWithResult(TEAM_GET_TASK, teamName, taskId);
    },
    requestReview: async (teamName, taskId) => {
      return invokeIpcWithResult(TEAM_REQUEST_REVIEW, teamName, taskId);
    },
    updateKanban: async (teamName, taskId, patch) => {
      return invokeIpcWithResult(TEAM_UPDATE_KANBAN, teamName, taskId, patch);
    },
    updateKanbanColumnOrder: async (teamName, columnId, orderedTaskIds) => {
      return invokeIpcWithResult(
        TEAM_UPDATE_KANBAN_COLUMN_ORDER,
        teamName,
        columnId,
        orderedTaskIds
      );
    },
    updateTaskStatus: async (teamName, taskId, status) => {
      return invokeIpcWithResult(TEAM_UPDATE_TASK_STATUS, teamName, taskId, status);
    },
    updateTaskOwner: async (teamName, taskId, owner) => {
      return invokeIpcWithResult(TEAM_UPDATE_TASK_OWNER, teamName, taskId, owner);
    },
    updateTaskFields: async (teamName, taskId, fields) => {
      return invokeIpcWithResult(TEAM_UPDATE_TASK_FIELDS, teamName, taskId, fields);
    },
    startTask: async (teamName, taskId) => {
      return invokeIpcWithResult(TEAM_START_TASK, teamName, taskId);
    },
    startTaskByUser: async (teamName, taskId) => {
      return invokeIpcWithResult(
        TEAM_START_TASK_BY_USER,
        teamName,
        taskId
      );
    },
    processSend: async (teamName, message) => {
      return invokeIpcWithResult(TEAM_PROCESS_SEND, teamName, message);
    },
    processAlive: async (teamName) => {
      return invokeIpcWithResult(TEAM_PROCESS_ALIVE, teamName);
    },
    aliveList: async () => {
      return invokeIpcWithResult(TEAM_ALIVE_LIST);
    },
    stop: async (teamName) => {
      return invokeIpcWithResult(TEAM_STOP, teamName);
    },
    forceStop: async (teamName) => {
      return invokeIpcWithResult(TEAM_FORCE_STOP, teamName);
    },
    getQueuedUserMessages: async (teamName, memberName) => {
      return invokeIpcWithResult(
        TEAM_GET_QUEUED_USER_MESSAGES,
        teamName,
        memberName
      );
    },
    discardQueuedUserMessages: async (teamName, memberName, messageIds) => {
      return invokeIpcWithResult(
        TEAM_DISCARD_QUEUED_USER_MESSAGES,
        teamName,
        memberName,
        [...messageIds]
      );
    },
    createConfig: async (request) => {
      return invokeIpcWithResult(TEAM_CREATE_CONFIG, request);
    },
    createConfigResult: (request) => electron.ipcRenderer.invoke(TEAM_CREATE_CONFIG, request),
    getMemberLogs: async (teamName, memberName) => {
      return invokeIpcWithResult(TEAM_GET_MEMBER_LOGS, teamName, memberName);
    },
    getLogsForTask: async (teamName, taskId, options) => {
      return invokeIpcWithResult(
        TEAM_GET_LOGS_FOR_TASK,
        teamName,
        taskId,
        options
      );
    },
    getTaskActivity: async (teamName, taskId) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_ACTIVITY,
        teamName,
        taskId
      );
    },
    getTaskActivityDetail: async (teamName, taskId, activityId) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_ACTIVITY_DETAIL,
        teamName,
        taskId,
        activityId
      );
    },
    getTaskLogStreamSummary: async (teamName, taskId) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_LOG_STREAM_SUMMARY,
        teamName,
        taskId
      );
    },
    getTaskLogStream: async (teamName, taskId) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_LOG_STREAM,
        teamName,
        taskId
      );
    },
    getTaskExactLogSummaries: async (teamName, taskId) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_EXACT_LOG_SUMMARIES,
        teamName,
        taskId
      );
    },
    getTaskExactLogDetail: async (teamName, taskId, exactLogId, expectedSourceGeneration) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_EXACT_LOG_DETAIL,
        teamName,
        taskId,
        exactLogId,
        expectedSourceGeneration
      );
    },
    getMemberStats: async (teamName, memberName) => {
      return invokeIpcWithResult(TEAM_GET_MEMBER_STATS, teamName, memberName);
    },
    getAllTasks: async () => {
      return invokeIpcWithResult(TEAM_GET_ALL_TASKS);
    },
    updateConfig: async (teamName, updates) => {
      return invokeIpcWithResult(TEAM_UPDATE_CONFIG, teamName, updates);
    },
    addTaskComment: async (teamName, taskId, request) => {
      return invokeIpcWithResult(TEAM_ADD_TASK_COMMENT, teamName, taskId, request);
    },
    addMember: async (teamName, request) => {
      return invokeIpcWithResult(TEAM_ADD_MEMBER, teamName, request);
    },
    replaceMembers: async (teamName, request) => {
      return invokeIpcWithResult(TEAM_REPLACE_MEMBERS, teamName, request);
    },
    removeMember: async (teamName, memberName) => {
      return invokeIpcWithResult(TEAM_REMOVE_MEMBER, teamName, memberName);
    },
    restoreMember: async (teamName, memberName) => {
      return invokeIpcWithResult(TEAM_RESTORE_MEMBER, teamName, memberName);
    },
    updateMemberRole: async (teamName, memberName, role) => {
      return invokeIpcWithResult(TEAM_UPDATE_MEMBER_ROLE, teamName, memberName, role);
    },
    getProjectBranch: async (projectPath) => {
      return invokeIpcWithResult(TEAM_GET_PROJECT_BRANCH, projectPath);
    },
    setProjectBranchTracking: async (projectPath, enabled) => {
      return invokeIpcWithResult(TEAM_SET_PROJECT_BRANCH_TRACKING, projectPath, enabled);
    },
    getAttachments: async (teamName, messageId) => {
      return invokeIpcWithResult(TEAM_GET_ATTACHMENTS, teamName, messageId);
    },
    killProcess: async (teamName, pid) => {
      return invokeIpcWithResult(TEAM_KILL_PROCESS, teamName, pid);
    },
    getLeadActivity: async (teamName) => {
      return invokeIpcWithResult(TEAM_LEAD_ACTIVITY, teamName);
    },
    getLeadContext: async (teamName) => {
      return invokeIpcWithResult(TEAM_LEAD_CONTEXT, teamName);
    },
    getMemberSpawnStatuses: async (teamName) => {
      return invokeIpcWithResult(TEAM_MEMBER_SPAWN_STATUSES, teamName);
    },
    getTeamAgentRuntime: async (teamName) => {
      return invokeIpcWithResult(TEAM_GET_AGENT_RUNTIME, teamName);
    },
    retryFailedOpenCodeSecondaryLanes: async (teamName) => {
      return invokeIpcWithResult(
        TEAM_RETRY_FAILED_OPENCODE_SECONDARY_LANES,
        teamName
      );
    },
    restartMember: async (teamName, memberName, expectedSecondary) => {
      return parseTeamMemberRestartResult(
        await invokeIpcWithResult(
          TEAM_RESTART_MEMBER,
          teamName,
          memberName,
          ...expectedSecondary === void 0 ? [] : [expectedSecondary]
        )
      );
    },
    skipMemberForLaunch: async (teamName, memberName) => {
      return invokeIpcWithResult(TEAM_SKIP_MEMBER_FOR_LAUNCH, teamName, memberName);
    },
    softDeleteTask: async (teamName, taskId) => {
      return invokeIpcWithResult(TEAM_SOFT_DELETE_TASK, teamName, taskId);
    },
    restoreTask: async (teamName, taskId) => {
      return invokeIpcWithResult(TEAM_RESTORE_TASK, teamName, taskId);
    },
    getDeletedTasks: async (teamName) => {
      return invokeIpcWithResult(TEAM_GET_DELETED_TASKS, teamName);
    },
    setTaskClarification: async (teamName, taskId, value) => {
      return invokeIpcWithResult(TEAM_SET_TASK_CLARIFICATION, teamName, taskId, value);
    },
    showMessageNotification: async (data) => {
      return invokeIpcWithResult(TEAM_SHOW_MESSAGE_NOTIFICATION, data);
    },
    addTaskRelationship: async (teamName, taskId, targetId, type) => {
      return invokeIpcWithResult(
        TEAM_ADD_TASK_RELATIONSHIP,
        teamName,
        taskId,
        targetId,
        type
      );
    },
    removeTaskRelationship: async (teamName, taskId, targetId, type) => {
      return invokeIpcWithResult(
        TEAM_REMOVE_TASK_RELATIONSHIP,
        teamName,
        taskId,
        targetId,
        type
      );
    },
    saveTaskAttachment: async (teamName, taskId, attachmentId, filename, mimeType, base64Data) => {
      return invokeIpcWithResult(
        TEAM_SAVE_TASK_ATTACHMENT,
        teamName,
        taskId,
        attachmentId,
        filename,
        mimeType,
        base64Data
      );
    },
    getTaskAttachment: async (teamName, taskId, attachmentId, mimeType) => {
      return invokeIpcWithResult(
        TEAM_GET_TASK_ATTACHMENT,
        teamName,
        taskId,
        attachmentId,
        mimeType
      );
    },
    deleteTaskAttachment: async (teamName, taskId, attachmentId, mimeType) => {
      return invokeIpcWithResult(
        TEAM_DELETE_TASK_ATTACHMENT,
        teamName,
        taskId,
        attachmentId,
        mimeType
      );
    },
    onProjectBranchChange: (callback) => {
      electron.ipcRenderer.on(
        TEAM_PROJECT_BRANCH_CHANGE,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          TEAM_PROJECT_BRANCH_CHANGE,
          callback
        );
      };
    },
    onTeamChange: (callback) => {
      electron.ipcRenderer.on(
        TEAM_CHANGE,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          TEAM_CHANGE,
          callback
        );
      };
    },
    onProvisioningProgress: (callback) => {
      electron.ipcRenderer.on(
        TEAM_PROVISIONING_PROGRESS,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          TEAM_PROVISIONING_PROGRESS,
          callback
        );
      };
    },
    respondToToolApproval: async (teamName, runId, requestId, allow, message) => {
      return invokeIpcWithResult(
        TEAM_TOOL_APPROVAL_RESPOND,
        teamName,
        runId,
        requestId,
        allow,
        message
      );
    },
    validateCliArgs: async (rawArgs) => {
      return invokeIpcWithResult(TEAM_VALIDATE_CLI_ARGS, rawArgs);
    },
    onToolApprovalEvent: (callback) => {
      electron.ipcRenderer.on(
        TEAM_TOOL_APPROVAL_EVENT,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          TEAM_TOOL_APPROVAL_EVENT,
          callback
        );
      };
    },
    updateToolApprovalSettings: async (teamName, settings) => {
      return invokeIpcWithResult(TEAM_TOOL_APPROVAL_SETTINGS, teamName, settings);
    },
    readFileForToolApproval: async (filePath) => {
      return invokeIpcWithResult(TEAM_TOOL_APPROVAL_READ_FILE, filePath);
    }
  },
  crossTeam: {
    send: async (request) => {
      return invokeIpcWithResult(CROSS_TEAM_SEND, request);
    },
    listTargets: async (excludeTeam) => {
      return invokeIpcWithResult(CROSS_TEAM_LIST_TARGETS, excludeTeam);
    },
    getOutbox: async (teamName) => {
      return invokeIpcWithResult(CROSS_TEAM_GET_OUTBOX, teamName);
    }
  },
  review: {
    getAgentChanges: async (teamName, memberName) => {
      return invokeIpcWithResult(REVIEW_GET_AGENT_CHANGES, teamName, memberName);
    },
    getTaskChanges: async (teamName, taskId, options) => {
      return invokeIpcWithResult(
        REVIEW_GET_TASK_CHANGES,
        teamName,
        taskId,
        options
      );
    },
    getTeamTaskChangeSummaries: async (teamName, requests) => {
      return invokeIpcWithResult(
        REVIEW_GET_TEAM_TASK_CHANGE_SUMMARIES,
        teamName,
        requests
      );
    },
    invalidateTaskChangeSummaries: async (teamName, taskIds) => {
      return invokeIpcWithResult(REVIEW_INVALIDATE_TASK_CHANGE_SUMMARIES, teamName, taskIds);
    },
    getChangeStats: async (teamName, memberName) => {
      return invokeIpcWithResult(REVIEW_GET_CHANGE_STATS, teamName, memberName);
    },
    getFileContent: async (teamName, memberName, filePath, snippets = []) => {
      return invokeIpcWithResult(
        REVIEW_GET_FILE_CONTENT,
        teamName,
        memberName ?? "",
        filePath,
        snippets
      );
    },
    applyDecisions: async (request) => {
      return invokeIpcWithResult(REVIEW_APPLY_DECISIONS, request);
    },
    executeMutation: async (request) => {
      return invokeIpcWithResult(REVIEW_EXECUTE_MUTATION, request);
    },
    retryMutationRecovery: async (request) => {
      return invokeIpcWithResult(
        REVIEW_RETRY_MUTATION_RECOVERY,
        request
      );
    },
    restoreHistory: async (request) => {
      return invokeIpcWithResult(REVIEW_RESTORE_HISTORY, request);
    },
    // Phase 2
    checkConflict: async (scope, filePath, expectedModified) => {
      return invokeIpcWithResult(
        REVIEW_CHECK_CONFLICT,
        scope,
        filePath,
        expectedModified
      );
    },
    rejectHunks: async (scope, filePath, hunkIndices) => {
      return invokeIpcWithResult(REVIEW_REJECT_HUNKS, scope, filePath, hunkIndices);
    },
    rejectFile: async (scope, filePath) => {
      return invokeIpcWithResult(REVIEW_REJECT_FILE, scope, filePath);
    },
    previewReject: async (filePath, original, modified, hunkIndices, snippets) => {
      return invokeIpcWithResult(
        REVIEW_PREVIEW_REJECT,
        filePath,
        original,
        modified,
        hunkIndices,
        snippets
      );
    },
    // Editable diff
    saveEditedFile: async (scope, filePath, content, expectedCurrentContent) => {
      return invokeIpcWithResult(
        REVIEW_SAVE_EDITED_FILE,
        scope,
        filePath,
        content,
        expectedCurrentContent
      );
    },
    deleteEditedFile: async (scope, filePath, expectedCurrentContent) => {
      return invokeIpcWithResult(
        REVIEW_DELETE_EDITED_FILE,
        scope,
        filePath,
        expectedCurrentContent
      );
    },
    restoreRejectedRename: async (scope, filePath, expectation) => {
      return invokeIpcWithResult(
        REVIEW_RESTORE_REJECTED_RENAME,
        scope,
        filePath,
        expectation
      );
    },
    reapplyRejectedRename: async (scope, filePath, expectation) => {
      return invokeIpcWithResult(
        REVIEW_REAPPLY_REJECTED_RENAME,
        scope,
        filePath,
        expectation
      );
    },
    watchFiles: async (projectPath, filePaths) => {
      return invokeIpcWithResult(REVIEW_WATCH_FILES, projectPath, filePaths);
    },
    unwatchFiles: async () => {
      return invokeIpcWithResult(REVIEW_UNWATCH_FILES);
    },
    onExternalFileChange: (callback) => {
      const handler = (_event, data) => callback(data);
      electron.ipcRenderer.on(REVIEW_FILE_CHANGE, handler);
      return () => {
        electron.ipcRenderer.removeListener(REVIEW_FILE_CHANGE, handler);
      };
    },
    // Decision persistence
    loadDecisions: async (teamName, scopeKey, scopeToken) => {
      return invokeIpcWithResult(REVIEW_LOAD_DECISIONS, teamName, scopeKey, scopeToken ?? null);
    },
    saveDecisions: async (teamName, scopeKey, scopeToken, hunkDecisions, fileDecisions, hunkContextHashesByFile, reviewActionHistory, expectedRevision, reviewRedoHistory) => {
      return invokeIpcWithResult(
        REVIEW_SAVE_DECISIONS,
        teamName,
        scopeKey,
        scopeToken,
        hunkDecisions,
        fileDecisions,
        hunkContextHashesByFile ?? null,
        reviewActionHistory ?? [],
        expectedRevision,
        reviewRedoHistory ?? []
      );
    },
    clearDecisions: async (teamName, scopeKey, scopeToken, expectedRevision) => {
      return invokeIpcWithResult(
        REVIEW_CLEAR_DECISIONS,
        teamName,
        scopeKey,
        scopeToken ?? null,
        expectedRevision
      );
    },
    loadDecisionConflictCandidates: async (teamName, scopeKey, scopeToken) => {
      return invokeIpcWithResult(
        REVIEW_LOAD_DECISION_CONFLICT_CANDIDATES,
        teamName,
        scopeKey,
        scopeToken
      );
    },
    resolveDecisionConflictCandidate: async (teamName, scopeKey, scopeToken, candidateId, resolution, expectedCurrentRevision) => {
      return invokeIpcWithResult(
        REVIEW_RESOLVE_DECISION_CONFLICT_CANDIDATE,
        teamName,
        scopeKey,
        scopeToken,
        candidateId,
        resolution,
        expectedCurrentRevision
      );
    },
    loadDraftHistory: async (teamName, scopeKey, scopeToken) => {
      return invokeIpcWithResult(
        REVIEW_LOAD_DRAFT_HISTORY,
        teamName,
        scopeKey,
        scopeToken
      );
    },
    saveDraftHistoryEntry: async (teamName, scopeKey, scopeToken, entry, expectedRevision, expectedGeneration) => {
      return invokeIpcWithResult(
        REVIEW_SAVE_DRAFT_HISTORY_ENTRY,
        teamName,
        scopeKey,
        scopeToken,
        entry,
        expectedRevision,
        expectedGeneration
      );
    },
    clearDraftHistory: async (teamName, scopeKey, scopeToken, filePath, expectedRevision, expectedGeneration) => {
      return invokeIpcWithResult(
        REVIEW_CLEAR_DRAFT_HISTORY,
        teamName,
        scopeKey,
        scopeToken,
        filePath ?? null,
        expectedRevision ?? null,
        expectedGeneration ?? null
      );
    },
    loadDraftHistoryConflictCandidates: async (teamName, scopeKey, scopeToken) => {
      return invokeIpcWithResult(
        REVIEW_LOAD_DRAFT_HISTORY_CONFLICT_CANDIDATES,
        teamName,
        scopeKey,
        scopeToken
      );
    },
    resolveDraftHistoryConflictCandidate: async (teamName, scopeKey, scopeToken, candidateId, resolution, expectedCurrentRevision, expectedCurrentGeneration) => {
      return invokeIpcWithResult(
        REVIEW_RESOLVE_DRAFT_HISTORY_CONFLICT_CANDIDATE,
        teamName,
        scopeKey,
        scopeToken,
        candidateId,
        resolution,
        expectedCurrentRevision,
        expectedCurrentGeneration
      );
    },
    replaceDraftHistoryConflictCandidate: async (teamName, scopeKey, scopeToken, expectedEntry, replacementEntry, expectedCurrentRevision, expectedCurrentGeneration) => {
      return invokeIpcWithResult(
        REVIEW_REPLACE_DRAFT_HISTORY_CONFLICT_CANDIDATE,
        teamName,
        scopeKey,
        scopeToken,
        expectedEntry,
        replacementEntry,
        expectedCurrentRevision,
        expectedCurrentGeneration
      );
    },
    onCmdN: (callback) => {
      const handler = () => callback();
      electron.ipcRenderer.on("review:cmdN", handler);
      return () => {
        electron.ipcRenderer.removeListener("review:cmdN", handler);
      };
    },
    // Phase 4
    getGitFileLog: async (projectPath, filePath) => {
      return invokeIpcWithResult(
        REVIEW_GET_GIT_FILE_LOG,
        projectPath,
        filePath
      );
    }
  },
  // ===== CLI Installer API =====
  cliInstaller: {
    getStatus: async (options) => {
      return invokeIpcWithResult(CLI_INSTALLER_GET_STATUS, options);
    },
    getProviderStatus: async (providerId, options) => {
      return invokeIpcWithResult(CLI_INSTALLER_GET_PROVIDER_STATUS, providerId, options);
    },
    verifyProviderModels: async (providerId) => {
      return invokeIpcWithResult(CLI_INSTALLER_VERIFY_PROVIDER_MODELS, providerId);
    },
    install: async () => {
      return invokeIpcWithResult(CLI_INSTALLER_INSTALL);
    },
    invalidateStatus: async () => {
      return invokeIpcWithResult(CLI_INSTALLER_INVALIDATE_STATUS);
    },
    onProgress: (callback) => {
      electron.ipcRenderer.on(
        CLI_INSTALLER_PROGRESS,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          CLI_INSTALLER_PROGRESS,
          callback
        );
      };
    }
  },
  // ===== OpenCode Runtime Installer API =====
  openCodeRuntime: {
    platform: process.platform,
    arch: process.arch,
    getStatus: async () => {
      return invokeIpcWithResult(OPENCODE_RUNTIME_GET_STATUS);
    },
    install: async (options) => {
      return invokeIpcWithResult(OPENCODE_RUNTIME_INSTALL, options);
    },
    invalidateStatus: async (mode) => {
      return mode === void 0 ? invokeIpcWithResult(OPENCODE_RUNTIME_INVALIDATE_STATUS) : invokeIpcWithResult(OPENCODE_RUNTIME_INVALIDATE_STATUS, mode);
    },
    onProgress: (callback) => {
      electron.ipcRenderer.on(
        OPENCODE_RUNTIME_PROGRESS,
        callback
      );
      return () => {
        electron.ipcRenderer.removeListener(
          OPENCODE_RUNTIME_PROGRESS,
          callback
        );
      };
    }
  },
  // ===== Codex Runtime Installer API =====
  codexRuntime: createCodexRuntimeInstallerBridge({ ipcRenderer: electron.ipcRenderer, invokeIpcWithResult }),
  tmux: createTmuxInstallerBridge({ ipcRenderer: electron.ipcRenderer, invokeIpcWithResult }),
  // ===== Terminal API =====
  terminal: {
    spawn: (options) => invokeIpcWithResult(TERMINAL_SPAWN, options),
    write: (ptyId, data) => electron.ipcRenderer.send(TERMINAL_WRITE, ptyId, data),
    resize: (ptyId, cols, rows) => electron.ipcRenderer.send(TERMINAL_RESIZE, ptyId, cols, rows),
    kill: (ptyId) => electron.ipcRenderer.send(TERMINAL_KILL, ptyId),
    onData: (cb) => {
      electron.ipcRenderer.on(
        TERMINAL_DATA,
        cb
      );
      return () => {
        electron.ipcRenderer.removeListener(
          TERMINAL_DATA,
          cb
        );
      };
    },
    onExit: (cb) => {
      electron.ipcRenderer.on(
        TERMINAL_EXIT,
        cb
      );
      return () => {
        electron.ipcRenderer.removeListener(
          TERMINAL_EXIT,
          cb
        );
      };
    }
  },
  // ===== Project API (editor-independent) =====
  project: {
    listFiles: (projectPath) => invokeIpcWithResult(PROJECT_LIST_FILES, projectPath)
  },
  // ===== Editor API =====
  editor: {
    ...createDocumentPreviewBridge(),
    open: (projectPath) => invokeIpcWithResult(EDITOR_OPEN, projectPath),
    close: () => invokeIpcWithResult(EDITOR_CLOSE),
    readDir: (dirPath, maxEntries) => invokeIpcWithResult(EDITOR_READ_DIR, dirPath, maxEntries),
    readFile: (filePath) => invokeIpcWithResult(EDITOR_READ_FILE, filePath),
    writeFile: (filePath, content, baselineMtimeMs) => invokeIpcWithResult(EDITOR_WRITE_FILE, filePath, content, baselineMtimeMs),
    createFile: (parentDir, fileName) => invokeIpcWithResult(EDITOR_CREATE_FILE, parentDir, fileName),
    createDir: (parentDir, dirName) => invokeIpcWithResult(EDITOR_CREATE_DIR, parentDir, dirName),
    deleteFile: (filePath) => invokeIpcWithResult(EDITOR_DELETE_FILE, filePath),
    moveFile: (sourcePath, destDir) => invokeIpcWithResult(EDITOR_MOVE_FILE, sourcePath, destDir),
    renameFile: (sourcePath, newName) => invokeIpcWithResult(EDITOR_RENAME_FILE, sourcePath, newName),
    searchInFiles: (options) => invokeIpcWithResult(EDITOR_SEARCH_IN_FILES, options),
    listFiles: () => invokeIpcWithResult(EDITOR_LIST_FILES),
    readBinaryPreview: (filePath) => invokeIpcWithResult(EDITOR_READ_BINARY_PREVIEW, filePath),
    gitStatus: () => invokeIpcWithResult(EDITOR_GIT_STATUS),
    watchDir: (enable) => invokeIpcWithResult(EDITOR_WATCH_DIR, enable),
    setWatchedFiles: (filePaths) => invokeIpcWithResult(EDITOR_SET_WATCHED_FILES, filePaths),
    setWatchedDirs: (dirPaths) => invokeIpcWithResult(EDITOR_SET_WATCHED_DIRS, dirPaths),
    onEditorChange: (callback) => {
      const listener = (_event, data) => callback(data);
      electron.ipcRenderer.on(EDITOR_CHANGE, listener);
      return () => {
        electron.ipcRenderer.removeListener(EDITOR_CHANGE, listener);
      };
    }
  },
  schedules: {
    list: () => invokeIpcWithResult(SCHEDULE_LIST),
    get: (id) => invokeIpcWithResult(SCHEDULE_GET, id),
    create: (input) => invokeIpcWithResult(SCHEDULE_CREATE, input),
    update: (id, patch) => invokeIpcWithResult(SCHEDULE_UPDATE, id, patch),
    delete: (id) => invokeIpcWithResult(SCHEDULE_DELETE, id),
    pause: (id) => invokeIpcWithResult(SCHEDULE_PAUSE, id),
    resume: (id) => invokeIpcWithResult(SCHEDULE_RESUME, id),
    triggerNow: (id) => invokeIpcWithResult(SCHEDULE_TRIGGER_NOW, id),
    getRuns: (scheduleId, opts) => invokeIpcWithResult(SCHEDULE_GET_RUNS, scheduleId, opts),
    getRunLogs: (scheduleId, runId) => invokeIpcWithResult(
      SCHEDULE_GET_RUN_LOGS,
      scheduleId,
      runId
    ),
    onScheduleChange: (callback) => {
      const listener = (_event, data) => callback(null, data);
      electron.ipcRenderer.on(SCHEDULE_CHANGE, listener);
      return () => {
        electron.ipcRenderer.removeListener(SCHEDULE_CHANGE, listener);
      };
    }
  },
  // ===== Plugin Catalog API (Electron-only) =====
  plugins: {
    getAll: (projectPath, forceRefresh) => invokeIpcWithResult(PLUGIN_GET_ALL, projectPath, forceRefresh),
    getReadme: (pluginId) => invokeIpcWithResult(PLUGIN_GET_README, pluginId),
    install: (request) => invokeIpcWithResult(PLUGIN_INSTALL, request),
    uninstall: (pluginId, scope, projectPath) => invokeIpcWithResult(PLUGIN_UNINSTALL, pluginId, scope, projectPath)
  },
  // ===== MCP Registry API (Electron-only) =====
  mcpRegistry: {
    search: (query, limit) => invokeIpcWithResult(MCP_REGISTRY_SEARCH, query, limit),
    browse: (cursor, limit) => invokeIpcWithResult(
      MCP_REGISTRY_BROWSE,
      cursor,
      limit
    ),
    getById: (registryId) => invokeIpcWithResult(MCP_REGISTRY_GET_BY_ID, registryId),
    getInstalled: (projectPath) => invokeIpcWithResult(MCP_REGISTRY_GET_INSTALLED, projectPath),
    diagnose: (projectPath) => invokeIpcWithResult(MCP_REGISTRY_DIAGNOSE, projectPath),
    install: (request) => invokeIpcWithResult(MCP_REGISTRY_INSTALL, request),
    installCustom: (request) => invokeIpcWithResult(MCP_REGISTRY_INSTALL_CUSTOM, request),
    uninstall: (name, scope, projectPath) => invokeIpcWithResult(MCP_REGISTRY_UNINSTALL, name, scope, projectPath),
    githubStars: (repositoryUrls) => invokeIpcWithResult(MCP_GITHUB_STARS, repositoryUrls)
  },
  // ===== Skills Catalog API (Electron-only) =====
  skills: {
    list: (projectPath) => invokeIpcWithResult(SKILLS_LIST, projectPath),
    getDetail: (skillId, projectPath) => invokeIpcWithResult(SKILLS_GET_DETAIL, skillId, projectPath),
    previewUpsert: (request) => invokeIpcWithResult(SKILLS_PREVIEW_UPSERT, request),
    applyUpsert: (request) => invokeIpcWithResult(SKILLS_APPLY_UPSERT, request),
    previewImport: (request) => invokeIpcWithResult(SKILLS_PREVIEW_IMPORT, request),
    applyImport: (request) => invokeIpcWithResult(SKILLS_APPLY_IMPORT, request),
    deleteSkill: (request) => invokeIpcWithResult(SKILLS_DELETE, request),
    startWatching: (projectPath) => invokeIpcWithResult(SKILLS_START_WATCHING, projectPath),
    stopWatching: (watchId) => invokeIpcWithResult(SKILLS_STOP_WATCHING, watchId),
    onChanged: (callback) => {
      const listener = (_event, data) => callback(data);
      electron.ipcRenderer.on(SKILLS_CHANGED, listener);
      return () => {
        electron.ipcRenderer.removeListener(SKILLS_CHANGED, listener);
      };
    }
  },
  // ===== API Keys API (Electron-only) =====
  apiKeys: {
    list: () => invokeIpcWithResult(API_KEYS_LIST),
    save: (request) => invokeIpcWithResult(API_KEYS_SAVE, request),
    delete: (id) => invokeIpcWithResult(API_KEYS_DELETE, id),
    lookup: (envVarNames, projectPath) => invokeIpcWithResult(API_KEYS_LOOKUP, envVarNames, projectPath),
    getStorageStatus: () => invokeIpcWithResult(API_KEYS_STORAGE_STATUS)
  },
  getPathForFile: (file) => electron.webUtils.getPathForFile(file)
};
electron.contextBridge.exposeInMainWorld("electronAPI", electronAPI);
