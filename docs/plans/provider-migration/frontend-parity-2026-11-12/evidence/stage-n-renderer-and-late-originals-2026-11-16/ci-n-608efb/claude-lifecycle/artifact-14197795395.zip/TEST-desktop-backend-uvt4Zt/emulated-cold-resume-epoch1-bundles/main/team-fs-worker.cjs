for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const node_worker_threads = require("node:worker_threads");
const taskHistory = require("./chunks/taskHistory-2kbwfqIg.cjs");
const teamTaskSnapshotCompaction = require("./chunks/teamTaskSnapshotCompaction-mUovQwio.cjs");
require("crypto");
require("fs");
require("path");
require("node:fs/promises");
require("os");
require("node:async_hooks");
require("node:os");
require("node:perf_hooks");
require("node:child_process");
require("node:stream");
require("node:events");
require("node:util");
require("node:diagnostics_channel");
require("node:module");
require("node:process");
require("fs/promises");
require("events");
require("child_process");
require("util");
require("async_hooks");
require("buffer");
require("net");
require("module");
require("url");
require("readline");
require("string_decoder");
require("node:buffer");
require("node:timers/promises");
require("node:url");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const fs__namespace = /* @__PURE__ */ _interopNamespaceDefault(fs);
const path__namespace = /* @__PURE__ */ _interopNamespaceDefault(path);
function unescapeLiteralNewlines(text) {
  return text.replace(/\\n/g, "\n").replace(/\\t/g, "	");
}
function compactWorkerTaskProjection(task) {
  return teamTaskSnapshotCompaction.compactTeamTaskForSnapshot(task);
}
const MAX_LAUNCH_STATE_BYTES = 32 * 1024;
const TEAM_LAUNCH_STATE_FILE = "launch-state.json";
const REVIEW_RESET_STATUSES = /* @__PURE__ */ new Set(["in_progress", "deleted"]);
const TEAM_SUMMARY_CACHE_MAX_ENTRIES = 1e3;
const TASK_FILE_CACHE_MAX_ENTRIES = 512;
const TASK_FILE_CACHE_MAX_BYTES = 32 * 1024 * 1024;
const TASK_FILE_CACHE_MAX_ENTRY_BYTES = 3 * 1024 * 1024;
const PERSISTENT_TASK_PROJECTION_CACHE_VERSION = 1;
const PERSISTENT_TASK_PROJECTION_CACHE_DIR = "v1";
const MAX_PERSISTENT_TASK_PROJECTION_CACHE_BYTES = 16 * 1024 * 1024;
const CACHEABLE_TASK_SKIP_REASONS = /* @__PURE__ */ new Set(["task_internal", "task_deleted"]);
const BOOTSTRAP_STATE_FILE = "bootstrap-state.json";
const BOOTSTRAP_JOURNAL_FILE = "bootstrap-journal.jsonl";
const teamSummaryCache = /* @__PURE__ */ new Map();
const taskFileCache = /* @__PURE__ */ new Map();
let taskFileCacheBytes = 0;
function isAbortError(error) {
  return !!error && typeof error === "object" && "name" in error && error.name === "AbortError";
}
async function readFileUtf8WithTimeout(filePath, timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fs__namespace.promises.readFile(filePath, { encoding: "utf8", signal: controller.signal });
  } catch (error) {
    if (isAbortError(error)) {
      const err = new Error("READ_TIMEOUT");
      err.code = "READ_TIMEOUT";
      throw err;
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function readFileHeadUtf8(filePath, maxBytes) {
  const handle = await fs__namespace.promises.open(filePath, "r");
  try {
    const stat = await handle.stat();
    const bytesToRead = Math.max(0, Math.min(stat.size, maxBytes));
    if (bytesToRead === 0) return "";
    const buffer = Buffer.alloc(bytesToRead);
    await handle.read(buffer, 0, bytesToRead, 0);
    return buffer.toString("utf8");
  } finally {
    await handle.close();
  }
}
function extractQuotedString(head, key) {
  const re = new RegExp(`"${key}"\\s*:\\s*("(?:\\\\.|[^"\\\\])*")`);
  const match = re.exec(head);
  if (!match?.[1]) return null;
  try {
    const value = JSON.parse(match[1]);
    return typeof value === "string" ? value : null;
  } catch {
    return null;
  }
}
async function mapLimit(items, limit, fn) {
  const results = new Array(items.length);
  let index = 0;
  const workerCount = Math.max(1, Math.min(limit, items.length));
  const workers = new Array(workerCount).fill(0).map(async () => {
    while (true) {
      const i = index++;
      if (i >= items.length) return;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}
function nowMs() {
  return Date.now();
}
function bumpSkipReason(reasons, reason) {
  reasons[reason] = (reasons[reason] || 0) + 1;
}
function pushSlowest(list, entry, maxLen) {
  list.push(entry);
  list.sort((a, b) => b.ms - a.ms);
  if (list.length > maxLen) list.length = maxLen;
}
function cloneCached(value) {
  return typeof structuredClone === "function" ? structuredClone(value) : JSON.parse(JSON.stringify(value));
}
function dateFromFingerprintMs(ms) {
  if (typeof ms !== "number" || !Number.isFinite(ms) || ms <= 0) {
    return null;
  }
  const date = new Date(ms);
  return Number.isFinite(date.getTime()) ? date : null;
}
async function statPathFingerprint(filePath) {
  try {
    const stat = await fs__namespace.promises.stat(filePath, { bigint: true });
    const mtimeNs = typeof stat.mtimeNs === "bigint" ? stat.mtimeNs : void 0;
    const ctimeNs = typeof stat.ctimeNs === "bigint" ? stat.ctimeNs : void 0;
    const birthtimeNs = typeof stat.birthtimeNs === "bigint" ? stat.birthtimeNs : void 0;
    return {
      exists: true,
      isFile: stat.isFile(),
      isDirectory: stat.isDirectory(),
      highResolution: typeof mtimeNs === "bigint" && typeof ctimeNs === "bigint",
      size: stat.size.toString(),
      mode: stat.mode.toString(),
      dev: stat.dev.toString(),
      ino: stat.ino.toString(),
      mtimeNs: mtimeNs?.toString(),
      ctimeNs: ctimeNs?.toString(),
      birthtimeNs: birthtimeNs?.toString(),
      mtimeMs: Number(stat.mtimeMs),
      ctimeMs: Number(stat.ctimeMs),
      birthtimeMs: Number(stat.birthtimeMs)
    };
  } catch (error) {
    return {
      exists: false,
      errorCode: typeof error?.code === "string" ? error.code : void 0
    };
  }
}
function fingerprintToString(value) {
  return JSON.stringify(value);
}
function isCacheSafeFingerprint(fingerprint) {
  if (fingerprint.exists) {
    return fingerprint.highResolution === true;
  }
  return fingerprint.errorCode === "ENOENT" || fingerprint.errorCode === "ENOTDIR";
}
function makeTeamSummaryOptionKey(payload) {
  return fingerprintToString({
    largeConfigBytes: payload.largeConfigBytes,
    configHeadBytes: payload.configHeadBytes,
    maxConfigBytes: payload.maxConfigBytes,
    maxConfigReadMs: payload.maxConfigReadMs,
    maxMembersMetaBytes: payload.maxMembersMetaBytes,
    maxSessionHistoryInSummary: payload.maxSessionHistoryInSummary,
    maxProjectPathHistoryInSummary: payload.maxProjectPathHistoryInSummary
  });
}
function makeTeamSummaryCacheKey(teamsDir, teamName, optionKey) {
  return `${teamsDir}\0${teamName}\0${optionKey}`;
}
function canCacheTeamSummary(summary) {
  if (summary.teamLaunchState === "partial_pending") {
    return false;
  }
  const pendingKeys = [
    "pendingCount",
    "runtimeAlivePendingCount",
    "shellOnlyPendingCount",
    "runtimeProcessPendingCount",
    "runtimeCandidatePendingCount",
    "noRuntimePendingCount",
    "permissionPendingCount"
  ];
  return pendingKeys.every((key) => {
    const value = summary[key];
    return typeof value !== "number" || value <= 0;
  });
}
async function readInboxNamesFingerprint(inboxDir) {
  const dir = await statPathFingerprint(inboxDir);
  if (!dir.exists || !dir.isDirectory) {
    return { dir, names: [], cacheSafe: isCacheSafeFingerprint(dir) };
  }
  try {
    const entries = await fs__namespace.promises.readdir(inboxDir, { withFileTypes: true });
    const names = entries.filter((entry) => entry.isFile() && entry.name.endsWith(".json")).map((entry) => entry.name).sort();
    return { dir, names, cacheSafe: isCacheSafeFingerprint(dir) };
  } catch (error) {
    return {
      dir: {
        ...dir,
        errorCode: typeof error?.code === "string" ? error.code : "READDIR_FAILED"
      },
      names: [],
      cacheSafe: false
    };
  }
}
async function buildTeamSummaryFingerprint(teamsDir, teamName, optionKey) {
  const teamDir = path__namespace.join(teamsDir, teamName);
  const [
    config,
    teamMeta,
    membersMeta,
    launchState,
    launchSummary,
    bootstrapState,
    bootstrapJournal
  ] = await Promise.all([
    statPathFingerprint(path__namespace.join(teamDir, "config.json")),
    statPathFingerprint(path__namespace.join(teamDir, "team.meta.json")),
    statPathFingerprint(path__namespace.join(teamDir, "members.meta.json")),
    statPathFingerprint(path__namespace.join(teamDir, TEAM_LAUNCH_STATE_FILE)),
    statPathFingerprint(path__namespace.join(teamDir, taskHistory.TEAM_LAUNCH_SUMMARY_FILE)),
    statPathFingerprint(path__namespace.join(teamDir, BOOTSTRAP_STATE_FILE)),
    statPathFingerprint(path__namespace.join(teamDir, BOOTSTRAP_JOURNAL_FILE))
  ]);
  const inbox = await readInboxNamesFingerprint(path__namespace.join(teamDir, "inboxes"));
  const dependencyFingerprint = {
    version: 1,
    optionKey,
    config,
    teamMeta,
    membersMeta,
    launchState,
    launchSummary,
    bootstrapState,
    bootstrapJournal,
    inbox
  };
  return {
    value: fingerprintToString(dependencyFingerprint),
    cacheSafe: [
      config,
      teamMeta,
      membersMeta,
      launchState,
      launchSummary,
      bootstrapState,
      bootstrapJournal
    ].every(isCacheSafeFingerprint) && inbox.cacheSafe
  };
}
async function cacheTeamSummaryIfStable(cacheKey, teamsDir, teamName, optionKey, fingerprintBefore, summary, cacheAllowed, diag) {
  if (!cacheAllowed) {
    teamSummaryCache.delete(cacheKey);
    diag.cacheWriteSkips++;
    return;
  }
  if (!canCacheTeamSummary(summary)) {
    teamSummaryCache.delete(cacheKey);
    diag.cacheWriteSkips++;
    return;
  }
  if (!fingerprintBefore.cacheSafe) {
    diag.cacheWriteSkips++;
    return;
  }
  const fingerprintAfter = await buildTeamSummaryFingerprint(teamsDir, teamName, optionKey);
  if (!fingerprintAfter.cacheSafe || fingerprintAfter.value !== fingerprintBefore.value) {
    diag.cacheWriteSkips++;
    return;
  }
  teamSummaryCache.set(cacheKey, {
    fingerprint: fingerprintAfter.value,
    summary: cloneCached(summary),
    teamsDir,
    optionKey,
    lastUsedAt: nowMs()
  });
}
function pruneTeamSummaryCache(teamsDir, optionKey, liveTeamNames, diag) {
  for (const [key, entry] of teamSummaryCache) {
    if (entry.teamsDir === teamsDir && entry.optionKey === optionKey) {
      const teamName = key.split("\0")[1] ?? "";
      if (!liveTeamNames.has(teamName)) {
        teamSummaryCache.delete(key);
        diag.cacheEvictions++;
      }
    }
  }
  while (teamSummaryCache.size > TEAM_SUMMARY_CACHE_MAX_ENTRIES) {
    const oldest = teamSummaryCache.keys().next().value;
    if (typeof oldest !== "string") break;
    teamSummaryCache.delete(oldest);
    diag.cacheEvictions++;
  }
}
function makeTaskOptionKey(payload) {
  return fingerprintToString({
    maxTaskBytes: payload.maxTaskBytes,
    maxTaskReadMs: payload.maxTaskReadMs
  });
}
function makeTaskCacheKey(tasksBase, teamName, fileName, optionKey) {
  return `${tasksBase}\0${teamName}\0${fileName}\0${optionKey}`;
}
function deleteTaskFileCacheEntry(cacheKey, diag) {
  const cached = taskFileCache.get(cacheKey);
  if (!cached) {
    return;
  }
  taskFileCacheBytes = Math.max(0, taskFileCacheBytes - cached.estimatedBytes);
  taskFileCache.delete(cacheKey);
  if (diag) {
    diag.cacheEvictions++;
  }
}
function evictOldestTaskFileCacheEntry(diag) {
  const oldest = taskFileCache.keys().next().value;
  if (typeof oldest !== "string") {
    return false;
  }
  deleteTaskFileCacheEntry(oldest, diag);
  return true;
}
function trimTaskFileCache(diag) {
  while (taskFileCache.size > TASK_FILE_CACHE_MAX_ENTRIES || taskFileCacheBytes > TASK_FILE_CACHE_MAX_BYTES) {
    if (!evictOldestTaskFileCacheEntry(diag)) {
      return;
    }
  }
}
function setTaskFileCacheEntry(cacheKey, entry, taskDiag, diag) {
  const estimatedBytes = taskHistory.estimateCachedValueBytes(entry.result);
  deleteTaskFileCacheEntry(cacheKey);
  if (estimatedBytes > TASK_FILE_CACHE_MAX_ENTRY_BYTES) {
    taskDiag.cacheWriteSkips++;
    return false;
  }
  taskFileCache.set(cacheKey, {
    ...entry,
    estimatedBytes
  });
  taskFileCacheBytes += estimatedBytes;
  trimTaskFileCache(diag);
  return true;
}
async function cacheTaskReadResultIfStable(cacheKey, taskPath, tasksBase, fingerprintBefore, fingerprintBeforeCacheSafe, result, taskDiag) {
  if (!fingerprintBeforeCacheSafe) {
    taskDiag.cacheWriteSkips++;
    return false;
  }
  const after = await statPathFingerprint(taskPath);
  if (!isCacheSafeFingerprint(after) || fingerprintToString(after) !== fingerprintBefore) {
    taskDiag.cacheWriteSkips++;
    return false;
  }
  return setTaskFileCacheEntry(
    cacheKey,
    {
      fingerprint: fingerprintBefore,
      result: cloneCached(result),
      tasksBase,
      lastUsedAt: nowMs()
    },
    taskDiag
  );
}
function applyCachedTaskReadResult(cached, tasks, taskDiag) {
  if (cached.skipReason) {
    taskDiag.skipped++;
    bumpSkipReason(taskDiag.skipReasons, cached.skipReason);
    return;
  }
  tasks.push(cached.task);
}
function pruneTaskFileCache(tasksBase, liveCacheKeys, diag) {
  for (const [key, entry] of taskFileCache) {
    if (entry.tasksBase === tasksBase && !liveCacheKeys.has(key)) {
      deleteTaskFileCacheEntry(key, diag);
    }
  }
  trimTaskFileCache(diag);
}
function getPersistentTaskProjectionCachePath(payload, teamName) {
  const base = typeof payload.projectionCacheBase === "string" ? payload.projectionCacheBase : "";
  if (!base.trim()) return null;
  const digest = crypto.createHash("sha256").update(payload.tasksBase).update("\0").update(teamName).digest("hex");
  return path__namespace.join(base, PERSISTENT_TASK_PROJECTION_CACHE_DIR, `${digest}.json`);
}
function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function isSafeTaskProjectionFileName(file) {
  return file.endsWith(".json") && !file.startsWith(".") && !file.includes("/") && !file.includes("\\") && file !== ".lock" && file !== ".highwatermark";
}
function normalizePersistentTaskReadResult(value, teamName) {
  if (!isRecord(value)) return null;
  const skipReason = value.skipReason;
  if (typeof skipReason === "string") {
    return CACHEABLE_TASK_SKIP_REASONS.has(skipReason) ? { skipReason } : null;
  }
  const task = value.task;
  if (!isRecord(task)) return null;
  if (task.teamName !== teamName) return null;
  if (typeof task.id !== "string") return null;
  if (typeof task.subject !== "string") return null;
  const status = task.status === "pending" || task.status === "in_progress" || task.status === "completed" || task.status === "deleted" ? task.status : null;
  if (!status) return null;
  if (status === "deleted") return null;
  return { task: restorePersistentTaskProjectionShape(task, teamName, status) };
}
function restorePersistentTaskProjectionShape(task, teamName, status) {
  const id = typeof task.id === "string" ? task.id : "";
  const subject = typeof task.subject === "string" ? task.subject : "";
  const displayId = task.displayId;
  const reviewState = normalizeFallbackReviewState(task.reviewState, status);
  return compactWorkerTaskProjection({
    id,
    displayId: typeof displayId === "string" && displayId.trim().length > 0 ? displayId.trim() : teamTaskSnapshotCompaction.deriveTaskDisplayId(id),
    subject,
    description: typeof task.description === "string" ? task.description : void 0,
    groupChatId: typeof task.groupChatId === "string" ? task.groupChatId : void 0,
    descriptionTaskRefs: Array.isArray(task.descriptionTaskRefs) ? task.descriptionTaskRefs : void 0,
    activeForm: typeof task.activeForm === "string" ? task.activeForm : void 0,
    prompt: typeof task.prompt === "string" ? task.prompt : void 0,
    promptTaskRefs: Array.isArray(task.promptTaskRefs) ? task.promptTaskRefs : void 0,
    owner: typeof task.owner === "string" ? task.owner : void 0,
    createdBy: typeof task.createdBy === "string" ? task.createdBy : void 0,
    status,
    workIntervals: normalizeWorkIntervals(task),
    reviewIntervals: normalizeReviewIntervals(task),
    historyEvents: normalizeHistoryEvents(task),
    blocks: Array.isArray(task.blocks) ? task.blocks : void 0,
    blockedBy: Array.isArray(task.blockedBy) ? task.blockedBy : void 0,
    related: Array.isArray(task.related) ? task.related.filter((id2) => typeof id2 === "string") : void 0,
    createdAt: typeof task.createdAt === "string" ? task.createdAt : void 0,
    updatedAt: typeof task.updatedAt === "string" ? task.updatedAt : void 0,
    projectPath: typeof task.projectPath === "string" ? task.projectPath : void 0,
    comments: normalizeComments(task),
    needsClarification: task.needsClarification === "lead" || task.needsClarification === "user" ? task.needsClarification : void 0,
    reviewState,
    deletedAt: void 0,
    attachments: Array.isArray(task.attachments) ? task.attachments : void 0,
    sourceMessageId: typeof task.sourceMessageId === "string" && task.sourceMessageId.trim() ? task.sourceMessageId.trim() : void 0,
    sourceMessage: isRecord(task.sourceMessage) && typeof task.sourceMessage.text === "string" && typeof task.sourceMessage.from === "string" && typeof task.sourceMessage.timestamp === "string" ? task.sourceMessage : void 0,
    teamName
  });
}
function normalizePersistentTaskProjectionEntry(value, teamName) {
  if (!isRecord(value) || typeof value.fingerprint !== "string") return null;
  const result = normalizePersistentTaskReadResult(value.result, teamName);
  return result ? { fingerprint: value.fingerprint, result } : null;
}
async function readPersistentTaskProjectionCache(payload, teamName, optionKey, taskDiag) {
  const cachePath = getPersistentTaskProjectionCachePath(payload, teamName);
  if (!cachePath) return null;
  try {
    const stat = await fs__namespace.promises.stat(cachePath);
    if (!stat.isFile() || stat.size > MAX_PERSISTENT_TASK_PROJECTION_CACHE_BYTES) {
      taskDiag.persistentCacheReadFailures++;
      await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
      return null;
    }
    const raw = await fs__namespace.promises.readFile(cachePath, "utf8");
    const parsed = JSON.parse(raw);
    if (!isRecord(parsed)) {
      taskDiag.persistentCacheReadFailures++;
      await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
      return null;
    }
    if (parsed.version !== PERSISTENT_TASK_PROJECTION_CACHE_VERSION || parsed.tasksBase !== payload.tasksBase || parsed.teamName !== teamName || parsed.optionKey !== optionKey) {
      taskDiag.persistentCacheMisses++;
      await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
      return null;
    }
    if (!isRecord(parsed.entries)) {
      taskDiag.persistentCacheReadFailures++;
      await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
      return null;
    }
    const entries = /* @__PURE__ */ new Map();
    for (const [file, entry] of Object.entries(parsed.entries)) {
      if (!isSafeTaskProjectionFileName(file)) continue;
      const normalized = normalizePersistentTaskProjectionEntry(entry, teamName);
      if (normalized) {
        entries.set(file, normalized);
      }
    }
    taskDiag.persistentCacheLoads++;
    return entries;
  } catch (error) {
    if (error?.code === "ENOENT") {
      return null;
    }
    taskDiag.persistentCacheReadFailures++;
    await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
    return null;
  }
}
function shouldWritePersistentTaskProjectionCache(previous, next, taskDiag) {
  if (next.size === 0) return false;
  if (!previous) return true;
  if (previous.size !== next.size) return true;
  return taskDiag.persistentCacheMisses > 0 || taskDiag.cacheMisses > 0;
}
async function writePersistentTaskProjectionCache(payload, teamName, optionKey, entries, taskDiag) {
  const cachePath = getPersistentTaskProjectionCachePath(payload, teamName);
  if (!cachePath || entries.size === 0) return;
  const body = {
    version: PERSISTENT_TASK_PROJECTION_CACHE_VERSION,
    tasksBase: payload.tasksBase,
    teamName,
    optionKey,
    writtenAt: nowMs(),
    entries: Object.fromEntries(entries)
  };
  const raw = JSON.stringify(body);
  if (Buffer.byteLength(raw, "utf8") > MAX_PERSISTENT_TASK_PROJECTION_CACHE_BYTES) {
    taskDiag.persistentCacheWriteFailures++;
    await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
    return;
  }
  try {
    await taskHistory.atomicWriteAsync(cachePath, raw);
    taskDiag.persistentCacheWrites++;
  } catch {
    taskDiag.persistentCacheWriteFailures++;
  }
}
function isRawMember(v) {
  return !!v && typeof v === "object";
}
function normalizeProjectPathCandidate(value) {
  if (typeof value !== "string") {
    return void 0;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : void 0;
}
function getRawConfigMembers(config) {
  if (!Array.isArray(config.members)) {
    return [];
  }
  return config.members.filter(isRawMember);
}
function resolveProjectPathFromConfig(config) {
  const direct = normalizeProjectPathCandidate(config.projectPath);
  if (direct) {
    return direct;
  }
  const members = getRawConfigMembers(config);
  const leadMemberCwd = members.find((member) => taskHistory.isLeadMember(member))?.cwd;
  const leadResolved = normalizeProjectPathCandidate(leadMemberCwd);
  if (leadResolved) {
    return leadResolved;
  }
  const distinctMemberCwds = Array.from(
    new Set(
      members.map((member) => normalizeProjectPathCandidate(member.cwd)).filter((cwd) => Boolean(cwd))
    )
  );
  if (distinctMemberCwds.length === 1) {
    return distinctMemberCwds[0];
  }
  if (Array.isArray(config.projectPathHistory)) {
    for (let i = config.projectPathHistory.length - 1; i >= 0; i -= 1) {
      const historyValue = normalizeProjectPathCandidate(config.projectPathHistory[i]);
      if (historyValue) {
        return historyValue;
      }
    }
  }
  return void 0;
}
function mergeMember(m, memberMap, removedKeys) {
  const name = typeof m.name === "string" ? m.name.trim() : "";
  if (!name) return;
  if (name === "user" || taskHistory.isLeadMember(m)) return;
  const key = name.toLowerCase();
  if (removedKeys.has(key)) return;
  const existing = memberMap.get(key);
  memberMap.set(key, {
    name: existing?.name ?? name,
    role: typeof m.role === "string" && m.role.trim() || existing?.role,
    color: typeof m.color === "string" && m.color.trim() || existing?.color
  });
}
function dropCliAutoSuffixedMembers(memberMap) {
  const keys = Array.from(memberMap.keys());
  const allLower = new Set(keys);
  for (const key of keys) {
    const member = memberMap.get(key);
    const name = member?.name ?? "";
    const match = /^(.+)-(\d+)$/.exec(name.trim());
    if (!match?.[1] || !match[2]) continue;
    const suffix = Number(match[2]);
    if (!Number.isFinite(suffix) || suffix < 2) continue;
    const baseLower = match[1].toLowerCase();
    if (allLower.has(baseLower)) {
      memberMap.delete(key);
    }
  }
}
const PROVISIONER_SUFFIX = "-provisioner";
function dropCliProvisionerMembers(memberMap) {
  for (const [key, member] of Array.from(memberMap.entries())) {
    const lower = member.name.trim().toLowerCase();
    if (!lower.endsWith(PROVISIONER_SUFFIX)) continue;
    const base = lower.slice(0, -PROVISIONER_SUFFIX.length);
    if (base) {
      memberMap.delete(key);
    }
  }
}
async function readLaunchState(teamsDir, teamName) {
  const bootstrapSnapshot = await taskHistory.readBootstrapLaunchSnapshot(teamName);
  const launchStatePath = path__namespace.join(teamsDir, teamName, TEAM_LAUNCH_STATE_FILE);
  const launchSummaryPath = path__namespace.join(teamsDir, teamName, taskHistory.TEAM_LAUNCH_SUMMARY_FILE);
  const [launchSnapshot, launchSummaryProjection] = await Promise.all([
    (async () => {
      try {
        const stat = await fs__namespace.promises.stat(launchStatePath);
        if (!stat.isFile() || stat.size > MAX_LAUNCH_STATE_BYTES) {
          return null;
        }
        const raw = await fs__namespace.promises.readFile(launchStatePath, "utf8");
        return taskHistory.normalizePersistedLaunchSnapshot(teamName, JSON.parse(raw));
      } catch {
        return null;
      }
    })(),
    (async () => {
      try {
        const stat = await fs__namespace.promises.stat(launchSummaryPath);
        if (!stat.isFile() || stat.size > MAX_LAUNCH_STATE_BYTES) {
          return null;
        }
        const raw = await fs__namespace.promises.readFile(launchSummaryPath, "utf8");
        return taskHistory.normalizePersistedLaunchSummaryProjection(teamName, JSON.parse(raw));
      } catch {
        return null;
      }
    })()
  ]);
  const summary = taskHistory.choosePreferredLaunchStateSummary({
    bootstrapSnapshot,
    launchSnapshot,
    launchSummaryProjection
  });
  if (launchSnapshot) {
    return { summary, cacheable: true };
  }
  if (!bootstrapSnapshot) {
    return { summary, cacheable: true };
  }
  if (bootstrapSnapshot.launchPhase === "finished" && bootstrapSnapshot.teamLaunchState !== "partial_pending") {
    return { summary, cacheable: true };
  }
  return { summary, cacheable: false };
}
async function readDraftTeamMeta(teamsDir, teamName, options) {
  const metaPath = path__namespace.join(teamsDir, teamName, "team.meta.json");
  try {
    const stat = await fs__namespace.promises.stat(metaPath);
    if (!stat.isFile() || stat.size > 256 * 1024) return null;
    const raw = await readFileUtf8WithTimeout(metaPath, options.maxConfigReadMs);
    const meta = JSON.parse(raw);
    if (meta?.version !== 1 || typeof meta?.cwd !== "string") return null;
    const displayName = typeof meta.displayName === "string" && meta.displayName.trim() ? meta.displayName.trim() : teamName;
    let memberCount = 0;
    let leadName;
    let leadColor;
    try {
      const membersPath = path__namespace.join(teamsDir, teamName, "members.meta.json");
      const membersStat = await fs__namespace.promises.stat(membersPath);
      if (!membersStat.isFile() || membersStat.size > options.maxMembersMetaBytes) {
        throw new Error("members_meta_too_large");
      }
      const membersRaw = await readFileUtf8WithTimeout(membersPath, options.maxConfigReadMs);
      const membersData = JSON.parse(membersRaw);
      if (Array.isArray(membersData?.members)) {
        memberCount = membersData.members.filter((member) => {
          if (!isRawMember(member)) return false;
          const name = typeof member.name === "string" ? member.name.trim() : "";
          if (!member.removedAt && taskHistory.isLeadMember(member)) {
            if (name) {
              leadName = name;
            }
            const color = typeof member.color === "string" ? member.color.trim() : "";
            if (color) {
              leadColor = color;
            }
          }
          if (!name || name === "user" || taskHistory.isLeadMember(member)) return false;
          return !member.removedAt;
        }).length;
      }
    } catch {
    }
    return {
      teamName,
      displayName,
      description: typeof meta.description === "string" ? meta.description : "",
      memberCount,
      taskCount: 0,
      lastActivity: typeof meta.createdAt === "number" ? new Date(meta.createdAt).toISOString() : null,
      color: typeof meta.color === "string" ? meta.color : void 0,
      ...leadName ? { leadName } : {},
      ...leadColor ? { leadColor } : {},
      projectPath: typeof meta.cwd === "string" ? meta.cwd : void 0,
      pendingCreate: true,
      deletedAt: typeof meta.deletedAt === "string" ? meta.deletedAt : void 0
    };
  } catch {
    return null;
  }
}
async function listTeams(payload) {
  const startedAt = nowMs();
  const diag = {
    op: "listTeams",
    startedAt,
    teamsDir: payload.teamsDir,
    totalDirs: 0,
    returned: 0,
    skipped: 0,
    skipReasons: {},
    slowest: [],
    cacheHits: 0,
    cacheMisses: 0,
    cacheWriteSkips: 0,
    cacheEvictions: 0,
    totalMs: 0
  };
  let entries;
  try {
    entries = await fs__namespace.promises.readdir(payload.teamsDir, { withFileTypes: true });
  } catch {
    diag.totalMs = nowMs() - startedAt;
    return { teams: [], diag };
  }
  const teamDirs = entries.filter((e) => e.isDirectory());
  diag.totalDirs = teamDirs.length;
  const optionKey = makeTeamSummaryOptionKey(payload);
  const liveTeamNames = new Set(teamDirs.map((entry) => entry.name));
  const perTeam = await mapLimit(teamDirs, payload.concurrency, async (entry) => {
    const teamName = entry.name;
    const t0 = nowMs();
    const configPath = path__namespace.join(payload.teamsDir, teamName, "config.json");
    const cacheKey = makeTeamSummaryCacheKey(payload.teamsDir, teamName, optionKey);
    const dependencyFingerprint = await buildTeamSummaryFingerprint(
      payload.teamsDir,
      teamName,
      optionKey
    );
    const cached = teamSummaryCache.get(cacheKey);
    if (dependencyFingerprint.cacheSafe && cached?.fingerprint === dependencyFingerprint.value) {
      cached.lastUsedAt = nowMs();
      diag.cacheHits++;
      return cached.summary;
    }
    diag.cacheMisses++;
    const skip = (reason) => {
      diag.skipped++;
      bumpSkipReason(diag.skipReasons, reason);
      return null;
    };
    let stat;
    try {
      stat = await fs__namespace.promises.stat(configPath);
    } catch {
      const draft = await readDraftTeamMeta(payload.teamsDir, teamName, payload);
      if (draft) {
        await cacheTeamSummaryIfStable(
          cacheKey,
          payload.teamsDir,
          teamName,
          optionKey,
          dependencyFingerprint,
          draft,
          true,
          diag
        );
        return draft;
      }
      return skip("config_stat_failed");
    }
    if (!stat.isFile()) {
      const draft = await readDraftTeamMeta(payload.teamsDir, teamName, payload);
      if (draft) {
        await cacheTeamSummaryIfStable(
          cacheKey,
          payload.teamsDir,
          teamName,
          optionKey,
          dependencyFingerprint,
          draft,
          true,
          diag
        );
        return draft;
      }
      return skip("config_not_file");
    }
    if (stat.size > payload.maxConfigBytes) return skip("config_too_large");
    let config = null;
    let displayName = null;
    let description = "";
    let color;
    let projectPath;
    let leadSessionId;
    let deletedAt;
    let projectPathHistory;
    let sessionHistory;
    try {
      if (stat.size > payload.largeConfigBytes) {
        const head = await readFileHeadUtf8(configPath, payload.configHeadBytes);
        displayName = extractQuotedString(head, "name");
        const desc = extractQuotedString(head, "description");
        description = typeof desc === "string" ? desc : "";
        const c = extractQuotedString(head, "color");
        color = typeof c === "string" && c.trim().length > 0 ? c : void 0;
        const pp = extractQuotedString(head, "projectPath");
        projectPath = typeof pp === "string" && pp.trim().length > 0 ? pp : void 0;
        const lead = extractQuotedString(head, "leadSessionId");
        leadSessionId = typeof lead === "string" && lead.trim().length > 0 ? lead : void 0;
        const del = extractQuotedString(head, "deletedAt");
        deletedAt = typeof del === "string" ? del : void 0;
      } else {
        const raw = await readFileUtf8WithTimeout(configPath, payload.maxConfigReadMs);
        config = JSON.parse(raw);
        displayName = typeof config.name === "string" ? config.name : null;
        description = typeof config.description === "string" ? config.description : "";
        color = typeof config.color === "string" && config.color.trim().length > 0 ? config.color : void 0;
        projectPath = resolveProjectPathFromConfig(config);
        leadSessionId = typeof config.leadSessionId === "string" && config.leadSessionId.trim().length > 0 ? config.leadSessionId : void 0;
        projectPathHistory = Array.isArray(config.projectPathHistory) ? config.projectPathHistory.slice(-payload.maxProjectPathHistoryInSummary) : void 0;
        sessionHistory = Array.isArray(config.sessionHistory) ? config.sessionHistory.slice(-payload.maxSessionHistoryInSummary) : void 0;
        deletedAt = typeof config.deletedAt === "string" ? config.deletedAt : void 0;
      }
    } catch (error) {
      const code = error.code;
      if (code === "READ_TIMEOUT") return skip("config_read_timeout");
      return skip("config_parse_failed");
    }
    if (typeof displayName !== "string" || displayName.trim() === "") {
      return skip("invalid_display_name");
    }
    const memberMap = /* @__PURE__ */ new Map();
    const removedKeys = /* @__PURE__ */ new Set();
    const expectedTeammateNames = /* @__PURE__ */ new Set();
    const confirmedArtifactNames = /* @__PURE__ */ new Set();
    const metaRuntimeMembers = [];
    let leadProviderId;
    let leadName;
    let leadColor;
    const captureLeadMember = (member, overwrite = false) => {
      if (member.removedAt) return;
      if (!taskHistory.isLeadMember(member)) return;
      const name = typeof member.name === "string" ? member.name.trim() : "";
      if (name && (overwrite || !leadName)) {
        leadName = name;
      }
      const colorValue = typeof member.color === "string" ? member.color.trim() : "";
      if (colorValue && (overwrite || !leadColor)) {
        leadColor = colorValue;
      }
    };
    try {
      const teamMetaPath = path__namespace.join(payload.teamsDir, teamName, "team.meta.json");
      const teamMetaStat = await fs__namespace.promises.stat(teamMetaPath);
      if (teamMetaStat.isFile() && teamMetaStat.size <= 256 * 1024) {
        const raw = await readFileUtf8WithTimeout(teamMetaPath, payload.maxConfigReadMs);
        const parsed = JSON.parse(raw);
        leadProviderId = parsed?.providerId === "anthropic" || parsed?.providerId === "codex" || parsed?.providerId === "gemini" || parsed?.providerId === "opencode" ? parsed.providerId : void 0;
      }
    } catch {
      leadProviderId = void 0;
    }
    try {
      const metaPath = path__namespace.join(payload.teamsDir, teamName, "members.meta.json");
      const metaStat = await fs__namespace.promises.stat(metaPath);
      if (metaStat.isFile() && metaStat.size <= payload.maxMembersMetaBytes) {
        const raw = await readFileUtf8WithTimeout(metaPath, payload.maxConfigReadMs);
        const parsed = JSON.parse(raw);
        const members2 = Array.isArray(parsed?.members) ? parsed.members : [];
        for (const member of members2) {
          if (!isRawMember(member)) continue;
          const rawProviderId = member.providerId ?? member.provider;
          const providerId = rawProviderId === "anthropic" || rawProviderId === "codex" || rawProviderId === "gemini" || rawProviderId === "opencode" ? rawProviderId : void 0;
          const name = typeof member.name === "string" ? member.name.trim() : "";
          if (!name) continue;
          captureLeadMember(member);
          if (taskHistory.isLeadMember(member)) continue;
          const key = name.toLowerCase();
          if (member.removedAt) {
            removedKeys.add(key);
            metaRuntimeMembers.push({
              name,
              providerId,
              removedAt: member.removedAt
            });
            continue;
          }
          expectedTeammateNames.add(name);
          metaRuntimeMembers.push({
            name,
            providerId
          });
          mergeMember(member, memberMap, removedKeys);
        }
      }
    } catch {
    }
    if (config && Array.isArray(config.members)) {
      for (const member of config.members) {
        if (isRawMember(member)) {
          const name = typeof member.name === "string" ? member.name.trim() : "";
          captureLeadMember(member, true);
          if (name && name !== "user" && !taskHistory.isLeadMember(member)) {
            confirmedArtifactNames.add(name);
          }
          mergeMember(member, memberMap, removedKeys);
        }
      }
    }
    try {
      const inboxDir = path__namespace.join(payload.teamsDir, teamName, "inboxes");
      const inboxEntries = await fs__namespace.promises.readdir(inboxDir, { withFileTypes: true });
      for (const entry2 of inboxEntries) {
        if (!entry2.isFile() || !entry2.name.endsWith(".json")) continue;
        const inboxName = entry2.name.slice(0, -".json".length).trim();
        if (!inboxName || inboxName === "user" || taskHistory.isLeadMember({ name: inboxName })) continue;
        confirmedArtifactNames.add(inboxName);
      }
    } catch {
    }
    dropCliAutoSuffixedMembers(memberMap);
    dropCliProvisionerMembers(memberMap);
    const members = Array.from(memberMap.values());
    const memberColors = teamTaskSnapshotCompaction.buildTeamMemberColorMap(members, { preferProvidedColors: false });
    const coloredMembers = members.map((member) => ({
      ...member,
      color: memberColors.get(member.name) ?? member.color
    }));
    const suppressLegacyLaunchArtifactHeuristic = taskHistory.shouldSuppressLegacyLaunchArtifactHeuristic({
      leadProviderId,
      members: metaRuntimeMembers
    });
    const launchStateRead = await readLaunchState(payload.teamsDir, teamName);
    const fallbackLaunchStateSummary = () => {
      if (suppressLegacyLaunchArtifactHeuristic) {
        return null;
      }
      if (!leadSessionId || expectedTeammateNames.size === 0 || confirmedArtifactNames.size === 0) {
        return null;
      }
      const missingMembers = Array.from(expectedTeammateNames).filter(
        (name) => !confirmedArtifactNames.has(name)
      );
      if (missingMembers.length === 0) {
        return null;
      }
      return {
        partialLaunchFailure: true,
        expectedMemberCount: expectedTeammateNames.size,
        confirmedMemberCount: confirmedArtifactNames.size,
        missingMembers
      };
    };
    const launchStateSummary = launchStateRead.summary ?? fallbackLaunchStateSummary();
    const summary = {
      teamName,
      displayName,
      description,
      memberCount: memberMap.size,
      taskCount: 0,
      lastActivity: null,
      ...coloredMembers.length > 0 ? { members: coloredMembers } : {},
      ...leadName ? { leadName } : {},
      ...leadColor ? { leadColor } : {},
      ...color ? { color } : {},
      ...projectPath ? { projectPath } : {},
      ...leadSessionId ? { leadSessionId } : {},
      ...projectPathHistory ? { projectPathHistory } : {},
      ...sessionHistory ? { sessionHistory } : {},
      ...deletedAt ? { deletedAt } : {},
      ...launchStateSummary ?? {}
    };
    const ms = nowMs() - t0;
    if (ms >= 250) {
      pushSlowest(diag.slowest, { teamName, ms }, 10);
    }
    await cacheTeamSummaryIfStable(
      cacheKey,
      payload.teamsDir,
      teamName,
      optionKey,
      dependencyFingerprint,
      summary,
      launchStateRead.cacheable,
      diag
    );
    return summary;
  });
  const teams = perTeam.filter((t) => t !== null);
  pruneTeamSummaryCache(payload.teamsDir, optionKey, liveTeamNames, diag);
  diag.returned = teams.length;
  diag.totalMs = nowMs() - startedAt;
  return { teams, diag };
}
function normalizeWorkIntervals(parsed) {
  if (!Array.isArray(parsed.workIntervals)) return void 0;
  return parsed.workIntervals.filter(
    (i) => Boolean(i) && typeof i === "object" && typeof i.startedAt === "string" && (i.completedAt === void 0 || typeof i.completedAt === "string")
  ).map((i) => ({
    startedAt: i.startedAt,
    completedAt: i.completedAt
  }));
}
function normalizeReviewIntervals(parsed) {
  if (!Array.isArray(parsed.reviewIntervals)) return void 0;
  return parsed.reviewIntervals.filter(
    (i) => Boolean(i) && typeof i === "object" && typeof i.reviewer === "string" && typeof i.startedAt === "string" && (i.completedAt === void 0 || typeof i.completedAt === "string")
  ).map((i) => ({
    reviewer: i.reviewer,
    startedAt: i.startedAt,
    completedAt: i.completedAt
  }));
}
function normalizeHistoryEvents(parsed) {
  if (!Array.isArray(parsed.historyEvents)) return void 0;
  return parsed.historyEvents.filter(
    (i) => Boolean(i) && typeof i === "object" && typeof i.id === "string" && typeof i.timestamp === "string" && typeof i.type === "string"
  ).map((i) => ({ ...i }));
}
function normalizeReviewState(value) {
  return value === "review" || value === "needsFix" || value === "approved" ? value : "none";
}
function normalizeFallbackReviewState(value, status) {
  const reviewState = normalizeReviewState(value);
  if (reviewState === "none") return "none";
  if (status === "in_progress" || status === "deleted") return "none";
  if (status === "pending") return reviewState === "needsFix" ? "needsFix" : "none";
  if (status === "completed") {
    return reviewState === "review" || reviewState === "approved" || reviewState === "needsFix" ? reviewState : "none";
  }
  return reviewState;
}
function eventReviewState(event) {
  const type = typeof event.type === "string" ? event.type : "";
  if (!taskHistory.isTaskReviewLifecycleEventType(type)) {
    return null;
  }
  return normalizeReviewState(event.to);
}
function derivePendingReviewState(events, startIndex) {
  for (let i = startIndex - 1; i >= 0; i--) {
    const previous = events[i];
    const reviewState = eventReviewState(previous);
    if (reviewState) {
      return reviewState === "needsFix" ? "needsFix" : "none";
    }
    if (previous.type === "task_created" || previous.type === "status_changed" && (REVIEW_RESET_STATUSES.has(String(previous.to || "")) || previous.to === "pending")) {
      return "none";
    }
  }
  return "none";
}
function deriveReviewStateFromEvents(events) {
  if (!Array.isArray(events) || events.length === 0) return null;
  for (let i = events.length - 1; i >= 0; i--) {
    const e = events[i];
    const reviewState = eventReviewState(e);
    if (reviewState) {
      return reviewState;
    }
    if (e.type === "status_changed" && REVIEW_RESET_STATUSES.has(String(e.to || ""))) {
      return "none";
    }
    if (e.type === "status_changed" && e.to === "pending") {
      return derivePendingReviewState(events, i);
    }
  }
  return null;
}
function normalizeComments(parsed) {
  if (!Array.isArray(parsed.comments)) return void 0;
  return parsed.comments.filter(
    (c) => !!c && typeof c === "object" && typeof c.id === "string" && typeof c.author === "string" && typeof c.text === "string" && typeof c.createdAt === "string"
  ).map((c) => ({
    id: c.id,
    author: c.author,
    text: unescapeLiteralNewlines(c.text),
    createdAt: c.createdAt,
    taskRefs: Array.isArray(c.taskRefs) ? c.taskRefs : void 0,
    type: c.type === "regular" || c.type === "review_request" || c.type === "review_approved" ? c.type : "regular"
  }));
}
async function readTasksDirForTeam(tasksDir, teamName, payload) {
  const taskDiag = {
    skipped: 0,
    skipReasons: {},
    cacheHits: 0,
    cacheMisses: 0,
    cacheWriteSkips: 0,
    persistentCacheHits: 0,
    persistentCacheMisses: 0,
    persistentCacheLoads: 0,
    persistentCacheWrites: 0,
    persistentCacheReadFailures: 0,
    persistentCacheWriteFailures: 0
  };
  let entries;
  try {
    entries = await fs__namespace.promises.readdir(tasksDir);
  } catch (error) {
    if (error.code === "ENOENT") {
      return { tasks: [], taskDiag, liveCacheKeys: /* @__PURE__ */ new Set() };
    }
    throw error;
  }
  const tasks = [];
  const liveCacheKeys = /* @__PURE__ */ new Set();
  const optionKey = makeTaskOptionKey(payload);
  const persistentCache = await readPersistentTaskProjectionCache(
    payload,
    teamName,
    optionKey,
    taskDiag
  );
  const nextPersistentEntries = /* @__PURE__ */ new Map();
  for (const file of entries) {
    if (!file.endsWith(".json") || file.startsWith(".") || file === ".lock" || file === ".highwatermark") {
      continue;
    }
    const taskPath = path__namespace.join(tasksDir, file);
    const cacheKey = makeTaskCacheKey(payload.tasksBase, teamName, file, optionKey);
    liveCacheKeys.add(cacheKey);
    try {
      const pathFingerprint = await statPathFingerprint(taskPath);
      const taskSize = Number(pathFingerprint.size ?? Number.NaN);
      if (!pathFingerprint.isFile || !Number.isFinite(taskSize) || taskSize > payload.maxTaskBytes) {
        taskDiag.skipped++;
        bumpSkipReason(taskDiag.skipReasons, "task_not_file_or_large");
        continue;
      }
      const fingerprint = fingerprintToString(pathFingerprint);
      const fingerprintCacheSafe = isCacheSafeFingerprint(pathFingerprint);
      const cached = taskFileCache.get(cacheKey);
      if (fingerprintCacheSafe && cached?.fingerprint === fingerprint) {
        cached.lastUsedAt = nowMs();
        taskFileCache.delete(cacheKey);
        taskFileCache.set(cacheKey, cached);
        taskDiag.cacheHits++;
        applyCachedTaskReadResult(cached.result, tasks, taskDiag);
        nextPersistentEntries.set(file, {
          fingerprint,
          result: cloneCached(cached.result)
        });
        continue;
      }
      const persistentEntry = persistentCache?.get(file);
      if (fingerprintCacheSafe && persistentEntry?.fingerprint === fingerprint) {
        const result2 = cloneCached(persistentEntry.result);
        setTaskFileCacheEntry(
          cacheKey,
          {
            fingerprint,
            result: cloneCached(result2),
            tasksBase: payload.tasksBase,
            lastUsedAt: nowMs()
          },
          taskDiag
        );
        taskDiag.persistentCacheHits++;
        applyCachedTaskReadResult(result2, tasks, taskDiag);
        nextPersistentEntries.set(file, {
          fingerprint,
          result: cloneCached(result2)
        });
        continue;
      }
      if (persistentCache) {
        taskDiag.persistentCacheMisses++;
      }
      taskDiag.cacheMisses++;
      const raw = await readFileUtf8WithTimeout(taskPath, payload.maxTaskReadMs);
      const parsed = JSON.parse(raw);
      const metadata = parsed.metadata;
      if (metadata?._internal === true) {
        taskDiag.skipped++;
        bumpSkipReason(taskDiag.skipReasons, "task_internal");
        const result2 = { skipReason: "task_internal" };
        const cachedStable2 = await cacheTaskReadResultIfStable(
          cacheKey,
          taskPath,
          payload.tasksBase,
          fingerprint,
          fingerprintCacheSafe,
          result2,
          taskDiag
        );
        if (cachedStable2) {
          nextPersistentEntries.set(file, {
            fingerprint,
            result: cloneCached(result2)
          });
        }
        continue;
      }
      if (parsed.status === "deleted") {
        taskDiag.skipped++;
        bumpSkipReason(taskDiag.skipReasons, "task_deleted");
        const result2 = { skipReason: "task_deleted" };
        const cachedStable2 = await cacheTaskReadResultIfStable(
          cacheKey,
          taskPath,
          payload.tasksBase,
          fingerprint,
          fingerprintCacheSafe,
          result2,
          taskDiag
        );
        if (cachedStable2) {
          nextPersistentEntries.set(file, {
            fingerprint,
            result: cloneCached(result2)
          });
        }
        continue;
      }
      const subject = typeof parsed.subject === "string" ? parsed.subject : typeof parsed.title === "string" ? parsed.title : "";
      let createdAt = typeof parsed.createdAt === "string" ? parsed.createdAt : void 0;
      let updatedAt;
      try {
        const birthtime = dateFromFingerprintMs(pathFingerprint.birthtimeMs);
        const mtime = dateFromFingerprintMs(pathFingerprint.mtimeMs);
        if (!createdAt) {
          createdAt = (birthtime ?? mtime)?.toISOString();
        }
        updatedAt = mtime?.toISOString();
      } catch {
      }
      const needsClarification = parsed.needsClarification === "lead" || parsed.needsClarification === "user" ? parsed.needsClarification : void 0;
      const historyEvents = normalizeHistoryEvents(parsed);
      const status = parsed.status === "pending" || parsed.status === "in_progress" || parsed.status === "completed" || parsed.status === "deleted" ? parsed.status : "pending";
      const derivedReviewState = deriveReviewStateFromEvents(historyEvents);
      const reviewState = derivedReviewState !== null ? normalizeFallbackReviewState(derivedReviewState, status) : normalizeFallbackReviewState(parsed.reviewState, status);
      const task = compactWorkerTaskProjection({
        id: typeof parsed.id === "string" || typeof parsed.id === "number" ? String(parsed.id) : "",
        displayId: typeof parsed.displayId === "string" && parsed.displayId.trim().length > 0 ? parsed.displayId.trim() : teamTaskSnapshotCompaction.deriveTaskDisplayId(
          typeof parsed.id === "string" || typeof parsed.id === "number" ? String(parsed.id) : ""
        ),
        subject,
        description: typeof parsed.description === "string" ? unescapeLiteralNewlines(parsed.description) : void 0,
        groupChatId: typeof parsed.groupChatId === "string" ? parsed.groupChatId : void 0,
        descriptionTaskRefs: Array.isArray(parsed.descriptionTaskRefs) ? parsed.descriptionTaskRefs : void 0,
        activeForm: typeof parsed.activeForm === "string" ? parsed.activeForm : void 0,
        prompt: typeof parsed.prompt === "string" ? parsed.prompt : void 0,
        promptTaskRefs: Array.isArray(parsed.promptTaskRefs) ? parsed.promptTaskRefs : void 0,
        owner: typeof parsed.owner === "string" ? parsed.owner : void 0,
        createdBy: typeof parsed.createdBy === "string" ? parsed.createdBy : void 0,
        status,
        workIntervals: normalizeWorkIntervals(parsed),
        reviewIntervals: normalizeReviewIntervals(parsed),
        historyEvents,
        blocks: Array.isArray(parsed.blocks) ? parsed.blocks : void 0,
        blockedBy: Array.isArray(parsed.blockedBy) ? parsed.blockedBy : void 0,
        related: Array.isArray(parsed.related) ? parsed.related.filter((id) => typeof id === "string") : void 0,
        createdAt,
        updatedAt,
        projectPath: typeof parsed.projectPath === "string" ? parsed.projectPath : void 0,
        comments: normalizeComments(parsed),
        needsClarification,
        reviewState,
        deletedAt: void 0,
        attachments: Array.isArray(parsed.attachments) ? parsed.attachments : void 0,
        sourceMessageId: typeof parsed.sourceMessageId === "string" && parsed.sourceMessageId.trim() ? parsed.sourceMessageId.trim() : void 0,
        sourceMessage: parsed.sourceMessage && typeof parsed.sourceMessage === "object" && typeof parsed.sourceMessage.text === "string" && typeof parsed.sourceMessage.from === "string" && typeof parsed.sourceMessage.timestamp === "string" ? parsed.sourceMessage : void 0,
        teamName
      });
      tasks.push(task);
      const result = { task };
      const cachedStable = await cacheTaskReadResultIfStable(
        cacheKey,
        taskPath,
        payload.tasksBase,
        fingerprint,
        fingerprintCacheSafe,
        result,
        taskDiag
      );
      if (cachedStable) {
        nextPersistentEntries.set(file, {
          fingerprint,
          result: cloneCached(result)
        });
      }
    } catch (error) {
      taskDiag.skipped++;
      const code = error.code;
      if (code === "READ_TIMEOUT") {
        bumpSkipReason(taskDiag.skipReasons, "task_read_timeout");
      } else {
        bumpSkipReason(taskDiag.skipReasons, "task_parse_failed");
      }
    }
  }
  if (persistentCache && nextPersistentEntries.size === 0) {
    const cachePath = getPersistentTaskProjectionCachePath(payload, teamName);
    if (cachePath) {
      await fs__namespace.promises.rm(cachePath, { force: true }).catch(() => void 0);
    }
  } else if (shouldWritePersistentTaskProjectionCache(persistentCache, nextPersistentEntries, taskDiag)) {
    await writePersistentTaskProjectionCache(
      payload,
      teamName,
      optionKey,
      nextPersistentEntries,
      taskDiag
    );
  }
  return { tasks, taskDiag, liveCacheKeys };
}
function mergeTaskDiag(target, source) {
  target.skipped += source.skipped;
  target.cacheHits += source.cacheHits;
  target.cacheMisses += source.cacheMisses;
  target.cacheWriteSkips += source.cacheWriteSkips;
  target.persistentCacheHits += source.persistentCacheHits;
  target.persistentCacheMisses += source.persistentCacheMisses;
  target.persistentCacheLoads += source.persistentCacheLoads;
  target.persistentCacheWrites += source.persistentCacheWrites;
  target.persistentCacheReadFailures += source.persistentCacheReadFailures;
  target.persistentCacheWriteFailures += source.persistentCacheWriteFailures;
  for (const [reason, count] of Object.entries(source.skipReasons)) {
    target.skipReasons[reason] = (target.skipReasons[reason] || 0) + count;
  }
}
async function getAllTasks(payload) {
  const startedAt = nowMs();
  const diag = {
    op: "getAllTasks",
    startedAt,
    tasksBase: payload.tasksBase,
    teamDirs: 0,
    returned: 0,
    skipped: 0,
    skipReasons: {},
    slowestTeams: [],
    cacheHits: 0,
    cacheMisses: 0,
    cacheWriteSkips: 0,
    cacheEvictions: 0,
    persistentCacheHits: 0,
    persistentCacheMisses: 0,
    persistentCacheLoads: 0,
    persistentCacheWrites: 0,
    persistentCacheReadFailures: 0,
    persistentCacheWriteFailures: 0,
    totalMs: 0
  };
  let entries;
  try {
    entries = await fs__namespace.promises.readdir(payload.tasksBase, { withFileTypes: true });
  } catch (error) {
    if (error.code === "ENOENT") {
      diag.totalMs = nowMs() - startedAt;
      return { tasks: [], diag };
    }
    throw error;
  }
  const dirs = entries.filter((e) => e.isDirectory());
  diag.teamDirs = dirs.length;
  const liveCacheKeys = /* @__PURE__ */ new Set();
  const chunks = await mapLimit(dirs, payload.concurrency, async (entry) => {
    const teamName = entry.name;
    const t0 = nowMs();
    try {
      const tasksDir = path__namespace.join(payload.tasksBase, teamName);
      const {
        tasks: tasks2,
        taskDiag,
        liveCacheKeys: teamLiveCacheKeys
      } = await readTasksDirForTeam(tasksDir, teamName, payload);
      for (const key of teamLiveCacheKeys) {
        liveCacheKeys.add(key);
      }
      mergeTaskDiag(diag, taskDiag);
      const ms = nowMs() - t0;
      if (ms >= 250) {
        pushSlowest(diag.slowestTeams, { teamName, ms }, 10);
      }
      return tasks2;
    } catch {
      diag.skipped++;
      bumpSkipReason(diag.skipReasons, "team_dir_failed");
      return [];
    }
  });
  const tasks = chunks.flat();
  pruneTaskFileCache(payload.tasksBase, liveCacheKeys, diag);
  diag.returned = tasks.length;
  diag.totalMs = nowMs() - startedAt;
  return { tasks, diag };
}
function post(msg) {
  node_worker_threads.parentPort?.postMessage(msg);
}
node_worker_threads.parentPort?.on("message", async (msg) => {
  const { id, op } = msg;
  try {
    if (op === "warmup") {
      post({
        id,
        ok: true,
        result: {
          ready: true,
          teamSummaryCacheEntries: teamSummaryCache.size,
          taskFileCacheEntries: taskFileCache.size
        },
        diag: { op, totalMs: 0 }
      });
      return;
    }
    if (op === "listTeams") {
      const { teams, diag } = await listTeams(msg.payload);
      post({ id, ok: true, result: teams, diag });
      return;
    }
    if (op === "getAllTasks") {
      const { tasks, diag } = await getAllTasks(msg.payload);
      post({ id, ok: true, result: tasks, diag });
      return;
    }
    post({ id, ok: false, error: `Unknown op: ${String(op)}` });
  } catch (error) {
    post({ id, ok: false, error: error instanceof Error ? error.message : String(error) });
  }
});
