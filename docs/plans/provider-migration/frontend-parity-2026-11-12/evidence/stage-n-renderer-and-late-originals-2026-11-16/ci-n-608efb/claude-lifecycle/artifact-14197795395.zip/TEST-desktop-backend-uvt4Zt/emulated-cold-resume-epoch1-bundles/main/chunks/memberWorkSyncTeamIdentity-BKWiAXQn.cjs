for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const node_module = require("node:module");
const node_url = require("node:url");
let nativeDriver = null;
let nativeDriverPinned = false;
function loadInternalStorageNativeDriver() {
  if (nativeDriver) return nativeDriver;
  const requireModule = node_module.createRequire(
    typeof __filename === "string" && __filename.length > 0 ? __filename : node_url.fileURLToPath(require("url").pathToFileURL(__filename).href)
  );
  try {
    nativeDriver = requireModule("better-sqlite3");
    return nativeDriver;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`better-sqlite3 native module failed to load: ${message}`);
  }
}
function pinInternalStorageNativeDriver() {
  if (nativeDriverPinned) return;
  try {
    const Driver = loadInternalStorageNativeDriver();
    const probe = new Driver(":memory:");
    probe.close();
    nativeDriverPinned = true;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`better-sqlite3 native module pin failed: ${message}`);
  }
}
function normalizeMemberWorkSyncTeamKey(teamName) {
  return typeof teamName === "string" ? teamName.trim().toLowerCase() : "";
}
function isSameMemberWorkSyncTeam(leftTeamName, rightTeamName) {
  const leftKey = normalizeMemberWorkSyncTeamKey(leftTeamName);
  return leftKey.length > 0 && leftKey === normalizeMemberWorkSyncTeamKey(rightTeamName);
}
function parseJsonObject(json, recordKind) {
  const value = JSON.parse(json);
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`Invalid member-work-sync ${recordKind} JSON`);
  }
  return value;
}
function normalizeNestedTeamName(value, teamName) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    value.teamName = teamName;
  }
}
function normalizeStatusRecord(teamName, record) {
  const status = parseJsonObject(record.statusJson, "status");
  normalizeNestedTeamName(status, teamName);
  normalizeNestedTeamName(status.agenda, teamName);
  if (status.lastAcceptedReport != null)
    normalizeNestedTeamName(status.lastAcceptedReport, teamName);
  if (status.report != null) {
    normalizeNestedTeamName(status.report, teamName);
  }
  return {
    ...record,
    teamName,
    statusJson: JSON.stringify(status)
  };
}
function normalizeReportIntentRecord(teamName, record) {
  const request = parseJsonObject(record.requestJson, "report request");
  normalizeNestedTeamName(request, teamName);
  return {
    ...record,
    teamName,
    requestJson: JSON.stringify(request),
    journalJson: record.journalJson ?? null
  };
}
function normalizeMetricEventRecord(teamName, record) {
  const event = parseJsonObject(record.eventJson, "metric event");
  normalizeNestedTeamName(event, teamName);
  return {
    ...record,
    teamName,
    eventJson: JSON.stringify(event)
  };
}
function normalizeMemberWorkSyncSnapshotTeamIdentity(teamName, snapshot) {
  return {
    statuses: snapshot.statuses.map((record) => normalizeStatusRecord(teamName, record)),
    reportIntents: snapshot.reportIntents.map(
      (record) => normalizeReportIntentRecord(teamName, record)
    ),
    outboxItems: snapshot.outboxItems.map((record) => ({ ...record, teamName })),
    metricEvents: snapshot.metricEvents.map(
      (record) => normalizeMetricEventRecord(teamName, record)
    )
  };
}
exports.isSameMemberWorkSyncTeam = isSameMemberWorkSyncTeam;
exports.loadInternalStorageNativeDriver = loadInternalStorageNativeDriver;
exports.normalizeMemberWorkSyncSnapshotTeamIdentity = normalizeMemberWorkSyncSnapshotTeamIdentity;
exports.normalizeMemberWorkSyncTeamKey = normalizeMemberWorkSyncTeamKey;
exports.pinInternalStorageNativeDriver = pinInternalStorageNativeDriver;
