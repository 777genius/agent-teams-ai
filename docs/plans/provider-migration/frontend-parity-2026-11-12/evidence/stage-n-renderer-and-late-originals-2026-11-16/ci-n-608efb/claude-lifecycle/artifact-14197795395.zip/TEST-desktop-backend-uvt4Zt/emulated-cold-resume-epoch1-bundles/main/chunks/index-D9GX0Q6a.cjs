for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const index = require("../index.cjs");
const fs = require("node:fs/promises");
const path = require("node:path");
const taskChangeState = require("./taskChangeState-rZolvpL6.cjs");
const TeamDataService = require("./TeamDataService-DySh5-O-.cjs");
require("fs");
require("node:crypto");
require("crypto");
require("path");
const TaskBoundaryParser = require("./TaskBoundaryParser-Zk2WZzJg.cjs");
require("./taskHistory-2kbwfqIg.cjs");
require("os");
require("node:fs");
require("node:async_hooks");
require("node:os");
require("node:perf_hooks");
require("node:child_process");
require("node:stream");
require("node:events");
require("node:util");
require("node:diagnostics_channel");
require("node:module");
require("node:process");
require("fs/promises");
require("events");
require("child_process");
require("util");
require("async_hooks");
require("buffer");
require("net");
require("module");
require("url");
require("readline");
require("string_decoder");
require("node:buffer");
require("node:timers/promises");
require("node:url");
require("electron");
require("agent-teams-controller");
require("node:string_decoder");
require("zlib");
require("node:stream/promises");
require("node:zlib");
require("node:http");
require("http");
require("http2");
require("stream");
require("node:net");
require("node:worker_threads");
require("node:https");
require("process");
require("node:readline");
require("node:sqlite");
require("./teamTaskSnapshotCompaction-mUovQwio.cjs");
require("./memberWorkSyncTeamIdentity-BKWiAXQn.cjs");
require("ws");
require("./index-yaJFGvjB.cjs");
require("tty");
require("node:tty");
require("https");
require("@fastify/cors");
require("@fastify/static");
require("fastify");
require("assert");
require("tls");
require("dns");
require("constants");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const fs__namespace = /* @__PURE__ */ _interopNamespaceDefault(fs);
const path__namespace = /* @__PURE__ */ _interopNamespaceDefault(path);
function structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options) {
  let optionsObj;
  {
    optionsObj = {};
  }
  if (typeof optionsObj.context === "undefined") {
    optionsObj.context = 4;
  }
  const context = optionsObj.context;
  if (optionsObj.newlineIsToken) {
    throw new Error("newlineIsToken may not be used with patch-generation functions, only with diffing functions");
  }
  if (!optionsObj.callback) {
    return diffLinesResultToPatch(TaskBoundaryParser.diffLines(oldStr, newStr, optionsObj));
  } else {
    const { callback } = optionsObj;
    TaskBoundaryParser.diffLines(oldStr, newStr, Object.assign(Object.assign({}, optionsObj), { callback: (diff) => {
      const patch = diffLinesResultToPatch(diff);
      callback(patch);
    } }));
  }
  function diffLinesResultToPatch(diff) {
    if (!diff) {
      return;
    }
    diff.push({ value: "", lines: [] });
    function contextLines(lines) {
      return lines.map(function(entry) {
        return " " + entry;
      });
    }
    const hunks = [];
    let oldRangeStart = 0, newRangeStart = 0, curRange = [], oldLine = 1, newLine = 1;
    for (let i = 0; i < diff.length; i++) {
      const current = diff[i], lines = current.lines || splitLines(current.value);
      current.lines = lines;
      if (current.added || current.removed) {
        if (!oldRangeStart) {
          const prev = diff[i - 1];
          oldRangeStart = oldLine;
          newRangeStart = newLine;
          if (prev) {
            curRange = context > 0 ? contextLines(prev.lines.slice(-context)) : [];
            oldRangeStart -= curRange.length;
            newRangeStart -= curRange.length;
          }
        }
        for (const line of lines) {
          curRange.push((current.added ? "+" : "-") + line);
        }
        if (current.added) {
          newLine += lines.length;
        } else {
          oldLine += lines.length;
        }
      } else {
        if (oldRangeStart) {
          if (lines.length <= context * 2 && i < diff.length - 2) {
            for (const line of contextLines(lines)) {
              curRange.push(line);
            }
          } else {
            const contextSize = Math.min(lines.length, context);
            for (const line of contextLines(lines.slice(0, contextSize))) {
              curRange.push(line);
            }
            const hunk = {
              oldStart: oldRangeStart,
              oldLines: oldLine - oldRangeStart + contextSize,
              newStart: newRangeStart,
              newLines: newLine - newRangeStart + contextSize,
              lines: curRange
            };
            hunks.push(hunk);
            oldRangeStart = 0;
            newRangeStart = 0;
            curRange = [];
          }
        }
        oldLine += lines.length;
        newLine += lines.length;
      }
    }
    for (const hunk of hunks) {
      for (let i = 0; i < hunk.lines.length; i++) {
        if (hunk.lines[i].endsWith("\n")) {
          hunk.lines[i] = hunk.lines[i].slice(0, -1);
        } else {
          hunk.lines.splice(i + 1, 0, "\\ No newline at end of file");
          i++;
        }
      }
    }
    return {
      oldFileName,
      newFileName,
      oldHeader,
      newHeader,
      hunks
    };
  }
}
function splitLines(text) {
  const hasTrailingNl = text.endsWith("\n");
  const result = text.split("\n").map((line) => line + "\n");
  if (hasTrailingNl) {
    result.pop();
  } else {
    result.push(result.pop().slice(0, -1));
  }
  return result;
}
const logger = taskChangeState.createLogger("Extensions:SkillReview");
class SkillReviewService {
  async buildTextChanges(targetSkillDir, files) {
    return Promise.all(
      files.map(async (file) => {
        const absolutePath = path__namespace.join(targetSkillDir, file.relativePath);
        const oldContent = await this.readUtf8IfExists(absolutePath);
        return {
          relativePath: file.relativePath,
          absolutePath,
          action: oldContent === null ? "create" : "update",
          oldContent,
          newContent: file.content,
          isBinary: false
        };
      })
    );
  }
  async buildImportChanges(targetSkillDir, files) {
    return Promise.all(
      files.map(async (file) => {
        const destPath = path__namespace.join(targetSkillDir, file.relativePath);
        const exists = await this.pathExists(destPath);
        const oldContent = file.isBinary ? null : await this.readUtf8IfExists(destPath);
        return {
          relativePath: file.relativePath,
          absolutePath: destPath,
          action: exists ? "update" : "create",
          oldContent,
          newContent: file.isBinary ? null : file.content,
          isBinary: file.isBinary
        };
      })
    );
  }
  async readUtf8IfExists(filePath) {
    try {
      return await fs__namespace.readFile(filePath, "utf8");
    } catch (error) {
      if (error.code === "ENOENT") {
        return null;
      }
      logger.warn(`Failed to read existing file ${filePath}`, error);
      return null;
    }
  }
  async pathExists(targetPath) {
    try {
      await fs__namespace.stat(targetPath);
      return true;
    } catch {
      return false;
    }
  }
}
class HunkSnippetMatcher {
  /**
   * Match hunk indices to their corresponding snippets.
   * Returns a Map where each hunk index maps to the set of matching snippet indices.
   *
   * @param snippets — MUST be pre-filtered (no isError entries).
   *   Returned indices are relative to this array.
   */
  matchHunksToSnippets(original, modified, hunkIndices, snippets) {
    if (snippets.length === 0) return /* @__PURE__ */ new Map();
    const patch = structuredPatch("file", "file", original, modified);
    if (!patch.hunks || patch.hunks.length === 0) return /* @__PURE__ */ new Map();
    const mapping = /* @__PURE__ */ new Map();
    for (const hunkIdx of hunkIndices) {
      if (hunkIdx < 0 || hunkIdx >= patch.hunks.length) continue;
      const hunk = patch.hunks[hunkIdx];
      const snippetSet = /* @__PURE__ */ new Set();
      const strongMatches = /* @__PURE__ */ new Set();
      const oldSideContent = hunk.lines.filter((l) => !l.startsWith("+")).map((l) => l.slice(1)).join("\n");
      const newSideContent = hunk.lines.filter((l) => !l.startsWith("-")).map((l) => l.slice(1)).join("\n");
      for (let sIdx = 0; sIdx < snippets.length; sIdx++) {
        const snippet = snippets[sIdx];
        if (this.hasContentOverlap(snippet, oldSideContent, newSideContent)) {
          snippetSet.add(sIdx);
        }
        if (snippet.contextHash) {
          const h = TeamDataService.computeDiffContextHash(oldSideContent, newSideContent);
          if (h === snippet.contextHash) {
            strongMatches.add(sIdx);
          }
        }
      }
      mapping.set(hunkIdx, strongMatches.size > 0 ? strongMatches : snippetSet);
    }
    return mapping;
  }
  /**
   * Find the correct position of a snippet's newString in the content,
   * disambiguating when multiple occurrences exist.
   */
  findSnippetPosition(snippet, content) {
    const { newString, oldString } = snippet;
    if (!newString) return -1;
    const firstPos = content.indexOf(newString);
    if (firstPos === -1) return -1;
    const lastPos = content.lastIndexOf(newString);
    if (firstPos === lastPos) return firstPos;
    const positions = [];
    let searchStart = 0;
    while (true) {
      const pos = content.indexOf(newString, searchStart);
      if (pos === -1) break;
      positions.push(pos);
      searchStart = pos + 1;
    }
    if (oldString) {
      const oldTokens = oldString.split(/\s+/).filter((t) => t.length > 3).slice(0, 20);
      if (oldTokens.length > 0) {
        let bestPos = firstPos;
        let bestScore = 0;
        for (const pos of positions) {
          const nearbyStart = Math.max(0, pos - 500);
          const nearbyEnd = Math.min(content.length, pos + newString.length + 500);
          const nearby = content.substring(nearbyStart, nearbyEnd);
          const matchScore = oldTokens.filter((t) => nearby.includes(t)).length;
          if (matchScore > bestScore) {
            bestScore = matchScore;
            bestPos = pos;
          }
        }
        return bestPos;
      }
    }
    return firstPos;
  }
  // ── Private helpers ──
  /**
   * Check if a snippet's content overlaps with a hunk's reconstructed file ranges.
   *
   * @param hunkOldSide — reconstructed original file text within hunk range (context + removed lines)
   * @param hunkNewSide — reconstructed modified file text within hunk range (context + added lines)
   */
  hasContentOverlap(snippet, hunkOldSide, hunkNewSide) {
    if (!snippet.newString && !snippet.oldString) return false;
    if (snippet.type === "write-new" || snippet.type === "write-update" || snippet.type === "notebook-edit" || snippet.type === "shell-snapshot" || snippet.type === "hook-snapshot") {
      return false;
    }
    const hasOld = snippet.oldString.length > 0;
    const hasNew = snippet.newString.length > 0;
    const matchesOld = hasOld ? hunkOldSide.includes(snippet.oldString) : false;
    const matchesNew = hasNew ? hunkNewSide.includes(snippet.newString) : false;
    if (hasOld && hasNew) return matchesOld && matchesNew;
    if (hasOld) return matchesOld;
    return matchesNew;
  }
}
const VALID_SOURCES = /* @__PURE__ */ new Set([
  "manual",
  "launch_runtime",
  "reconcile"
]);
const TEAM_NAME_PATTERN = /^[a-z0-9][a-z0-9-]{0,127}$/;
const TASK_ID_PATTERN = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,63}$/;
const MEMBER_NAME_PATTERN = /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/;
const MAX_RUNTIME_ID_LENGTH = 256;
function trimOptionalString(value) {
  if (typeof value !== "string") {
    return void 0;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : void 0;
}
function requireString(field, value) {
  const trimmed = trimOptionalString(value);
  if (!trimmed) {
    throw new Error(`OpenCode task-log attribution ${field} is required`);
  }
  return trimmed;
}
function requirePatternString(field, value, pattern) {
  const trimmed = requireString(field, value);
  if (!pattern.test(trimmed)) {
    throw new Error(`OpenCode task-log attribution ${field} contains invalid characters`);
  }
  return trimmed;
}
function trimRuntimeId(field, value) {
  const trimmed = trimOptionalString(value);
  if (!trimmed) {
    return void 0;
  }
  if (trimmed.length > MAX_RUNTIME_ID_LENGTH) {
    throw new Error(
      `OpenCode task-log attribution ${field} exceeds max length (${MAX_RUNTIME_ID_LENGTH})`
    );
  }
  return trimmed;
}
function normalizeIso(field, value) {
  if (value === void 0) {
    return void 0;
  }
  const timestamp = value instanceof Date ? value.getTime() : Date.parse(requireString(field, value));
  if (!Number.isFinite(timestamp)) {
    throw new Error(`OpenCode task-log attribution ${field} must be a valid timestamp`);
  }
  return new Date(timestamp).toISOString();
}
function normalizeScope(value) {
  if (value === void 0) {
    return "member_session_window";
  }
  if (value === "task_session" || value === "member_session_window") {
    return value;
  }
  throw new Error("OpenCode task-log attribution scope is invalid");
}
function normalizeSource(value, fallback) {
  const source = value ?? fallback;
  if (!VALID_SOURCES.has(source)) {
    throw new Error("OpenCode task-log attribution source is invalid");
  }
  return source;
}
function assertRecordPolicy(record) {
  if (record.since && record.until && Date.parse(record.since) > Date.parse(record.until)) {
    throw new Error("OpenCode task-log attribution since must be before or equal to until");
  }
  if (record.scope === "task_session") {
    if (!record.sessionId) {
      throw new Error("OpenCode task-log attribution task_session requires sessionId");
    }
    return;
  }
  if (!record.since && !record.startMessageUuid) {
    throw new Error(
      "OpenCode task-log attribution member_session_window requires since or startMessageUuid"
    );
  }
}
function buildRecord(taskId, draft, fallbackSource) {
  const sessionId = trimRuntimeId("sessionId", draft.sessionId);
  const since = normalizeIso("since", draft.since);
  const until = normalizeIso("until", draft.until);
  const startMessageUuid = trimRuntimeId("startMessageUuid", draft.startMessageUuid);
  const endMessageUuid = trimRuntimeId("endMessageUuid", draft.endMessageUuid);
  const record = {
    taskId: requirePatternString("taskId", taskId, TASK_ID_PATTERN),
    memberName: requirePatternString("memberName", draft.memberName, MEMBER_NAME_PATTERN),
    scope: normalizeScope(draft.scope),
    ...sessionId ? { sessionId } : {},
    ...since ? { since } : {},
    ...until ? { until } : {},
    ...startMessageUuid ? { startMessageUuid } : {},
    ...endMessageUuid ? { endMessageUuid } : {},
    source: normalizeSource(draft.source, fallbackSource)
  };
  assertRecordPolicy(record);
  return record;
}
class OpenCodeTaskLogAttributionService {
  constructor(writer = new index.OpenCodeTaskLogAttributionStore(), now = () => /* @__PURE__ */ new Date()) {
    this.writer = writer;
    this.now = now;
  }
  writer;
  now;
  async recordTaskSession(input) {
    const teamName = requirePatternString("teamName", input.teamName, TEAM_NAME_PATTERN);
    const record = buildRecord(
      requireString("taskId", input.taskId),
      {
        memberName: input.memberName,
        scope: "task_session",
        sessionId: input.sessionId,
        since: input.since,
        until: input.until,
        startMessageUuid: input.startMessageUuid,
        endMessageUuid: input.endMessageUuid,
        source: input.source
      },
      "launch_runtime"
    );
    return {
      result: await this.writer.upsertTaskRecord(teamName, record, { now: this.now() }),
      record
    };
  }
  async recordMemberSessionWindow(input) {
    const teamName = requirePatternString("teamName", input.teamName, TEAM_NAME_PATTERN);
    const record = buildRecord(
      requireString("taskId", input.taskId),
      {
        memberName: input.memberName,
        scope: "member_session_window",
        sessionId: input.sessionId,
        since: input.since,
        until: input.until,
        startMessageUuid: input.startMessageUuid,
        endMessageUuid: input.endMessageUuid,
        source: input.source
      },
      "reconcile"
    );
    return {
      result: await this.writer.upsertTaskRecord(teamName, record, { now: this.now() }),
      record
    };
  }
  async replaceTaskAttribution(input) {
    const teamName = requirePatternString("teamName", input.teamName, TEAM_NAME_PATTERN);
    const taskId = requirePatternString("taskId", input.taskId, TASK_ID_PATTERN);
    const fallbackSource = normalizeSource(input.source, "reconcile");
    const records = input.records.map((record) => buildRecord(taskId, record, fallbackSource));
    return {
      result: await this.writer.replaceTaskRecords(teamName, taskId, records, { now: this.now() }),
      recordCount: records.length
    };
  }
  async clearTaskAttribution(input) {
    const teamName = requirePatternString("teamName", input.teamName, TEAM_NAME_PATTERN);
    const taskId = requirePatternString("taskId", input.taskId, TASK_ID_PATTERN);
    return {
      result: await this.writer.clearTaskRecords(teamName, taskId),
      recordCount: 0
    };
  }
}
exports.ActiveTeamRegistry = index.ActiveTeamRegistry;
exports.ApiKeyService = index.ApiKeyService;
exports.AutoResumeService = index.AutoResumeService;
exports.BoardTaskActivityBatchIndexer = index.BoardTaskActivityBatchIndexer;
exports.BoardTaskActivityDetailService = index.BoardTaskActivityDetailService;
exports.BoardTaskActivityRecordSource = index.BoardTaskActivityRecordSource;
exports.BoardTaskActivityService = index.BoardTaskActivityService;
exports.BoardTaskExactLogDetailService = index.BoardTaskExactLogDetailService;
exports.BoardTaskExactLogsService = index.BoardTaskExactLogsService;
exports.BoardTaskLogStreamService = index.BoardTaskLogStreamService;
exports.BranchStatusService = index.BranchStatusService;
exports.CascadeGuard = index.CascadeGuard;
exports.ChangeExtractorService = index.ChangeExtractorService;
exports.ChunkBuilder = index.ChunkBuilder;
exports.ClaudeBinaryResolver = index.ClaudeBinaryResolver;
exports.ClaudeExtensionsAdapter = index.ClaudeExtensionsAdapter;
exports.CliInstallerService = index.CliInstallerService;
exports.ConfigManager = index.ConfigManager;
exports.CrossTeamOutbox = index.CrossTeamOutbox;
exports.CrossTeamService = index.CrossTeamService;
exports.DEFAULT_TRIGGERS = index.DEFAULT_TRIGGERS;
exports.DataCache = index.DataCache;
exports.ExtensionFacadeService = index.ExtensionFacadeService;
exports.FileContentResolver = index.FileContentResolver;
exports.FileWatcher = index.FileWatcher;
exports.GitDiffFallback = index.GitDiffFallback;
exports.GitHubStarsService = index.GitHubStarsService;
exports.GlamaMcpEnrichmentService = index.GlamaMcpEnrichmentService;
exports.HttpServer = index.HttpServer;
exports.JsonScheduleRepository = index.JsonScheduleRepository;
exports.McpCatalogAggregator = index.McpCatalogAggregator;
exports.McpHealthDiagnosticsService = index.McpHealthDiagnosticsService;
exports.McpInstallService = index.McpInstallService;
exports.McpInstallationStateService = index.McpInstallationStateService;
exports.MemberStatsComputer = index.MemberStatsComputer;
exports.MultimodelExtensionsAdapter = index.MultimodelExtensionsAdapter;
exports.NotificationManager = index.NotificationManager;
exports.OfficialMcpRegistryService = index.OfficialMcpRegistryService;
exports.OpenCodeReadinessBridge = index.OpenCodeReadinessBridge;
exports.OpenCodeRuntimeInstallerService = index.OpenCodeRuntimeInstallerService;
exports.OpenCodeTaskLogAttributionStore = index.OpenCodeTaskLogAttributionStore;
exports.OpenCodeTeamRuntimeAdapter = index.OpenCodeTeamRuntimeAdapter;
exports.PluginCatalogService = index.PluginCatalogService;
exports.PluginInstallService = index.PluginInstallService;
exports.PluginInstallationStateService = index.PluginInstallationStateService;
exports.ProjectPathResolver = index.ProjectPathResolver;
exports.ProjectScanner = index.ProjectScanner;
exports.PtyTerminalService = index.PtyTerminalService;
exports.ReviewApplierService = index.ReviewApplierService;
exports.ScheduledTaskExecutor = index.ScheduledTaskExecutor;
exports.SchedulerService = index.SchedulerService;
exports.SearchTextCache = index.SearchTextCache;
exports.ServiceContext = index.ServiceContext;
exports.ServiceContextRegistry = index.ServiceContextRegistry;
exports.SessionContentFilter = index.SessionContentFilter;
exports.SessionParser = index.SessionParser;
exports.SessionSearcher = index.SessionSearcher;
exports.SkillImportService = index.SkillImportService;
exports.SkillMetadataParser = index.SkillMetadataParser;
exports.SkillPlanService = index.SkillPlanService;
exports.SkillRootsResolver = index.SkillRootsResolver;
exports.SkillScaffoldService = index.SkillScaffoldService;
exports.SkillScanner = index.SkillScanner;
exports.SkillValidator = index.SkillValidator;
exports.SkillsCatalogService = index.SkillsCatalogService;
exports.SkillsMutationService = index.SkillsMutationService;
exports.SkillsWatcherService = index.SkillsWatcherService;
exports.SshConfigParser = index.SshConfigParser;
exports.SshConnectionManager = index.SshConnectionManager;
exports.SshFileSystemProvider = index.SshFileSystemProvider;
exports.SubagentLocator = index.SubagentLocator;
exports.SubagentResolver = index.SubagentResolver;
exports.TEAM_RUNTIME_PROVIDER_IDS = index.TEAM_RUNTIME_PROVIDER_IDS;
exports.TeamAttachmentStore = index.TeamAttachmentStore;
exports.TeamBackupService = index.TeamBackupService;
exports.TeamLogSourceTracker = index.TeamLogSourceTracker;
exports.TeamProvisioningService = index.TeamProvisioningService;
exports.TeamRuntimeAdapterRegistry = index.TeamRuntimeAdapterRegistry;
exports.TeamTaskLogFreshnessReader = index.TeamTaskLogFreshnessReader;
exports.TeamTaskStallExactRowReader = index.TeamTaskStallExactRowReader;
exports.TeamTaskStallJournal = index.TeamTaskStallJournal;
exports.TeamTaskStallMonitor = index.TeamTaskStallMonitor;
exports.TeamTaskStallNotifier = index.TeamTaskStallNotifier;
exports.TeamTaskStallPolicy = index.TeamTaskStallPolicy;
exports.TeamTaskStallSnapshotSource = index.TeamTaskStallSnapshotSource;
exports.TeamTranscriptSourceLocator = index.TeamTranscriptSourceLocator;
exports.TeammateToolTracker = index.TeammateToolTracker;
exports.TriggerManager = index.TriggerManager;
exports.UpdaterService = index.UpdaterService;
exports.WorktreeGrouper = index.WorktreeGrouper;
exports.applyCursorAgentAttributionEnv = index.applyCursorAgentAttributionEnv;
exports.buildAIChunkFromBuffer = index.buildAIChunkFromBuffer;
exports.buildCompactChunk = index.buildCompactChunk;
exports.buildGroups = index.buildGroups;
exports.buildSemanticStepGroups = index.buildSemanticStepGroups;
exports.buildSubagentDetail = index.buildSubagentDetail;
exports.buildSystemChunk = index.buildSystemChunk;
exports.buildToolExecutions = index.buildToolExecutions;
exports.buildToolResultMap = index.buildToolResultMap;
exports.buildToolUseMap = index.buildToolUseMap;
exports.buildUserChunk = index.buildUserChunk;
exports.checkTokenThresholdTrigger = index.checkTokenThresholdTrigger;
exports.checkToolResultTrigger = index.checkToolResultTrigger;
exports.checkToolUseTrigger = index.checkToolUseTrigger;
exports.classifyMessages = index.classifyMessages;
exports.clearAutoResumeService = index.clearAutoResumeService;
exports.clearOpenCodeRuntimeBinaryResolverCache = index.clearOpenCodeRuntimeResolverCache;
exports.configManager = index.configManager;
exports.configureCursorAgentAtomicReapBridge = index.configureCursorAgentAtomicReapBridge;
exports.createDefaultTeamProvisioningService = index.createDefaultTeamProvisioningService;
exports.createDetectedError = index.createDetectedError;
exports.createExtensionsRuntimeAdapter = index.createExtensionsRuntimeAdapter;
exports.deriveSubagentDescription = index.deriveSubagentDescription;
exports.errorDetector = index.errorDetector;
exports.estimateTokens = index.estimateTokens;
exports.extractErrorMessage = index.extractErrorMessage;
exports.extractOpenCodeRuntimeBinaryFromTarball = index.extractOpenCodeRuntimeBinaryFromTarball;
exports.extractSearchableEntries = index.extractSearchableEntries;
exports.extractSemanticStepsFromAIChunk = index.extractSemanticStepsFromAIChunk;
exports.extractToolResults = index.extractToolResults;
exports.extractToolUseField = index.extractToolUseField;
exports.extractUserText = index.extractUserText;
exports.findToolNameByToolUseId = index.findToolNameByToolUseId;
exports.formatTokens = index.formatTokens;
exports.getAutoResumeService = index.getAutoResumeService;
exports.getContentBlocks = index.getContentBlocks;
exports.getOpenCodeRuntimePlatformCandidates = index.getOpenCodeRuntimePlatformCandidates;
exports.getOpenCodeTaskLogAttributionPath = index.getOpenCodeTaskLogAttributionPath;
exports.getToolSummary = index.getToolSummary;
exports.initializeAutoResumeService = index.initializeAutoResumeService;
exports.isSupportedOpenCodeRuntimeBinaryPath = index.isSupportedOpenCodeRuntimeBinaryPath;
exports.isTeamRuntimeProviderId = index.isTeamRuntimeProviderId;
exports.isVersionOlder = index.isVersionOlder;
exports.linkProcessesToAIChunk = index.linkProcessesToAIChunk;
exports.matchesIgnorePatterns = index.matchesIgnorePatterns;
exports.matchesPattern = index.matchesPattern;
exports.matchesRepositoryScope = index.matchesRepositoryScope;
exports.normalizeVersion = index.normalizeVersion;
exports.preResolveRepositoryIds = index.preResolveRepositoryIds;
exports.projectPathResolver = index.projectPathResolver;
exports.readAgentConfigs = index.readAgentConfigs;
exports.readAllClaudeMdFiles = index.readAllClaudeMdFiles;
exports.readDirectoryClaudeMd = index.readDirectoryClaudeMd;
exports.resolveAppManagedOpenCodeRuntimeBinaryPath = index.resolveAppManagedOpenCodeRuntimeBinaryPath;
exports.resolveCachedVerifiedOpenCodeRuntimeBinaryPath = index.resolveCachedVerifiedOpenCodeRuntimeBinaryPath;
exports.resolveVerifiedAppManagedOpenCodeRuntimeBinaryPath = index.resolveVerifiedAppManagedOpenCodeRuntimeBinaryPath;
exports.resolveVerifiedOpenCodeRuntimeBinaryPath = index.resolveVerifiedOpenCodeRuntimeBinaryPath;
exports.subprojectRegistry = index.subprojectRegistry;
exports.testTrigger = index.testTrigger;
exports.verifyOpenCodeRuntimePackageIntegrity = index.verifyOpenCodeRuntimePackageIntegrity;
exports.LocalFileSystemProvider = taskChangeState.LocalFileSystemProvider;
exports.TeamConfigReader = taskChangeState.TeamConfigReader;
exports.TeamInboxReader = taskChangeState.TeamInboxReader;
exports.TeamMemberLogsFinder = taskChangeState.TeamMemberLogsFinder;
exports.TeamMembersMetaStore = taskChangeState.TeamMembersMetaStore;
exports.TeamDataService = TeamDataService.TeamDataService;
exports.TeamInboxWriter = TeamDataService.TeamInboxWriter;
exports.TeamKanbanManager = TeamDataService.TeamKanbanManager;
exports.TeamMemberResolver = TeamDataService.TeamMemberResolver;
exports.TeamSentMessagesStore = TeamDataService.TeamSentMessagesStore;
exports.TeamTaskReader = TeamDataService.TeamTaskReader;
exports.TeamTaskWriter = TeamDataService.TeamTaskWriter;
exports.gitIdentityResolver = TeamDataService.gitIdentityResolver;
exports.TaskBoundaryParser = TaskBoundaryParser.TaskBoundaryParser;
exports.countLineChanges = TaskBoundaryParser.countLineChanges;
exports.HunkSnippetMatcher = HunkSnippetMatcher;
exports.OpenCodeTaskLogAttributionService = OpenCodeTaskLogAttributionService;
exports.SkillReviewService = SkillReviewService;
