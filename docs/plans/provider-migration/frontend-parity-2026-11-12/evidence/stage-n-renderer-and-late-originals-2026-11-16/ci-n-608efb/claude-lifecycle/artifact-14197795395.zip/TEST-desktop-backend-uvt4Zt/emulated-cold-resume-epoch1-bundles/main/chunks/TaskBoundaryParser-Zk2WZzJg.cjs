for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const taskChangeState = require("./taskChangeState-rZolvpL6.cjs");
const fs = require("fs");
const fs$1 = require("fs/promises");
const readline = require("readline");
const taskHistory = require("./taskHistory-2kbwfqIg.cjs");
const path = require("path");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const readline__namespace = /* @__PURE__ */ _interopNamespaceDefault(readline);
class Diff {
  diff(oldStr, newStr, options = {}) {
    let callback;
    if (typeof options === "function") {
      callback = options;
      options = {};
    } else if ("callback" in options) {
      callback = options.callback;
    }
    const oldString = this.castInput(oldStr, options);
    const newString = this.castInput(newStr, options);
    const oldTokens = this.removeEmpty(this.tokenize(oldString, options));
    const newTokens = this.removeEmpty(this.tokenize(newString, options));
    return this.diffWithOptionsObj(oldTokens, newTokens, options, callback);
  }
  diffWithOptionsObj(oldTokens, newTokens, options, callback) {
    var _a;
    const done = (value) => {
      value = this.postProcess(value, options);
      if (callback) {
        setTimeout(function() {
          callback(value);
        }, 0);
        return void 0;
      } else {
        return value;
      }
    };
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let editLength = 1;
    let maxEditLength = newLen + oldLen;
    if (options.maxEditLength != null) {
      maxEditLength = Math.min(maxEditLength, options.maxEditLength);
    }
    const maxExecutionTime = (_a = options.timeout) !== null && _a !== void 0 ? _a : Infinity;
    const abortAfterTimestamp = Date.now() + maxExecutionTime;
    const bestPath = [{ oldPos: -1, lastComponent: void 0 }];
    let newPos = this.extractCommon(bestPath[0], newTokens, oldTokens, 0, options);
    if (bestPath[0].oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
      return done(this.buildValues(bestPath[0].lastComponent, newTokens, oldTokens));
    }
    let minDiagonalToConsider = -Infinity, maxDiagonalToConsider = Infinity;
    const execEditLength = () => {
      for (let diagonalPath = Math.max(minDiagonalToConsider, -editLength); diagonalPath <= Math.min(maxDiagonalToConsider, editLength); diagonalPath += 2) {
        let basePath;
        const removePath = bestPath[diagonalPath - 1], addPath = bestPath[diagonalPath + 1];
        if (removePath) {
          bestPath[diagonalPath - 1] = void 0;
        }
        let canAdd = false;
        if (addPath) {
          const addPathNewPos = addPath.oldPos - diagonalPath;
          canAdd = addPath && 0 <= addPathNewPos && addPathNewPos < newLen;
        }
        const canRemove = removePath && removePath.oldPos + 1 < oldLen;
        if (!canAdd && !canRemove) {
          bestPath[diagonalPath] = void 0;
          continue;
        }
        if (!canRemove || canAdd && removePath.oldPos < addPath.oldPos) {
          basePath = this.addToPath(addPath, true, false, 0, options);
        } else {
          basePath = this.addToPath(removePath, false, true, 1, options);
        }
        newPos = this.extractCommon(basePath, newTokens, oldTokens, diagonalPath, options);
        if (basePath.oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
          return done(this.buildValues(basePath.lastComponent, newTokens, oldTokens)) || true;
        } else {
          bestPath[diagonalPath] = basePath;
          if (basePath.oldPos + 1 >= oldLen) {
            maxDiagonalToConsider = Math.min(maxDiagonalToConsider, diagonalPath - 1);
          }
          if (newPos + 1 >= newLen) {
            minDiagonalToConsider = Math.max(minDiagonalToConsider, diagonalPath + 1);
          }
        }
      }
      editLength++;
    };
    if (callback) {
      (function exec() {
        setTimeout(function() {
          if (editLength > maxEditLength || Date.now() > abortAfterTimestamp) {
            return callback(void 0);
          }
          if (!execEditLength()) {
            exec();
          }
        }, 0);
      })();
    } else {
      while (editLength <= maxEditLength && Date.now() <= abortAfterTimestamp) {
        const ret = execEditLength();
        if (ret) {
          return ret;
        }
      }
    }
  }
  addToPath(path2, added, removed, oldPosInc, options) {
    const last = path2.lastComponent;
    if (last && !options.oneChangePerToken && last.added === added && last.removed === removed) {
      return {
        oldPos: path2.oldPos + oldPosInc,
        lastComponent: { count: last.count + 1, added, removed, previousComponent: last.previousComponent }
      };
    } else {
      return {
        oldPos: path2.oldPos + oldPosInc,
        lastComponent: { count: 1, added, removed, previousComponent: last }
      };
    }
  }
  extractCommon(basePath, newTokens, oldTokens, diagonalPath, options) {
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let oldPos = basePath.oldPos, newPos = oldPos - diagonalPath, commonCount = 0;
    while (newPos + 1 < newLen && oldPos + 1 < oldLen && this.equals(oldTokens[oldPos + 1], newTokens[newPos + 1], options)) {
      newPos++;
      oldPos++;
      commonCount++;
      if (options.oneChangePerToken) {
        basePath.lastComponent = { count: 1, previousComponent: basePath.lastComponent, added: false, removed: false };
      }
    }
    if (commonCount && !options.oneChangePerToken) {
      basePath.lastComponent = { count: commonCount, previousComponent: basePath.lastComponent, added: false, removed: false };
    }
    basePath.oldPos = oldPos;
    return newPos;
  }
  equals(left, right, options) {
    if (options.comparator) {
      return options.comparator(left, right);
    } else {
      return left === right || !!options.ignoreCase && left.toLowerCase() === right.toLowerCase();
    }
  }
  removeEmpty(array) {
    const ret = [];
    for (let i = 0; i < array.length; i++) {
      if (array[i]) {
        ret.push(array[i]);
      }
    }
    return ret;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  castInput(value, options) {
    return value;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  tokenize(value, options) {
    return Array.from(value);
  }
  join(chars) {
    return chars.join("");
  }
  postProcess(changeObjects, options) {
    return changeObjects;
  }
  get useLongestToken() {
    return false;
  }
  buildValues(lastComponent, newTokens, oldTokens) {
    const components = [];
    let nextComponent;
    while (lastComponent) {
      components.push(lastComponent);
      nextComponent = lastComponent.previousComponent;
      delete lastComponent.previousComponent;
      lastComponent = nextComponent;
    }
    components.reverse();
    const componentLen = components.length;
    let componentPos = 0, newPos = 0, oldPos = 0;
    for (; componentPos < componentLen; componentPos++) {
      const component = components[componentPos];
      if (!component.removed) {
        if (!component.added && this.useLongestToken) {
          let value = newTokens.slice(newPos, newPos + component.count);
          value = value.map(function(value2, i) {
            const oldValue = oldTokens[oldPos + i];
            return oldValue.length > value2.length ? oldValue : value2;
          });
          component.value = this.join(value);
        } else {
          component.value = this.join(newTokens.slice(newPos, newPos + component.count));
        }
        newPos += component.count;
        if (!component.added) {
          oldPos += component.count;
        }
      } else {
        component.value = this.join(oldTokens.slice(oldPos, oldPos + component.count));
        oldPos += component.count;
      }
    }
    return components;
  }
}
class LineDiff extends Diff {
  constructor() {
    super(...arguments);
    this.tokenize = tokenize;
  }
  equals(left, right, options) {
    if (options.ignoreWhitespace) {
      if (!options.newlineIsToken || !left.includes("\n")) {
        left = left.trim();
      }
      if (!options.newlineIsToken || !right.includes("\n")) {
        right = right.trim();
      }
    } else if (options.ignoreNewlineAtEof && !options.newlineIsToken) {
      if (left.endsWith("\n")) {
        left = left.slice(0, -1);
      }
      if (right.endsWith("\n")) {
        right = right.slice(0, -1);
      }
    }
    return super.equals(left, right, options);
  }
}
const lineDiff = new LineDiff();
function diffLines(oldStr, newStr, options) {
  return lineDiff.diff(oldStr, newStr, options);
}
function tokenize(value, options) {
  if (options.stripTrailingCr) {
    value = value.replace(/\r\n/g, "\n");
  }
  const retLines = [], linesAndNewlines = value.split(/(\n|\r\n)/);
  if (!linesAndNewlines[linesAndNewlines.length - 1]) {
    linesAndNewlines.pop();
  }
  for (let i = 0; i < linesAndNewlines.length; i++) {
    const line = linesAndNewlines[i];
    if (i % 2 && !options.newlineIsToken) {
      retLines[retLines.length - 1] += line;
    } else {
      retLines.push(line);
    }
  }
  return retLines;
}
function parsePatch(uniDiff) {
  const diffstr = uniDiff.split(/\n/), list = [];
  let i = 0;
  function parseIndex() {
    const index = {};
    list.push(index);
    while (i < diffstr.length) {
      const line = diffstr[i];
      if (/^(---|\+\+\+|@@)\s/.test(line)) {
        break;
      }
      const headerMatch = /^(?:Index:|diff(?: -r \w+)+)\s+/.exec(line);
      if (headerMatch) {
        index.index = line.substring(headerMatch[0].length).trim();
      }
      i++;
    }
    parseFileHeader(index);
    parseFileHeader(index);
    index.hunks = [];
    while (i < diffstr.length) {
      const line = diffstr[i];
      if (/^(Index:\s|diff\s|---\s|\+\+\+\s|===================================================================)/.test(line)) {
        break;
      } else if (/^@@/.test(line)) {
        index.hunks.push(parseHunk());
      } else if (line) {
        throw new Error("Unknown line " + (i + 1) + " " + JSON.stringify(line));
      } else {
        i++;
      }
    }
  }
  function parseFileHeader(index) {
    const fileHeaderMatch = /^(---|\+\+\+)\s+/.exec(diffstr[i]);
    if (fileHeaderMatch) {
      const prefix = fileHeaderMatch[1], data = diffstr[i].substring(3).trim().split("	", 2), header = (data[1] || "").trim();
      let fileName = data[0].replace(/\\\\/g, "\\");
      if (fileName.startsWith('"') && fileName.endsWith('"')) {
        fileName = fileName.substr(1, fileName.length - 2);
      }
      if (prefix === "---") {
        index.oldFileName = fileName;
        index.oldHeader = header;
      } else {
        index.newFileName = fileName;
        index.newHeader = header;
      }
      i++;
    }
  }
  function parseHunk() {
    var _a;
    const chunkHeaderIndex = i, chunkHeaderLine = diffstr[i++], chunkHeader = chunkHeaderLine.split(/@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
    const hunk = {
      oldStart: +chunkHeader[1],
      oldLines: typeof chunkHeader[2] === "undefined" ? 1 : +chunkHeader[2],
      newStart: +chunkHeader[3],
      newLines: typeof chunkHeader[4] === "undefined" ? 1 : +chunkHeader[4],
      lines: []
    };
    if (hunk.oldLines === 0) {
      hunk.oldStart += 1;
    }
    if (hunk.newLines === 0) {
      hunk.newStart += 1;
    }
    let addCount = 0, removeCount = 0;
    for (; i < diffstr.length && (removeCount < hunk.oldLines || addCount < hunk.newLines || ((_a = diffstr[i]) === null || _a === void 0 ? void 0 : _a.startsWith("\\"))); i++) {
      const operation = diffstr[i].length == 0 && i != diffstr.length - 1 ? " " : diffstr[i][0];
      if (operation === "+" || operation === "-" || operation === " " || operation === "\\") {
        hunk.lines.push(diffstr[i]);
        if (operation === "+") {
          addCount++;
        } else if (operation === "-") {
          removeCount++;
        } else if (operation === " ") {
          addCount++;
          removeCount++;
        }
      } else {
        throw new Error(`Hunk at line ${chunkHeaderIndex + 1} contained invalid line ${diffstr[i]}`);
      }
    }
    if (!addCount && hunk.newLines === 1) {
      hunk.newLines = 0;
    }
    if (!removeCount && hunk.oldLines === 1) {
      hunk.oldLines = 0;
    }
    if (addCount !== hunk.newLines) {
      throw new Error("Added line count did not match for hunk at line " + (chunkHeaderIndex + 1));
    }
    if (removeCount !== hunk.oldLines) {
      throw new Error("Removed line count did not match for hunk at line " + (chunkHeaderIndex + 1));
    }
    return hunk;
  }
  while (i < diffstr.length) {
    parseIndex();
  }
  return list;
}
function countLineChanges(oldText, newText) {
  if (!oldText && !newText)
    return { added: 0, removed: 0 };
  if (!oldText)
    return { added: countTextLines(newText), removed: 0 };
  if (!newText)
    return { added: 0, removed: countTextLines(oldText) };
  let added = 0;
  let removed = 0;
  for (const change of diffLines(oldText, newText)) {
    if (change.added)
      added += change.count ?? 0;
    if (change.removed)
      removed += change.count ?? 0;
  }
  return { added, removed };
}
function countTextLines(value) {
  if (!value)
    return 0;
  let lines = 1;
  for (let index = 0; index < value.length; index += 1) {
    if (value.charCodeAt(index) === 10)
      lines += 1;
  }
  return value.endsWith("\n") ? lines - 1 : lines;
}
function extractMetadataChangePaths(input) {
  const changes = Array.isArray(input.changes) ? input.changes : [];
  const paths = [];
  for (const change of changes) {
    if (!change || typeof change !== "object") continue;
    const changeObj = change;
    const filePath = typeof changeObj.path === "string" ? changeObj.path : "";
    if (!filePath) continue;
    const kind = typeof changeObj.kind === "string" ? changeObj.kind : void 0;
    paths.push({ filePath, change: changeObj, ...kind ? { kind } : {} });
  }
  return paths;
}
function parseCodexChangeHunks(diff) {
  try {
    const patches = parsePatch(diff);
    if (patches.length !== 1 || patches[0].hunks.length === 0) return null;
    const result = [];
    for (const hunk of patches[0].hunks) {
      const oldLines = [];
      const newLines = [];
      let oldHasTrailingNewline = true;
      let newHasTrailingNewline = true;
      let previousMarker = null;
      for (const line of hunk.lines) {
        if (line === "\\ No newline at end of file") {
          if (previousMarker === "-" || previousMarker === " ") oldHasTrailingNewline = false;
          if (previousMarker === "+" || previousMarker === " ") newHasTrailingNewline = false;
          if (previousMarker !== "-" && previousMarker !== "+" && previousMarker !== " ")
            return null;
          previousMarker = null;
          continue;
        }
        const marker = line[0];
        if (marker === " " || marker === "-") oldLines.push(line.slice(1));
        if (marker === " " || marker === "+") newLines.push(line.slice(1));
        if (marker !== " " && marker !== "-" && marker !== "+") return null;
        previousMarker = marker;
      }
      if (oldLines.length !== hunk.oldLines || newLines.length !== hunk.newLines) return null;
      result.push({
        oldString: oldLines.length > 0 ? oldLines.join("\n") + (oldHasTrailingNewline ? "\n" : "") : "",
        newString: newLines.length > 0 ? newLines.join("\n") + (newHasTrailingNewline ? "\n" : "") : ""
      });
    }
    return result;
  } catch {
    return null;
  }
}
function extractEditToolSnippets(input, context) {
  const oldString = typeof input.old_string === "string" ? input.old_string : "";
  const newString = typeof input.new_string === "string" ? input.new_string : "";
  const hasTextPayload = typeof input.old_string === "string" || typeof input.new_string === "string";
  const metadataPaths = hasTextPayload ? [] : extractMetadataChangePaths(input);
  const targetPath = typeof input.file_path === "string" ? input.file_path : "";
  const targetPaths = metadataPaths.length > 0 ? metadataPaths : targetPath ? [{ filePath: targetPath }] : [];
  const snippets = [];
  for (const target of targetPaths) {
    const codexChange = ("change" in target ? target.change : void 0) ?? (Array.isArray(input.changes) ? input.changes.find(
      (change) => change && typeof change === "object" && change.path === target.filePath
    ) : void 0);
    const codexKind = codexChange?.kind;
    const codexKindType = typeof codexKind === "string" ? codexKind : codexKind && typeof codexKind === "object" ? codexKind.type : null;
    const codexHunks = !hasTextPayload && (codexKindType === "update" || codexKindType === "add" || codexKindType === "delete") && typeof codexChange?.diff === "string" ? parseCodexChangeHunks(codexChange.diff) : null;
    const isCodexAdd = codexKindType === "add" && (codexHunks === null || codexHunks.every((pair) => pair.oldString === ""));
    const pairs = codexHunks ?? [{ oldString, newString }];
    for (const pair of pairs) {
      snippets.push({
        toolUseId: context.toolUseId,
        filePath: target.filePath,
        toolName: "Edit",
        type: !hasTextPayload && (isCodexAdd || codexHunks === null && "kind" in target && target.kind === "add") ? "write-new" : "edit",
        oldString: pair.oldString,
        newString: pair.newString,
        replaceAll: codexHunks ? false : input.replace_all === true,
        timestamp: context.timestamp,
        isError: context.isError,
        contextHash: context.includeDetails ? context.computeContextHash(pair.oldString, pair.newString) : void 0
      });
    }
  }
  return snippets;
}
function resolveExistingAncestor(filePath, pathApi) {
  let candidate = filePath;
  const missingSegments = [];
  while (true) {
    try {
      return pathApi.join(fs.realpathSync.native(candidate), ...missingSegments.reverse());
    } catch (error) {
      if (error.code !== "ENOENT") break;
      const parent = pathApi.dirname(candidate);
      if (parent === candidate) break;
      missingSegments.push(pathApi.basename(candidate));
      candidate = parent;
    }
  }
  return filePath;
}
function taskChangeFileIdentity(filePath) {
  const slashes = filePath.replace(/\\/g, "/");
  if (taskChangeState.isWindowsishPath(slashes)) {
    if (process.platform === "win32") {
      return resolveExistingAncestor(filePath, path.win32).replace(/\\/g, "/");
    }
    return taskChangeState.normalizePathForComparison(path.win32.normalize(filePath));
  }
  const resolved = slashes.startsWith("/") ? resolveExistingAncestor(slashes, path.posix) : slashes;
  return path.posix.normalize(resolved);
}
const logger$1 = taskChangeState.createLogger("Service:TaskChangeComputer");
const NO_LOG_FILES_FOUND_WARNING = "No log files found for this task.";
function shouldWarnAboutUnavailableTaskChangeEvidence(input) {
  const status = input.taskMeta?.status?.trim() || input.effectiveOptions.status?.trim();
  const stateBucket = taskChangeState.getTaskChangeStateBucket({
    status,
    reviewState: input.taskMeta?.reviewState,
    historyEvents: input.taskMeta?.historyEvents,
    kanbanColumn: input.taskMeta?.kanbanColumn
  });
  return stateBucket === "completed" || stateBucket === "review" || stateBucket === "approved";
}
const DEFAULT_MAX_SUMMARY_JSONL_PARSE_BYTES = 2 * 1024 * 1024;
class TaskChangeComputer {
  constructor(logsFinder, boundaryParser, options = {}) {
    this.logsFinder = logsFinder;
    this.boundaryParser = boundaryParser;
    this.maxSummaryJsonlParseBytes = options.maxSummaryJsonlParseBytes ?? DEFAULT_MAX_SUMMARY_JSONL_PARSE_BYTES;
  }
  logsFinder;
  boundaryParser;
  parsedSnippetsCache = /* @__PURE__ */ new Map();
  parsedSnippetsInFlight = /* @__PURE__ */ new Map();
  parsedSnippetsCacheBytes = 0;
  parsedSnippetsCacheTtl = 20 * 1e3;
  maxParsedSnippetsCacheEntries = 1e3;
  maxParsedSnippetsCacheBytes = 8 * 1024 * 1024;
  maxSummaryJsonlParseBytes;
  static JSONL_PARSE_CONCURRENCY = 6;
  async computeAgentChanges(teamName, memberName, projectPath) {
    const paths = await this.logsFinder.findMemberLogPaths(teamName, memberName);
    const parseResults = await this.parseJSONLFilesWithConcurrency(paths, true);
    let latestMtime = 0;
    const merged = [];
    for (const result of parseResults) {
      merged.push(...result.snippets);
      if (result.mtime > latestMtime) {
        latestMtime = result.mtime;
      }
    }
    const files = this.aggregateByFile(
      this.sortSnippetRecordsChronologically(merged),
      projectPath,
      true
    );
    const taskChangeResult = {
      teamName,
      memberName,
      files,
      totalLinesAdded: files.reduce((sum, file) => sum + file.linesAdded, 0),
      totalLinesRemoved: files.reduce((sum, file) => sum + file.linesRemoved, 0),
      totalFiles: files.length,
      computedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    return { result: taskChangeResult, latestMtime };
  }
  async computeTaskChanges(input) {
    const { teamName, taskId, taskMeta, effectiveOptions, projectPath, includeDetails } = input;
    const logRefs = await this.logsFinder.findLogFileRefsForTask(
      teamName,
      taskId,
      effectiveOptions
    );
    if (logRefs.length === 0) {
      return this.emptyTaskChangeSet(input);
    }
    const allScopes = [];
    const scopesByLogPath = /* @__PURE__ */ new Map();
    for (const ref of logRefs) {
      const boundaries = await this.boundaryParser.parseBoundaries(ref.filePath);
      const scope = boundaries.scopes.find((candidate) => candidate.taskId === taskId);
      if (scope) {
        const scoped = { ...scope, memberName: ref.memberName };
        allScopes.push(scoped);
        scopesByLogPath.set(ref.filePath, scoped);
      }
    }
    if (allScopes.length === 0) {
      const intervalScoped = await this.buildIntervalScopedTaskChangeSet({
        teamName,
        taskId,
        taskMeta,
        logRefs,
        intervals: effectiveOptions.intervals,
        projectPath,
        includeDetails,
        warningWithFiles: "Task boundaries missing - scoped by workIntervals timestamps.",
        warningWithoutFiles: "No file edits found within persisted workIntervals."
      });
      if (intervalScoped) return intervalScoped;
      return this.fallbackSingleTaskScope(input, logRefs);
    }
    const files = await this.extractScopedChanges(
      logRefs,
      scopesByLogPath,
      projectPath,
      includeDetails
    );
    const worstTier = Math.max(...allScopes.map((scope) => scope.confidence.tier));
    if (worstTier >= 3) {
      const intervalScoped = await this.buildIntervalScopedTaskChangeSet({
        teamName,
        taskId,
        taskMeta,
        logRefs: this.selectScopedLogRefs(logRefs, allScopes),
        intervals: effectiveOptions.intervals,
        projectPath,
        includeDetails,
        warningWithFiles: "Task start boundary missing - scoped by persisted workIntervals timestamps.",
        warningWithoutFiles: "No file edits found within persisted workIntervals."
      });
      if (intervalScoped && intervalScoped.files.length > 0) {
        return intervalScoped;
      }
    }
    return {
      teamName,
      taskId,
      files,
      totalLinesAdded: files.reduce((sum, file) => sum + file.linesAdded, 0),
      totalLinesRemoved: files.reduce((sum, file) => sum + file.linesRemoved, 0),
      totalFiles: files.length,
      confidence: worstTier <= 1 ? "high" : worstTier <= 2 ? "medium" : "low",
      computedAt: (/* @__PURE__ */ new Date()).toISOString(),
      scope: allScopes[0],
      warnings: worstTier >= 3 ? ["Some task boundaries could not be precisely determined."] : []
    };
  }
  selectScopedLogRefs(logRefs, scopes) {
    const scopedMembers = new Set(
      scopes.map((scope) => scope.memberName).filter((memberName) => memberName.length > 0)
    );
    if (scopedMembers.size === 0) {
      return logRefs;
    }
    const selected = logRefs.filter((ref) => scopedMembers.has(ref.memberName));
    return selected.length > 0 ? selected : logRefs;
  }
  async buildIntervalScopedTaskChangeSet(input) {
    const intervals = input.intervals;
    if (!Array.isArray(intervals) || intervals.length === 0) {
      return null;
    }
    const { files, toolUseIds, startTimestamp, endTimestamp } = await this.extractIntervalScopedChanges(
      input.logRefs,
      intervals,
      input.projectPath,
      input.includeDetails
    );
    return {
      teamName: input.teamName,
      taskId: input.taskId,
      files,
      totalLinesAdded: files.reduce((sum, file) => sum + file.linesAdded, 0),
      totalLinesRemoved: files.reduce((sum, file) => sum + file.linesRemoved, 0),
      totalFiles: files.length,
      confidence: "medium",
      computedAt: (/* @__PURE__ */ new Date()).toISOString(),
      scope: {
        taskId: input.taskId,
        memberName: input.taskMeta?.owner ?? input.logRefs[0]?.memberName ?? "",
        startLine: 0,
        endLine: 0,
        startTimestamp,
        endTimestamp,
        toolUseIds,
        filePaths: files.map((file) => file.filePath),
        confidence: {
          tier: 2,
          label: "medium",
          reason: "Scoped by persisted task workIntervals (timestamp-based)"
        }
      },
      warnings: [files.length === 0 ? input.warningWithoutFiles : input.warningWithFiles]
    };
  }
  async extractIntervalScopedChanges(logRefs, intervals, projectPath, includeDetails = true) {
    const normalized = [];
    for (const interval of intervals) {
      const startMs = Date.parse(interval.startedAt);
      if (!Number.isFinite(startMs)) continue;
      const endMsRaw = typeof interval.completedAt === "string" ? Date.parse(interval.completedAt) : Number.NaN;
      const endMs = interval.completedAt === void 0 ? null : Number.isFinite(endMsRaw) ? Math.max(endMsRaw, startMs) : startMs;
      normalized.push({
        startMs,
        endMs,
        startedAt: interval.startedAt,
        completedAt: interval.completedAt
      });
    }
    normalized.sort((a, b) => a.startMs - b.startMs);
    const startTimestamp = normalized[0]?.startedAt ?? "";
    const maxEnd = normalized.reduce(
      (acc, item) => {
        if (item.endMs == null || typeof item.completedAt !== "string" || !Number.isFinite(Date.parse(item.completedAt))) {
          return acc;
        }
        if (!acc || item.endMs > acc.endMs) {
          return { endMs: item.endMs, endTimestamp: item.completedAt };
        }
        return acc;
      },
      null
    );
    const endTimestamp = maxEnd?.endTimestamp ?? "";
    const inAnyInterval = (timestamp) => {
      const ms = Date.parse(timestamp);
      if (!Number.isFinite(ms)) return false;
      for (const interval of normalized) {
        if (ms < interval.startMs) continue;
        if (interval.endMs == null) return true;
        if (ms <= interval.endMs) return true;
      }
      return false;
    };
    const allParsed = await this.parseJSONLFilesWithConcurrency(
      logRefs.map((ref) => ref.filePath),
      includeDetails
    );
    const allowedSnippets = [];
    const toolUseIdsSet = /* @__PURE__ */ new Set();
    for (const { snippets } of allParsed) {
      for (const record of snippets) {
        const { snippet } = record;
        if (snippet.isError) continue;
        if (!inAnyInterval(snippet.timestamp)) continue;
        allowedSnippets.push(record);
        if (snippet.toolUseId) {
          toolUseIdsSet.add(snippet.toolUseId);
        }
      }
    }
    return {
      files: this.aggregateByFile(
        this.sortSnippetRecordsChronologically(allowedSnippets),
        projectPath,
        includeDetails
      ),
      toolUseIds: [...toolUseIdsSet],
      startTimestamp,
      endTimestamp
    };
  }
  async extractScopedChanges(logRefs, scopesByLogPath, projectPath, includeDetails = true) {
    if (![...scopesByLogPath.values()].some((scope) => scope.toolUseIds.length > 0)) {
      return [];
    }
    const allParsed = await this.parseJSONLFilesWithConcurrency(
      logRefs.map((ref) => ref.filePath),
      includeDetails
    );
    const allSnippets = [];
    for (let index = 0; index < allParsed.length; index++) {
      const ref = logRefs[index];
      const parsed = allParsed[index];
      if (!ref || !parsed) continue;
      const scope = scopesByLogPath.get(ref.filePath);
      if (!scope || scope.toolUseIds.length === 0) continue;
      for (const record of parsed.snippets) {
        if (this.recordMatchesScope(record, scope)) allSnippets.push(record);
      }
    }
    return this.aggregateByFile(
      this.sortSnippetRecordsChronologically(allSnippets),
      projectPath,
      includeDetails
    );
  }
  recordMatchesScope(record, scope) {
    const snippet = record.snippet;
    if (!scope.toolUseIds.includes(snippet.toolUseId)) return false;
    if (record.sourceLine < scope.startLine || record.sourceLine > scope.endLine) return false;
    if (!this.timestampMatchesScope(snippet.timestamp, scope)) return false;
    if (!this.filePathMatchesScope(snippet.filePath, scope.filePaths)) return false;
    return true;
  }
  timestampMatchesScope(timestamp, scope) {
    const snippetMs = Date.parse(timestamp);
    if (!Number.isFinite(snippetMs)) return true;
    const startMs = scope.startTimestamp ? Date.parse(scope.startTimestamp) : Number.NaN;
    if (Number.isFinite(startMs) && snippetMs < startMs) return false;
    const endMs = scope.endTimestamp ? Date.parse(scope.endTimestamp) : Number.NaN;
    if (Number.isFinite(endMs) && snippetMs > endMs) return false;
    return true;
  }
  filePathMatchesScope(filePath, scopeFilePaths) {
    if (scopeFilePaths.length === 0) return true;
    const normalizedFilePath = this.normalizeFilePathKey(filePath);
    return scopeFilePaths.some((scopePath) => {
      const normalizedScopePath = this.normalizeFilePathKey(scopePath);
      return normalizedFilePath === normalizedScopePath || normalizedFilePath.endsWith(`/${normalizedScopePath}`) || normalizedScopePath.endsWith(`/${normalizedFilePath}`);
    });
  }
  async fallbackSingleTaskScope(input, logRefs) {
    const { teamName, taskId, projectPath, includeDetails } = input;
    const allParsed = await this.parseJSONLFilesWithConcurrency(
      logRefs.map((ref) => ref.filePath),
      includeDetails
    );
    const allSnippets = this.sortSnippetRecordsChronologically(
      allParsed.flatMap((result) => result.snippets)
    );
    const aggregatedFiles = this.aggregateByFile(allSnippets, projectPath, includeDetails);
    const shouldWarn = aggregatedFiles.length > 0 || shouldWarnAboutUnavailableTaskChangeEvidence(input);
    return {
      teamName,
      taskId,
      files: aggregatedFiles,
      totalLinesAdded: aggregatedFiles.reduce((sum, file) => sum + file.linesAdded, 0),
      totalLinesRemoved: aggregatedFiles.reduce((sum, file) => sum + file.linesRemoved, 0),
      totalFiles: aggregatedFiles.length,
      confidence: "fallback",
      computedAt: (/* @__PURE__ */ new Date()).toISOString(),
      scope: {
        taskId,
        memberName: logRefs[0]?.memberName ?? "unknown",
        startLine: 1,
        endLine: 0,
        startTimestamp: "",
        endTimestamp: "",
        toolUseIds: [],
        filePaths: aggregatedFiles.map((file) => file.filePath),
        confidence: { tier: 4, label: "fallback", reason: "No task boundaries found in JSONL" }
      },
      warnings: shouldWarn ? ["No task boundaries found - showing all changes from related sessions."] : []
    };
  }
  emptyTaskChangeSet(input) {
    const { teamName, taskId } = input;
    return {
      teamName,
      taskId,
      files: [],
      totalLinesAdded: 0,
      totalLinesRemoved: 0,
      totalFiles: 0,
      confidence: "fallback",
      computedAt: (/* @__PURE__ */ new Date()).toISOString(),
      scope: {
        taskId,
        memberName: "",
        startLine: 0,
        endLine: 0,
        startTimestamp: "",
        endTimestamp: "",
        toolUseIds: [],
        filePaths: [],
        confidence: { tier: 4, label: "fallback", reason: "No log files found for task" }
      },
      warnings: shouldWarnAboutUnavailableTaskChangeEvidence(input) ? [NO_LOG_FILES_FOUND_WARNING] : []
    };
  }
  async parseJSONLFilesWithConcurrency(paths, includeDetails) {
    if (paths.length === 0) return [];
    const results = new Array(paths.length);
    let nextIndex = 0;
    const worker = async () => {
      while (true) {
        const currentIndex = nextIndex++;
        if (currentIndex >= paths.length) return;
        results[currentIndex] = await this.parseJSONLFile(paths[currentIndex], includeDetails);
      }
    };
    await Promise.all(
      Array.from(
        { length: Math.min(TaskChangeComputer.JSONL_PARSE_CONCURRENCY, paths.length) },
        () => worker()
      )
    );
    return results;
  }
  async parseJSONLFile(filePath, includeDetails) {
    const cacheKey = this.buildParsedSnippetsCacheKey(filePath, includeDetails);
    let fileMtime = 0;
    try {
      const fileStat = await fs$1.stat(filePath);
      fileMtime = fileStat.mtimeMs;
      const cached = this.parsedSnippetsCache.get(cacheKey);
      if (cached?.mtime === fileMtime && cached.expiresAt > Date.now()) {
        return { snippets: cached.data, mtime: fileMtime };
      }
    } catch (error) {
      logger$1.debug(`Не удалось stat файла ${filePath}: ${String(error)}`);
      return { snippets: [], mtime: 0 };
    }
    const inFlightKey = `${cacheKey}:${fileMtime}`;
    const inFlight = this.parsedSnippetsInFlight.get(inFlightKey);
    if (inFlight) return inFlight;
    const promise = this.parseJSONLFileUncached(filePath, fileMtime, includeDetails).finally(() => {
      if (this.parsedSnippetsInFlight.get(inFlightKey) === promise) {
        this.parsedSnippetsInFlight.delete(inFlightKey);
      }
    });
    this.parsedSnippetsInFlight.set(inFlightKey, promise);
    return promise;
  }
  async parseJSONLFileUncached(filePath, fileMtime, includeDetails) {
    const snippets = [];
    const snippetsByToolUseId = /* @__PURE__ */ new Map();
    const erroredIds = /* @__PURE__ */ new Set();
    const markErroredToolUseId = (toolUseId) => {
      erroredIds.add(toolUseId);
      for (const record of snippetsByToolUseId.get(toolUseId) ?? []) {
        record.snippet.isError = true;
      }
    };
    const markErroredIds = (entry) => {
      for (const toolUseId of this.collectErroredToolUseIdsFromEntry(entry)) {
        markErroredToolUseId(toolUseId);
      }
    };
    const addSnippet = (lineNumber, snippet, lineCounts) => {
      const { added, removed } = lineCounts ?? countLineChanges(snippet.oldString, snippet.newString);
      const record = {
        snippet: includeDetails ? snippet : { ...snippet, oldString: "", newString: "" },
        sourceLine: lineNumber,
        linesAdded: added,
        linesRemoved: removed
      };
      snippets.push(record);
      if (snippet.toolUseId) {
        const records = snippetsByToolUseId.get(snippet.toolUseId);
        if (records) {
          records.push(record);
        } else {
          snippetsByToolUseId.set(snippet.toolUseId, [record]);
        }
      }
    };
    try {
      const stream = fs.createReadStream(filePath, { encoding: "utf8" });
      const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
      let lineNumber = 0;
      for await (const line of rl) {
        lineNumber += 1;
        const trimmed = line.trim();
        if (!trimmed) continue;
        let entry;
        if (!includeDetails && this.maxSummaryJsonlParseBytes > 0 && Buffer.byteLength(trimmed, "utf8") > this.maxSummaryJsonlParseBytes) {
          for (const toolUseId of this.collectRawErroredToolUseIds(trimmed)) {
            markErroredToolUseId(toolUseId);
          }
          const oversizedSnippets = this.extractOversizedSummarySnippets(
            lineNumber,
            trimmed,
            erroredIds
          );
          for (const oversized of oversizedSnippets) {
            addSnippet(lineNumber, oversized.snippet, oversized.lineCounts);
          }
          continue;
        }
        try {
          entry = JSON.parse(trimmed);
        } catch {
          continue;
        }
        markErroredIds(entry);
        const role = this.extractRole(entry);
        if (role !== "assistant") continue;
        const content = this.extractContent(entry);
        if (!content) continue;
        const timestamp = typeof entry.timestamp === "string" ? entry.timestamp : (/* @__PURE__ */ new Date()).toISOString();
        for (const block of content) {
          if (!block || typeof block !== "object" || block.type !== "tool_use") {
            continue;
          }
          const toolBlock = block;
          const rawName = typeof toolBlock.name === "string" ? toolBlock.name : "";
          const toolName = rawName.startsWith("proxy_") ? rawName.slice(6) : rawName;
          const toolUseId = typeof toolBlock.id === "string" ? toolBlock.id : "";
          const input = toolBlock.input;
          if (!input) continue;
          const isError = erroredIds.has(toolUseId);
          if (toolName === "Edit") {
            for (const snippet of extractEditToolSnippets(input, {
              toolUseId,
              timestamp,
              isError,
              includeDetails,
              computeContextHash: (oldString, newString) => this.computeContextHash(oldString, newString)
            })) {
              addSnippet(lineNumber, snippet);
            }
          } else if (toolName === "Write") {
            const targetPath = typeof input.file_path === "string" ? input.file_path : "";
            const writeContent = typeof input.content === "string" ? input.content : "";
            if (targetPath) {
              addSnippet(lineNumber, {
                toolUseId,
                filePath: targetPath,
                toolName: "Write",
                // A first-seen legacy Write is not proof that the file did not exist before
                // the task. Treat it as an update unless a separate lifecycle signal (for
                // example metadata kind=add or a ledger create event) proves creation.
                type: "write-update",
                oldString: "",
                newString: writeContent,
                replaceAll: false,
                timestamp,
                isError,
                contextHash: includeDetails ? this.computeContextHash("", writeContent) : void 0
              });
            }
          } else if (toolName === "MultiEdit") {
            const targetPath = typeof input.file_path === "string" ? input.file_path : "";
            const edits = Array.isArray(input.edits) ? input.edits : [];
            if (targetPath) {
              for (const edit of edits) {
                if (!edit || typeof edit !== "object") continue;
                const editObj = edit;
                const oldString = typeof editObj.old_string === "string" ? editObj.old_string : "";
                const newString = typeof editObj.new_string === "string" ? editObj.new_string : "";
                addSnippet(lineNumber, {
                  toolUseId,
                  filePath: targetPath,
                  toolName: "MultiEdit",
                  type: "multi-edit",
                  oldString,
                  newString,
                  replaceAll: false,
                  timestamp,
                  isError,
                  contextHash: includeDetails ? this.computeContextHash(oldString, newString) : void 0
                });
              }
            }
          }
        }
      }
      rl.close();
      stream.destroy();
    } catch (error) {
      logger$1.debug(`Не удалось прочитать файл ${filePath}: ${String(error)}`);
      return { snippets: [], mtime: 0 };
    }
    this.setParsedSnippetsCache(filePath, includeDetails, fileMtime, snippets);
    return { snippets, mtime: fileMtime };
  }
  extractOversizedSummarySnippets(lineNumber, rawLine, erroredIds) {
    if (!this.rawLineLooksLikeAssistantToolUse(rawLine)) {
      return [];
    }
    const timestamp = this.extractRawJsonStringValue(rawLine, "timestamp")?.value ?? (/* @__PURE__ */ new Date()).toISOString();
    const snippets = [];
    let searchIndex = 0;
    while (searchIndex < rawLine.length) {
      const toolUseIndex = rawLine.indexOf('"tool_use"', searchIndex);
      if (toolUseIndex < 0) break;
      const nextToolUseIndex = rawLine.indexOf('"tool_use"', toolUseIndex + '"tool_use"'.length);
      const toolUseEndIndex = nextToolUseIndex >= 0 ? nextToolUseIndex : rawLine.length;
      const snippet = this.extractOversizedSummarySnippetInRange({
        lineNumber,
        rawLine,
        erroredIds,
        toolUseIndex,
        toolUseEndIndex,
        timestamp,
        ordinal: snippets.length
      });
      if (snippet) {
        snippets.push(snippet);
      }
      searchIndex = toolUseEndIndex;
    }
    return snippets;
  }
  extractOversizedSummarySnippetInRange(input) {
    const { lineNumber, rawLine, erroredIds, toolUseIndex, toolUseEndIndex, timestamp, ordinal } = input;
    const rawToolName = this.extractRawJsonStringValue(rawLine, "name", toolUseIndex, toolUseEndIndex)?.value ?? "";
    const toolName = rawToolName.startsWith("proxy_") ? rawToolName.slice(6) : rawToolName;
    if (toolName !== "Write" && toolName !== "Edit" && toolName !== "MultiEdit") {
      return null;
    }
    const filePath = this.extractRawJsonStringValue(rawLine, "file_path", toolUseIndex, toolUseEndIndex)?.value ?? "";
    if (!filePath) {
      return null;
    }
    const toolUseId = this.extractRawJsonStringValue(rawLine, "id", toolUseIndex, toolUseEndIndex)?.value ?? `oversized-${lineNumber}-${ordinal}`;
    let added = 0;
    let removed = 0;
    let snippetType = "edit";
    if (toolName === "Write") {
      added = this.countRawJsonStringDiffLines(rawLine, "content", toolUseIndex, toolUseEndIndex) ?? 0;
      snippetType = "write-update";
    } else if (toolName === "MultiEdit") {
      added = this.countAllRawJsonStringDiffLines(
        rawLine,
        "new_string",
        toolUseIndex,
        toolUseEndIndex
      );
      removed = this.countAllRawJsonStringDiffLines(
        rawLine,
        "old_string",
        toolUseIndex,
        toolUseEndIndex
      );
      snippetType = "multi-edit";
    } else {
      added = this.countRawJsonStringDiffLines(rawLine, "new_string", toolUseIndex, toolUseEndIndex) ?? 0;
      removed = this.countRawJsonStringDiffLines(rawLine, "old_string", toolUseIndex, toolUseEndIndex) ?? 0;
    }
    return {
      snippet: {
        toolUseId,
        filePath,
        toolName,
        type: snippetType,
        oldString: "",
        newString: "",
        replaceAll: false,
        timestamp,
        isError: erroredIds.has(toolUseId)
      },
      lineCounts: { added, removed }
    };
  }
  collectRawErroredToolUseIds(rawLine) {
    const ids = /* @__PURE__ */ new Set();
    let searchIndex = 0;
    while (searchIndex < rawLine.length) {
      const resultIndex = rawLine.indexOf('"tool_result"', searchIndex);
      if (resultIndex < 0) break;
      const nextResultIndex = rawLine.indexOf(
        '"tool_result"',
        resultIndex + '"tool_result"'.length
      );
      const resultEndIndex = nextResultIndex >= 0 ? nextResultIndex : rawLine.length;
      if (this.rawJsonBooleanValue(rawLine, "is_error", true, resultIndex, resultEndIndex)) {
        const toolUseId = this.extractRawJsonStringValue(
          rawLine,
          "tool_use_id",
          resultIndex,
          resultEndIndex
        )?.value;
        if (toolUseId) {
          ids.add(toolUseId);
        }
      }
      searchIndex = resultEndIndex;
    }
    return ids;
  }
  rawLineLooksLikeAssistantToolUse(rawLine) {
    return rawLine.includes('"tool_use"') && /"role"\s*:\s*"assistant"/.test(rawLine);
  }
  extractRawJsonStringValue(rawLine, key, startIndex = 0, endIndex = rawLine.length) {
    const quoteIndex = this.findRawJsonStringValueQuote(rawLine, key, startIndex, endIndex);
    if (quoteIndex == null) {
      return null;
    }
    const endQuoteIndex = this.findRawJsonStringEnd(rawLine, quoteIndex, endIndex);
    if (endQuoteIndex == null) {
      return null;
    }
    try {
      return {
        value: JSON.parse(rawLine.slice(quoteIndex, endQuoteIndex + 1)),
        nextIndex: endQuoteIndex + 1
      };
    } catch {
      return null;
    }
  }
  countRawJsonStringDiffLines(rawLine, key, startIndex = 0, endIndex = rawLine.length) {
    const quoteIndex = this.findRawJsonStringValueQuote(rawLine, key, startIndex, endIndex);
    if (quoteIndex == null) {
      return null;
    }
    return this.countRawJsonStringLines(rawLine, quoteIndex, endIndex)?.lines ?? null;
  }
  countAllRawJsonStringDiffLines(rawLine, key, startIndex = 0, endIndex = rawLine.length) {
    let total = 0;
    let index = Math.max(0, startIndex);
    while (index < endIndex) {
      const quoteIndex = this.findRawJsonStringValueQuote(rawLine, key, index, endIndex);
      if (quoteIndex == null) {
        break;
      }
      const counted = this.countRawJsonStringLines(rawLine, quoteIndex, endIndex);
      if (!counted) {
        break;
      }
      total += counted.lines;
      index = counted.nextIndex;
    }
    return total;
  }
  findRawJsonStringValueQuote(rawLine, key, startIndex = 0, endIndex = rawLine.length) {
    const keyIndex = rawLine.indexOf(`"${key}"`, Math.max(0, startIndex));
    if (keyIndex < 0 || keyIndex >= endIndex) {
      return null;
    }
    let index = keyIndex + key.length + 2;
    while (index < endIndex && /\s/.test(rawLine[index] ?? "")) index += 1;
    if (rawLine[index] !== ":") {
      return null;
    }
    index += 1;
    while (index < endIndex && /\s/.test(rawLine[index] ?? "")) index += 1;
    return index < endIndex && rawLine[index] === '"' ? index : null;
  }
  rawJsonBooleanValue(rawLine, key, expected, startIndex = 0, endIndex = rawLine.length) {
    const keyIndex = rawLine.indexOf(`"${key}"`, Math.max(0, startIndex));
    if (keyIndex < 0 || keyIndex >= endIndex) {
      return false;
    }
    let index = keyIndex + key.length + 2;
    while (index < endIndex && /\s/.test(rawLine[index] ?? "")) index += 1;
    if (rawLine[index] !== ":") {
      return false;
    }
    index += 1;
    while (index < endIndex && /\s/.test(rawLine[index] ?? "")) index += 1;
    const expectedRaw = expected ? "true" : "false";
    return index + expectedRaw.length <= endIndex && rawLine.startsWith(expectedRaw, index);
  }
  findRawJsonStringEnd(rawLine, quoteIndex, endIndex = rawLine.length) {
    let index = quoteIndex + 1;
    while (index < endIndex) {
      const char = rawLine.charCodeAt(index);
      if (char === 34) {
        return index;
      }
      if (char === 92) {
        index += 2;
      } else {
        index += 1;
      }
    }
    return null;
  }
  countRawJsonStringLines(rawLine, quoteIndex, endIndex = rawLine.length) {
    let index = quoteIndex + 1;
    let hasContent = false;
    let lines = 1;
    let lastDecodedWasNewline = false;
    while (index < endIndex) {
      const char = rawLine.charCodeAt(index);
      if (char === 34) {
        return {
          lines: hasContent ? lastDecodedWasNewline ? lines - 1 : lines : 0,
          nextIndex: index + 1
        };
      }
      hasContent = true;
      if (char === 92) {
        const escaped = rawLine[index + 1];
        if (escaped === "n") {
          lines += 1;
          lastDecodedWasNewline = true;
          index += 2;
          continue;
        }
        if (escaped === "u" && rawLine.slice(index + 2, index + 6).toLowerCase() === "000a") {
          lines += 1;
          lastDecodedWasNewline = true;
          index += 6;
          continue;
        }
        lastDecodedWasNewline = false;
        index += 2;
        continue;
      }
      if (char === 10) {
        lines += 1;
        lastDecodedWasNewline = true;
      } else {
        lastDecodedWasNewline = false;
      }
      index += 1;
    }
    return null;
  }
  buildParsedSnippetsCacheKey(filePath, includeDetails) {
    return `${includeDetails ? "details" : "summary"}\0${filePath}`;
  }
  setParsedSnippetsCache(filePath, includeDetails, fileMtime, snippets) {
    const cacheKey = this.buildParsedSnippetsCacheKey(filePath, includeDetails);
    const existing = this.parsedSnippetsCache.get(cacheKey);
    if (existing) {
      this.parsedSnippetsCacheBytes -= existing.bytes;
    }
    const bytes = taskHistory.estimateCachedValueBytes(snippets);
    this.parsedSnippetsCache.set(cacheKey, {
      data: snippets,
      mtime: fileMtime,
      expiresAt: Date.now() + this.parsedSnippetsCacheTtl,
      bytes
    });
    this.parsedSnippetsCacheBytes += bytes;
    this.pruneParsedSnippetsCache();
  }
  pruneParsedSnippetsCache() {
    while (this.parsedSnippetsCache.size > this.maxParsedSnippetsCacheEntries || this.parsedSnippetsCacheBytes > this.maxParsedSnippetsCacheBytes) {
      const oldestKey = this.parsedSnippetsCache.keys().next().value;
      if (!oldestKey) break;
      const oldest = this.parsedSnippetsCache.get(oldestKey);
      if (oldest) {
        this.parsedSnippetsCacheBytes -= oldest.bytes;
      }
      this.parsedSnippetsCache.delete(oldestKey);
    }
    if (this.parsedSnippetsCacheBytes < 0) {
      this.parsedSnippetsCacheBytes = 0;
    }
  }
  extractContent(entry) {
    const message = entry.message;
    if (message && Array.isArray(message.content)) return message.content;
    if (Array.isArray(entry.content)) return entry.content;
    return null;
  }
  extractRole(entry) {
    if (typeof entry.role === "string") return entry.role;
    const message = entry.message;
    if (message && typeof message.role === "string") return message.role;
    return null;
  }
  collectErroredToolUseIdsFromEntry(entry) {
    const erroredIds = /* @__PURE__ */ new Set();
    if (Array.isArray(entry.content)) {
      for (const block of entry.content) {
        if (this.isErroredToolResult(block)) {
          const toolUseId = block.tool_use_id;
          if (typeof toolUseId === "string") {
            erroredIds.add(toolUseId);
          }
        }
      }
    }
    const message = entry.message;
    if (message && Array.isArray(message.content)) {
      for (const block of message.content) {
        if (this.isErroredToolResult(block)) {
          const toolUseId = block.tool_use_id;
          if (typeof toolUseId === "string") {
            erroredIds.add(toolUseId);
          }
        }
      }
    }
    return erroredIds;
  }
  isErroredToolResult(block) {
    if (!block || typeof block !== "object") return false;
    const obj = block;
    return obj.type === "tool_result" && obj.is_error === true;
  }
  aggregateByFile(records, projectPath, includeDetails = true) {
    const fileMap = /* @__PURE__ */ new Map();
    for (const record of records) {
      const { snippet } = record;
      if (snippet.isError) continue;
      const normalizedFilePath = record.fileIdentity ?? this.normalizeFilePathKey(snippet.filePath);
      const existing = fileMap.get(normalizedFilePath);
      if (existing) {
        existing.records.push(record);
      } else {
        fileMap.set(normalizedFilePath, {
          filePath: snippet.filePath,
          records: [record],
          isNewFile: snippet.type === "write-new"
        });
      }
    }
    return [...fileMap.values()].map((data) => {
      let totalAdded = 0;
      let totalRemoved = 0;
      for (const record of data.records) {
        const { snippet } = record;
        if (snippet.isError) continue;
        totalAdded += record.linesAdded;
        totalRemoved += record.linesRemoved;
      }
      const normalizedFilePath = data.filePath.replace(/\\/g, "/");
      const normalizedProjectPath = projectPath?.replace(/\\/g, "/");
      const relativePath = normalizedProjectPath ? normalizedFilePath.startsWith(normalizedProjectPath + "/") ? normalizedFilePath.slice(normalizedProjectPath.length + 1) : normalizedFilePath.startsWith(normalizedProjectPath) ? normalizedFilePath.slice(normalizedProjectPath.length) : normalizedFilePath.split("/").slice(-3).join("/") : normalizedFilePath.split("/").slice(-3).join("/");
      return {
        filePath: data.filePath,
        relativePath,
        snippets: includeDetails ? data.records.map((record) => record.snippet) : [],
        linesAdded: totalAdded,
        linesRemoved: totalRemoved,
        isNewFile: data.isNewFile,
        timeline: includeDetails ? this.buildTimeline(
          data.filePath,
          data.records.map((record) => record.snippet)
        ) : void 0
      };
    });
  }
  buildTimeline(filePath, snippets) {
    const events = snippets.filter((snippet) => !snippet.isError).map((snippet, index) => {
      const { added, removed } = countLineChanges(snippet.oldString, snippet.newString);
      return {
        toolUseId: snippet.toolUseId,
        toolName: snippet.toolName,
        timestamp: snippet.timestamp,
        summary: this.generateEditSummary(snippet),
        linesAdded: added,
        linesRemoved: removed,
        snippetIndex: index
      };
    });
    const timestamps = events.map((event) => new Date(event.timestamp).getTime()).filter((timestamp) => !Number.isNaN(timestamp));
    const durationMs = timestamps.length >= 2 ? Math.max(...timestamps) - Math.min(...timestamps) : 0;
    return { filePath, events, durationMs };
  }
  generateEditSummary(snippet) {
    switch (snippet.type) {
      case "write-new":
        return "Created new file";
      case "write-update":
        return "Wrote full file content";
      case "multi-edit": {
        const { added, removed } = countLineChanges(snippet.oldString, snippet.newString);
        const total = added + removed;
        return `Multi-edit (${total} line${total !== 1 ? "s" : ""})`;
      }
      case "edit": {
        const { added, removed } = countLineChanges(snippet.oldString, snippet.newString);
        if (snippet.oldString === "" && snippet.newString === "") return "File change metadata";
        if (snippet.oldString === "") return `Added ${added} line${added !== 1 ? "s" : ""}`;
        if (snippet.newString === "") return `Removed ${removed} line${removed !== 1 ? "s" : ""}`;
        return `Changed ${removed} → ${added} lines`;
      }
      default:
        return "File modified";
    }
  }
  computeContextHash(oldString, newString) {
    const take3 = (value) => {
      const lines = value.split("\n");
      const head = lines.slice(0, 3).join("\n");
      const tail = lines.length > 3 ? lines.slice(-3).join("\n") : "";
      return `${head}|${tail}`;
    };
    const raw = `${take3(oldString)}::${take3(newString)}`;
    let hash = 5381;
    for (let index = 0; index < raw.length; index++) {
      hash = (hash << 5) + hash + raw.charCodeAt(index) | 0;
    }
    return (hash >>> 0).toString(36);
  }
  sortSnippetRecordsChronologically(records) {
    return records.map((record, originalIndex) => ({
      record: { ...record, fileIdentity: this.normalizeFilePathKey(record.snippet.filePath) },
      originalIndex
    })).sort((a, b) => {
      const aMs = Date.parse(a.record.snippet.timestamp);
      const bMs = Date.parse(b.record.snippet.timestamp);
      const safeA = Number.isFinite(aMs) ? aMs : Number.MAX_SAFE_INTEGER;
      const safeB = Number.isFinite(bMs) ? bMs : Number.MAX_SAFE_INTEGER;
      if (safeA !== safeB) return safeA - safeB;
      const aPath = a.record.fileIdentity ?? "";
      const bPath = b.record.fileIdentity ?? "";
      if (aPath !== bPath) return aPath < bPath ? -1 : 1;
      return a.originalIndex - b.originalIndex;
    }).map(({ record }) => record);
  }
  normalizeFilePathKey(filePath) {
    return taskChangeFileIdentity(filePath);
  }
}
async function* readJsonlLines(filePath) {
  const stream = fs.createReadStream(filePath, { encoding: "utf8" });
  let pending = "";
  try {
    for await (const chunk of stream) {
      pending += chunk;
      let newlineIndex = pending.indexOf("\n");
      while (newlineIndex !== -1) {
        const line = pending.slice(0, newlineIndex);
        pending = pending.slice(newlineIndex + 1);
        yield line.endsWith("\r") ? line.slice(0, -1) : line;
        newlineIndex = pending.indexOf("\n");
      }
    }
    if (pending.length > 0) {
      yield pending.endsWith("\r") ? pending.slice(0, -1) : pending;
    }
  } finally {
    stream.destroy();
  }
}
const logger = taskChangeState.createLogger("Service:TaskBoundaryParser");
const FILE_MODIFYING_TOOLS = /* @__PURE__ */ new Set(["Edit", "Write", "MultiEdit", "NotebookEdit"]);
function extractTaskId(input) {
  const rawTaskId = input.taskId ?? input.task_id;
  if (typeof rawTaskId === "string") return rawTaskId;
  if (typeof rawTaskId === "number") return String(rawTaskId);
  return "";
}
function pickDetectedMechanism(current, next) {
  const priority = {
    none: 0,
    TaskUpdate: 1,
    mcp: 2
  };
  return priority[next] > priority[current] ? next : current;
}
class TaskBoundaryParser {
  cache = /* @__PURE__ */ new Map();
  inFlight = /* @__PURE__ */ new Map();
  cacheTtl = 60 * 1e3;
  // 60s
  /** Парсинг JSONL файла для обнаружения границ задач */
  async parseBoundaries(filePath) {
    let fileStat;
    try {
      fileStat = await fs$1.stat(filePath);
    } catch (err) {
      logger.debug(`Cannot stat file ${filePath}: ${String(err)}`);
      return { boundaries: [], scopes: [], isSingleTaskSession: true, detectedMechanism: "none" };
    }
    const cached = this.cache.get(filePath);
    if (cached?.mtime === fileStat.mtimeMs && cached.expiresAt > Date.now()) {
      return cached.data;
    }
    const inFlightKey = `${filePath}:${fileStat.mtimeMs}`;
    const inFlight = this.inFlight.get(inFlightKey);
    if (inFlight) return inFlight;
    const promise = this.parseBoundariesUncached(filePath, fileStat.mtimeMs).finally(() => {
      if (this.inFlight.get(inFlightKey) === promise) {
        this.inFlight.delete(inFlightKey);
      }
    });
    this.inFlight.set(inFlightKey, promise);
    return promise;
  }
  async parseBoundariesUncached(filePath, fileMtimeMs) {
    const boundaries = [];
    const allToolUsesByLine = /* @__PURE__ */ new Map();
    let lineNumber = 0;
    let detectedMechanism = "none";
    try {
      for await (const line of readJsonlLines(filePath)) {
        lineNumber++;
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          const entry = JSON.parse(trimmed);
          const timestamp = typeof entry.timestamp === "string" ? entry.timestamp : "";
          const content = this.extractContent(entry);
          if (!Array.isArray(content)) continue;
          for (const block of content) {
            if (!block || typeof block !== "object") continue;
            const b = block;
            if (b.type !== "tool_use") continue;
            const rawName = typeof b.name === "string" ? b.name : "";
            const toolName = taskChangeState.canonicalizeAgentTeamsToolName(rawName);
            const toolUseId = typeof b.id === "string" ? b.id : "";
            const input = b.input;
            const filePaths = input ? this.extractFilePaths(input) : [];
            if (!allToolUsesByLine.has(lineNumber)) allToolUsesByLine.set(lineNumber, []);
            allToolUsesByLine.get(lineNumber).push({ toolUseId, toolName, filePaths });
          }
          const taskUpdateBounds = this.extractTaskUpdateBoundaries(content, lineNumber, timestamp);
          if (taskUpdateBounds.length > 0) {
            detectedMechanism = pickDetectedMechanism(detectedMechanism, "TaskUpdate");
            boundaries.push(...taskUpdateBounds);
            continue;
          }
          const mcpBounds = this.extractMcpTaskBoundaries(content, lineNumber, timestamp);
          if (mcpBounds.length > 0) {
            detectedMechanism = pickDetectedMechanism(detectedMechanism, "mcp");
            boundaries.push(...mcpBounds);
            continue;
          }
        } catch {
        }
      }
    } catch (err) {
      logger.debug(`Error reading file ${filePath}: ${String(err)}`);
    }
    const scopes = this.computeScopes(boundaries, allToolUsesByLine, lineNumber);
    const uniqueTaskIds = new Set(boundaries.map((b) => b.taskId));
    const isSingleTaskSession = uniqueTaskIds.size <= 1;
    const result = {
      boundaries,
      scopes,
      isSingleTaskSession,
      detectedMechanism
    };
    this.cache.set(filePath, {
      data: result,
      mtime: fileMtimeMs,
      expiresAt: Date.now() + this.cacheTtl
    });
    return result;
  }
  /** Получить scope для конкретной задачи */
  async getTaskScope(filePath, taskId) {
    const result = await this.parseBoundaries(filePath);
    return result.scopes.find((s) => s.taskId === taskId) ?? null;
  }
  /** Очистить кеш (для тестов) */
  clearCache() {
    this.cache.clear();
    this.inFlight.clear();
  }
  // ── Приватные методы ──
  /** Извлечь content array из JSONL entry (оба формата: subagent и main) */
  extractContent(entry) {
    const message = entry.message;
    if (message && Array.isArray(message.content)) return message.content;
    if (Array.isArray(entry.content)) return entry.content;
    return null;
  }
  extractFilePaths(input) {
    const paths = [];
    const seen = /* @__PURE__ */ new Set();
    const addPath = (value) => {
      if (typeof value !== "string" || value.length === 0) return;
      const normalized = value.replace(/\\/g, "/");
      if (seen.has(normalized)) return;
      seen.add(normalized);
      paths.push(value);
    };
    addPath(input.file_path);
    const changes = Array.isArray(input.changes) ? input.changes : [];
    for (const change of changes) {
      if (!change || typeof change !== "object") continue;
      addPath(change.path);
    }
    return paths;
  }
  /**
   * Найти TaskUpdate/proxy_TaskUpdate tool_use блоки.
   * status: in_progress → start, completed → complete
   */
  extractTaskUpdateBoundaries(content, lineNumber, timestamp) {
    const results = [];
    for (const block of content) {
      if (!block || typeof block !== "object") continue;
      const b = block;
      if (b.type !== "tool_use") continue;
      const rawName = typeof b.name === "string" ? b.name : "";
      const toolName = rawName.replace(/^proxy_/, "");
      if (toolName !== "TaskUpdate") continue;
      const input = b.input;
      if (!input) continue;
      const taskId = extractTaskId(input);
      if (!taskId) continue;
      const status = typeof input.status === "string" ? input.status : "";
      let event = null;
      if (status === "in_progress") event = "start";
      else if (status === "completed") event = "complete";
      if (event) {
        const toolUseId = typeof b.id === "string" ? b.id : void 0;
        results.push({
          taskId,
          event,
          lineNumber,
          timestamp,
          mechanism: "TaskUpdate",
          toolUseId
        });
      }
    }
    return results;
  }
  /**
   * Find MCP task tools that mark task boundaries.
   */
  extractMcpTaskBoundaries(content, lineNumber, timestamp) {
    const results = [];
    for (const block of content) {
      if (!block || typeof block !== "object") continue;
      const b = block;
      if (b.type !== "tool_use") continue;
      const rawName = typeof b.name === "string" ? b.name : "";
      const toolName = taskChangeState.canonicalizeAgentTeamsToolName(rawName);
      if (!taskChangeState.isAgentTeamsTaskBoundaryToolName(toolName)) continue;
      const input = b.input;
      if (!input) continue;
      const taskId = extractTaskId(input);
      if (!taskId) continue;
      let event = null;
      if (toolName === "task_start") event = "start";
      else if (toolName === "task_complete") event = "complete";
      else {
        const status = typeof input.status === "string" ? input.status : "";
        if (status === "in_progress") event = "start";
        else if (status === "completed") event = "complete";
      }
      if (event) {
        const toolUseId = typeof b.id === "string" ? b.id : void 0;
        results.push({
          taskId,
          event,
          lineNumber,
          timestamp,
          mechanism: "mcp",
          toolUseId
        });
      }
    }
    return results;
  }
  /**
   * Вычислить scopes для каждой задачи на основе границ.
   *
   * Tier 1 (high): обе границы (start + complete)
   * Tier 2 (medium): только start (end = конец файла)
   * Tier 3 (low): только complete (start = начало файла)
   * Tier 4 (fallback): нет границ (весь файл)
   */
  computeScopes(boundaries, allToolUsesByLine, totalLines) {
    const byTask = /* @__PURE__ */ new Map();
    for (const b of boundaries) {
      if (!byTask.has(b.taskId)) byTask.set(b.taskId, []);
      byTask.get(b.taskId).push(b);
    }
    const scopes = [];
    for (const [taskId, taskBoundaries] of byTask) {
      const starts = taskBoundaries.filter((b) => b.event === "start");
      const completes = taskBoundaries.filter((b) => b.event === "complete");
      const hasStart = starts.length > 0;
      const hasComplete = completes.length > 0;
      let startLine;
      let endLine;
      let startTimestamp;
      let endTimestamp;
      let confidence;
      if (hasStart && hasComplete) {
        const firstStart = starts.reduce(
          (a, b) => a.lineNumber < b.lineNumber ? a : b,
          starts[0]
        );
        const lastComplete = completes.reduce(
          (a, b) => a.lineNumber > b.lineNumber ? a : b,
          completes[0]
        );
        startLine = firstStart.lineNumber;
        endLine = lastComplete.lineNumber;
        startTimestamp = firstStart.timestamp;
        endTimestamp = lastComplete.timestamp;
        confidence = { tier: 1, label: "high", reason: "Both start and complete markers found" };
      } else if (hasStart) {
        const firstStart = starts.reduce(
          (a, b) => a.lineNumber < b.lineNumber ? a : b,
          starts[0]
        );
        startLine = firstStart.lineNumber;
        endLine = totalLines;
        startTimestamp = firstStart.timestamp;
        endTimestamp = "";
        confidence = {
          tier: 2,
          label: "medium",
          reason: "Only start marker found, end assumed at file end"
        };
      } else {
        const lastComplete = completes.reduce(
          (a, b) => a.lineNumber > b.lineNumber ? a : b,
          completes[0]
        );
        startLine = 1;
        endLine = lastComplete.lineNumber;
        startTimestamp = "";
        endTimestamp = lastComplete.timestamp;
        confidence = {
          tier: 3,
          label: "low",
          reason: "Only complete marker found, start assumed at file beginning"
        };
      }
      const toolUseIds = [];
      const filePaths = /* @__PURE__ */ new Set();
      for (const [line, tools] of allToolUsesByLine) {
        if (line < startLine || line > endLine) continue;
        for (const tool of tools) {
          if (FILE_MODIFYING_TOOLS.has(tool.toolName) && tool.toolUseId) {
            toolUseIds.push(tool.toolUseId);
            for (const filePath of tool.filePaths) {
              filePaths.add(filePath);
            }
          }
        }
      }
      scopes.push({
        taskId,
        memberName: "",
        // будет заполнен вызывающим кодом
        startLine,
        endLine,
        startTimestamp,
        endTimestamp,
        toolUseIds,
        filePaths: [...filePaths],
        confidence
      });
    }
    return scopes;
  }
}
exports.TaskBoundaryParser = TaskBoundaryParser;
exports.TaskChangeComputer = TaskChangeComputer;
exports.countLineChanges = countLineChanges;
exports.diffLines = diffLines;
exports.readJsonlLines = readJsonlLines;
