for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const node_worker_threads = require("node:worker_threads");
const taskChangeState = require("./chunks/taskChangeState-rZolvpL6.cjs");
const TeamDataService = require("./chunks/TeamDataService-DySh5-O-.cjs");
const taskHistory = require("./chunks/taskHistory-2kbwfqIg.cjs");
require("fs");
require("fs/promises");
require("path");
require("readline");
require("node:crypto");
require("node:fs");
require("node:path");
require("crypto");
require("node:fs/promises");
require("node:url");
require("node:module");
require("util");
require("node:perf_hooks");
require("node:async_hooks");
require("string_decoder");
require("./chunks/index-yaJFGvjB.cjs");
require("./chunks/teamTaskSnapshotCompaction-mUovQwio.cjs");
require("child_process");
require("agent-teams-controller");
require("async_hooks");
require("node:sqlite");
require("os");
require("node:os");
require("node:child_process");
require("node:stream");
require("node:events");
require("node:util");
require("node:diagnostics_channel");
require("node:process");
require("events");
require("buffer");
require("net");
require("module");
require("url");
require("node:buffer");
require("node:timers/promises");
const logger = taskChangeState.createLogger("Worker:TeamData");
TeamDataService.applyElectronDevClaudeRootOverrideForWorker();
if (typeof node_worker_threads.workerData === "string") {
  taskHistory.setClaudeBasePathOverride(node_worker_threads.workerData);
}
const teamDataService = new TeamDataService.TeamDataService();
const logsFinder = new taskChangeState.TeamMemberLogsFinder();
const logsInFlight = /* @__PURE__ */ new Map();
const logsResultCache = /* @__PURE__ */ new Map();
const LOGS_CACHE_TTL_MS = 1e4;
let heavyReadQueue = Promise.resolve();
function respond(msg) {
  node_worker_threads.parentPort?.postMessage(msg);
}
function runHeavyRead(load) {
  const result = heavyReadQueue.catch(() => void 0).then(load);
  heavyReadQueue = result.then(
    () => void 0,
    () => void 0
  );
  return result;
}
node_worker_threads.parentPort?.on("message", async (msg) => {
  const startedAt = Date.now();
  const buildDiag = () => ({
    op: msg.op,
    ...msg.payload && "teamName" in msg.payload ? { teamName: msg.payload.teamName } : {},
    ...msg.payload && "taskId" in msg.payload ? { taskId: msg.payload.taskId } : {},
    totalMs: Date.now() - startedAt
  });
  try {
    switch (msg.op) {
      case "warmup": {
        respond({ id: msg.id, ok: true, result: null, diag: buildDiag() });
        break;
      }
      case "getTeamData": {
        const result = await runHeavyRead(
          () => teamDataService.getTeamData(msg.payload.teamName, msg.payload.options)
        );
        respond({ id: msg.id, ok: true, result, diag: buildDiag() });
        break;
      }
      case "getMessagesPage": {
        const result = await runHeavyRead(
          () => teamDataService.getMessagesPage(msg.payload.teamName, msg.payload.options)
        );
        respond({ id: msg.id, ok: true, result, diag: buildDiag() });
        break;
      }
      case "getMemberActivityMeta": {
        const result = await runHeavyRead(
          () => teamDataService.getMemberActivityMeta(msg.payload.teamName)
        );
        respond({ id: msg.id, ok: true, result, diag: buildDiag() });
        break;
      }
      case "invalidateTeamConfig": {
        taskChangeState.TeamConfigReader.invalidateTeam(msg.payload.teamName);
        teamDataService.invalidateMessageFeed(msg.payload.teamName);
        teamDataService.invalidateTeamRuntimeAdvisories(msg.payload.teamName);
        respond({ id: msg.id, ok: true, result: null, diag: buildDiag() });
        break;
      }
      case "invalidateTeamMessageFeed": {
        teamDataService.invalidateMessageFeed(msg.payload.teamName);
        respond({ id: msg.id, ok: true, result: null, diag: buildDiag() });
        break;
      }
      case "invalidateMemberRuntimeAdvisory": {
        if (msg.payload.memberName) {
          teamDataService.invalidateMemberRuntimeAdvisory(
            msg.payload.teamName,
            msg.payload.memberName
          );
        } else {
          teamDataService.invalidateTeamRuntimeAdvisories(
            msg.payload.teamName,
            msg.payload.runStartedAtMs
          );
        }
        respond({ id: msg.id, ok: true, result: null, diag: buildDiag() });
        break;
      }
      case "findLogsForTask": {
        const result = await runHeavyRead(async () => {
          const { teamName, taskId, options } = msg.payload;
          const intervalsKey = options?.intervals ? options.intervals.map((i) => `${i.startedAt}~${i.completedAt ?? ""}`).join(",") : "";
          const cacheKey = `${teamName}:${taskId}:${options?.owner ?? ""}:${options?.status ?? ""}:${options?.since ?? ""}:${intervalsKey}`;
          const cached = logsResultCache.get(cacheKey);
          if (cached && Date.now() - cached.cachedAt < LOGS_CACHE_TTL_MS) {
            return cached.result;
          }
          let promise = logsInFlight.get(cacheKey);
          if (!promise) {
            promise = logsFinder.findLogsForTask(teamName, taskId, options).then((result2) => {
              logsResultCache.set(cacheKey, { result: result2, cachedAt: Date.now() });
              if (logsResultCache.size > 100) {
                const firstKey = logsResultCache.keys().next().value;
                if (firstKey !== void 0) logsResultCache.delete(firstKey);
              }
              return result2;
            }).finally(() => {
              logsInFlight.delete(cacheKey);
            });
            logsInFlight.set(cacheKey, promise);
          }
          return promise;
        });
        respond({ id: msg.id, ok: true, result, diag: buildDiag() });
        break;
      }
      default: {
        const _exhaustive = msg;
        respond({ id: _exhaustive.id, ok: false, error: `Unknown op` });
      }
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error(`[${msg.op}] ${message}`);
    respond({ id: msg.id, ok: false, error: message });
  }
});
logger.info("team-data-worker started");
