for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
var ApplicationCommandLedgerStatus = /* @__PURE__ */ ((ApplicationCommandLedgerStatus2) => {
  ApplicationCommandLedgerStatus2["Started"] = "started";
  ApplicationCommandLedgerStatus2["Completed"] = "completed";
  ApplicationCommandLedgerStatus2["FailedRetryable"] = "failed_retryable";
  ApplicationCommandLedgerStatus2["FailedTerminal"] = "failed_terminal";
  ApplicationCommandLedgerStatus2["UnknownAfterTimeout"] = "unknown_after_timeout";
  return ApplicationCommandLedgerStatus2;
})(ApplicationCommandLedgerStatus || {});
var ApplicationCommandFailureKind = /* @__PURE__ */ ((ApplicationCommandFailureKind2) => {
  ApplicationCommandFailureKind2["Retryable"] = "retryable";
  ApplicationCommandFailureKind2["Terminal"] = "terminal";
  ApplicationCommandFailureKind2["UnknownAfterTimeout"] = "unknown_after_timeout";
  return ApplicationCommandFailureKind2;
})(ApplicationCommandFailureKind || {});
var ApplicationCommandBeginOutcome = /* @__PURE__ */ ((ApplicationCommandBeginOutcome2) => {
  ApplicationCommandBeginOutcome2["Started"] = "started";
  ApplicationCommandBeginOutcome2["RetryStarted"] = "retry_started";
  ApplicationCommandBeginOutcome2["DuplicateCompleted"] = "duplicate_completed";
  ApplicationCommandBeginOutcome2["AlreadyStarted"] = "already_started";
  ApplicationCommandBeginOutcome2["FailedTerminal"] = "failed_terminal";
  ApplicationCommandBeginOutcome2["UnknownAfterTimeout"] = "unknown_after_timeout";
  ApplicationCommandBeginOutcome2["Conflict"] = "conflict";
  return ApplicationCommandBeginOutcome2;
})(ApplicationCommandBeginOutcome || {});
var ApplicationCommandConflictReason = /* @__PURE__ */ ((ApplicationCommandConflictReason2) => {
  ApplicationCommandConflictReason2["CommandIdReused"] = "command_id_reused";
  ApplicationCommandConflictReason2["IdempotencyKeyReused"] = "idempotency_key_reused";
  ApplicationCommandConflictReason2["OperationMismatch"] = "operation_mismatch";
  ApplicationCommandConflictReason2["PayloadHashMismatch"] = "payload_hash_mismatch";
  return ApplicationCommandConflictReason2;
})(ApplicationCommandConflictReason || {});
var ApplicationCommandRunOutcome = /* @__PURE__ */ ((ApplicationCommandRunOutcome2) => {
  ApplicationCommandRunOutcome2["Executed"] = "executed";
  ApplicationCommandRunOutcome2["Reconciled"] = "reconciled";
  ApplicationCommandRunOutcome2["Retried"] = "retried";
  ApplicationCommandRunOutcome2["Replayed"] = "replayed";
  return ApplicationCommandRunOutcome2;
})(ApplicationCommandRunOutcome || {});
var ApplicationCommandLedgerErrorCode = /* @__PURE__ */ ((ApplicationCommandLedgerErrorCode2) => {
  ApplicationCommandLedgerErrorCode2["AlreadyStarted"] = "already_started";
  ApplicationCommandLedgerErrorCode2["CompletedResultInvalid"] = "completed_result_invalid";
  ApplicationCommandLedgerErrorCode2["CompletedResultMissing"] = "completed_result_missing";
  ApplicationCommandLedgerErrorCode2["Conflict"] = "conflict";
  ApplicationCommandLedgerErrorCode2["FailedTerminal"] = "failed_terminal";
  ApplicationCommandLedgerErrorCode2["InvalidInput"] = "invalid_input";
  ApplicationCommandLedgerErrorCode2["RecordNotFound"] = "record_not_found";
  ApplicationCommandLedgerErrorCode2["StoreRejected"] = "store_rejected";
  ApplicationCommandLedgerErrorCode2["UnknownOutcome"] = "unknown_outcome";
  return ApplicationCommandLedgerErrorCode2;
})(ApplicationCommandLedgerErrorCode || {});
exports.ApplicationCommandBeginOutcome = ApplicationCommandBeginOutcome;
exports.ApplicationCommandConflictReason = ApplicationCommandConflictReason;
exports.ApplicationCommandFailureKind = ApplicationCommandFailureKind;
exports.ApplicationCommandLedgerErrorCode = ApplicationCommandLedgerErrorCode;
exports.ApplicationCommandLedgerStatus = ApplicationCommandLedgerStatus;
exports.ApplicationCommandRunOutcome = ApplicationCommandRunOutcome;
