for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const taskHistory = require("./taskHistory-2kbwfqIg.cjs");
const fs = require("fs");
const fs$2 = require("fs/promises");
const path$1 = require("path");
const readline = require("readline");
const crypto$1 = require("node:crypto");
const fs$1 = require("node:fs");
const path = require("node:path");
const require$$0 = require("crypto");
require("node:fs/promises");
const node_url = require("node:url");
const node_worker_threads = require("node:worker_threads");
const node_module = require("node:module");
require("util");
require("node:perf_hooks");
const node_async_hooks = require("node:async_hooks");
const string_decoder = require("string_decoder");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const fs__namespace = /* @__PURE__ */ _interopNamespaceDefault(fs);
const fs__namespace$2 = /* @__PURE__ */ _interopNamespaceDefault(fs$2);
const path__namespace$1 = /* @__PURE__ */ _interopNamespaceDefault(path$1);
const readline__namespace = /* @__PURE__ */ _interopNamespaceDefault(readline);
const fs__namespace$1 = /* @__PURE__ */ _interopNamespaceDefault(fs$1);
const path__namespace = /* @__PURE__ */ _interopNamespaceDefault(path);
class TeamOwnerError extends Error {
  code;
  constructor(code) {
    super(`Team operation ${code}`);
    this.code = code;
  }
}
function stableJson(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean")
    return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value))
    return JSON.stringify(value);
  if (Array.isArray(value))
    return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
    const record = value;
    return `{${Object.keys(record).filter((key) => record[key] !== void 0).sort().map((key) => `${JSON.stringify(key)}:${stableJson(record[key])}`).join(",")}}`;
  }
  throw new TeamOwnerError("invalid");
}
function digest(value) {
  return crypto$1.createHash("sha256").update(stableJson(value)).digest("hex");
}
function effectId(...parts) {
  const hex = crypto$1.createHash("sha256").update(parts.join("\0")).digest("hex");
  const normalized = `${hex.slice(0, 12)}5${hex.slice(13, 16)}${(Number.parseInt(hex[16], 16) & 3 | 8).toString(16)}${hex.slice(17, 32)}`;
  return `${normalized.slice(0, 8)}-${normalized.slice(8, 12)}-${normalized.slice(12, 16)}-${normalized.slice(16, 20)}-${normalized.slice(20)}`;
}
function buildLegacyInboxMessageId(from, timestamp2, text2) {
  return `inbox-${require$$0.createHash("sha256").update(`${from}
${timestamp2}
${text2}`).digest("hex").slice(0, 16)}`;
}
function getEffectiveInboxMessageId(row2) {
  if (typeof row2.messageId === "string" && row2.messageId.trim().length > 0) {
    return row2.messageId;
  }
  if (typeof row2.from !== "string" || typeof row2.timestamp !== "string" || typeof row2.text !== "string") {
    return null;
  }
  return buildLegacyInboxMessageId(row2.from, row2.timestamp, row2.text);
}
const logSinks = /* @__PURE__ */ new Set();
function addLogSink(sink) {
  logSinks.add(sink);
  return () => {
    logSinks.delete(sink);
  };
}
function emitToLogSinks(entry) {
  for (const sink of logSinks) {
    try {
      sink(entry);
    } catch {
    }
  }
}
class Logger {
  constructor(namespace) {
    this.namespace = namespace;
  }
  namespace;
  static level = process.env.NODE_ENV === "production" ? 3 : 2;
  debug(...args) {
    if (Logger.level <= 0) {
      console.debug(`[${this.namespace}]`, ...args);
    }
  }
  info(...args) {
    if (Logger.level <= 1) {
      console.log(`[${this.namespace}]`, ...args);
    }
  }
  /**
   * Durable diagnostic. Written to the log sinks at every log level and never
   * to the console.
   *
   * `info` cannot carry this: it is filtered out at the default level in both
   * development and production, and it never reaches a sink, so the evidence is
   * gone by the time anyone looks for it. `warn` can carry it, but only by
   * telling every developer about a line that is not a warning.
   */
  diagnostic(...args) {
    emitToLogSinks({
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: "diagnostic",
      namespace: this.namespace,
      args
    });
  }
  warn(...args) {
    emitToLogSinks({
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: "warn",
      namespace: this.namespace,
      args
    });
    if (Logger.level <= 2) {
      console.warn(`[${this.namespace}]`, ...args);
    }
  }
  error(...args) {
    emitToLogSinks({
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: "error",
      namespace: this.namespace,
      args
    });
    if (Logger.level <= 3) {
      console.error(`[${this.namespace}]`, ...args);
    }
  }
  /** Allow runtime level changes (for testing/debugging) */
  static setLevel(level) {
    Logger.level = level;
  }
  static getLevel() {
    return Logger.level;
  }
}
function createLogger(namespace) {
  return new Logger(namespace);
}
const TEAM_MEMBER_MCP_SCOPES = [
  "user",
  "project",
  "local"
];
const TEAM_MEMBER_MCP_MODES = /* @__PURE__ */ new Set([
  "inheritLead",
  "inheritScopes",
  "strictAllowlist",
  "appOnly"
]);
const DEFAULT_MCP_SCOPES = {
  user: true,
  project: true,
  local: true
};
function hasAnyResolvedMcpScope(scopes) {
  return TEAM_MEMBER_MCP_SCOPES.some((scope) => scopes[scope] ?? DEFAULT_MCP_SCOPES[scope]);
}
function normalizeMcpMode(value) {
  return typeof value === "string" && TEAM_MEMBER_MCP_MODES.has(value) ? value : null;
}
function normalizeTeamMemberMcpScopes(value) {
  if (!value || typeof value !== "object") {
    return void 0;
  }
  const input = value;
  const out = {};
  for (const scope of TEAM_MEMBER_MCP_SCOPES) {
    if (typeof input[scope] === "boolean") {
      out[scope] = input[scope];
    }
  }
  return Object.keys(out).length > 0 ? out : void 0;
}
function normalizeTeamMemberMcpServerNames(value) {
  if (!Array.isArray(value)) {
    return void 0;
  }
  const seen = /* @__PURE__ */ new Set();
  const names2 = [];
  for (const item of value) {
    if (typeof item !== "string") {
      continue;
    }
    const name2 = item.trim();
    if (!name2 || name2.length > 128) {
      continue;
    }
    const key = name2.toLowerCase();
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    names2.push(name2);
    if (names2.length >= 100) {
      break;
    }
  }
  return names2.length > 0 ? names2 : void 0;
}
function normalizeTeamMemberMcpPolicy(value) {
  if (!value || typeof value !== "object") {
    return void 0;
  }
  const input = value;
  const mode = normalizeMcpMode(input.mode);
  if (!mode || mode === "inheritLead") {
    return void 0;
  }
  const scopes = normalizeTeamMemberMcpScopes(input.scopes);
  const serverNames = normalizeTeamMemberMcpServerNames(input.serverNames);
  if (mode === "appOnly") {
    return { mode };
  }
  if (scopes && !hasAnyResolvedMcpScope(scopes)) {
    return {
      mode: "appOnly"
    };
  }
  if (mode === "strictAllowlist") {
    return {
      mode,
      ...scopes ? { scopes } : {},
      ...serverNames ? { serverNames } : {}
    };
  }
  return {
    mode,
    ...scopes ? { scopes } : {}
  };
}
function resolveTeamMemberMcpScopes(policy2) {
  return {
    user: policy2?.scopes?.user ?? DEFAULT_MCP_SCOPES.user,
    project: policy2?.scopes?.project ?? DEFAULT_MCP_SCOPES.project,
    local: policy2?.scopes?.local ?? DEFAULT_MCP_SCOPES.local
  };
}
function buildTeamMemberMcpSettingSources(policy2) {
  if (policy2?.mode !== "inheritScopes") {
    return "user,project,local";
  }
  const scopes = resolveTeamMemberMcpScopes(policy2);
  const selected = TEAM_MEMBER_MCP_SCOPES.filter((scope) => scopes[scope]);
  return selected.length > 0 ? selected.join(",") : "user,project,local";
}
function requiresStrictTeamMemberMcpConfig(policy2) {
  return policy2?.mode === "strictAllowlist" || policy2?.mode === "appOnly";
}
const GROUP_CHAT_CHANNELS = {
  getReaction: "team-group-chats:get-reaction",
  setReaction: "team-group-chats:set-reaction",
  list: "team-group-chats:list",
  create: "team-group-chats:create",
  setArchived: "team-group-chats:set-archived",
  send: "team-group-chats:send"
};
const GROUP_PROTOCOL_FIELDS = [
  "groupChatId",
  "groupChatName",
  "groupMessageId",
  "groupChatProtocolVersion",
  "groupRunKey",
  "groupRecipientNames",
  "groupRecipientRunKeys",
  "groupDeliverySummary",
  "groupHandoffStartedAt"
];
function hasGroupChatEnvelopeMarker(value) {
  return !!value && typeof value === "object" && GROUP_PROTOCOL_FIELDS.some((key) => Object.prototype.hasOwnProperty.call(value, key));
}
function copyGroupChatEnvelope(row2) {
  return Object.fromEntries(GROUP_PROTOCOL_FIELDS.filter((key) => Object.prototype.hasOwnProperty.call(row2, key)).map((key) => [key, row2[key]]));
}
function assertValidGroupInboxRows(rows) {
  if (!Array.isArray(rows))
    throw new Error("Inbox storage unavailable: expected array");
  const canonicalIds = /* @__PURE__ */ new Set();
  for (const item of rows) {
    if (!item || typeof item !== "object")
      continue;
    const row2 = item;
    if (!hasGroupChatEnvelopeMarker(row2))
      continue;
    if (typeof row2.groupChatId !== "string" || !row2.groupChatId || typeof row2.groupMessageId !== "string" || !row2.groupMessageId || typeof row2.messageId !== "string" || !row2.messageId || row2.groupChatProtocolVersion !== 1 || typeof row2.from !== "string" || typeof row2.text !== "string" || typeof row2.timestamp !== "string" || typeof row2.read !== "boolean" || !Number.isFinite(Date.parse(row2.timestamp)))
      throw new Error("Inbox storage unavailable: malformed group envelope");
    if (row2.groupMessageId === row2.messageId) {
      if (row2.to !== "user" || canonicalIds.has(row2.messageId))
        throw new Error("Inbox storage unavailable: duplicate or misplaced canonical group row");
      if (!Array.isArray(row2.groupRecipientNames) || row2.groupRecipientNames.some((name2) => typeof name2 !== "string" || !name2) || new Set(row2.groupRecipientNames).size !== row2.groupRecipientNames.length || !row2.groupRecipientRunKeys || typeof row2.groupRecipientRunKeys !== "object" || Array.isArray(row2.groupRecipientRunKeys) || row2.groupRecipientNames.some((name2) => typeof row2.groupRecipientRunKeys[name2] !== "string" || !row2.groupRecipientRunKeys[name2]))
        throw new Error("Inbox storage unavailable: invalid frozen recipients");
      canonicalIds.add(row2.messageId);
    } else if (typeof row2.to !== "string" || typeof row2.groupRunKey !== "string" || !row2.groupRunKey) {
      throw new Error("Inbox storage unavailable: invalid group physical destination");
    }
    if (row2.groupChatName !== void 0 && typeof row2.groupChatName !== "string")
      throw new Error("Inbox storage unavailable: invalid group name");
    if (row2.groupDeliverySummary !== void 0) {
      const summary = row2.groupDeliverySummary;
      if (!summary || typeof summary.recordedAt !== "string" || !Number.isFinite(Date.parse(summary.recordedAt)) || !Array.isArray(summary.recipients))
        throw new Error("Inbox storage unavailable: invalid delivery summary");
      const seen = /* @__PURE__ */ new Set();
      for (const entry of summary.recipients) {
        if (!entry || typeof entry !== "object")
          throw new Error("Inbox storage unavailable: invalid delivery outcome");
        const outcome = entry;
        if (typeof outcome.memberName !== "string" || typeof outcome.physicalMessageId !== "string" || !["queued", "accepted", "failed", "unknown", "skipped"].includes(String(outcome.status)) || seen.has(outcome.memberName) || outcome.reason !== void 0 && typeof outcome.reason !== "string")
          throw new Error("Inbox storage unavailable: invalid delivery outcome");
        seen.add(outcome.memberName);
      }
    }
    if (row2.groupHandoffStartedAt !== void 0 && typeof row2.groupHandoffStartedAt !== "string")
      throw new Error("Inbox storage unavailable: invalid handoff marker");
  }
}
function isAbortError(error) {
  return !!error && typeof error === "object" && "name" in error && typeof error.name === "string" && error.name === "AbortError";
}
class FileReadTimeoutError extends Error {
  constructor(filePath, timeoutMs) {
    super(`Timed out after ${timeoutMs}ms reading ${filePath}`);
    this.filePath = filePath;
    this.timeoutMs = timeoutMs;
    this.name = "FileReadTimeoutError";
  }
  filePath;
  timeoutMs;
}
async function readFileUtf8WithTimeout(filePath, timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fs__namespace.promises.readFile(filePath, { encoding: "utf8", signal: controller.signal });
  } catch (error) {
    if (isAbortError(error)) {
      throw new FileReadTimeoutError(filePath, timeoutMs);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}
function parseNumericSuffixName(name2) {
  const trimmed = name2.trim();
  if (!trimmed) return null;
  const match = /^(.+)-(\d+)$/.exec(trimmed);
  if (!match?.[1] || !match[2]) return null;
  const suffix = Number(match[2]);
  if (!Number.isFinite(suffix)) return null;
  return { base: match[1], suffix };
}
const WINDOWS_RESERVED_MEMBER_FILE_STEMS = /* @__PURE__ */ new Set([
  "con",
  "prn",
  "aux",
  "nul",
  "com1",
  "com2",
  "com3",
  "com4",
  "com5",
  "com6",
  "com7",
  "com8",
  "com9",
  "lpt1",
  "lpt2",
  "lpt3",
  "lpt4",
  "lpt5",
  "lpt6",
  "lpt7",
  "lpt8",
  "lpt9"
]);
function isWindowsReservedMemberFileSegment(name2) {
  const normalized = name2.trim().replace(/[. ]+$/g, "").toLowerCase();
  if (!normalized) return false;
  const stem = normalized.split(".")[0] || normalized;
  return WINDOWS_RESERVED_MEMBER_FILE_STEMS.has(stem);
}
function validateTeamMemberNameFormat(name2) {
  const trimmed = name2.trim();
  if (!trimmed) return null;
  if (trimmed.length < 1 || trimmed.length > 128) {
    return "Start with alphanumeric, use only [a-zA-Z0-9._-], max 128 chars";
  }
  if (!/^[a-zA-Z0-9]/.test(trimmed)) {
    return "Start with alphanumeric, use only [a-zA-Z0-9._-], max 128 chars";
  }
  if (!/^[a-zA-Z0-9._-]+$/.test(trimmed)) {
    return "Start with alphanumeric, use only [a-zA-Z0-9._-], max 128 chars";
  }
  if (/[. ]$/.test(trimmed)) {
    return "Member name cannot end with a space or period";
  }
  if (isWindowsReservedMemberFileSegment(trimmed)) {
    return "Member name is reserved on Windows";
  }
  return null;
}
function createCliAutoSuffixNameGuard(allNames) {
  const trimmed = [];
  const seen = /* @__PURE__ */ new Set();
  for (const n of allNames) {
    if (typeof n !== "string") continue;
    const t = n.trim();
    if (!t) continue;
    if (seen.has(t)) continue;
    seen.add(t);
    trimmed.push(t);
  }
  const allLower = new Set(trimmed.map((n) => n.toLowerCase()));
  return (name2) => {
    const info = parseNumericSuffixName(name2);
    if (!info) return true;
    if (info.suffix < 2) return true;
    return !allLower.has(info.base.toLowerCase());
  };
}
const PROVISIONER_SUFFIX = "-provisioner";
function createCliProvisionerNameGuard(_allNames) {
  return (name2) => {
    const lower = name2.trim().toLowerCase();
    if (!lower.endsWith(PROVISIONER_SUFFIX)) return true;
    const base = lower.slice(0, -PROVISIONER_SUFFIX.length);
    return !base;
  };
}
function isReadableTeamConfigPayload(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const config = value;
  if (typeof config.name !== "string" || !config.name.trim()) return false;
  return config.members == null || Array.isArray(config.members) && config.members.every(
    (member2) => member2 && typeof member2 === "object" && !Array.isArray(member2) && typeof member2.name === "string" && ["agentId", "agentType", "role", "color"].every(
      (key) => member2[key] == null || typeof member2[key] === "string"
    )
  );
}
function captureStartupMemorySnapshot(readMemoryUsage = () => process.memoryUsage()) {
  const memory = readMemoryUsage();
  return {
    rssBytes: memory.rss,
    heapUsedBytes: memory.heapUsed,
    heapTotalBytes: memory.heapTotal,
    externalBytes: memory.external,
    arrayBuffersBytes: memory.arrayBuffers ?? 0
  };
}
function formatStartupMemorySnapshot(memory) {
  return `rss=${formatMiB(memory.rssBytes)} heap=${formatMiB(memory.heapUsedBytes)}/${formatMiB(
    memory.heapTotalBytes
  )} external=${formatMiB(memory.externalBytes)}`;
}
function formatProcessMemorySnapshot(memory, pid = process.pid) {
  return `pid=${pid} ${formatStartupMemorySnapshot(memory)} arrayBuffers=${formatMiB(
    memory.arrayBuffersBytes ?? 0
  )}`;
}
function formatCurrentProcessMemorySnapshot(readMemoryUsage = () => process.memoryUsage(), pid = process.pid) {
  return formatProcessMemorySnapshot(captureStartupMemorySnapshot(readMemoryUsage), pid);
}
function formatMiB(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(1)}MiB`;
}
const logger$6 = createLogger("Service:TeamFsWorkerClient");
const DEFAULT_CONCURRENCY = process.platform === "win32" ? 4 : 12;
const DEFAULT_READ_TIMEOUT_MS = 5e3;
const WARMUP_TIMEOUT_MS = 5e3;
const SCAN_TIMEOUT_MS = 9e4;
function summarizeWorkerPayload(payload) {
  if (!payload) {
    return {};
  }
  if ("teamsDir" in payload) {
    return {
      teamsDir: payload.teamsDir,
      concurrency: payload.concurrency,
      maxConfigReadMs: payload.maxConfigReadMs,
      maxConfigBytes: payload.maxConfigBytes
    };
  }
  if (!("tasksBase" in payload)) {
    return {};
  }
  return {
    tasksBase: payload.tasksBase,
    projectionCacheBase: payload.projectionCacheBase,
    concurrency: payload.concurrency,
    maxTaskReadMs: payload.maxTaskReadMs,
    maxTaskBytes: payload.maxTaskBytes
  };
}
function getDiagTotalMs(diag) {
  return diag && typeof diag === "object" ? diag.totalMs : void 0;
}
function makeId() {
  return `${Date.now()}-${crypto.randomUUID().slice(0, 12)}`;
}
function buildTeamFsWorkerPathCandidates(baseDir) {
  const candidates = [path__namespace.join(baseDir, "team-fs-worker.cjs")];
  if (path__namespace.basename(baseDir) === "chunks") {
    candidates.push(path__namespace.join(path__namespace.dirname(baseDir), "team-fs-worker.cjs"));
  }
  candidates.push(
    path__namespace.join(process.cwd(), "dist-electron", "main", "team-fs-worker.cjs"),
    path__namespace.join(process.cwd(), "dist-electron", "main", "team-fs-worker.js")
  );
  return candidates;
}
function resolveWorkerPath() {
  const baseDir = typeof __dirname === "string" && __dirname.length > 0 ? __dirname : path__namespace.dirname(node_url.fileURLToPath(require("url").pathToFileURL(__filename).href));
  const candidates = buildTeamFsWorkerPathCandidates(baseDir);
  for (const candidate of candidates) {
    try {
      if (fs__namespace$1.existsSync(candidate)) {
        return candidate;
      }
    } catch {
    }
  }
  return null;
}
function shouldWarnUnavailableWorker() {
  return process.env.NODE_ENV !== "test" && process.env.VITEST !== "true";
}
class TeamFsWorkerClient {
  worker = null;
  workerPath = resolveWorkerPath();
  warnedUnavailable = false;
  pending = /* @__PURE__ */ new Map();
  queue = [];
  activeCallId = null;
  activeTimeout = null;
  failWorker(worker, error) {
    if (this.worker !== worker) return;
    this.worker = null;
    this.clearActiveCall();
    const pendingEntries = Array.from(this.pending.values());
    const queuedEntries = [...this.queue];
    this.pending.clear();
    this.queue = [];
    for (const entry of pendingEntries) {
      entry.reject(error);
    }
    for (const entry of queuedEntries) {
      entry.reject(error);
    }
  }
  failActiveCall(worker, id2, error) {
    if (this.worker !== worker) return;
    if (this.activeCallId !== id2) return;
    const entry = this.pending.get(id2);
    this.pending.delete(id2);
    this.clearActiveCall(id2);
    this.worker = null;
    entry?.reject(error);
    void worker.terminate().catch(() => void 0);
    this.processQueue();
  }
  isAvailable() {
    if (!this.workerPath && !this.warnedUnavailable && shouldWarnUnavailableWorker()) {
      this.warnedUnavailable = true;
      const baseDir = typeof __dirname === "string" && __dirname.length > 0 ? __dirname : path__namespace.dirname(node_url.fileURLToPath(require("url").pathToFileURL(__filename).href));
      const expected = buildTeamFsWorkerPathCandidates(baseDir);
      logger$6.warn(
        `team-fs-worker not found; falling back to main-thread scanning. expectedOneOf=${expected.join(",")}`
      );
    }
    return this.workerPath !== null;
  }
  ensureWorker() {
    if (!this.workerPath) {
      throw new Error("Worker is not available in this environment");
    }
    if (this.worker) {
      return this.worker;
    }
    const worker = new node_worker_threads.Worker(this.workerPath);
    this.worker = worker;
    worker.on("message", (msg) => {
      const entry = this.pending.get(msg.id);
      if (!entry) return;
      this.pending.delete(msg.id);
      this.clearActiveCall(msg.id);
      if (msg.ok) {
        entry.resolve({ result: msg.result, diag: msg.diag });
      } else {
        entry.reject(new Error(msg.error));
      }
      this.processQueue();
    });
    worker.on("error", (err) => {
      logger$6.error("Worker error", err);
      this.failWorker(worker, err instanceof Error ? err : new Error(String(err)));
    });
    worker.on("exit", (code) => {
      if (code !== 0) {
        logger$6.warn(`Worker exited with code ${code}`);
      }
      this.failWorker(worker, new Error(`Worker exited with code ${code}`));
    });
    return worker;
  }
  clearActiveCall(id2) {
    if (id2 && this.activeCallId !== id2) {
      return;
    }
    if (this.activeTimeout) {
      clearTimeout(this.activeTimeout);
      this.activeTimeout = null;
    }
    this.activeCallId = null;
  }
  processQueue() {
    if (this.activeCallId || this.queue.length === 0) {
      return;
    }
    const entry = this.queue.shift();
    if (!entry) {
      return;
    }
    let worker;
    try {
      worker = this.ensureWorker();
    } catch (error) {
      entry.reject(error instanceof Error ? error : new Error(String(error)));
      this.processQueue();
      return;
    }
    const postedAt = Date.now();
    const pendingAtStart = this.pending.size;
    const pendingEntry = {
      ...entry,
      postedAt,
      pendingAtStart
    };
    this.pending.set(entry.id, pendingEntry);
    this.activeCallId = entry.id;
    const timeoutMs = entry.op === "warmup" ? WARMUP_TIMEOUT_MS : SCAN_TIMEOUT_MS;
    this.activeTimeout = setTimeout(() => {
      if (this.activeCallId !== entry.id) {
        return;
      }
      const timeoutError = new Error(`Worker call timeout after ${timeoutMs}ms (${entry.op})`);
      logger$6.warn(
        `worker call timeout op=${entry.op} ms=${Date.now() - entry.createdAt} workerMs=${Date.now() - postedAt} queuedMs=${postedAt - entry.createdAt} pendingAtStart=${pendingAtStart} pendingNow=${this.pending.size} queued=${this.queue.length} payload=${JSON.stringify(
          summarizeWorkerPayload(entry.payload)
        )} memory=${formatCurrentProcessMemorySnapshot()}`
      );
      this.failActiveCall(worker, entry.id, timeoutError);
    }, timeoutMs);
    try {
      worker.postMessage({ id: entry.id, op: entry.op, payload: entry.payload });
    } catch (error) {
      const postError = error instanceof Error ? error : new Error(String(error));
      this.pending.delete(entry.id);
      this.clearActiveCall(entry.id);
      pendingEntry.reject(postError);
      this.processQueue();
    }
  }
  call(op, payload) {
    const id2 = makeId();
    const createdAt = Date.now();
    return new Promise((resolve, reject) => {
      this.queue.push({
        id: id2,
        resolve: (value) => {
          const ms = Date.now() - createdAt;
          if (ms >= 1500) {
            const memorySuffix = ms >= 5e3 ? ` memory=${formatCurrentProcessMemorySnapshot()}` : "";
            logger$6.warn(
              `worker call slow op=${op} ms=${ms} workerTotalMs=${String(getDiagTotalMs(value.diag))} pendingNow=${this.pending.size} queued=${this.queue.length} payload=${JSON.stringify(
                summarizeWorkerPayload(payload)
              )}${memorySuffix}`
            );
          }
          resolve(value);
        },
        reject: (error) => {
          const ms = Date.now() - createdAt;
          if (ms >= 1500) {
            const memorySuffix = ms >= 5e3 ? ` memory=${formatCurrentProcessMemorySnapshot()}` : "";
            logger$6.warn(
              `worker call failed slow op=${op} ms=${ms} pendingNow=${this.pending.size} queued=${this.queue.length} payload=${JSON.stringify(
                summarizeWorkerPayload(payload)
              )}${memorySuffix} error=${error.message}`
            );
          }
          reject(error);
        },
        op,
        payload,
        createdAt
      });
      this.processQueue();
    });
  }
  async prewarm() {
    if (this.worker) {
      return;
    }
    if (!this.isAvailable()) {
      return;
    }
    const startedAt = Date.now();
    await this.call("warmup", {});
    const ms = Date.now() - startedAt;
    if (ms >= 1500) {
      logger$6.warn(`worker prewarm slow ms=${ms}`);
    }
  }
  async listTeams(options) {
    const payload = {
      teamsDir: taskHistory.getTeamsBasePath(),
      largeConfigBytes: options.largeConfigBytes,
      configHeadBytes: options.configHeadBytes,
      maxConfigBytes: options.maxConfigBytes,
      maxConfigReadMs: options.maxConfigReadMs ?? DEFAULT_READ_TIMEOUT_MS,
      maxMembersMetaBytes: options.maxMembersMetaBytes,
      maxSessionHistoryInSummary: options.maxSessionHistoryInSummary,
      maxProjectPathHistoryInSummary: options.maxProjectPathHistoryInSummary,
      concurrency: options.concurrency ?? DEFAULT_CONCURRENCY
    };
    const { result, diag } = await this.call("listTeams", payload);
    return { teams: result, diag };
  }
  async getAllTasks(options) {
    const payload = {
      tasksBase: taskHistory.getTasksBasePath(),
      projectionCacheBase: path__namespace.join(taskHistory.getAppDataPath(), "cache", "team-task-projections"),
      maxTaskBytes: options.maxTaskBytes,
      maxTaskReadMs: options.maxTaskReadMs ?? DEFAULT_READ_TIMEOUT_MS,
      concurrency: options.concurrency ?? DEFAULT_CONCURRENCY
    };
    const { result, diag } = await this.call("getAllTasks", payload);
    return { tasks: result, diag };
  }
}
let singleton = null;
function getTeamFsWorkerClient() {
  if (!singleton) {
    singleton = new TeamFsWorkerClient();
  }
  return singleton;
}
const TEAM_EFFORT_LEVELS = [
  "none",
  "minimal",
  "low",
  "medium",
  "high",
  "xhigh",
  "max",
  "ultra"
];
const LEGACY_TEAM_EFFORT_LEVELS = [
  "low",
  "medium",
  "high"
];
const CODEX_TEAM_EFFORT_LEVELS = [
  "minimal",
  "low",
  "medium",
  "high",
  "xhigh",
  "max",
  "ultra"
];
const ANTHROPIC_TEAM_EFFORT_LEVELS = [
  "low",
  "medium",
  "high",
  "max"
];
const LEGACY_TEAM_EFFORT_LEVEL_SET = new Set(LEGACY_TEAM_EFFORT_LEVELS);
const CODEX_TEAM_EFFORT_LEVEL_SET = new Set(CODEX_TEAM_EFFORT_LEVELS);
const ANTHROPIC_TEAM_EFFORT_LEVEL_SET = new Set(ANTHROPIC_TEAM_EFFORT_LEVELS);
function isTeamEffortLevel(value) {
  return typeof value === "string" && TEAM_EFFORT_LEVELS.includes(value);
}
function isTeamEffortLevelForProvider(value, providerId) {
  if (!isTeamEffortLevel(value)) {
    return false;
  }
  if (providerId === "codex") {
    return CODEX_TEAM_EFFORT_LEVEL_SET.has(value);
  }
  if (providerId === "anthropic") {
    return ANTHROPIC_TEAM_EFFORT_LEVEL_SET.has(value);
  }
  return LEGACY_TEAM_EFFORT_LEVEL_SET.has(value);
}
function formatEffortLevelListForProvider(providerId) {
  if (providerId === "codex") {
    return CODEX_TEAM_EFFORT_LEVELS.join(", ");
  }
  if (providerId === "anthropic") {
    return ANTHROPIC_TEAM_EFFORT_LEVELS.join(", ");
  }
  return LEGACY_TEAM_EFFORT_LEVELS.join(", ");
}
function hasCompleteKnownMetadata(raw, normalized) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw) || !normalized || typeof normalized !== "object" || Array.isArray(normalized))
    return false;
  const input = raw;
  for (const [key, canonical] of Object.entries(normalized)) {
    const value = input[key];
    if (value == null) continue;
    if (key === "providerBackendId" && typeof value === "string") {
      const provider = taskHistory.normalizeOptionalTeamProviderId(input.providerId);
      const migrated = taskHistory.migrateProviderBackendId(provider, value);
      if (migrated != null && migrated === canonical) continue;
      if (canonical == null && (provider == null || provider === "anthropic") && taskHistory.isTeamProviderBackendId(value.trim()))
        continue;
    }
    if (typeof value === "string") {
      if (value === canonical || value.trim() === canonical || !value.trim() && canonical == null)
        continue;
      return false;
    }
    if (typeof value === "number") {
      if (Number.isFinite(value) && value === canonical) continue;
      return false;
    }
    if (typeof value === "boolean") {
      if (value === canonical) continue;
      return false;
    }
    if (!hasCompleteKnownMetadata(value, canonical)) return false;
  }
  return true;
}
const MAX_TEAM_METADATA_BYTES = 256 * 1024;
class TeamMetadataTooLargeError extends Error {
  name = "TeamMetadataTooLargeError";
  code = "TEAM_METADATA_TOO_LARGE";
  statusCode = 413;
  constructor() {
    super("Saved team metadata exceeds the supported 256 KiB UTF-8 size");
  }
}
function serializeTeamMetadata(payload) {
  const serialized = JSON.stringify(payload, null, 2);
  if (Buffer.byteLength(serialized, "utf8") > MAX_TEAM_METADATA_BYTES) {
    throw new TeamMetadataTooLargeError();
  }
  return serialized;
}
function normalizeOptionalBackendId$1(value) {
  if (typeof value !== "string") {
    return void 0;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : void 0;
}
function normalizeFastMode$1(value) {
  return value === "inherit" || value === "on" || value === "off" ? value : void 0;
}
function normalizeMember(member2) {
  const trimmedName = typeof member2.name === "string" ? member2.name.trim() : void 0;
  if (!trimmedName) {
    return null;
  }
  const providerId = taskHistory.normalizeOptionalTeamProviderId(member2.providerId);
  return {
    name: trimmedName,
    role: typeof member2.role === "string" ? member2.role.trim() || void 0 : void 0,
    workflow: typeof member2.workflow === "string" ? member2.workflow.trim() || void 0 : void 0,
    isolation: member2.isolation === "worktree" ? "worktree" : void 0,
    providerId,
    providerBackendId: taskHistory.migrateProviderBackendId(
      providerId,
      normalizeOptionalBackendId$1(member2.providerBackendId)
    ),
    model: typeof member2.model === "string" ? member2.model.trim() || void 0 : void 0,
    effort: isTeamEffortLevel(member2.effort) ? member2.effort : void 0,
    fastMode: normalizeFastMode$1(member2.fastMode),
    mcpPolicy: normalizeTeamMemberMcpPolicy(member2.mcpPolicy),
    agentType: typeof member2.agentType === "string" ? member2.agentType.trim() || void 0 : void 0,
    color: typeof member2.color === "string" ? member2.color.trim() || void 0 : void 0,
    joinedAt: typeof member2.joinedAt === "number" ? member2.joinedAt : void 0,
    agentId: typeof member2.agentId === "string" ? member2.agentId : void 0,
    cwd: typeof member2.cwd === "string" ? member2.cwd.trim() || void 0 : void 0,
    removedAt: typeof member2.removedAt === "number" ? member2.removedAt : void 0
  };
}
function hasCompleteMcpPolicy(value) {
  if (value == null) return true;
  if (typeof value !== "object" || Array.isArray(value)) return false;
  const input = value;
  if (input.mode !== "inheritLead" && !normalizeTeamMemberMcpPolicy({ mode: input.mode }))
    return false;
  if (input.scopes != null) {
    if (typeof input.scopes !== "object" || Array.isArray(input.scopes)) return false;
    const scopes = input.scopes;
    const normalized = normalizeTeamMemberMcpScopes(scopes);
    if (TEAM_MEMBER_MCP_SCOPES.some(
      (scope) => scopes[scope] != null && scopes[scope] !== normalized?.[scope]
    ))
      return false;
  }
  if (input.serverNames != null) {
    if (!Array.isArray(input.serverNames)) return false;
    const names2 = /* @__PURE__ */ new Set();
    for (const name2 of input.serverNames) {
      if (typeof name2 !== "string" || name2.trim().length > 128) return false;
      if (name2.trim()) names2.add(name2.trim().toLowerCase());
    }
    if (names2.size !== (normalizeTeamMemberMcpServerNames(input.serverNames)?.length ?? 0))
      return false;
  }
  return true;
}
function hasCompleteKnownMemberFields(member2, normalized) {
  return hasCompleteKnownMetadata({ ...member2, mcpPolicy: void 0 }, normalized) && hasCompleteMcpPolicy(member2.mcpPolicy);
}
function buildActiveNameGuard(membersByName) {
  const activeNames = Array.from(membersByName.values()).filter((member2) => !member2.removedAt).map((member2) => member2.name);
  return createCliAutoSuffixNameGuard(activeNames);
}
class TeamMembersMetaStore {
  getMetaPath(teamName2) {
    return path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "members.meta.json");
  }
  /** Management replacement requires every recognized member value to survive canonical read. */
  async getMeta(teamName2, options) {
    const metaPath = this.getMetaPath(teamName2);
    try {
      const stat = await fs__namespace.promises.stat(metaPath);
      if (!stat.isFile()) {
        return null;
      }
      if (stat.isFile() && stat.size > MAX_TEAM_METADATA_BYTES) {
        return null;
      }
    } catch {
    }
    let raw;
    try {
      raw = await readFileUtf8WithTimeout(metaPath, 5e3);
    } catch (error) {
      if (error.code === "ENOENT") {
        return null;
      }
      if (error instanceof FileReadTimeoutError) {
        return null;
      }
      throw error;
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (!parsed || typeof parsed !== "object") {
      return null;
    }
    const file = parsed;
    if (!Array.isArray(file.members)) {
      return null;
    }
    if (options?.requireCompleteMembers && (file.version != null && file.version !== 1 || file.providerBackendId != null && typeof file.providerBackendId !== "string"))
      return null;
    const deduped = /* @__PURE__ */ new Map();
    const identities = options?.requireCompleteMembers ? /* @__PURE__ */ new Set() : void 0;
    for (const item of file.members) {
      if (!item || typeof item !== "object") {
        if (options?.requireCompleteMembers) return null;
        continue;
      }
      const normalized = normalizeMember(item);
      if (!normalized) {
        if (options?.requireCompleteMembers) return null;
        continue;
      }
      if (options?.requireCompleteMembers && !hasCompleteKnownMemberFields(item, normalized))
        return null;
      const identity = normalized.name.toLowerCase();
      if (identities?.has(identity)) return null;
      identities?.add(identity);
      deduped.set(normalized.name, normalized);
    }
    const allNames = Array.from(deduped.keys());
    const keepName = buildActiveNameGuard(deduped);
    for (const name2 of allNames) {
      if (!keepName(name2)) {
        if (options?.requireCompleteMembers) return null;
        deduped.delete(name2);
      }
    }
    return {
      version: 1,
      providerBackendId: normalizeOptionalBackendId$1(file.providerBackendId),
      members: Array.from(deduped.values()).sort((a, b) => a.name.localeCompare(b.name))
    };
  }
  async getMembers(teamName2) {
    return (await this.getMeta(teamName2))?.members ?? [];
  }
  async writeMembers(teamName2, members, options) {
    await taskHistory.atomicWriteAsync(
      path__namespace$1.join(options?.teamsBasePath ?? taskHistory.getTeamsBasePath(), teamName2, "members.meta.json"),
      this.serializeMembers(members, options)
    );
  }
  serializeMembers(members, options) {
    const deduped = /* @__PURE__ */ new Map();
    for (const member2 of members) {
      const normalized = normalizeMember(member2);
      if (!normalized) {
        continue;
      }
      deduped.set(normalized.name, normalized);
    }
    const allNames = Array.from(deduped.keys());
    const keepName = buildActiveNameGuard(deduped);
    for (const name2 of allNames) {
      if (!keepName(name2)) {
        deduped.delete(name2);
      }
    }
    return serializeTeamMetadata({
      version: 1,
      providerBackendId: normalizeOptionalBackendId$1(options?.providerBackendId),
      members: Array.from(deduped.values()).sort((a, b) => a.name.localeCompare(b.name))
    });
  }
}
class TeamRuntimeSelectionError extends Error {
  constructor(code, message) {
    super(`${code}: ${message}`);
    this.code = code;
  }
  code;
  name = "TeamLaunchValidationError";
}
function normalizeRuntimeSelectionVersion(value) {
  if (value === void 0) return void 0;
  if (value === 1) return 1;
  throw new TeamRuntimeSelectionError(
    "RUNTIME_SELECTION_UNSUPPORTED",
    "Unsupported runtimeSelectionVersion"
  );
}
function resolveTeamRuntimeSelection(input) {
  const version2 = normalizeRuntimeSelectionVersion(input.runtimeSelectionVersion);
  const providerId = taskHistory.normalizeOptionalTeamProviderId(input.providerId);
  if (providerId) return { status: "selected", providerId };
  return version2 === 1 ? { status: "unresolved" } : { status: "selected", providerId: "anthropic" };
}
function requireTeamRuntimeSelection(input) {
  const selection = resolveTeamRuntimeSelection(input);
  if (selection.status === "unresolved") {
    throw new TeamRuntimeSelectionError(
      "RUNTIME_SELECTION_REQUIRED",
      "Choose a team provider before launching"
    );
  }
  return selection.providerId;
}
const metaMutationLocks = /* @__PURE__ */ new Map();
async function withMetaMutationLock(pathKey, operation) {
  const previous = metaMutationLocks.get(pathKey);
  let release;
  const current = new Promise((resolve) => {
    release = resolve;
  });
  metaMutationLocks.set(pathKey, current);
  if (previous) await previous;
  try {
    return await operation();
  } finally {
    release();
    if (metaMutationLocks.get(pathKey) === current) metaMutationLocks.delete(pathKey);
  }
}
function normalizeOptionalBackendId(value) {
  if (typeof value !== "string") {
    return void 0;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : void 0;
}
function normalizeProviderId(value) {
  return value === "anthropic" || value === "codex" || value === "gemini" || value === "opencode" ? value : void 0;
}
function normalizeOptionalString(value) {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : null;
}
function normalizeFastMode(value) {
  return value === "inherit" || value === "on" || value === "off" ? value : null;
}
function normalizeLaunchIdentity(value) {
  if (!value || typeof value !== "object") {
    return void 0;
  }
  const raw = value;
  const providerId = normalizeProviderId(raw.providerId);
  const selectedModelKind = raw.selectedModelKind === "default" || raw.selectedModelKind === "explicit" ? raw.selectedModelKind : null;
  if (!providerId || !selectedModelKind) {
    return void 0;
  }
  const catalogSource = raw.catalogSource === "anthropic-models-api" || raw.catalogSource === "anthropic-compatible-api" || raw.catalogSource === "app-server" || raw.catalogSource === "static-fallback" || raw.catalogSource === "runtime" || raw.catalogSource === "unavailable" ? raw.catalogSource : "unavailable";
  const selectedEffort = raw.selectedEffort === "none" || raw.selectedEffort === "minimal" || raw.selectedEffort === "low" || raw.selectedEffort === "medium" || raw.selectedEffort === "high" || raw.selectedEffort === "xhigh" || raw.selectedEffort === "max" || raw.selectedEffort === "ultra" ? raw.selectedEffort : null;
  const resolvedEffort = raw.resolvedEffort === "none" || raw.resolvedEffort === "minimal" || raw.resolvedEffort === "low" || raw.resolvedEffort === "medium" || raw.resolvedEffort === "high" || raw.resolvedEffort === "xhigh" || raw.resolvedEffort === "max" || raw.resolvedEffort === "ultra" ? raw.resolvedEffort : null;
  return {
    providerId,
    providerBackendId: taskHistory.migrateProviderBackendId(providerId, normalizeOptionalString(raw.providerBackendId)) ?? null,
    billingMode: taskHistory.normalizeProviderBillingMode(raw.billingMode),
    selectedModel: normalizeOptionalString(raw.selectedModel),
    selectedModelKind,
    resolvedLaunchModel: normalizeOptionalString(raw.resolvedLaunchModel),
    catalogId: normalizeOptionalString(raw.catalogId),
    catalogSource,
    catalogFetchedAt: normalizeOptionalString(raw.catalogFetchedAt),
    selectedEffort,
    resolvedEffort,
    selectedFastMode: normalizeFastMode(raw.selectedFastMode),
    resolvedFastMode: typeof raw.resolvedFastMode === "boolean" ? raw.resolvedFastMode : null,
    fastResolutionReason: normalizeOptionalString(raw.fastResolutionReason)
  };
}
class TeamMetaStore {
  getMetaPath(teamName2, teamsBasePath = taskHistory.getTeamsBasePath()) {
    return path__namespace$1.join(teamsBasePath, teamName2, "team.meta.json");
  }
  async getMeta(teamName2, teamsBasePath = taskHistory.getTeamsBasePath(), options) {
    const metaPath = this.getMetaPath(teamName2, teamsBasePath);
    try {
      const stat = await fs__namespace.promises.stat(metaPath);
      if (!stat.isFile() || stat.size > MAX_TEAM_METADATA_BYTES) {
        return null;
      }
    } catch {
      return null;
    }
    let raw;
    try {
      raw = await readFileUtf8WithTimeout(metaPath, 5e3);
    } catch (error) {
      if (error.code === "ENOENT" || error instanceof FileReadTimeoutError) {
        return null;
      }
      throw error;
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (!parsed || typeof parsed !== "object") {
      return null;
    }
    const file = parsed;
    if (file.version !== 1 || typeof file.cwd !== "string") {
      return null;
    }
    if (options?.requireCompleteFields && file.createdAt !== void 0 && (typeof file.createdAt !== "number" || !Number.isFinite(file.createdAt)))
      return null;
    const providerId = normalizeProviderId(file.providerId);
    try {
      const normalized = {
        version: 1,
        deletedAt: typeof file.deletedAt === "string" ? file.deletedAt : void 0,
        runtimeSelectionVersion: normalizeRuntimeSelectionVersion(file.runtimeSelectionVersion),
        displayName: typeof file.displayName === "string" ? file.displayName.trim() || void 0 : void 0,
        description: typeof file.description === "string" ? file.description.trim() || void 0 : void 0,
        color: typeof file.color === "string" ? file.color.trim() || void 0 : void 0,
        cwd: file.cwd.trim(),
        prompt: typeof file.prompt === "string" ? file.prompt.trim() || void 0 : void 0,
        providerId,
        providerBackendId: taskHistory.migrateProviderBackendId(
          providerId,
          normalizeOptionalBackendId(file.providerBackendId)
        ),
        model: typeof file.model === "string" ? file.model.trim() || void 0 : void 0,
        effort: typeof file.effort === "string" ? file.effort.trim() || void 0 : void 0,
        fastMode: normalizeFastMode(file.fastMode) ?? void 0,
        syncModelsWithLead: typeof file.syncModelsWithLead === "boolean" ? file.syncModelsWithLead : void 0,
        skipPermissions: typeof file.skipPermissions === "boolean" ? file.skipPermissions : void 0,
        worktree: typeof file.worktree === "string" ? file.worktree.trim() || void 0 : void 0,
        extraCliArgs: typeof file.extraCliArgs === "string" ? file.extraCliArgs.trim() || void 0 : void 0,
        limitContext: typeof file.limitContext === "boolean" ? file.limitContext : void 0,
        launchIdentity: normalizeLaunchIdentity(file.launchIdentity),
        createdAt: typeof file.createdAt === "number" ? file.createdAt : Date.now()
      };
      return options?.requireCompleteFields && !hasCompleteKnownMetadata(file, normalized) ? null : normalized;
    } catch (error) {
      if (options?.requireCompleteFields) return null;
      throw error;
    }
  }
  async writeMeta(teamName2, data, teamsBasePath = taskHistory.getTeamsBasePath()) {
    const metaPath = this.getMetaPath(teamName2, teamsBasePath);
    await withMetaMutationLock(metaPath, async () => {
      const current = await this.getMeta(teamName2, teamsBasePath);
      await this.writeMetaUnlocked(metaPath, {
        ...data,
        runtimeSelectionVersion: normalizeRuntimeSelectionVersion(data.runtimeSelectionVersion) ?? current?.runtimeSelectionVersion
      });
    });
  }
  async updateMeta(teamName2, update) {
    const metaPath = this.getMetaPath(teamName2);
    await withMetaMutationLock(metaPath, async () => {
      const data = await update(await this.getMeta(teamName2));
      await this.writeMetaUnlocked(metaPath, data);
    });
  }
  async writeMetaUnlocked(metaPath, data) {
    await taskHistory.atomicWriteAsync(metaPath, this.serializeMeta(data));
  }
  serializeMeta(data) {
    return serializeTeamMetadata({
      version: 1,
      deletedAt: data.deletedAt,
      runtimeSelectionVersion: normalizeRuntimeSelectionVersion(data.runtimeSelectionVersion),
      displayName: data.displayName?.trim() || void 0,
      description: data.description?.trim() || void 0,
      color: data.color?.trim() || void 0,
      cwd: data.cwd.trim(),
      prompt: data.prompt?.trim() || void 0,
      providerId: data.providerId,
      providerBackendId: taskHistory.migrateProviderBackendId(
        data.providerId,
        normalizeOptionalBackendId(data.providerBackendId)
      ),
      model: data.model?.trim() || void 0,
      effort: data.effort?.trim() || void 0,
      fastMode: normalizeFastMode(data.fastMode) ?? void 0,
      syncModelsWithLead: data.syncModelsWithLead,
      skipPermissions: data.skipPermissions,
      worktree: data.worktree?.trim() || void 0,
      extraCliArgs: data.extraCliArgs?.trim() || void 0,
      limitContext: data.limitContext,
      launchIdentity: normalizeLaunchIdentity(data.launchIdentity),
      createdAt: data.createdAt
    });
  }
  async deleteMeta(teamName2) {
    const metaPath = this.getMetaPath(teamName2);
    await withMetaMutationLock(metaPath, async () => {
      try {
        await fs__namespace.promises.unlink(metaPath);
      } catch (error) {
        if (error.code !== "ENOENT") {
          throw error;
        }
      }
    });
  }
}
const logger$5 = createLogger("Service:TeamConfigReader");
const TEAM_LIST_CONCURRENCY = process.platform === "win32" ? 4 : 12;
const LARGE_CONFIG_BYTES = 512 * 1024;
const CONFIG_HEAD_BYTES = 64 * 1024;
const MAX_CONFIG_READ_BYTES = 10 * 1024 * 1024;
const PER_TEAM_READ_TIMEOUT_MS = 5e3;
const GET_CONFIG_SLOW_READ_WARN_MS = 500;
const CONFIG_SNAPSHOT_RECENT_STAT_FAILURE_FALLBACK_MS = 5e3;
const COARSE_FS_FULL_VERIFY_MS = 1500;
const LIST_TEAMS_CACHE_TTL_MS = 5e3;
const MAX_SESSION_HISTORY_IN_SUMMARY = 2e3;
const MAX_PROJECT_PATH_HISTORY_IN_SUMMARY = 200;
const MAX_LAUNCH_STATE_BYTES$1 = 32 * 1024;
const TEAM_LAUNCH_STATE_FILE$1 = "launch-state.json";
function normalizeProjectPathCandidate$1(value) {
  if (typeof value !== "string") {
    return void 0;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : void 0;
}
function resolveProjectPathFromConfig(config) {
  const direct = normalizeProjectPathCandidate$1(config.projectPath);
  if (direct) {
    return direct;
  }
  const leadMemberCwd = (config.members ?? []).find((member2) => taskHistory.isLeadMember(member2))?.cwd;
  const leadResolved = normalizeProjectPathCandidate$1(leadMemberCwd);
  if (leadResolved) {
    return leadResolved;
  }
  const distinctMemberCwds = Array.from(
    new Set(
      (config.members ?? []).map((member2) => normalizeProjectPathCandidate$1(member2.cwd)).filter((cwd) => Boolean(cwd))
    )
  );
  if (distinctMemberCwds.length === 1) {
    return distinctMemberCwds[0];
  }
  if (Array.isArray(config.projectPathHistory)) {
    for (let i = config.projectPathHistory.length - 1; i >= 0; i--) {
      const historyValue = normalizeProjectPathCandidate$1(config.projectPathHistory[i]);
      if (historyValue) {
        return historyValue;
      }
    }
  }
  return void 0;
}
async function readLaunchStateSummary(teamDir) {
  const bootstrapSnapshot = await taskHistory.readBootstrapLaunchSnapshot(path__namespace$1.basename(teamDir));
  const launchStatePath = path__namespace$1.join(teamDir, TEAM_LAUNCH_STATE_FILE$1);
  const launchSummaryPath = path__namespace$1.join(teamDir, taskHistory.TEAM_LAUNCH_SUMMARY_FILE);
  const [launchSnapshot, launchSummaryProjection] = await Promise.all([
    (async () => {
      try {
        const stat = await fs__namespace.promises.stat(launchStatePath);
        if (!stat.isFile() || stat.size > MAX_LAUNCH_STATE_BYTES$1) {
          return null;
        }
        const raw = await readFileUtf8WithTimeout(launchStatePath, PER_TEAM_READ_TIMEOUT_MS);
        return taskHistory.normalizePersistedLaunchSnapshot(path__namespace$1.basename(teamDir), JSON.parse(raw));
      } catch {
        return null;
      }
    })(),
    (async () => {
      try {
        const stat = await fs__namespace.promises.stat(launchSummaryPath);
        if (!stat.isFile() || stat.size > MAX_LAUNCH_STATE_BYTES$1) {
          return null;
        }
        const raw = await readFileUtf8WithTimeout(launchSummaryPath, PER_TEAM_READ_TIMEOUT_MS);
        return taskHistory.normalizePersistedLaunchSummaryProjection(path__namespace$1.basename(teamDir), JSON.parse(raw));
      } catch {
        return null;
      }
    })()
  ]);
  return taskHistory.choosePreferredLaunchStateSummary({
    bootstrapSnapshot,
    launchSnapshot,
    launchSummaryProjection
  });
}
async function mapLimit$3(items, limit, fn) {
  const results = new Array(items.length);
  let index = 0;
  const workerCount = Math.max(1, Math.min(limit, items.length));
  const workers = new Array(workerCount).fill(0).map(async () => {
    while (true) {
      const i = index++;
      if (i >= items.length) return;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}
function withReadTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error("Team config read timeout")), ms);
  });
  return Promise.race([promise, timeout]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}
function cloneConfig(config) {
  return structuredClone(config);
}
function cloneTeamSummaries(teams) {
  return structuredClone([...teams]);
}
function freezeTeamSummariesDeep(teams) {
  const freeze = (value) => {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) {
      return;
    }
    Object.freeze(value);
    for (const nested of Object.values(value)) {
      freeze(nested);
    }
  };
  freeze(teams);
  return teams;
}
function classifyConfigReadTiming(timing) {
  const statMs = timing.statMs ?? 0;
  const readMs = timing.readMs ?? 0;
  const parseMs = timing.parseMs ?? 0;
  if (readMs >= 1e3 && readMs >= statMs * 2 && readMs >= parseMs * 2) {
    return "io_read_slow";
  }
  if (statMs >= 1e3 && statMs >= readMs * 2 && statMs >= parseMs * 2) {
    return "io_stat_slow";
  }
  if (parseMs >= 500 && parseMs >= readMs && parseMs >= statMs) {
    return "json_parse_slow";
  }
  if (statMs + readMs >= 1e3) {
    return "filesystem_pressure";
  }
  return "mixed_or_unknown";
}
function captureConfigReadCaller() {
  const stack = new Error().stack?.split("\n").slice(2) ?? [];
  const frame = stack.find((line) => {
    const normalized = line.trim();
    return normalized.length > 0 && !normalized.includes("TeamConfigReader.") && !normalized.includes("TeamConfigReader.ts") && !normalized.includes("captureConfigReadCaller") && !normalized.includes("node:internal");
  });
  return frame?.trim().slice(0, 240) ?? null;
}
class TeamConfigReader {
  constructor(membersMetaStore = new TeamMembersMetaStore(), teamMetaStore = new TeamMetaStore()) {
    this.membersMetaStore = membersMetaStore;
    this.teamMetaStore = teamMetaStore;
  }
  membersMetaStore;
  teamMetaStore;
  static configCacheByPath = /* @__PURE__ */ new Map();
  static configReadInFlightByPath = /* @__PURE__ */ new Map();
  static configStatInFlightByPath = /* @__PURE__ */ new Map();
  static configGenerationByPath = /* @__PURE__ */ new Map();
  static listTeamsCacheByBasePath = /* @__PURE__ */ new Map();
  static listTeamsInFlightByBasePath = /* @__PURE__ */ new Map();
  static listTeamsGeneration = 0;
  static clearCacheForTests() {
    TeamConfigReader.configCacheByPath.clear();
    TeamConfigReader.configReadInFlightByPath.clear();
    TeamConfigReader.configStatInFlightByPath.clear();
    TeamConfigReader.configGenerationByPath.clear();
    TeamConfigReader.listTeamsCacheByBasePath.clear();
    TeamConfigReader.listTeamsInFlightByBasePath.clear();
    TeamConfigReader.listTeamsGeneration = 0;
  }
  static invalidateTeam(teamName2) {
    const configPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "config.json");
    TeamConfigReader.invalidatePath(configPath);
  }
  static invalidatePath(configPath) {
    TeamConfigReader.configCacheByPath.delete(configPath);
    TeamConfigReader.bumpConfigGeneration(configPath);
    TeamConfigReader.invalidateListTeamsCache();
  }
  static invalidateListTeamsCache() {
    TeamConfigReader.listTeamsCacheByBasePath.clear();
    TeamConfigReader.listTeamsGeneration += 1;
  }
  static invalidatePathForGeneration(configPath, expectedGeneration) {
    if (typeof expectedGeneration === "number" && TeamConfigReader.getConfigGeneration(configPath) !== expectedGeneration) {
      return;
    }
    TeamConfigReader.invalidatePath(configPath);
  }
  static async primeConfig(teamName2, config, fingerprint) {
    const configPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "config.json");
    const generation = TeamConfigReader.bumpConfigGeneration(configPath);
    TeamConfigReader.configReadInFlightByPath.delete(configPath);
    TeamConfigReader.configStatInFlightByPath.delete(configPath);
    let internalFingerprint = null;
    if (fingerprint) {
      internalFingerprint = {
        ...fingerprint,
        isFile: true,
        highResolution: Boolean(fingerprint.mtimeNs || fingerprint.ctimeNs),
        numericSize: Number(fingerprint.size)
      };
    } else {
      internalFingerprint = await TeamConfigReader.readConfigFingerprint(configPath).catch(
        () => null
      );
    }
    TeamConfigReader.storeConfigCache(configPath, config, internalFingerprint, true, generation);
    TeamConfigReader.invalidateListTeamsCache();
  }
  async listTeams() {
    const teamsBasePath = taskHistory.getTeamsBasePath();
    const cached = TeamConfigReader.listTeamsCacheByBasePath.get(teamsBasePath);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.value;
    }
    const existingRequest = TeamConfigReader.listTeamsInFlightByBasePath.get(teamsBasePath);
    if (existingRequest?.generationAtStart === TeamConfigReader.listTeamsGeneration) {
      return existingRequest.promise;
    }
    const request = this.listTeamsUncached(teamsBasePath).then(
      (teams) => freezeTeamSummariesDeep(cloneTeamSummaries(teams))
    );
    const generationAtStart = TeamConfigReader.listTeamsGeneration;
    TeamConfigReader.listTeamsInFlightByBasePath.set(teamsBasePath, {
      promise: request,
      generationAtStart
    });
    try {
      const frozenTeams = await request;
      if (TeamConfigReader.listTeamsGeneration === generationAtStart) {
        TeamConfigReader.listTeamsCacheByBasePath.set(teamsBasePath, {
          value: frozenTeams,
          expiresAt: Date.now() + LIST_TEAMS_CACHE_TTL_MS
        });
      }
      return frozenTeams;
    } finally {
      if (TeamConfigReader.listTeamsInFlightByBasePath.get(teamsBasePath)?.promise === request) {
        TeamConfigReader.listTeamsInFlightByBasePath.delete(teamsBasePath);
      }
    }
  }
  async listTeamsUncached(teamsBasePath) {
    const worker = getTeamFsWorkerClient();
    if (worker.isAvailable()) {
      const startedAt = Date.now();
      try {
        const { teams, diag } = await worker.listTeams({
          largeConfigBytes: LARGE_CONFIG_BYTES,
          configHeadBytes: CONFIG_HEAD_BYTES,
          maxConfigBytes: MAX_CONFIG_READ_BYTES,
          maxMembersMetaBytes: 256 * 1024,
          maxSessionHistoryInSummary: MAX_SESSION_HISTORY_IN_SUMMARY,
          maxProjectPathHistoryInSummary: MAX_PROJECT_PATH_HISTORY_IN_SUMMARY,
          concurrency: TEAM_LIST_CONCURRENCY,
          maxConfigReadMs: PER_TEAM_READ_TIMEOUT_MS
        });
        const ms = Date.now() - startedAt;
        const skipReasons = diag && typeof diag === "object" ? diag.skipReasons : null;
        if (skipReasons && typeof skipReasons === "object") {
          const bad = Number(skipReasons.config_parse_failed ?? 0) + Number(skipReasons.config_read_timeout ?? 0);
          if (bad > 0) {
            logger$5.warn(`[listTeams] worker skipped broken team configs count=${bad}`);
          }
        }
        if (ms >= 1500) {
          logger$5.warn(`[listTeams] worker slow ms=${ms} diag=${JSON.stringify(diag)}`);
        }
        return teams;
      } catch (error) {
        logger$5.warn(
          `[listTeams] worker failed: ${error instanceof Error ? error.message : String(error)}`
        );
      }
    }
    const teamsDir = teamsBasePath;
    let entries;
    try {
      entries = await fs__namespace.promises.readdir(teamsDir, { withFileTypes: true });
    } catch {
      return [];
    }
    const teamDirs = entries.filter((e) => e.isDirectory());
    const perTeam = await mapLimit$3(
      teamDirs,
      TEAM_LIST_CONCURRENCY,
      async (entry) => {
        const teamName2 = entry.name;
        try {
          return await withReadTimeout(
            this.readTeamSummary(teamsDir, teamName2),
            PER_TEAM_READ_TIMEOUT_MS
          );
        } catch (err) {
          const reason = err instanceof Error ? err.message : "unknown";
          logger$5.warn(`Skipping team dir (${reason}): ${teamName2}`);
          return null;
        }
      }
    );
    return perTeam.filter((t) => t !== null);
  }
  async readTeamSummary(teamsDir, teamName2) {
    const configPath = path__namespace$1.join(teamsDir, teamName2, "config.json");
    const teamDir = path__namespace$1.join(teamsDir, teamName2);
    try {
      let config = null;
      let leadProviderId;
      let displayName = null;
      let description = "";
      let color;
      let projectPath;
      let leadSessionId;
      let deletedAt;
      let projectPathHistory;
      let sessionHistory;
      let stat = null;
      try {
        stat = await fs__namespace.promises.stat(configPath);
      } catch {
        stat = null;
      }
      if (!stat?.isFile()) {
        return this.readDraftTeamSummary(teamsDir, teamName2);
      }
      if (stat.size > MAX_CONFIG_READ_BYTES) {
        logger$5.warn(
          `Skipping team dir with oversized config.json (${stat.size} bytes): ${teamName2}`
        );
        return null;
      }
      if (stat.size > LARGE_CONFIG_BYTES) {
        displayName = teamName2;
      } else {
        const raw = await readFileUtf8WithTimeout(configPath, PER_TEAM_READ_TIMEOUT_MS);
        config = JSON.parse(raw);
        displayName = typeof config.name === "string" ? config.name : null;
        description = typeof config.description === "string" ? config.description : "";
        color = typeof config.color === "string" && config.color.trim().length > 0 ? config.color : void 0;
        projectPath = resolveProjectPathFromConfig(config);
        leadSessionId = typeof config.leadSessionId === "string" && config.leadSessionId.trim().length > 0 ? config.leadSessionId : void 0;
        projectPathHistory = Array.isArray(config.projectPathHistory) ? config.projectPathHistory.slice(-MAX_PROJECT_PATH_HISTORY_IN_SUMMARY) : void 0;
        sessionHistory = Array.isArray(config.sessionHistory) ? config.sessionHistory.slice(-MAX_SESSION_HISTORY_IN_SUMMARY) : void 0;
        deletedAt = typeof config.deletedAt === "string" ? config.deletedAt : void 0;
      }
      if (typeof displayName !== "string" || displayName.trim() === "") {
        logger$5.debug(`Skipping team dir with invalid config name: ${teamName2}`);
        return null;
      }
      const memberMap = /* @__PURE__ */ new Map();
      const removedKeys = /* @__PURE__ */ new Set();
      const expectedTeammateNames = /* @__PURE__ */ new Set();
      const confirmedArtifactNames = /* @__PURE__ */ new Set();
      let metaMembers = [];
      let leadName;
      let leadColor;
      const captureLeadMember = (m, overwrite = false) => {
        if (m.removedAt) return;
        if (!taskHistory.isLeadMember(m)) return;
        const name2 = m.name?.trim();
        if (name2 && (overwrite || !leadName)) {
          leadName = name2;
        }
        const colorValue = m.color?.trim();
        if (colorValue && (overwrite || !leadColor)) {
          leadColor = colorValue;
        }
      };
      const mergeMember = (m) => {
        const name2 = m.name?.trim();
        if (!name2) return;
        if (name2 === "user" || taskHistory.isLeadMember(m)) return;
        const key = name2.toLowerCase();
        if (removedKeys.has(key)) return;
        const existing = memberMap.get(key);
        memberMap.set(key, {
          name: existing?.name ?? name2,
          role: m.role?.trim() || existing?.role,
          color: m.color?.trim() || existing?.color,
          mcpPolicy: normalizeTeamMemberMcpPolicy(m.mcpPolicy) ?? existing?.mcpPolicy
        });
      };
      try {
        metaMembers = await this.membersMetaStore.getMembers(teamName2);
        for (const member2 of metaMembers) {
          const name2 = member2.name?.trim();
          if (!name2) continue;
          captureLeadMember(member2);
          if (name2 === "user" || taskHistory.isLeadMember(member2)) continue;
          const key = name2.toLowerCase();
          if (member2.removedAt) {
            removedKeys.add(key);
            continue;
          }
          expectedTeammateNames.add(name2);
          mergeMember(member2);
        }
      } catch {
      }
      try {
        leadProviderId = (await this.teamMetaStore.getMeta(teamName2))?.providerId;
      } catch {
        leadProviderId = void 0;
      }
      if (config && Array.isArray(config.members)) {
        for (const member2 of config.members) {
          if (member2 && typeof member2.name === "string") {
            const name2 = member2.name.trim();
            captureLeadMember(member2, true);
            if (name2 && name2 !== "user" && !taskHistory.isLeadMember(member2)) {
              confirmedArtifactNames.add(name2);
            }
            mergeMember(member2);
          }
        }
      }
      try {
        const inboxDir = path__namespace$1.join(teamDir, "inboxes");
        const inboxEntries = await fs__namespace.promises.readdir(inboxDir, { withFileTypes: true });
        for (const entry of inboxEntries) {
          if (!entry.isFile() || !entry.name.endsWith(".json")) continue;
          const inboxName = entry.name.slice(0, -".json".length).trim();
          if (!inboxName || inboxName === "user" || taskHistory.isLeadMember({ name: inboxName })) continue;
          confirmedArtifactNames.add(inboxName);
        }
      } catch {
      }
      const activeNamesForAutoSuffix = Array.from(memberMap.values()).map((member2) => member2.name).filter((name2) => !removedKeys.has(name2.trim().toLowerCase()));
      const keepName = createCliAutoSuffixNameGuard(activeNamesForAutoSuffix);
      const keepProvisioner = createCliProvisionerNameGuard(activeNamesForAutoSuffix);
      for (const [key, member2] of Array.from(memberMap.entries())) {
        if (!keepName(member2.name) || !keepProvisioner(member2.name)) {
          memberMap.delete(key);
        }
      }
      const members = Array.from(memberMap.values());
      const suppressLegacyLaunchArtifactHeuristic = taskHistory.shouldSuppressLegacyLaunchArtifactHeuristic({
        leadProviderId,
        members: metaMembers
      });
      const launchStateSummary = await readLaunchStateSummary(teamDir) ?? (() => {
        if (suppressLegacyLaunchArtifactHeuristic) {
          return null;
        }
        if (!leadSessionId || expectedTeammateNames.size === 0 || confirmedArtifactNames.size === 0) {
          return null;
        }
        const missingMembers = Array.from(expectedTeammateNames).filter(
          (name2) => !confirmedArtifactNames.has(name2)
        );
        if (missingMembers.length === 0) {
          return null;
        }
        return {
          partialLaunchFailure: true,
          expectedMemberCount: expectedTeammateNames.size,
          confirmedMemberCount: confirmedArtifactNames.size,
          missingMembers
        };
      })();
      const summary = {
        teamName: teamName2,
        displayName,
        description,
        memberCount: memberMap.size,
        taskCount: 0,
        lastActivity: null,
        ...members.length > 0 ? { members } : {},
        ...leadName ? { leadName } : {},
        ...leadColor ? { leadColor } : {},
        ...color ? { color } : {},
        ...projectPath ? { projectPath } : {},
        ...leadSessionId ? { leadSessionId } : {},
        ...projectPathHistory ? { projectPathHistory } : {},
        ...sessionHistory ? { sessionHistory } : {},
        ...deletedAt ? { deletedAt } : {},
        ...launchStateSummary ?? {}
      };
      return summary;
    } catch {
      logger$5.debug(`Skipping team dir without valid config: ${teamName2}`);
      return null;
    }
  }
  /**
   * Checks for a draft team (team.meta.json exists without config.json).
   * This happens when provisioning failed before CLI's TeamCreate could run.
   */
  async readDraftTeamSummary(teamsDir, teamName2) {
    const metaPath = path__namespace$1.join(teamsDir, teamName2, "team.meta.json");
    try {
      const metaStat = await fs__namespace.promises.stat(metaPath);
      if (!metaStat.isFile() || metaStat.size > 256 * 1024) {
        return null;
      }
      const metaRaw = await readFileUtf8WithTimeout(metaPath, PER_TEAM_READ_TIMEOUT_MS);
      const meta = JSON.parse(metaRaw);
      if (meta?.version !== 1 || typeof meta?.cwd !== "string") {
        return null;
      }
      const displayName = typeof meta.displayName === "string" && meta.displayName.trim() ? meta.displayName.trim() : teamName2;
      let memberCount = 0;
      let leadName;
      let leadColor;
      try {
        const members = await this.membersMetaStore.getMembers(teamName2);
        memberCount = members.filter((member2) => {
          const name2 = member2.name?.trim() ?? "";
          if (!member2.removedAt && taskHistory.isLeadMember(member2)) {
            if (name2) {
              leadName = name2;
            }
            const color = member2.color?.trim();
            if (color) {
              leadColor = color;
            }
          }
          if (!name2 || name2 === "user" || taskHistory.isLeadMember(member2)) {
            return false;
          }
          return !member2.removedAt;
        }).length;
      } catch {
      }
      return {
        teamName: teamName2,
        displayName,
        description: typeof meta.description === "string" ? meta.description : "",
        memberCount,
        taskCount: 0,
        lastActivity: typeof meta.createdAt === "number" ? new Date(meta.createdAt).toISOString() : null,
        color: typeof meta.color === "string" ? meta.color : void 0,
        ...leadName ? { leadName } : {},
        ...leadColor ? { leadColor } : {},
        projectPath: typeof meta.cwd === "string" ? meta.cwd : void 0,
        pendingCreate: true,
        deletedAt: typeof meta.deletedAt === "string" ? meta.deletedAt : void 0
      };
    } catch {
      return null;
    }
  }
  async getConfig(teamName2) {
    return this.getConfigVerified(teamName2);
  }
  async getConfigVerified(teamName2) {
    const configPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "config.json");
    const existingRead = TeamConfigReader.configReadInFlightByPath.get(configPath);
    if (existingRead) {
      return this.resolveConfigRead(teamName2, configPath, existingRead);
    }
    const generation = TeamConfigReader.getConfigGeneration(configPath);
    const readPromise = this.readConfigFromDisk(
      teamName2,
      configPath,
      null,
      true,
      generation,
      "verified"
    );
    TeamConfigReader.configReadInFlightByPath.set(configPath, readPromise);
    try {
      return await this.resolveConfigRead(teamName2, configPath, readPromise);
    } finally {
      if (TeamConfigReader.configReadInFlightByPath.get(configPath) === readPromise) {
        TeamConfigReader.configReadInFlightByPath.delete(configPath);
      }
    }
  }
  async getConfigSnapshot(teamName2) {
    const configPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "config.json");
    for (let attempt = 0; attempt < 3; attempt++) {
      const generationAtStart = TeamConfigReader.getConfigGeneration(configPath);
      let fingerprint;
      try {
        fingerprint = await TeamConfigReader.getConfigFingerprint(configPath);
      } catch (error) {
        if (TeamConfigReader.getConfigGeneration(configPath) !== generationAtStart) {
          continue;
        }
        const cached2 = TeamConfigReader.configCacheByPath.get(configPath);
        if (cached2 && Date.now() - cached2.verifiedAt <= CONFIG_SNAPSHOT_RECENT_STAT_FAILURE_FALLBACK_MS) {
          logger$5.warn(
            `[getConfigSnapshot] config_snapshot_stat_failed_using_recent_cache team=${teamName2} error=${error instanceof Error ? error.message : String(error)}`
          );
          return cloneConfig(cached2.value);
        }
        return null;
      }
      if (TeamConfigReader.getConfigGeneration(configPath) !== generationAtStart) {
        continue;
      }
      if (!fingerprint?.isFile || fingerprint.numericSize > MAX_CONFIG_READ_BYTES) {
        TeamConfigReader.invalidatePathForGeneration(configPath, generationAtStart);
        if (fingerprint && fingerprint.numericSize > MAX_CONFIG_READ_BYTES) {
          logger$5.warn(
            `Refusing to load oversized config.json (${fingerprint.numericSize} bytes) for team: ${teamName2}`
          );
        }
        return null;
      }
      const cached = TeamConfigReader.configCacheByPath.get(configPath);
      if (cached?.fingerprint && TeamConfigReader.fingerprintsEqual(cached.fingerprint, fingerprint)) {
        const now = Date.now();
        const mustRevalidateCoarseFingerprint = !fingerprint.highResolution && now - cached.fullVerifiedAt >= COARSE_FS_FULL_VERIFY_MS;
        if (!mustRevalidateCoarseFingerprint) {
          cached.verifiedAt = now;
          return cloneConfig(cached.value);
        }
      }
      const existingRead = TeamConfigReader.configReadInFlightByPath.get(configPath);
      if (existingRead) {
        return this.resolveConfigRead(teamName2, configPath, existingRead);
      }
      const generation = TeamConfigReader.getConfigGeneration(configPath);
      const readPromise = this.readConfigFromDisk(
        teamName2,
        configPath,
        fingerprint,
        true,
        generation,
        "snapshot"
      );
      TeamConfigReader.configReadInFlightByPath.set(configPath, readPromise);
      try {
        return await this.resolveConfigRead(teamName2, configPath, readPromise);
      } finally {
        if (TeamConfigReader.configReadInFlightByPath.get(configPath) === readPromise) {
          TeamConfigReader.configReadInFlightByPath.delete(configPath);
        }
      }
    }
    return null;
  }
  async resolveConfigRead(teamName2, configPath, readPromise) {
    try {
      const config = await readPromise;
      return config ? cloneConfig(config) : null;
    } catch {
      return null;
    }
  }
  static async getConfigFingerprint(configPath) {
    const existing = TeamConfigReader.configStatInFlightByPath.get(configPath);
    if (existing) return existing;
    const statPromise = TeamConfigReader.readConfigFingerprint(configPath).finally(() => {
      if (TeamConfigReader.configStatInFlightByPath.get(configPath) === statPromise) {
        TeamConfigReader.configStatInFlightByPath.delete(configPath);
      }
    });
    TeamConfigReader.configStatInFlightByPath.set(configPath, statPromise);
    return statPromise;
  }
  static async readConfigFingerprint(configPath) {
    let stat;
    try {
      stat = await withReadTimeout(
        fs__namespace.promises.stat(configPath, { bigint: true }),
        PER_TEAM_READ_TIMEOUT_MS
      );
    } catch (error) {
      const code = typeof error === "object" && error ? error.code : null;
      if (code === "ENOENT") {
        return null;
      }
      throw error;
    }
    const highResStat = stat;
    const mtimeNs = highResStat.mtimeNs;
    const ctimeNs = highResStat.ctimeNs;
    const birthtimeNs = highResStat.birthtimeNs;
    return {
      size: stat.size.toString(),
      mode: stat.mode.toString(),
      dev: stat.dev.toString(),
      ino: stat.ino.toString(),
      mtimeNs: typeof mtimeNs === "bigint" ? mtimeNs.toString() : void 0,
      ctimeNs: typeof ctimeNs === "bigint" ? ctimeNs.toString() : void 0,
      birthtimeNs: typeof birthtimeNs === "bigint" ? birthtimeNs.toString() : void 0,
      mtimeMs: Number(stat.mtimeMs),
      ctimeMs: Number(stat.ctimeMs),
      birthtimeMs: Number(stat.birthtimeMs),
      isFile: stat.isFile(),
      highResolution: typeof mtimeNs === "bigint" || typeof ctimeNs === "bigint",
      numericSize: Number(stat.size)
    };
  }
  static fingerprintsEqual(a, b) {
    return a.size === b.size && a.mode === b.mode && a.dev === b.dev && a.ino === b.ino && a.mtimeNs === b.mtimeNs && a.ctimeNs === b.ctimeNs && a.birthtimeNs === b.birthtimeNs && a.mtimeMs === b.mtimeMs && a.ctimeMs === b.ctimeMs && a.birthtimeMs === b.birthtimeMs;
  }
  static storeConfigCache(configPath, config, fingerprint, fullVerified, expectedGeneration) {
    if (typeof expectedGeneration === "number" && TeamConfigReader.getConfigGeneration(configPath) !== expectedGeneration) {
      return;
    }
    const now = Date.now();
    const previous = TeamConfigReader.configCacheByPath.get(configPath);
    TeamConfigReader.configCacheByPath.set(configPath, {
      value: cloneConfig(config),
      fingerprint,
      verifiedAt: now,
      fullVerifiedAt: fullVerified ? now : previous?.fullVerifiedAt ?? now
    });
  }
  static getConfigGeneration(configPath) {
    return TeamConfigReader.configGenerationByPath.get(configPath) ?? 0;
  }
  static bumpConfigGeneration(configPath) {
    const next = TeamConfigReader.getConfigGeneration(configPath) + 1;
    TeamConfigReader.configGenerationByPath.set(configPath, next);
    return next;
  }
  async readConfigFromDisk(teamName2, configPath, knownFingerprint = null, updateCache = false, cacheGeneration, mode = "verified") {
    const startedAt = performance.now();
    const caller = captureConfigReadCaller();
    let size = null;
    let statMs = null;
    let readMs = null;
    let parseMs = null;
    let fingerprintHighResolution = knownFingerprint?.highResolution ?? null;
    const buildTiming = () => ({
      teamName: teamName2,
      mode,
      configPath,
      size,
      statMs,
      readMs,
      parseMs,
      totalMs: Math.round(performance.now() - startedAt),
      likelyCause: classifyConfigReadTiming({ statMs, readMs, parseMs }),
      fingerprintHighResolution,
      cacheGeneration: cacheGeneration ?? null,
      currentGeneration: TeamConfigReader.getConfigGeneration(configPath),
      caller
    });
    try {
      const statStartedAt = performance.now();
      const fingerprint = knownFingerprint ?? await TeamConfigReader.getConfigFingerprint(configPath);
      statMs = Math.round(performance.now() - statStartedAt);
      size = fingerprint?.numericSize ?? null;
      fingerprintHighResolution = fingerprint?.highResolution ?? null;
      if (!fingerprint?.isFile || fingerprint.numericSize > MAX_CONFIG_READ_BYTES) {
        TeamConfigReader.invalidatePathForGeneration(configPath, cacheGeneration);
        if (fingerprint?.isFile)
          logger$5.warn(
            `Refusing to load oversized config.json (${fingerprint.numericSize} bytes) for team: ${teamName2}`
          );
        return null;
      }
      const readStartedAt = performance.now();
      const raw = await readFileUtf8WithTimeout(configPath, PER_TEAM_READ_TIMEOUT_MS);
      readMs = Math.round(performance.now() - readStartedAt);
      const parseStartedAt = performance.now();
      const config = JSON.parse(raw);
      parseMs = Math.round(performance.now() - parseStartedAt);
      if (!isReadableTeamConfigPayload(config)) {
        TeamConfigReader.invalidatePathForGeneration(configPath, cacheGeneration);
        return null;
      }
      const resolvedProjectPath = resolveProjectPathFromConfig(config);
      const resolvedConfig = resolvedProjectPath ? { ...config, projectPath: resolvedProjectPath } : config;
      const totalMs = performance.now() - startedAt;
      if (totalMs >= GET_CONFIG_SLOW_READ_WARN_MS) {
        logger$5.warn(`[getConfig] slow read diag=${JSON.stringify(buildTiming())}`);
      }
      if (updateCache) {
        TeamConfigReader.storeConfigCache(
          configPath,
          resolvedConfig,
          fingerprint,
          true,
          cacheGeneration
        );
      }
      return resolvedConfig;
    } catch (error) {
      TeamConfigReader.invalidatePathForGeneration(configPath, cacheGeneration);
      if (error instanceof FileReadTimeoutError) {
        logger$5.warn(`[getConfig] ${error.message} diag=${JSON.stringify(buildTiming())}`);
      } else if (error instanceof Error && error.message === "Team config read timeout") {
        logger$5.warn(
          `[getConfig] Timed out after ${PER_TEAM_READ_TIMEOUT_MS}ms reading ${configPath} diag=${JSON.stringify(buildTiming())}`
        );
      }
      throw error;
    }
  }
  async updateConfig(teamName2, updates) {
    const config = await this.getConfig(teamName2);
    if (!config) {
      return null;
    }
    if (updates.name !== void 0 && updates.name.trim() !== "") {
      config.name = updates.name.trim();
    }
    if (updates.description !== void 0) {
      config.description = updates.description.trim() || void 0;
    }
    if (updates.color !== void 0) {
      config.color = updates.color.trim() || void 0;
    }
    if (updates.language !== void 0) {
      config.language = updates.language.trim() || void 0;
    }
    const configPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "config.json");
    await taskHistory.atomicWriteAsync(configPath, JSON.stringify(config, null, 2));
    await TeamConfigReader.primeConfig(teamName2, config);
    return config;
  }
}
const teamTaskStateCache = /* @__PURE__ */ new WeakMap();
function getCachedTeamTaskState(task) {
  const cached = teamTaskStateCache.get(task);
  if (cached && cached.status === task.status && cached.reviewState === task.reviewState && cached.kanbanColumn === task.kanbanColumn && cached.deletedAt === task.deletedAt) {
    return cached;
  }
  const deleted = task.status === "deleted" || Boolean(task.deletedAt);
  const workflowColumn = resolveTeamTaskWorkflowColumn(task, deleted);
  const approved = !deleted && task.status !== "pending" && (task.kanbanColumn === "approved" || task.kanbanColumn !== "review" && task.reviewState === "approved");
  const needsFixActionable = task.reviewState === "needsFix" && !deleted && workflowColumn === void 0;
  const finishedForDependency = workflowColumn === "approved" ? true : workflowColumn === "review" || needsFixActionable ? false : task.status === "completed";
  const terminalForActionableWork = deleted || workflowColumn === "approved" || workflowColumn !== "review" && !needsFixActionable && task.status === "completed";
  const next = {
    status: task.status,
    reviewState: task.reviewState,
    kanbanColumn: task.kanbanColumn,
    deletedAt: task.deletedAt,
    deleted,
    approved,
    workflowColumn,
    needsFixActionable,
    finishedForDependency,
    terminalForActionableWork
  };
  teamTaskStateCache.set(task, next);
  return next;
}
function resolveTeamTaskWorkflowColumn(task, deleted) {
  if (deleted || task.status === "pending") {
    return void 0;
  }
  if (task.kanbanColumn === "approved") {
    return "approved";
  }
  if (task.kanbanColumn === "review") {
    return "review";
  }
  if (task.reviewState === "approved") {
    return "approved";
  }
  if (task.reviewState === "review") {
    return "review";
  }
  return void 0;
}
function isTeamTaskDeleted(task) {
  return getCachedTeamTaskState(task).deleted;
}
function isTeamTaskActivelyWorked(task) {
  const cached = getCachedTeamTaskState(task);
  return task.status === "in_progress" && cached.workflowColumn !== "review" && !cached.approved && !cached.deleted;
}
function isTeamTaskNeedsFixActionable(task) {
  return getCachedTeamTaskState(task).needsFixActionable;
}
function isTeamTaskFinishedForDependency(task) {
  return getCachedTeamTaskState(task).finishedForDependency;
}
function normalizeTaskReference(value) {
  return typeof value === "string" ? value.trim().replace(/^#/, "") : "";
}
function findTaskStateByReference(taskStateById, taskId) {
  const normalized = normalizeTaskReference(taskId);
  if (!normalized) {
    return null;
  }
  const direct = taskStateById.get(taskId) ?? taskStateById.get(normalized) ?? taskStateById.get(`#${normalized}`);
  if (direct && (!direct.id || normalizeTaskReference(direct.id) === normalized)) {
    return direct;
  }
  let idMatched = null;
  for (const task of taskStateById.values()) {
    if (normalizeTaskReference(task.id) === normalized) {
      if (idMatched && idMatched !== task) {
        return null;
      }
      idMatched = task;
    }
  }
  if (idMatched) {
    return idMatched;
  }
  let displayMatched = null;
  for (const [key, task] of taskStateById) {
    if (normalizeTaskReference(key) === normalized || normalizeTaskReference(task.displayId) === normalized) {
      if (displayMatched && displayMatched !== task) {
        return null;
      }
      displayMatched = task;
    }
  }
  return displayMatched;
}
function isTeamTaskBlockedByUnfinishedDependency(task, taskStateById) {
  const blockedBy = task.blockedBy?.map((taskId) => taskId.trim()).filter((taskId) => taskId.length > 0) ?? [];
  if (blockedBy.length === 0) {
    return false;
  }
  return blockedBy.some((taskId) => {
    const blocker = findTaskStateByReference(taskStateById, taskId);
    return !blocker || !isTeamTaskFinishedForDependency(blocker) && !isTeamTaskDeleted(blocker);
  });
}
function isTeamTaskTerminalForActionableWork(task) {
  return getCachedTeamTaskState(task).terminalForActionableWork;
}
function getTeamTaskWorkflowColumn(task) {
  return getCachedTeamTaskState(task).workflowColumn;
}
const NATIVE_IMAGE_MIME_TYPES = [
  "image/png",
  "image/jpeg",
  "image/webp"
];
const NATIVE_VIDEO_MIME_TYPES = [
  "video/mp4",
  "video/webm",
  "video/quicktime"
];
const CLAUDE_IMAGE_MIME_TYPES = [
  ...NATIVE_IMAGE_MIME_TYPES,
  "image/gif"
];
function isAgentVideoMimeType$1(mimeType) {
  return NATIVE_VIDEO_MIME_TYPES.includes(mimeType);
}
function isNativeImageMimeType(mimeType) {
  return NATIVE_IMAGE_MIME_TYPES.includes(mimeType);
}
const MAX_AGENT_ATTACHMENT_DELIVERY_BYTES_TOTAL = 8 * 1024 * 1024;
const MAX_AGENT_VIDEO_ATTACHMENT_BYTES = 8 * 1024 * 1024;
const MAX_AGENT_ATTACHMENT_SERIALIZED_PAYLOAD_BYTES = 75e5;
const isAgentVideoMimeType = (mime) => ["video/mp4", "video/webm", "video/quicktime"].includes(mime);
const SAFE_ATTACHMENT_STORAGE_ID_RE = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,120}$/;
function isSafeAttachmentStorageId(value) {
  return SAFE_ATTACHMENT_STORAGE_ID_RE.test(value);
}
function assertSafeAttachmentStorageId(label, value) {
  if (!isSafeAttachmentStorageId(value))
    throw new Error(`Invalid ${label}`);
}
const MAX_ATTACHMENT_SIZE = 10 * 1024 * 1024;
const MAX_TOTAL_ATTACHMENT_SIZE = 20 * 1024 * 1024;
const MAX_TASK_ATTACHMENT_SIZE = MAX_TOTAL_ATTACHMENT_SIZE;
const ATTACHMENT_CHUNK_BYTES = 384 * 1024;
const ATTACHMENT_MAX_BYTES = MAX_TOTAL_ATTACHMENT_SIZE;
const MAX_VIDEO_ATTACHMENTS = 1;
const MAX_AGENT_IPC_ATTACHMENTS = 5;
const MAX_TASK_ATTACHMENT_BYTES_TOTAL = MAX_TASK_ATTACHMENT_SIZE * MAX_AGENT_IPC_ATTACHMENTS;
function validateAgentAttachmentIpcPayload(attachments, purpose = "message") {
  if (!Array.isArray(attachments)) {
    return { valid: false, error: "attachments must be an array" };
  }
  if (attachments.length > MAX_AGENT_IPC_ATTACHMENTS) {
    return { valid: false, error: `Maximum ${MAX_AGENT_IPC_ATTACHMENTS} attachments allowed` };
  }
  let totalSize = 0;
  let videoCount = 0;
  const ids = /* @__PURE__ */ new Set();
  const result = [];
  for (const attachment of attachments) {
    if (!attachment || typeof attachment !== "object") {
      return { valid: false, error: "Invalid attachment entry" };
    }
    const candidate = attachment;
    if (typeof candidate.id !== "string" || !isSafeAttachmentStorageId(candidate.id) || typeof candidate.filename !== "string" || !candidate.filename.trim() || candidate.filename.length > 4096 || /[\0\r\n]/.test(candidate.filename)) {
      return { valid: false, error: "Attachment must have id and filename" };
    }
    if (ids.has(candidate.id)) {
      return { valid: false, error: "Invalid or duplicate attachment ID" };
    }
    ids.add(candidate.id);
    if (typeof candidate.data !== "string" || typeof candidate.mimeType !== "string") {
      return { valid: false, error: "Attachment must have data and mimeType" };
    }
    if (typeof candidate.size !== "number" || !Number.isSafeInteger(candidate.size) || candidate.size <= 0) {
      return { valid: false, error: "Attachment must have a positive size" };
    }
    if (!candidate.mimeType || candidate.mimeType.length > 255 || /[\x00-\x1f\x7f-\x9f]/.test(candidate.mimeType)) {
      return { valid: false, error: `Unsupported attachment type: ${candidate.mimeType}` };
    }
    const isVideo = purpose === "message" && isAgentVideoMimeType(candidate.mimeType);
    const perAttachmentLimit = purpose === "task" ? MAX_TASK_ATTACHMENT_SIZE : isVideo ? MAX_AGENT_VIDEO_ATTACHMENT_BYTES : MAX_ATTACHMENT_SIZE;
    if (candidate.size > perAttachmentLimit) {
      return {
        valid: false,
        error: `Attachment "${candidate.filename}" exceeds ${purpose === "task" ? "20MB" : isVideo ? "8MB" : "10MB"} limit`
      };
    }
    if (candidate.data.length > Math.ceil(perAttachmentLimit / 3) * 4) {
      return { valid: false, error: "Attachment encoded data exceeds size limit" };
    }
    let binary;
    try {
      binary = atob(candidate.data);
      if (btoa(binary) !== candidate.data || binary.length !== candidate.size) {
        return { valid: false, error: "Attachment data must be canonical base64 with exact size" };
      }
    } catch {
      return { valid: false, error: "Attachment data must be canonical base64 with exact size" };
    }
    if (isVideo && ++videoCount > MAX_VIDEO_ATTACHMENTS) {
      return { valid: false, error: `Maximum ${MAX_VIDEO_ATTACHMENTS} video attachment allowed` };
    }
    totalSize += binary.length;
    result.push({
      id: candidate.id,
      filename: candidate.filename,
      data: candidate.data,
      mimeType: candidate.mimeType,
      size: candidate.size
    });
  }
  if (videoCount > 0 && totalSize > MAX_AGENT_ATTACHMENT_DELIVERY_BYTES_TOTAL) {
    return { valid: false, error: "Video and other attachments exceed the 8MB total size limit" };
  }
  const totalLimit = purpose === "task" ? MAX_TASK_ATTACHMENT_BYTES_TOTAL : MAX_TOTAL_ATTACHMENT_SIZE;
  if (totalSize > totalLimit) {
    return {
      valid: false,
      error: `Total attachment size exceeds ${purpose === "task" ? "100MB" : "20MB"} limit`
    };
  }
  return { valid: true, value: result };
}
const segment$4 = taskHistory.string().regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/);
const hash$6 = taskHistory.string().regex(/^[a-f0-9]{64}$/);
const taskAttachmentReadSchema = taskHistory.object({
  taskId: segment$4,
  attachmentId: segment$4,
  offset: taskHistory.number().int().min(0).max(ATTACHMENT_MAX_BYTES),
  expectedSha256: hash$6.optional()
}).strict().superRefine((input, context) => {
  if (input.offset > 0 && !input.expectedSha256)
    context.addIssue({ code: "custom", message: "Original attachment digest required" });
});
const attachmentMetadataSchema = taskHistory.object({
  id: segment$4,
  filename: taskHistory.string().min(1).max(4096).refine((value) => !/[\0\r\n]/.test(value)),
  mimeType: taskHistory.string().min(1).max(255).refine((value) => !/[\0\r\n]/.test(value)),
  size: taskHistory.number().int().min(0).max(ATTACHMENT_MAX_BYTES),
  addedAt: taskHistory.string().min(1).max(128).optional()
}).strict();
const messageReferenceSchema = taskHistory.string().regex(/^(?:im1:[A-Za-z0-9][A-Za-z0-9_-]{0,127}:[a-f0-9]{64}|[A-Za-z0-9][A-Za-z0-9_-]{0,127})$/);
taskHistory.object({ reference: messageReferenceSchema }).strict();
taskHistory.object({
  reference: messageReferenceSchema,
  attachmentId: segment$4,
  offset: taskHistory.number().int().min(0).max(ATTACHMENT_MAX_BYTES),
  expectedSha256: hash$6.optional()
}).strict().superRefine((input, context) => {
  if (input.offset > 0 && !input.expectedSha256)
    context.addIssue({ code: "custom", message: "Original attachment digest required" });
});
const id$c = taskHistory.string().regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,120}$/);
const hash$5 = taskHistory.string().regex(/^[a-f0-9]{64}$/);
const attachmentReferenceSchema = taskHistory.object({
  artifactId: id$c,
  mimeType: taskHistory.string().min(1).max(256),
  byteLength: taskHistory.number().int().positive().max(MAX_TASK_ATTACHMENT_SIZE),
  digest: hash$5
}).strict();
const attachmentReferencesSchema = taskHistory.array(attachmentReferenceSchema).max(MAX_AGENT_IPC_ATTACHMENTS).superRefine((refs2, ctx) => {
  if (new Set(refs2.map((ref) => ref.artifactId)).size !== refs2.length || refs2.reduce((sum, ref) => sum + ref.byteLength, 0) > MAX_TASK_ATTACHMENT_BYTES_TOTAL)
    ctx.addIssue({ code: "custom", message: "Invalid attachment batch" });
});
const messageAttachmentReferencesSchema = attachmentReferencesSchema.refine((refs2) => refs2.reduce((sum, ref) => sum + ref.byteLength, 0) <= MAX_TOTAL_ATTACHMENT_SIZE, "Message attachment batch exceeds limit");
const attachmentUploadSchema = taskHistory.object({
  uploadId: id$c,
  purpose: taskHistory.discriminatedUnion("kind", [
    taskHistory.object({ kind: taskHistory.literal("task"), taskId: id$c }).strict(),
    taskHistory.object({ kind: taskHistory.literal("message"), member: id$c }).strict()
  ]),
  attachment: attachmentMetadataSchema.omit({ addedAt: true }).extend({ size: taskHistory.number().int().positive().max(MAX_TASK_ATTACHMENT_SIZE) }),
  digest: hash$5,
  offset: taskHistory.number().int().min(0).max(MAX_TASK_ATTACHMENT_SIZE),
  base64: taskHistory.string().min(4).max(Math.ceil(ATTACHMENT_CHUNK_BYTES / 3) * 4).regex(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/)
}).strict().superRefine((input, context) => {
  if (input.purpose.kind === "message" && input.attachment.size > MAX_ATTACHMENT_SIZE)
    context.addIssue({ code: "custom", message: "Message attachment exceeds limit" });
});
const id$b = taskHistory.string().min(1).max(256).refine((value) => !!value.trim() && !value.includes("\0"));
const segment$3 = taskHistory.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/);
const createTeamRegistryPayloadSchema = taskHistory.object({
  contextId: id$b,
  teamName: segment$3,
  savedSettings: taskHistory.savedTeamSettingsSchema,
  members: taskHistory.array(taskHistory.object({ name: segment$3, memberSettings: taskHistory.memberSettingsSchema }).strict()).max(255)
}).strict().superRefine((value, context) => {
  const names2 = [
    "team-lead",
    "user",
    ...value.members.map((member2) => member2.name.toLowerCase())
  ];
  if (new Set(names2).size !== names2.length)
    context.addIssue({ code: "custom", message: "Duplicate or reserved member name" });
  if (!path.isAbsolute(value.savedSettings.cwd) || path.resolve(value.savedSettings.cwd) !== value.savedSettings.cwd)
    context.addIssue({ code: "custom", message: "Expected a canonical absolute project path" });
  if (new TextEncoder().encode(JSON.stringify(value)).byteLength > 512 * 1024)
    context.addIssue({ code: "custom", message: "Creation intent too large" });
});
const teamRegistryScopeSchema = taskHistory.object({
  projectId: id$b,
  workspaceId: id$b,
  teamId: segment$3,
  runId: id$b,
  memberId: id$b,
  generation: id$b
}).strict();
const teamRegistryRecordSchema = taskHistory.object({
  contextId: id$b,
  teamId: segment$3,
  teamName: segment$3,
  displayName: taskHistory.string().max(256).optional(),
  description: taskHistory.string().max(64 * 1024).optional(),
  color: taskHistory.string().max(256).optional(),
  members: taskHistory.array(taskHistory.object({ memberId: segment$3, label: segment$3 }).strict()).max(256),
  binding: taskHistory.object({
    schemaVersion: taskHistory.literal(1),
    handleId: id$b,
    scope: teamRegistryScopeSchema
  }).strict()
}).strict();
const teamRegistryReceiptSchema = taskHistory.object({
  commandId: id$b,
  phase: taskHistory._enum(["pending", "published", "held"]),
  record: teamRegistryRecordSchema
}).strict();
const teamRegistryListSchema = taskHistory.object({
  teams: taskHistory.array(teamRegistryRecordSchema).max(256),
  held: taskHistory.array(teamRegistryReceiptSchema).max(256)
}).strict();
const importCategories = [
  "team",
  "tasks",
  "attachments",
  "task-attachments",
  "history",
  "evidence"
];
const id$a = taskHistory.string().min(1).max(256).refine((value) => !!value.trim() && !value.includes("\0"));
const segment$2 = taskHistory.string().regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/);
const hash$4 = taskHistory.string().regex(/^[a-f0-9]{64}$/);
const snapshotHeaderSchema = taskHistory.object({
  sourceOwnerId: id$a,
  sourceId: id$a,
  sourceTeamName: segment$2,
  sourceRevision: hash$4,
  /** Actual Desktop save-only metadata has no native CLI config. */
  sourceKind: taskHistory.literal("saved-draft").optional(),
  savedSettings: taskHistory.savedTeamSettingsSchema,
  members: taskHistory.array(taskHistory.object({
    memberId: segment$2,
    name: segment$2,
    role: taskHistory._enum(["lead", "member"]),
    settings: taskHistory.memberSettingsSchema
  }).strict()).min(1).max(256),
  /** Inactive product identities only; no source delivery binding or grant is imported. */
  removedMembers: taskHistory.array(taskHistory.object({
    memberId: segment$2,
    name: segment$2,
    role: taskHistory.literal("member"),
    settings: taskHistory.memberSettingsSchema,
    removedAt: taskHistory.string().datetime()
  }).strict()).max(1024).optional(),
  obligations: taskHistory.object({
    launch: taskHistory.literal("released"),
    bootstrap: taskHistory.literal("released"),
    lane: taskHistory.literal("released"),
    session: taskHistory.literal("released"),
    stop: taskHistory.literal("released"),
    command: taskHistory.literal("released"),
    delivery: taskHistory.literal("released"),
    custody: taskHistory.literal("released"),
    background: taskHistory.literal("released")
  }).strict(),
  gaps: taskHistory.array(taskHistory.object({
    category: taskHistory._enum(importCategories),
    resourceId: id$a,
    reason: taskHistory._enum(["already-missing", "metadata-only"])
  }).strict()).max(4096)
}).strict().superRefine((header, context) => {
  if (Buffer.byteLength(JSON.stringify(header)) > 512 * 1024)
    context.addIssue({ code: "custom", message: "Source header too large" });
  const roster = [...header.members, ...header.removedMembers ?? []];
  if (new Set(roster.map((member2) => member2.memberId)).size !== roster.length || new Set(roster.map((member2) => member2.name.toLowerCase())).size !== roster.length)
    context.addIssue({ code: "custom", message: "Source roster identity conflict" });
});
const importRequestSchema = taskHistory.object({
  contextId: id$a,
  sourceId: id$a,
  snapshotDigest: hash$4,
  teamName: segment$2
}).strict();
const stoppedImportReceiptSchema = taskHistory.object({
  commandId: id$a,
  phase: taskHistory._enum(["held", "published"]),
  record: teamRegistryRecordSchema,
  source: taskHistory.object({ sourceId: id$a, snapshotDigest: hash$4 }).strict()
}).strict();
const alphabet = ["​", "‌", "‍", "⁠"];
function collectImportReferences(value, sourceTeam, tasks) {
  const found = /* @__PURE__ */ new Map();
  const add = (taskId, displayId, teamName2) => {
    if (typeof taskId !== "string" || !taskId || taskId.length > 256 || typeof displayId !== "string" || !displayId || displayId.length > 256 || typeof teamName2 !== "string" || !teamName2 || teamName2.length > 256)
      throw new TeamOwnerError("hold");
    const reference = {
      taskId,
      displayId,
      teamName: teamName2,
      target: teamName2 === sourceTeam && tasks.has(taskId) ? "internal" : teamName2 === sourceTeam ? "unresolved" : "source-archive"
    };
    found.set(JSON.stringify([taskId, displayId, teamName2]), reference);
    if (found.size > 16384)
      throw new TeamOwnerError("hold");
  };
  const string = (text2) => {
    let cursor = 0;
    while (true) {
      const start = text2.indexOf("⁣", cursor);
      if (start === -1)
        break;
      const end = text2.indexOf("⁤", start + 1);
      if (end === -1)
        throw new TeamOwnerError("hold");
      const encoded = text2.slice(start + 1, end);
      if (encoded.length % 4 || encoded.length > 16384)
        throw new TeamOwnerError("hold");
      const bytes = new Uint8Array(encoded.length / 4);
      for (let offset = 0; offset < encoded.length; offset += 4) {
        const parts = [...encoded.slice(offset, offset + 4)].map((char) => alphabet.indexOf(char));
        if (parts.some((part) => part < 0))
          throw new TeamOwnerError("hold");
        bytes[offset / 4] = parts[0] << 6 | parts[1] << 4 | parts[2] << 2 | parts[3];
      }
      let ref;
      try {
        ref = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
      } catch {
        throw new TeamOwnerError("hold");
      }
      add(ref.taskId, ref.displayId, ref.teamName);
      cursor = end + 1;
    }
    for (const match of text2.matchAll(/task:\/\/([^\s)\]<>"']+)/gu)) {
      const raw = match[1], [path2, query] = raw.split("?", 2), params = new URLSearchParams(query);
      let taskId;
      try {
        taskId = decodeURIComponent(path2);
      } catch {
        throw new TeamOwnerError("hold");
      }
      const teamName2 = params.get("team") ?? sourceTeam;
      add(taskId, params.get("display") ?? taskId, teamName2);
    }
  };
  const visit = (item, depth = 0) => {
    if (depth > 64)
      throw new TeamOwnerError("hold");
    if (typeof item === "string")
      string(item);
    else if (Array.isArray(item))
      item.forEach((child) => visit(child, depth + 1));
    else if (item && typeof item === "object") {
      const row2 = item;
      if ("taskId" in row2 && "teamName" in row2 && "displayId" in row2)
        add(row2.taskId, row2.displayId, row2.teamName);
      Object.values(row2).forEach((child) => visit(child, depth + 1));
    }
  };
  visit(value);
  return [...found.values()].sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
}
const STOPPED_IMPORT_LIMITS = {
  files: 4096,
  fileBytes: 20 * 1024 * 1024,
  totalBytes: 64 * 1024 * 1024
};
const sha = (bytes) => crypto$1.createHash("sha256").update(bytes).digest("hex");
const hold = () => {
  throw new TeamOwnerError("hold");
};
function safeImportPath(value) {
  if (!value || value.length > 8192 || value.includes("\\") || value.includes("\0") || path.isAbsolute(value) || value.split("/").some((part) => !part || part === "." || part === ".."))
    return hold();
  return value;
}
function plainImportAncestors(path$12) {
  if (!path.isAbsolute(path$12) || path.resolve(path$12) !== path$12)
    hold();
  let part = path.parse(path$12).root;
  for (const name2 of path$12.slice(part.length).split("/").filter(Boolean)) {
    part = path.join(part, name2);
    const stat = fs$1.lstatSync(part);
    if (!stat.isDirectory() || stat.isSymbolicLink())
      hold();
  }
}
function boundedFd(fd, size) {
  const buffer = Buffer.alloc(size + 1);
  let length = 0;
  while (length < buffer.length) {
    const count = fs$1.readSync(fd, buffer, length, buffer.length - length, null);
    if (!count)
      break;
    length += count;
  }
  if (length !== size)
    return hold();
  return buffer.subarray(0, length);
}
function readImportBytes(path$12, limit) {
  plainImportAncestors(path.dirname(path$12));
  const before = fs$1.lstatSync(path$12);
  if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1 || before.size > limit)
    return hold();
  const fd = fs$1.openSync(path$12, fs$1.constants.O_RDONLY | (fs$1.constants.O_NOFOLLOW ?? 0));
  try {
    const opened = fs$1.fstatSync(fd);
    if (opened.dev !== before.dev || opened.ino !== before.ino || opened.size !== before.size)
      return hold();
    const bytes = boundedFd(fd, opened.size), after = fs$1.fstatSync(fd);
    if (bytes.length !== opened.size || after.size !== opened.size || after.mtimeMs !== opened.mtimeMs || after.ctimeMs !== opened.ctimeMs)
      return hold();
    return bytes;
  } finally {
    fs$1.closeSync(fd);
  }
}
function disposition(category, path2) {
  const name2 = path2.split("/").at(-1);
  if (/(^|\/)(auth\.json|credentials?[^/]*|\.env[^/]*|checkpoints?[^/]*|runtime-checkpoints)(\/|$)/i.test(path2))
    return "excluded";
  if (category === "history" || category === "evidence")
    return "archive";
  if (category === "attachments" || category === "task-attachments")
    return "product";
  if (category === "tasks") {
    if (path2.startsWith("_internal/"))
      return "archive";
    if (!path2.includes("/") && name2.endsWith(".json"))
      return "product";
    return hold();
  }
  if (path2.startsWith(".host-owner/"))
    return hold();
  if (/^(launch-|bootstrap-|stop-|runtime-|opencode-|\.opencode-runtime\/|\.member-work-sync\/)/.test(path2) || /\.(sh|exe|bin|lock)$/.test(name2))
    return "excluded";
  if ([
    "config.json",
    "team.meta.json",
    "members.meta.json",
    "kanban-state.json",
    "sentMessages.json",
    "sent-cross-team.json",
    "group-chats.json",
    "group-chat-reactions.json"
  ].includes(path2))
    return path2 === "kanban-state.json" ? "product" : "archive";
  if (/^inboxes\/[^/]+\.json$/.test(path2))
    return "archive";
  if (/^(review-decisions|members|archive)\//.test(path2) || path2 === "comment-notification-journal.json")
    return "archive";
  return hold();
}
function json(file) {
  if (file.base64 === void 0 || !/\.jsonl?$/.test(file.path))
    return [];
  try {
    const text2 = new TextDecoder("utf-8", { fatal: true }).decode(Buffer.from(file.base64, "base64"));
    return file.path.endsWith(".jsonl") ? text2.split("\n").filter((line) => line.trim()).map((line) => JSON.parse(line)) : [JSON.parse(text2)];
  } catch {
    return hold();
  }
}
function captureFiles(source) {
  let total = 0, entries = 0;
  const files = [], identities = [], roots = [];
  for (const root of source.roots) {
    let stat;
    try {
      plainImportAncestors(root.path);
      stat = fs$1.lstatSync(root.path);
    } catch (error) {
      if (error.code !== "ENOENT")
        throw error;
      roots.push({
        category: root.category,
        exists: false,
        identity: digest({ absent: root.path })
      });
      continue;
    }
    roots.push({
      category: root.category,
      exists: true,
      identity: digest({ dev: stat.dev, ino: stat.ino })
    });
    const visit = (directory) => {
      if (++entries > STOPPED_IMPORT_LIMITS.files * 2)
        hold();
      const before = fs$1.lstatSync(directory);
      if (!before.isDirectory() || before.isSymbolicLink())
        hold();
      const names2 = fs$1.readdirSync(directory).sort();
      identities.push([
        root.category,
        path.relative(root.path, directory),
        before.dev,
        before.ino,
        before.mtimeMs,
        names2
      ]);
      for (const name2 of names2) {
        if (++entries > STOPPED_IMPORT_LIMITS.files * 2)
          hold();
        const path$12 = path.join(directory, name2), info = fs$1.lstatSync(path$12);
        if (info.isSymbolicLink())
          hold();
        if (info.isDirectory()) {
          visit(path$12);
          continue;
        }
        if (!info.isFile() || info.nlink !== 1 || info.size > STOPPED_IMPORT_LIMITS.fileBytes || files.length >= STOPPED_IMPORT_LIMITS.files)
          hold();
        const relativePath = safeImportPath(path.relative(root.path, path$12)), selected = disposition(root.category, relativePath);
        const fd = fs$1.openSync(path$12, fs$1.constants.O_RDONLY | (fs$1.constants.O_NOFOLLOW ?? 0));
        try {
          const opened = fs$1.fstatSync(fd);
          if (opened.dev !== info.dev || opened.ino !== info.ino || opened.size !== info.size)
            hold();
          const bytes = boundedFd(fd, opened.size), after2 = fs$1.fstatSync(fd);
          if (after2.size !== opened.size || after2.mtimeMs !== opened.mtimeMs || after2.ctimeMs !== opened.ctimeMs || bytes.byteLength !== opened.size)
            hold();
          total += bytes.length;
          if (total > STOPPED_IMPORT_LIMITS.totalBytes)
            hold();
          identities.push([
            root.category,
            relativePath,
            opened.dev,
            opened.ino,
            after2.ctimeMs,
            sha(bytes)
          ]);
          files.push({
            category: root.category,
            path: relativePath,
            sha256: sha(bytes),
            size: bytes.length,
            disposition: selected,
            ...selected === "excluded" ? {} : { base64: bytes.toString("base64") }
          });
        } finally {
          fs$1.closeSync(fd);
        }
      }
      const after = fs$1.lstatSync(directory);
      if (after.dev !== before.dev || after.ino !== before.ino || after.mtimeMs !== before.mtimeMs)
        hold();
    };
    visit(root.path);
  }
  return { roots, files, identities };
}
function validateProduct(snapshot, source) {
  const tasks = /* @__PURE__ */ new Set(), bodies = [], taskBodies = [];
  for (const file of snapshot.files) {
    const parsed = json(file);
    bodies.push(...parsed);
    if (file.category === "tasks" && file.disposition === "product") {
      const task = parsed[0];
      if (parsed.length !== 1 || !task || typeof task !== "object" || Array.isArray(task) || typeof task.id !== "string" || !task.id || file.path !== `${task.id}.json` || tasks.has(task.id))
        hold();
      if (typeof task.status !== "string" || !["pending", "in_progress", "completed", "deleted"].includes(task.status.trim()) || typeof task.subject !== "string")
        hold();
      if (task.comments !== void 0 && (!Array.isArray(task.comments) || task.comments.some((item) => !item || typeof item !== "object" || typeof item.id !== "string" || typeof item.text !== "string")))
        hold();
      tasks.add(task.id);
      taskBodies.push(task);
    }
  }
  for (const task of taskBodies)
    for (const key of ["blockedBy", "blocks", "related"]) {
      const values = task[key];
      if (values !== void 0 && (!Array.isArray(values) || values.some((id2) => typeof id2 !== "string" || !tasks.has(id2))))
        hold();
    }
  const blobs = /* @__PURE__ */ new Map();
  const attachments = snapshot.files.filter((file) => file.disposition !== "excluded" && (file.category === "attachments" || file.category === "task-attachments"));
  const visit = (value, depth = 0) => {
    if (depth > 64)
      hold();
    if (Array.isArray(value)) {
      value.forEach((item) => visit(item, depth + 1));
      return;
    }
    if (!value || typeof value !== "object")
      return;
    const row2 = value;
    if (typeof row2.id === "string" && typeof row2.filename === "string" && typeof row2.mimeType === "string") {
      if (typeof row2.filePath === "string") {
        if (!path.isAbsolute(row2.filePath) || path.resolve(row2.filePath) !== row2.filePath)
          hold();
        const selected = source.roots.filter((root) => root.category === "attachments" || root.category === "task-attachments").flatMap((root) => {
          const path$12 = path.relative(root.path, row2.filePath);
          return attachments.filter((file2) => file2.category === root.category && file2.path === path$12);
        });
        if (selected.length !== 1)
          hold();
        const file = selected[0];
        blobs.set(row2.filePath, {
          originalPath: row2.filePath,
          category: file.category,
          path: file.path
        });
      } else if (typeof row2.data !== "string" && typeof row2.base64Data !== "string" && !attachments.some((file) => file.path.split("/").at(-1)?.startsWith(`${row2.id}--`)) && !snapshot.header.gaps.some((gap) => gap.resourceId === `attachment:${row2.id}` && gap.reason === "metadata-only"))
        hold();
    }
    Object.values(row2).forEach((child) => visit(child, depth + 1));
  };
  bodies.forEach((body) => visit(body));
  return {
    references: collectImportReferences(bodies, snapshot.header.sourceTeamName, tasks),
    blobs: [...blobs.values()]
  };
}
function hasSourceConfiguration(header, files) {
  const has = (name2) => files.some((file) => file.category === "team" && file.path === name2);
  return header.sourceKind === "saved-draft" ? !has("config.json") && has("team.meta.json") && has("members.meta.json") : has("config.json");
}
async function exportStoppedTeam(source) {
  try {
    return await source.fenced(async () => {
      if (source.roots.length !== importCategories.length || importCategories.some((category) => source.roots.filter((root) => root.category === category).length !== 1))
        hold();
      const header = snapshotHeaderSchema.parse(await source.describe());
      if (header.members.filter((row2) => row2.role === "lead").length !== 1 || new Set(header.members.map((row2) => row2.memberId)).size !== header.members.length || new Set(header.members.map((row2) => row2.name.toLowerCase())).size !== header.members.length || header.members.some((row2) => row2.name.toLowerCase() === "user"))
        hold();
      const first = captureFiles(source);
      if (!hasSourceConfiguration(header, first.files) || !first.roots.find((root) => root.category === "tasks")?.exists)
        hold();
      for (const root of first.roots)
        if (!root.exists && !header.gaps.some((gap) => gap.category === root.category && gap.resourceId === "root" && gap.reason === "already-missing"))
          hold();
      const body = {
        schemaVersion: 1,
        header,
        roots: first.roots,
        files: first.files
      };
      const product = validateProduct(body, source);
      const after = snapshotHeaderSchema.parse(await source.describe()), second = captureFiles(source);
      if (digest(header) !== digest(after) || digest(first) !== digest(second))
        hold();
      const complete = { ...body, ...product };
      return { ...complete, digest: digest(complete) };
    });
  } catch (error) {
    if (error instanceof TeamOwnerError)
      throw error;
    return hold();
  }
}
function validateDetachedSnapshot(raw) {
  const { digest: expected, ...body } = raw;
  if (raw.schemaVersion !== 1 || digest(body) !== expected || raw.files.length > STOPPED_IMPORT_LIMITS.files)
    hold();
  if (digest(snapshotHeaderSchema.parse(raw.header)) !== digest(raw.header))
    hold();
  if (raw.header.members.filter((row2) => row2.role === "lead").length !== 1 || new Set(raw.header.members.map((row2) => row2.memberId)).size !== raw.header.members.length || new Set(raw.header.members.map((row2) => row2.name.toLowerCase())).size !== raw.header.members.length || raw.header.members.some((row2) => row2.name.toLowerCase() === "user"))
    hold();
  if (raw.roots.length !== importCategories.length || importCategories.some((category) => raw.roots.filter((root) => root.category === category).length !== 1) || raw.roots.some((root) => typeof root.exists !== "boolean" || !/^[a-f0-9]{64}$/.test(root.identity)))
    hold();
  if (!raw.roots.find((root) => root.category === "team")?.exists || !raw.roots.find((root) => root.category === "tasks")?.exists || !hasSourceConfiguration(raw.header, raw.files))
    hold();
  for (const root of raw.roots)
    if (!root.exists && !raw.header.gaps.some((gap) => gap.category === root.category && gap.resourceId === "root" && gap.reason === "already-missing"))
      hold();
  let total = 0;
  const seen = /* @__PURE__ */ new Set();
  for (const file of raw.files) {
    safeImportPath(file.path);
    const key = `${file.category}/${file.path}`;
    if (!importCategories.includes(file.category) || !raw.roots.find((root) => root.category === file.category)?.exists || !/^[a-f0-9]{64}$/.test(file.sha256) || seen.has(key) || file.disposition !== disposition(file.category, file.path) || !Number.isSafeInteger(file.size) || file.size < 0 || file.size > STOPPED_IMPORT_LIMITS.fileBytes)
      hold();
    seen.add(key);
    total += file.size;
    if (total > STOPPED_IMPORT_LIMITS.totalBytes)
      hold();
    if (file.disposition === "excluded") {
      if (file.base64 !== void 0)
        hold();
    } else if (typeof file.base64 !== "string" || file.base64.length !== Math.ceil(file.size / 3) * 4 || Buffer.from(file.base64, "base64").toString("base64") !== file.base64 || Buffer.from(file.base64, "base64").length !== file.size || sha(Buffer.from(file.base64, "base64")) !== file.sha256)
      hold();
    json(file);
  }
  const roots = importCategories.map((category) => {
    const mappings = raw.blobs.filter((blob) => blob.category === category);
    const inferred = mappings.map((blob) => {
      safeImportPath(blob.path);
      if (!path.isAbsolute(blob.originalPath) || path.resolve(blob.originalPath) !== blob.originalPath || !blob.originalPath.endsWith(`/${blob.path}`))
        return hold();
      return blob.originalPath.slice(0, -blob.path.length - 1);
    });
    if (new Set(inferred).size > 1)
      hold();
    return { category, path: inferred[0] ?? `/__host_import_without_source_reads__/${category}` };
  });
  const product = validateProduct(raw, { roots });
  if (digest(product.references) !== digest(raw.references) || digest(product.blobs) !== digest(raw.blobs))
    hold();
  return structuredClone(raw);
}
function validateStoppedSnapshot(raw) {
  try {
    return validateDetachedSnapshot(raw);
  } catch {
    return hold();
  }
}
const id$9 = taskHistory.string().min(1).max(200).refine((value) => !/[\0\r\n]/.test(value));
const uuid = taskHistory.string().uuid();
const name = taskHistory.string().min(1).max(200).refine((value) => value === value.trim() && !value.includes("\0"));
const names = taskHistory.array(name).max(200).refine((value) => new Set(value).size === value.length);
const refs = taskHistory.array(taskHistory.strictObject({ teamName: name, taskId: id$9, displayId: id$9 })).max(100);
const groupMutationSchema = taskHistory.discriminatedUnion("operation", [
  taskHistory.strictObject({
    operation: taskHistory.literal("create"),
    id: uuid,
    name: taskHistory.string().trim().min(1).max(100).refine((value) => !value.includes("\0")),
    selectedMemberNames: names,
    excludedMemberNames: names,
    autoIncludeNewMembers: taskHistory.boolean()
  }),
  taskHistory.strictObject({
    operation: taskHistory.literal("create.agent"),
    sourceMessageId: id$9,
    name: taskHistory.string().trim().min(1).max(100).refine((value) => !value.includes("\0")),
    selectedMemberNames: names,
    autoIncludeNewMembers: taskHistory.boolean().optional()
  }),
  taskHistory.strictObject({ operation: taskHistory.literal("archive"), groupChatId: uuid, archived: taskHistory.boolean() }),
  taskHistory.strictObject({
    operation: taskHistory.literal("send"),
    groupChatId: uuid,
    messageId: uuid,
    recipientName: name.optional(),
    text: taskHistory.string().min(1).max(1e5).refine((value) => !!value.trim() && !value.includes("\0")),
    summary: taskHistory.string().max(1e3).refine((value) => !value.includes("\0")).optional(),
    taskRefs: refs.optional(),
    relayOfMessageId: id$9.optional()
  }),
  taskHistory.strictObject({
    operation: taskHistory.literal("reaction.set"),
    groupChatId: uuid,
    messageId: uuid,
    active: taskHistory.boolean()
  }),
  taskHistory.strictObject({ operation: taskHistory.literal("reaction.ack"), groupChatId: uuid, relayOfMessageId: id$9 })
]);
const groupReactionTargetSchema = taskHistory.strictObject({ groupChatId: uuid, messageId: uuid });
function parseGroupPayload(operation, raw) {
  if (operation === "group.list" || operation === "group.lookup")
    return taskHistory.strictObject({}).parse(raw);
  if (operation === "group.reaction.read")
    return groupReactionTargetSchema.parse(raw);
  const selected = operation.slice("group.".length);
  const rawPayload = taskHistory.record(taskHistory.string(), taskHistory.unknown()).parse(raw);
  if (Object.hasOwn(rawPayload, "operation"))
    throw new Error("Unexpected group operation field");
  const request = groupMutationSchema.parse({
    ...rawPayload,
    operation: selected
  });
  if (request.operation === "create.agent" || request.operation === "reaction.ack")
    throw new Error("Native-only group operation");
  const { operation: _operation, ...payload } = request;
  return Object.fromEntries(Object.entries(payload).filter(([, value]) => value !== void 0));
}
const id$8 = taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0"));
const retainedDeliveryIntentSchema = taskHistory.object({
  schemaVersion: taskHistory.literal(1),
  binding: taskHistory.object({ backendId: id$8, teamId: id$8, teamName: id$8, runId: id$8, memberId: id$8, generation: id$8 }).strict(),
  commandId: id$8,
  principalId: id$8,
  authorityRevision: taskHistory.number().int().min(1),
  messageId: id$8,
  deliveryId: id$8,
  inputId: id$8,
  content: taskHistory.string().max(1024 * 1024),
  attachments: messageAttachmentReferencesSchema.optional(),
  phase: taskHistory._enum(["pending", "admitted", "not_admitted"]),
  runtimeReceipt: taskHistory.unknown().optional()
}).strict();
const retainedDeliveryCancellationSchema = taskHistory.object({
  intent: retainedDeliveryIntentSchema,
  proof: taskHistory.object({ inputId: id$8, outcome: taskHistory._enum(["admitted", "not_admitted", "unknown"]), receipt: taskHistory.unknown().optional() }).strict().optional(),
  fingerprint: taskHistory.string().optional()
}).strict();
const id$7 = taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0"));
const hash$3 = taskHistory.string().regex(/^[a-f0-9]{64}$/);
taskHistory.object({ commandId: id$7, member: id$7, messageIds: taskHistory.array(id$7).max(4096) }).strict();
taskHistory.object({
  schemaVersion: taskHistory.literal(1),
  family: taskHistory.literal("queued-discard"),
  binding: taskHistory.object({ backendId: id$7, teamId: id$7, teamName: id$7 }).strict(),
  commandId: id$7,
  principalId: id$7,
  fingerprint: hash$3,
  member: id$7,
  messageIds: taskHistory.array(id$7).max(4096),
  captureDigest: hash$3,
  phase: taskHistory._enum(["prepared", "completed"]),
  targets: taskHistory.array(retainedDeliveryCancellationSchema).max(4096),
  rows: taskHistory.array(taskHistory.object({ messageId: id$7, digest: hash$3 }).strict()).max(4096),
  discardedMessageIds: taskHistory.array(id$7).max(4096).optional(),
  remainingQueued: taskHistory.number().int().min(0).optional()
}).strict();
const id$6 = taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0"));
const hash$2 = taskHistory.string().regex(/^[a-f0-9]{64}$/);
const binding$1 = taskHistory.object({ backendId: id$6, teamId: id$6, teamName: id$6 }).strict();
const runtime = taskHistory.object({ backendId: id$6, teamId: id$6, runId: id$6, memberId: id$6, generation: id$6 }).strict();
const state = taskHistory.object({ deletedAt: id$6.optional(), cleanupCommandId: id$6, cleanupPending: taskHistory.boolean() }).strict();
taskHistory.object({ commandId: id$6, operation: taskHistory._enum(["trash", "restore"]), expectedRevision: hash$2 }).strict();
taskHistory.object({
  schemaVersion: taskHistory.literal(1),
  family: taskHistory.literal("lifecycle"),
  binding: binding$1,
  commandId: id$6,
  principalId: id$6,
  fingerprint: hash$2,
  captureDigest: hash$2,
  authorityRevision: taskHistory.number().int().min(1),
  operation: taskHistory._enum(["trash", "restore"]),
  createdAt: id$6,
  phase: taskHistory._enum(["prepared", "completed", "held"]),
  before: state.nullable(),
  after: state,
  targets: taskHistory.array(retainedDeliveryCancellationSchema).max(4096),
  runtimeBindings: taskHistory.array(runtime).max(4096)
}).strict();
const identifier = taskHistory.string().min(1).max(256).regex(/^\S(?:[\s\S]*\S)?$/);
const teamName = taskHistory.string().regex(/^[a-z0-9][a-z0-9-]{0,127}$/);
const memberName = taskHistory.string().min(1).max(128);
const side = taskHistory.strictObject({
  resourceRef: identifier,
  teamResourceRef: identifier,
  handleId: identifier.optional(),
  scope: taskHistory.strictObject({
    projectId: identifier,
    workspaceId: identifier,
    teamId: identifier,
    runId: identifier,
    memberId: identifier.nullable(),
    generation: taskHistory.union([identifier, taskHistory.number().int()]).nullable()
  }),
  teamId: identifier,
  teamName,
  principalId: identifier,
  grantRevision: taskHistory.number().int().positive(),
  actor: memberName,
  runId: identifier.optional(),
  sender: taskHistory.strictObject({ memberId: identifier, runId: identifier, generation: identifier }).optional()
});
taskHistory.strictObject({
  commandId: identifier,
  pair: taskHistory.strictObject({
    ownerId: identifier,
    ownerRevision: identifier,
    ownerFingerprint: taskHistory.string().regex(/^[a-f0-9]{64}$/),
    contextId: identifier.optional(),
    source: side,
    target: side.extend({
      recipient: taskHistory.strictObject({
        memberId: identifier,
        name: memberName,
        runId: identifier,
        generation: identifier
      })
    })
  }),
  request: taskHistory.strictObject({
    fromMember: memberName,
    toMember: memberName.optional(),
    text: taskHistory.string().min(1).max(48e3),
    messageId: identifier,
    conversationId: identifier,
    replyToConversationId: identifier.optional(),
    timestamp: identifier.optional(),
    summary: taskHistory.string().max(4e3).optional(),
    actionMode: taskHistory._enum(["do", "ask", "delegate"]).optional(),
    taskRefs: taskHistory.array(taskHistory.strictObject({
      taskId: identifier,
      displayId: identifier,
      team: taskHistory._enum(["source", "target"])
    })).max(100).optional(),
    chainDepth: taskHistory.number().int().min(0).max(4).optional()
  }),
  timestamp: identifier,
  authorityFingerprint: taskHistory.string().regex(/^[a-f0-9]{64}$/),
  targetCommandId: identifier
});
const id$5 = taskHistory.string().min(1).max(256).refine((value) => !/[\0\r\n]/u.test(value));
const units = taskHistory.number().int().min(0).max(Number.MAX_SAFE_INTEGER).nullable();
taskHistory.object({
  kind: taskHistory.literal("cost"),
  binding: taskHistory.object({
    backendId: id$5,
    teamId: id$5,
    runId: id$5,
    memberId: id$5,
    generation: id$5
  }).strict(),
  capturedAt: taskHistory.string().datetime(),
  inputTokens: units,
  outputTokens: units,
  partial: taskHistory.boolean(),
  launchId: id$5.nullable(),
  elapsedMs: units,
  text: taskHistory.string().min(1).max(8192).refine((value) => !value.includes("\0"))
}).strict();
const require$3 = node_module.createRequire(require("url").pathToFileURL(__filename).href);
const { agentBlocks: agentBlocks$2 } = require$3("agent-teams-controller");
const require$2 = node_module.createRequire(require("url").pathToFileURL(__filename).href);
require$2("agent-teams-controller/src/internal/crossTeamProtocol.js");
const { protocols: protocols$2 } = require$2("agent-teams-controller");
const require$1 = node_module.createRequire(require("url").pathToFileURL(__filename).href);
const { agentBlocks: agentBlocks$1, protocols: protocols$1 } = require$1("agent-teams-controller");
const { agentBlocks, protocols } = node_module.createRequire(require("url").pathToFileURL(__filename).href)("agent-teams-controller");
const id$4 = taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0"));
taskHistory.object({
  commandId: id$4,
  expectedRosterRevision: taskHistory.string().regex(/^[a-f0-9]{64}$/),
  member: taskHistory.memberSettingsSchema.pick({ model: true, role: true, workflow: true }).extend({
    name: taskHistory.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/),
    providerId: taskHistory._enum(["anthropic", "codex", "opencode"])
  }).strict()
}).strict();
const id$3 = taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0"));
const hash$1 = taskHistory.string().regex(/^[a-f0-9]{64}$/);
const memberId = taskHistory.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/);
const remainingMs = taskHistory.number().int().min(1).max(1e5);
const liveRosterPrivateInputSchema = taskHistory.discriminatedUnion("phase", [
  taskHistory.object({ phase: taskHistory.literal("capture"), remainingMs }).strict(),
  taskHistory.object({ phase: taskHistory.literal("continue"), captureDigest: hash$1, remainingMs }).strict(),
  taskHistory.object({ phase: taskHistory.literal("read") }).strict()
]);
const liveRosterCaptureViewSchema = taskHistory.object({
  schemaVersion: taskHistory.literal(1),
  commandId: id$3,
  teamId: id$3,
  requestDigest: hash$1,
  expectedRevision: hash$1,
  launchId: id$3,
  sourceCaptureDigest: hash$1,
  captureDigest: hash$1,
  target: taskHistory.object({
    memberId,
    name: memberId,
    provider: taskHistory._enum(["claude", "codex", "opencode"]),
    modelProviderId: id$3.nullable(),
    modelId: id$3,
    workspace: taskHistory.string().min(1).max(8192).refine((value) => !value.includes("\0") && path.isAbsolute(value)),
    optionsDigest: hash$1,
    configurationDigest: hash$1
  }).strict()
}).strict().refine((value) => value.target.provider === "opencode" ? value.target.modelProviderId !== null : value.target.modelProviderId === null);
const liveRosterPendingViewSchema = taskHistory.object({
  commandId: id$3,
  requestDigest: hash$1,
  phase: taskHistory._enum(["pending", "captured", "preparing", "published", "compensating", "held"]),
  captureDigest: hash$1.nullable()
}).strict();
const liveRosterResponseSchema = taskHistory.union([
  taskHistory.object({ ok: taskHistory.literal(true), liveRosterCapture: liveRosterCaptureViewSchema }).strict(),
  taskHistory.object({ ok: taskHistory.literal(true), liveRosterPending: liveRosterPendingViewSchema }).strict(),
  taskHistory.object({ ok: taskHistory.literal(true), value: taskHistory.object({ commandId: id$3, revision: hash$1 }).strict() }).strict(),
  taskHistory.object({
    ok: taskHistory.literal(false),
    code: taskHistory._enum(["invalid", "conflict", "forbidden", "hold"]),
    outcome: taskHistory._enum(["rejected", "unknown"])
  }).strict()
]);
function parseLiveRosterResponse(raw) {
  const result = liveRosterResponseSchema.parse(raw);
  if (Buffer.byteLength(JSON.stringify(result)) > 64 * 1024)
    throw new TeamOwnerError("hold");
  return result;
}
const deliverySchema = taskHistory.object({
  backendId: id$3,
  teamId: id$3,
  teamName: id$3,
  runId: id$3,
  memberId,
  generation: id$3
}).strict();
const memberSchema = taskHistory.object({
  memberId,
  name: memberId,
  role: taskHistory.literal("member"),
  settings: taskHistory.memberSettingsSchema.optional(),
  delivery: deliverySchema.optional()
}).strict().refine((value) => !value.delivery || value.delivery.memberId === value.memberId);
const removedSchema = taskHistory.object({
  memberId,
  name: memberId,
  role: taskHistory.literal("member"),
  settings: taskHistory.memberSettingsSchema.optional(),
  delivery: deliverySchema.optional(),
  removedAt: id$3
}).strict().refine((value) => !value.delivery || value.delivery.memberId === value.memberId);
const version = taskHistory.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER - 1);
const deltaSchema = taskHistory.object({
  kind: taskHistory._enum(["add", "remove", "restore"]),
  targetId: memberId,
  position: taskHistory.number().int().min(1).max(255),
  before: memberSchema.nullable(),
  after: memberSchema.nullable(),
  removedBefore: removedSchema.optional(),
  removedPosition: taskHistory.number().int().min(0).max(1023).optional()
}).strict();
const edgeSchema = taskHistory.object({
  beforeRevision: hash$1,
  afterRevision: hash$1,
  beforeVersion: version,
  afterVersion: version,
  before: memberSchema.nullable(),
  after: memberSchema.nullable(),
  position: taskHistory.number().int().min(1).max(255),
  removedBefore: removedSchema.optional(),
  removedAfter: removedSchema.optional()
}).strict();
taskHistory.object({
  schemaVersion: taskHistory.literal(1),
  phase: taskHistory._enum(["pending", "captured", "preparing", "published", "compensating", "held", "completed", "rejected"]),
  input: taskHistory.replaceRosterSchema,
  requestDigest: hash$1,
  authorityRevision: taskHistory.number().int().positive().safe(),
  launchId: id$3,
  sourceCaptureDigest: hash$1,
  hostIncarnation: id$3,
  cutoff: taskHistory.number().int().positive().safe(),
  beforeVersion: version,
  delta: deltaSchema,
  peerDigest: hash$1,
  savedSettingsDigest: hash$1,
  capture: liveRosterCaptureViewSchema.optional(),
  selection: taskHistory.object({ principalId: id$3, delivery: deliverySchema, configurationDigest: hash$1 }).strict().optional(),
  publication: edgeSchema.optional(),
  compensation: edgeSchema.optional(),
  rejection: taskHistory._enum(["invalid", "conflict", "forbidden", "hold"]).optional()
}).strict();
const id$2 = taskHistory.string().min(1).max(256).refine((value) => !!value.trim() && !value.includes("\0"));
const segment$1 = taskHistory.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/);
const hash = taskHistory.string().regex(/^[a-f0-9]{64}$/);
const delivery = taskHistory.object({
  backendId: segment$1,
  teamId: segment$1,
  teamName: segment$1,
  runId: id$2,
  memberId: segment$1,
  generation: id$2
}).strict();
taskHistory.object({
  cleanupCommandId: taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0")),
  cleanupPending: taskHistory.boolean(),
  deletedAt: taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0")).optional()
}).strict();
const member = taskHistory.object({ memberId: segment$1, principalId: id$2, delivery }).strict();
taskHistory.object({
  commandId: id$2,
  expectedRevision: hash,
  launchId: id$2,
  members: taskHistory.array(member).min(1).max(256)
}).strict();
taskHistory.object({
  commandId: id$2,
  configurationRevision: hash,
  launchId: id$2,
  members: taskHistory.array(member).min(1).max(256),
  principalId: id$2,
  fingerprint: hash
}).strict();
const id$1 = taskHistory.string().min(1).max(256).refine((value) => !value.includes("\0"));
const choice = taskHistory.object({
  memberId: id$1,
  sourceGeneration: id$1,
  reference: taskHistory.string().regex(/^cp1-[a-f0-9]{64}$/),
  commandId: id$1
}).strict();
taskHistory.object({
  launchId: id$1,
  rosterRevision: id$1,
  resumeId: id$1,
  members: taskHistory.array(choice).min(1).max(64)
}).strict();
const id = taskHistory.string().min(1).max(256);
const segment = taskHistory.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/);
const binding = taskHistory.object({ backendId: segment, teamId: segment, teamName: segment }).strict();
const hostedTeamDefinitionSchema = taskHistory.object({
  scope: teamRegistryScopeSchema,
  binding,
  savedSettings: taskHistory.savedTeamSettingsSchema.optional(),
  members: taskHistory.array(taskHistory.object({
    memberId: segment,
    name: segment,
    role: taskHistory._enum(["lead", "member"]),
    settings: taskHistory.memberSettingsSchema.optional(),
    launchPolicy: taskHistory._enum(["launch", "skip"]).optional(),
    delivery: binding.extend({ runId: id, memberId: segment, generation: id }).strict().optional()
  }).strict()).max(256),
  grants: taskHistory.array(taskHistory.object({
    principalId: id,
    memberName: segment,
    permissions: taskHistory.array(taskHistory._enum(["read", "task.write", "message.write", "process.write", "admin"])),
    revoked: taskHistory.boolean().optional()
  }).strict()).max(1024)
}).strict();
taskHistory.object({ contextId: taskHistory.string().min(1).max(256) }).strict();
function isWindowsishPath(filePath) {
  const p = filePath.replace(/\\/g, "/");
  return /^[A-Za-z]:\//.test(p) || p.startsWith("//");
}
function normalizePathForComparison(filePath) {
  const p = filePath.replace(/\\/g, "/");
  return isWindowsishPath(p) ? p.toLowerCase() : p;
}
const nativeKey = /^(agentId|leadAgentId|sessionId|leadSessionId|sessionHistory|runtimeSessionId|nativeSessionId|threadId|runId|pid|runtimePid|backendPid|processId|tmuxPaneId|tmuxSession|paneId|runtimeLeaseExpiresAt)$/i;
const namePattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
function isLegacyNativeIdentityKey(key) {
  return nativeKey.test(key);
}
function row(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid saved Team");
  return value;
}
function named(value) {
  const member2 = row(value);
  if (typeof member2.name !== "string" || !namePattern.test(member2.name))
    throw new Error("Invalid saved member");
  return member2;
}
function classifyLegacySavedTeamNativeRecords(teamName2, records) {
  try {
    if (!namePattern.test(teamName2)) return "unknown";
    const config = records.config === null ? null : row(records.config), meta = row(records.meta), roster = row(records.roster);
    if (meta.version !== 1 || roster.version !== 1 || !Array.isArray(roster.members) || config && (config.name !== teamName2 || !Array.isArray(config.members)))
      return "unknown";
    const members = roster.members.map(named);
    const configured = config ? config.members.map(named) : [];
    if ([members, configured].some(
      (rows) => new Set(rows.map((member2) => String(member2.name).toLowerCase())).size !== rows.length
    ))
      return "unknown";
    const leads = config ? configured.filter((member2) => member2.agentType === "team-lead") : [{ name: "team-lead" }];
    if (leads.length !== 1 || !config && members.some((member2) => member2.name === "team-lead"))
      return "unknown";
    const leadName = leads[0].name;
    const names2 = /* @__PURE__ */ new Set([leadName, ...members.map((member2) => member2.name)]);
    const productIds = /* @__PURE__ */ new Map();
    for (const member2 of [...members, ...configured]) {
      if (names2.has(member2.name)) productIds.set(member2, `${String(member2.name)}@${teamName2}`);
    }
    const nativeIdentity = (value, depth = 0) => {
      if (depth > 64) return true;
      if (Array.isArray(value)) return value.some((item) => nativeIdentity(item, depth + 1));
      if (!value || typeof value !== "object") return false;
      return Object.entries(value).some(
        ([key, item]) => isLegacyNativeIdentityKey(key) && item !== void 0 && item !== null && item !== "" && !(key === "agentId" && productIds.get(value) === item) && !(key === "leadAgentId" && value === config && item === `${leadName}@${teamName2}`) && !(key === "sessionHistory" && Array.isArray(item) && item.length === 0) || nativeIdentity(item, depth + 1)
      );
    };
    return [config, meta, roster].some((value) => nativeIdentity(value)) ? "retained" : "empty";
  } catch {
    return "unknown";
  }
}
const metaText = /* @__PURE__ */ new Set([
  "displayName",
  "description",
  "color",
  "cwd",
  "prompt",
  "providerId",
  "providerBackendId",
  "model",
  "effort",
  "fastMode",
  "worktree",
  "extraCliArgs"
]);
const metaBooleans = /* @__PURE__ */ new Set(["syncModelsWithLead", "skipPermissions", "limitContext"]);
const memberText = /* @__PURE__ */ new Set([
  "name",
  "agentId",
  "agentType",
  "role",
  "workflow",
  "isolation",
  "providerId",
  "providerBackendId",
  "model",
  "effort",
  "fastMode",
  "color",
  "cwd"
]);
function text(value) {
  return typeof value === "string" && value.length <= 256 * 1024 && !value.includes("\0");
}
function timestamp(value) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0;
}
function policy(value) {
  const source = row(value);
  if (!["inheritLead", "inheritScopes", "strictAllowlist", "appOnly"].includes(String(source.mode)))
    return false;
  return Object.entries(source).every(([key, item]) => {
    if (key === "mode") return true;
    if (key === "serverNames") return Array.isArray(item) && item.length <= 128 && item.every(text);
    if (key === "scopes")
      return Object.entries(row(item)).every(
        ([scope, flag]) => ["user", "project", "local"].includes(scope) && typeof flag === "boolean"
      );
    return false;
  });
}
function productMember(value) {
  const member2 = named(value);
  return Object.entries(member2).every(([key, item]) => {
    if (memberText.has(key)) return text(item);
    if (key === "joinedAt" || key === "removedAt") return timestamp(item);
    if (key === "mcpPolicy") return policy(item);
    return false;
  });
}
function isLegacySavedTeamProductRecords(teamName2, records) {
  try {
    if (classifyLegacySavedTeamNativeRecords(teamName2, records) !== "empty") return false;
    const meta = row(records.meta), roster = row(records.roster);
    if (!text(meta.cwd) || !timestamp(meta.createdAt) || !Object.entries(meta).every(([key, item]) => {
      if (key === "version") return item === 1;
      if (key === "createdAt") return timestamp(item);
      if (metaText.has(key)) return text(item);
      if (metaBooleans.has(key)) return typeof item === "boolean";
      return false;
    }))
      return false;
    if (!Object.entries(roster).every(
      ([key, item]) => key === "version" ? item === 1 : key === "providerBackendId" ? text(item) : key === "members" && Array.isArray(item) && item.length <= 128 && item.every(productMember)
    ))
      return false;
    if (records.config === null) return true;
    return Object.entries(row(records.config)).every(([key, item]) => {
      if (["name", "description", "projectPath", "leadAgentId"].includes(key)) return text(item);
      if (key === "createdAt") return timestamp(item);
      if (key === "members")
        return Array.isArray(item) && item.length <= 128 && item.every(productMember);
      return false;
    });
  } catch {
    return false;
  }
}
const nativeName = /^(launch-|bootstrap-|stop-|runtime-|opencode-|\.opencode-runtime|\.member-work-sync|\.bootstrap)/;
const publicationFiles = /* @__PURE__ */ new Set([
  "launch-state.json",
  "launch-summary.json",
  "launch-stopped.json",
  "launch-freshness.json"
]);
const configKeys = /* @__PURE__ */ new Set([
  "name",
  "description",
  "createdAt",
  "leadAgentId",
  "leadSessionId",
  "projectPath",
  "members",
  "_backupIdentityId"
]);
const memberKeys = /* @__PURE__ */ new Set([
  "name",
  "agentId",
  "agentType",
  "role",
  "workflow",
  "isolation",
  "providerId",
  "provider",
  "providerBackendId",
  "model",
  "effort",
  "fastMode",
  "color",
  "cwd",
  "joinedAt",
  "mcpPolicy",
  "isActive",
  "backendType"
]);
function readLegacyBackupIdentityMarker(config) {
  if (!Object.prototype.hasOwnProperty.call(config, "_backupIdentityId"))
    return Object.freeze({ present: false });
  const value = config._backupIdentityId;
  if (typeof value !== "string" || !value || value !== value.trim())
    throw new Error("Invalid native backup identity");
  return Object.freeze({ present: true, value });
}
function nativeReleaseDigest(value) {
  return crypto$1.createHash("sha256").update(JSON.stringify(value)).digest("hex");
}
function nativeRecord(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid native custody record");
  return value;
}
function readNativeRecord(path2, maxBytes = 1024 * 1024) {
  return nativeRecord(
    JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(readImportBytes(path2, maxBytes)))
  );
}
function present(value) {
  return value !== void 0 && value !== null && value !== "";
}
function validateNativeValue(key, value, target) {
  if (!present(value)) return;
  if (/^runId$/i.test(key) && value === target.runId) return;
  if (/^sessionHistory$/i.test(key) && Array.isArray(value) && value.every((session) => session === target.sessionId))
    return;
  if (/^(pid|runtimePid|backendPid|processId)$/i.test(key) && value === target.rootPid) return;
  if (/^(sessionId|leadSessionId|runtimeSessionId|nativeSessionId)$/i.test(key) && value === target.sessionId)
    return;
  if (/^(agentId|leadAgentId)$/i.test(key) && value === `${target.leadName}@${target.teamName}`)
    return;
  throw new Error("Native inventory is not covered by the owned solo CLI");
}
function nativeProjection(value, target, depth = 0) {
  if (depth > 48) throw new Error("Native custody nesting exceeds bound");
  if (Array.isArray(value)) return value.map((item) => nativeProjection(item, target, depth + 1));
  if (!value || typeof value !== "object") return null;
  const result = {};
  for (const key of Object.keys(value).sort()) {
    const item = value[key];
    if (isLegacyNativeIdentityKey(key)) {
      validateNativeValue(key, item, target);
      if (present(item)) result[key] = item;
    } else if (key === "bootstrapRunId" || key === "publicationRunId") {
      if (present(item) && item !== target.runId) throw new Error("Native run identity changed");
      if (present(item)) result[key] = item;
    } else if (item && typeof item === "object") {
      result[key] = nativeProjection(item, target, depth + 1);
    }
  }
  return result;
}
function assertQualifiedArtifacts(teamDir) {
  const names2 = fs$1.readdirSync(teamDir).sort();
  if (names2.length > 1024) throw new Error("Native Team census exceeds bound");
  for (const name2 of names2) {
    if (nativeName.test(name2) && !publicationFiles.has(name2))
      throw new Error("Unqualified native artifact inventory");
  }
}
const launchSelectionKeys = /* @__PURE__ */ new Set([
  "providerId",
  "providerBackendId",
  "billingMode",
  "selectedModel",
  "selectedModelKind",
  "resolvedLaunchModel",
  "catalogId",
  "catalogSource",
  "catalogFetchedAt",
  "selectedEffort",
  "resolvedEffort",
  "selectedFastMode",
  "resolvedFastMode",
  "fastResolutionReason"
]);
function productMetadata(teamName2, meta) {
  const { launchIdentity, ...saved } = meta;
  if (launchIdentity !== void 0) {
    const selection = nativeRecord(launchIdentity);
    if (selection.providerId !== "anthropic" || !["default", "explicit"].includes(String(selection.selectedModelKind)) || !Object.entries(selection).every(
      ([key, value]) => launchSelectionKeys.has(key) && (value === null || typeof value === "boolean" || typeof value === "string")
    ))
      return false;
  }
  return isLegacySavedTeamProductRecords(teamName2, {
    config: null,
    meta: saved,
    roster: { version: 1, members: [] }
  });
}
function readLegacyNativeCensus(teamDir, target, expectedMarker) {
  const directory = fs$1.lstatSync(teamDir);
  if (!directory.isDirectory() || directory.isSymbolicLink())
    throw new Error("Native Team directory changed");
  const config = readNativeRecord(path.join(teamDir, "config.json"), 10 * 1024 * 1024);
  const marker = readLegacyBackupIdentityMarker(config);
  if (expectedMarker && (marker.present !== expectedMarker.present || marker.present && expectedMarker.present && marker.value !== expectedMarker.value))
    throw new Error("Native backup identity changed");
  const roster = readNativeRecord(path.join(teamDir, "members.meta.json"), 20 * 1024 * 1024);
  const meta = readNativeRecord(path.join(teamDir, "team.meta.json"));
  if (config.name !== target.teamName || Object.keys(config).some((key) => !configKeys.has(key)) || !Array.isArray(config.members) || config.members.length !== 1 || meta.version !== 1 || !productMetadata(target.teamName, meta) || !Array.isArray(roster.members) || roster.version !== 1)
    throw new Error("Incomplete solo native inventory");
  const lead = nativeRecord(config.members[0]);
  if (lead.name !== target.leadName || lead.agentType !== "team-lead" || present(lead.providerId) && lead.providerId !== "anthropic" || present(lead.provider) && lead.provider !== "anthropic" || Object.keys(lead).some((key) => !memberKeys.has(key) && !isLegacyNativeIdentityKey(key)) || present(lead.backendType) && !["lead", "in-process", "process"].includes(String(lead.backendType)))
    throw new Error("Unsupported native lead");
  for (const value of roster.members) {
    const member2 = nativeRecord(value);
    if (member2.name !== target.leadName || member2.removedAt || present(member2.providerId) && member2.providerId !== "anthropic")
      throw new Error("Uncovered native member");
  }
  const identities = [
    nativeProjection(config, target),
    nativeProjection(roster, target),
    nativeProjection(meta, target)
  ];
  if (marker.present) identities.push({ _backupIdentityId: marker.value });
  assertQualifiedArtifacts(teamDir);
  const after = fs$1.lstatSync(teamDir);
  if (after.dev !== directory.dev || after.ino !== directory.ino)
    throw new Error("Native Team directory replaced");
  return {
    directory: { dev: directory.dev, ino: directory.ino, birthtimeMs: directory.birthtimeMs },
    nativeDigest: nativeReleaseDigest(identities)
  };
}
const capturedProofs = /* @__PURE__ */ new WeakMap();
function sameDirectory(left, right) {
  return JSON.stringify(left.directory) === JSON.stringify(right.directory);
}
function identityText(value) {
  return typeof value === "string" && value.length > 0 && value.length <= 256;
}
function captureLegacyNativeStop(teamsBasePath, run, current) {
  try {
    if (process.platform === "win32" || !current() || !run.child || !identityText(run.runId) || !identityText(run.detectedSessionId) || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(run.teamName) || run.expectedMembers.length || run.allEffectiveMembers.length || run.request.members.length || run.mixedSecondaryLanes.length || run.request.providerId !== void 0 && run.request.providerId !== "anthropic")
      return null;
    const processCapture = taskHistory.captureCliProcessStop(run.child);
    if (!processCapture) return null;
    const teamDir = path.join(teamsBasePath, run.teamName);
    const config = readNativeRecord(path.join(teamDir, "config.json"), 10 * 1024 * 1024);
    const expectedMarker = readLegacyBackupIdentityMarker(config);
    if (!Array.isArray(config.members) || config.members.length !== 1) return null;
    const leadName = nativeRecord(config.members[0]).name;
    if (!identityText(leadName)) return null;
    const target = {
      teamName: run.teamName,
      runId: run.runId,
      leadName,
      sessionId: run.detectedSessionId,
      rootPid: processCapture.rootPid
    };
    const launch = readNativeRecord(path.join(teamDir, "launch-state.json"));
    const freshness = readNativeRecord(path.join(teamDir, "launch-freshness.json"));
    if (launch.version !== 2 || launch.teamName !== target.teamName || launch.publicationRunId !== target.runId || launch.leadSessionId !== target.sessionId || !Array.isArray(launch.expectedMembers) || launch.expectedMembers.length || Object.keys(nativeRecord(launch.members)).length || freshness.version !== 1 || freshness.teamName !== target.teamName || freshness.kind !== "launch" || freshness.runId !== target.runId)
      return null;
    const original = readLegacyNativeCensus(teamDir, target, expectedMarker);
    return Object.freeze({
      complete() {
        try {
          if (!current()) return null;
          const verified = taskHistory.readVerifiedCliProcessRelease(processCapture);
          if (!verified) return null;
          const census = readLegacyNativeCensus(teamDir, target, expectedMarker);
          if (!sameDirectory(original, census)) return null;
          const proof = {
            version: 1,
            kind: "desktop-owned-unix-cli",
            target: structuredClone(target),
            census,
            process: verified
          };
          capturedProofs.set(proof, nativeReleaseDigest(proof));
          return proof;
        } catch {
          return null;
        }
      }
    });
  } catch {
    return null;
  }
}
function parseLegacyNativeStopRelease(value) {
  try {
    const proof = nativeRecord(value), target = nativeRecord(proof.target), census = nativeRecord(proof.census), directory = nativeRecord(census.directory), processProof = nativeRecord(proof.process);
    if (proof.version !== 1 || proof.kind !== "desktop-owned-unix-cli" || !["teamName", "runId", "leadName", "sessionId"].every((key) => identityText(target[key])) || !Number.isSafeInteger(target.rootPid) || Number(target.rootPid) <= 0 || !["dev", "ino", "birthtimeMs"].every(
      (key) => typeof directory[key] === "number" && Number.isFinite(directory[key]) && Number(directory[key]) >= 0
    ) || typeof census.nativeDigest !== "string" || !/^[a-f0-9]{64}$/.test(census.nativeDigest) || processProof.version !== 1 || !identityText(processProof.ownerIncarnation) || processProof.rootPid !== target.rootPid || processProof.processGroupId !== target.rootPid || !identityText(processProof.rootStartIdentity) || !Array.isArray(processProof.processes) || processProof.processes.length > 256)
      return null;
    const pids = /* @__PURE__ */ new Set();
    for (const value2 of processProof.processes) {
      const item = nativeRecord(value2);
      if (!Number.isSafeInteger(item.pid) || Number(item.pid) <= 0 || !Number.isSafeInteger(item.parentPid) || Number(item.parentPid) < 0 || item.processGroupId !== target.rootPid || !identityText(item.startIdentity) || item.pid === processProof.rootPid && item.startIdentity !== processProof.rootStartIdentity || pids.has(Number(item.pid)))
        return null;
      pids.add(Number(item.pid));
    }
    return structuredClone(value);
  } catch {
    return null;
  }
}
function isCurrentLegacyNativeStopRelease(teamDir, proof, requireCapture = false) {
  try {
    if (!parseLegacyNativeStopRelease(proof) || requireCapture && capturedProofs.get(proof) !== nativeReleaseDigest(proof))
      return false;
    const census = readLegacyNativeCensus(teamDir, proof.target);
    return sameDirectory(census, proof.census) && census.nativeDigest === proof.census.nativeDigest;
  } catch {
    return false;
  }
}
function readLegacyNativeStopRelease(teamDir, teamName2) {
  try {
    const marker = readNativeRecord(path.join(teamDir, "launch-stopped.json"));
    const freshness = readNativeRecord(path.join(teamDir, "launch-freshness.json"));
    const proof = parseLegacyNativeStopRelease(marker.nativeRelease);
    if (!proof || marker.version !== 1 || marker.teamName !== teamName2 || !identityText(marker.stopId) || freshness.version !== 1 || freshness.teamName !== teamName2 || freshness.kind !== "stop" || freshness.stopId !== marker.stopId || freshness.stoppedRunId !== proof.target.runId || proof.target.teamName !== teamName2 || freshness.nativeReleaseOwnerIncarnation !== proof.process.ownerIncarnation || freshness.nativeReleaseDigest !== nativeReleaseDigest(proof))
      return null;
    if (!isCurrentLegacyNativeStopRelease(teamDir, proof)) return null;
    return proof;
  } catch {
    return null;
  }
}
function selectLegacyNativeStopReleaseProof(options) {
  const { teamDir, teamName: teamName2, freshness, provided } = options;
  const proof = provided ?? (freshness?.kind === "stop" ? readLegacyNativeStopRelease(teamDir, teamName2) : null);
  const runId = freshness?.kind === "launch" ? freshness.runId : freshness?.stoppedRunId;
  if (!proof || proof.target.teamName !== teamName2 || proof.target.runId !== runId || !isCurrentLegacyNativeStopRelease(teamDir, proof, provided !== void 0))
    return null;
  const originalDigest = nativeReleaseDigest(proof);
  return Object.freeze({
    proof,
    assertCurrent() {
      if (nativeReleaseDigest(proof) !== originalDigest || !isCurrentLegacyNativeStopRelease(teamDir, proof, provided !== void 0))
        throw new Error("Native stop release authority changed");
    }
  });
}
const teamProvisioningRequestAdmissionContext = new node_async_hooks.AsyncLocalStorage();
function getAdmittedTeamPublicationAuthority(teamName2) {
  for (let context = teamProvisioningRequestAdmissionContext.getStore(); context; context = context.parent) {
    if (context.active && context.lockKey === teamName2) return context.publicationIsAuthorized;
  }
  return void 0;
}
const exactIdentity = (value) => typeof value === "string" && value.length > 0 && value.length <= 256 && value.trim() === value && !value.includes("\0");
function parseTranscriptBindings(value) {
  if (!Array.isArray(value) || value.length > 128) return [];
  const bindings = [];
  const members = /* @__PURE__ */ new Set();
  for (const entry of value) {
    if (!entry || typeof entry !== "object") return [];
    const record = entry;
    const { memberName: memberName2, laneId, runId, sessionId } = record;
    if (!exactIdentity(memberName2) || !exactIdentity(laneId) || !exactIdentity(runId) || !exactIdentity(sessionId))
      return [];
    const key = JSON.stringify([memberName2, laneId]);
    if (members.has(key)) return [];
    members.add(key);
    bindings.push({ memberName: memberName2, laneId, runId, sessionId });
  }
  return bindings;
}
function captureOpenCodeTranscriptBindings(snapshot) {
  const bindings = [];
  for (const [memberName2, member2] of Object.entries(snapshot.members)) {
    if (member2.providerId !== "opencode") continue;
    const binding2 = {
      memberName: memberName2,
      laneId: member2.laneId,
      runId: member2.runtimeRunId,
      sessionId: member2.runtimeSessionId
    };
    if (member2.name !== memberName2 || !Object.values(binding2).every(exactIdentity)) continue;
    const candidate = member2.appManagedBootstrapCandidate;
    if (member2.bootstrapEvidenceSource === "app_managed_bootstrap" && !candidate) continue;
    if (candidate && (candidate.teamName !== snapshot.teamName || candidate.memberName !== memberName2 || candidate.laneId !== binding2.laneId || candidate.runId !== binding2.runId || candidate.runtimeSessionId !== binding2.sessionId))
      continue;
    bindings.push(binding2);
  }
  return parseTranscriptBindings(bindings);
}
const TEAM_LAUNCH_FRESHNESS_FILE = "launch-freshness.json";
function getTeamLaunchFreshnessPath(teamName2) {
  return path__namespace.join(taskHistory.getTeamsBasePath(), teamName2, TEAM_LAUNCH_FRESHNESS_FILE);
}
function parseTeamLaunchFreshness(teamName2, value) {
  if (!value || typeof value !== "object") {
    return null;
  }
  const record = value;
  if (record.version !== 1 || record.teamName !== teamName2) {
    return null;
  }
  if (record.kind === "launch" && typeof record.runId === "string" && record.runId) {
    return { version: 1, teamName: teamName2, kind: "launch", runId: record.runId };
  }
  if (record.kind === "stop" && typeof record.stopId === "string" && record.stopId) {
    return {
      version: 1,
      teamName: teamName2,
      kind: "stop",
      stopId: record.stopId,
      ...typeof record.stoppedRunId === "string" && record.stoppedRunId ? { stoppedRunId: record.stoppedRunId } : {},
      ...record.transcriptBindings !== void 0 ? {
        transcriptBindings: exactIdentity(record.stoppedRunId) ? parseTranscriptBindings(record.transcriptBindings) : []
      } : {}
    };
  }
  return null;
}
function isStopLaunchFreshness(value) {
  if (value == null) return false;
  if (typeof value === "string") return value === "stop";
  return value.kind === "stop";
}
async function readTeamLaunchFreshness(teamName2) {
  let raw;
  try {
    const file = getTeamLaunchFreshnessPath(teamName2);
    if ((await fs$1.promises.stat(file)).size > 256 * 1024)
      throw new Error("Launch freshness exceeds size limit");
    raw = await fs$1.promises.readFile(file, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
  const parsed = parseTeamLaunchFreshness(teamName2, JSON.parse(raw));
  if (!parsed) {
    throw new Error("Invalid launch freshness authority");
  }
  return parsed;
}
async function readTeamLaunchFreshnessFromTeamDir(teamDir, teamName2) {
  try {
    const raw = await fs$1.promises.readFile(path__namespace.join(teamDir, TEAM_LAUNCH_FRESHNESS_FILE), "utf8");
    return parseTeamLaunchFreshness(teamName2, JSON.parse(raw));
  } catch {
    return null;
  }
}
async function canRestoreTeamStopMarker(teamName2, content) {
  const freshness = await readTeamLaunchFreshness(teamName2);
  if (!freshness) return true;
  if (freshness.kind === "launch") return false;
  const marker = JSON.parse(content.toString("utf8"));
  return marker.teamName === teamName2 && marker.stopId === freshness.stopId;
}
const logger$4 = createLogger("Service:TeamLaunchStateStore");
const TEAM_LAUNCH_STATE_FILE = "launch-state.json";
const MAX_LAUNCH_STATE_BYTES = 256 * 1024;
const stopIntentByTeam = /* @__PURE__ */ new Map();
const publicationQueueByTeam = /* @__PURE__ */ new Map();
function captureTeamLaunchPublicationAuthority(teamName2) {
  const intent = stopIntentByTeam.get(teamName2);
  const admitted = getAdmittedTeamPublicationAuthority(teamName2);
  return () => admitted?.() !== false && stopIntentByTeam.get(teamName2) === intent;
}
function getTeamLaunchStatePath(teamName2) {
  return path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, TEAM_LAUNCH_STATE_FILE);
}
function getTeamLaunchSummaryPath(teamName2) {
  return path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, taskHistory.TEAM_LAUNCH_SUMMARY_FILE);
}
const TEAM_LAUNCH_STOPPED_MARKER_FILE = "launch-stopped.json";
function getTeamLaunchStoppedMarkerPath(teamName2) {
  return path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, TEAM_LAUNCH_STOPPED_MARKER_FILE);
}
function readPersistedLaunchRuntimePidsSync(teamName2) {
  const targetPath = getTeamLaunchStatePath(teamName2);
  let parsed;
  try {
    const stat = fs__namespace.statSync(targetPath);
    if (!stat.isFile() || stat.size > MAX_LAUNCH_STATE_BYTES) {
      return [];
    }
    parsed = JSON.parse(fs__namespace.readFileSync(targetPath, "utf8"));
  } catch {
    return [];
  }
  if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
    const record = parsed;
    if (record.version === 2 && (typeof record.teamName !== "string" || record.teamName.trim() !== teamName2)) {
      return [];
    }
  }
  const snapshot = taskHistory.normalizePersistedLaunchSnapshot(teamName2, parsed);
  if (!snapshot) {
    return [];
  }
  const pids = /* @__PURE__ */ new Set();
  for (const member2 of Object.values(snapshot.members)) {
    const pid = member2?.runtimePid;
    if (typeof pid === "number" && Number.isFinite(pid) && pid > 0) {
      pids.add(Math.trunc(pid));
    }
  }
  return [...pids];
}
async function removeStoppedMarkerIfPresent(teamName2) {
  const markerPath = getTeamLaunchStoppedMarkerPath(teamName2);
  if (!fs__namespace.existsSync(markerPath)) return;
  await fs__namespace.promises.rm(markerPath, { force: true });
}
async function isMissingTeamDirectoryWriteRace(targetPath, error) {
  const code = error.code;
  if (code !== "ENOENT" && code !== "EINVAL") {
    return false;
  }
  const targetDir = path__namespace$1.dirname(targetPath);
  try {
    await fs__namespace.promises.access(targetDir);
    return false;
  } catch (accessError) {
    return accessError.code === "ENOENT";
  }
}
function throwPublicationRevocationFailure(teamName2, results) {
  const errors = results.filter((result) => result.status === "rejected").map((result) => result.reason);
  if (errors.length === 1) {
    throw errors[0];
  }
  if (errors.length > 1) {
    throw new AggregateError(errors, `[${teamName2}] Failed to clear launch-state publication`);
  }
}
function enqueuePublication(teamName2, operation) {
  const previous = publicationQueueByTeam.get(teamName2);
  const queued = (previous ?? Promise.resolve()).catch(() => void 0).then(operation);
  publicationQueueByTeam.set(teamName2, queued);
  return queued.finally(() => {
    if (publicationQueueByTeam.get(teamName2) === queued) {
      publicationQueueByTeam.delete(teamName2);
    }
  });
}
function withTeamLaunchStatePublicationLock(teamName2, operation) {
  return enqueuePublication(teamName2, operation);
}
function describeReadFailure(error) {
  return error instanceof Error ? error.message : String(error);
}
class TeamLaunchStateStore {
  /**
   * The launch snapshot, or `null` when there is none to be had. It cannot say
   * why: a team that never launched and a launch state this app could not read
   * both answer `null`. Callers that draw a conclusion from the absence of
   * recorded state - "nothing is running" - need `readResult` instead.
   */
  async read(teamName2) {
    const result = await this.readResult(teamName2);
    return result.status === "snapshot" ? result.snapshot : null;
  }
  /**
   * The same read, keeping "this team has no launch state" apart from "the
   * launch state could not be read". Only the first is evidence about the team;
   * the second is the absence of evidence, and a caller that counts it as an
   * empty snapshot reports a probe that answered nothing as a definite zero.
   */
  async readResult(teamName2) {
    const targetPath = getTeamLaunchStatePath(teamName2);
    let raw;
    try {
      const stat = await fs__namespace.promises.stat(targetPath);
      if (!stat.isFile()) {
        return { status: "unreadable", reason: "launch state path is not a file" };
      }
      if (stat.size > MAX_LAUNCH_STATE_BYTES) {
        return { status: "unreadable", reason: `launch state exceeds ${MAX_LAUNCH_STATE_BYTES}B` };
      }
      raw = await fs__namespace.promises.readFile(targetPath, "utf8");
    } catch (error) {
      return error.code === "ENOENT" ? { status: "absent" } : { status: "unreadable", reason: describeReadFailure(error) };
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (error) {
      return { status: "unreadable", reason: describeReadFailure(error) };
    }
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      const record = parsed;
      if (record.version === 2 && (typeof record.teamName !== "string" || record.teamName.trim() !== teamName2)) {
        return { status: "unreadable", reason: "launch state names a different team" };
      }
    }
    const snapshot = taskHistory.normalizePersistedLaunchSnapshot(teamName2, parsed);
    if (snapshot && parsed && typeof parsed === "object" && "publicationRunId" in parsed && typeof parsed.publicationRunId === "string")
      snapshot.publicationRunId = parsed.publicationRunId;
    return snapshot ? { status: "snapshot", snapshot } : { status: "unreadable", reason: "launch state did not describe a launch" };
  }
  async beginLaunch(teamName2, runId, expectedMembers, isAuthorized) {
    if (!runId.trim()) throw new Error("Launch publication requires a run identity");
    const publicationIsCurrent = captureTeamLaunchPublicationAuthority(teamName2);
    return enqueuePublication(
      teamName2,
      () => this.writeNow(
        teamName2,
        taskHistory.createPersistedLaunchSnapshot({
          teamName: teamName2,
          expectedMembers,
          launchPhase: "active",
          members: {}
        }),
        {
          runId,
          isAuthorized: () => isAuthorized() && publicationIsCurrent()
        },
        true
      )
    );
  }
  async write(teamName2, snapshot, options) {
    const publicationIsCurrent = captureTeamLaunchPublicationAuthority(teamName2);
    return enqueuePublication(
      teamName2,
      () => this.writeNow(teamName2, snapshot, {
        ...options,
        runId: options?.runId ?? snapshot.publicationRunId,
        isAuthorized: () => options?.isAuthorized?.() !== false && publicationIsCurrent()
      })
    );
  }
  async writeNow(teamName2, snapshot, options, beginsLaunch = false) {
    if (options.isAuthorized?.() === false) return false;
    const freshness = await readTeamLaunchFreshness(teamName2);
    if (options.isAuthorized?.() === false) return false;
    beginsLaunch ||= snapshot.launchPhase === "active" && options.republishesExistingLaunch !== true && !!options.runId && options.authorizesNewRun?.() === true && (freshness === null || (freshness.kind === "stop" ? freshness.stoppedRunId : freshness.runId) !== options.runId);
    if (!beginsLaunch && await this.isStopped(teamName2)) return false;
    if (!beginsLaunch && freshness?.kind === "launch" && options.runId !== freshness.runId)
      return false;
    const statePath = getTeamLaunchStatePath(teamName2);
    const directory = path__namespace$1.dirname(statePath);
    const directoryIdentity = await fs__namespace.promises.stat(directory).catch(() => null);
    if (!directoryIdentity) return false;
    const directoryIsCurrent = async () => {
      const current = await fs__namespace.promises.stat(directory).catch(() => null);
      return current !== null && taskHistory.isSameDurablePathIdentity(
        taskHistory.getDurablePathIdentity(current),
        taskHistory.getDurablePathIdentity(directoryIdentity)
      );
    };
    const beforeCommit = async () => {
      if (options.isAuthorized?.() === false || !await directoryIsCurrent()) {
        throw new Error("Launch publication authorization changed");
      }
    };
    const summaryPath = getTeamLaunchSummaryPath(teamName2);
    const paths = beginsLaunch ? [
      statePath,
      summaryPath,
      getTeamLaunchFreshnessPath(teamName2),
      getTeamLaunchStoppedMarkerPath(teamName2)
    ] : [statePath, summaryPath];
    const previous = await Promise.all(
      paths.map(async (file) => {
        try {
          return await fs__namespace.promises.readFile(file, "utf8");
        } catch (error) {
          if (error.code === "ENOENT") return null;
          throw error;
        }
      })
    );
    const rollback = async () => {
      const beforeRollbackCommit = async () => {
        if (!await directoryIsCurrent()) throw new Error("Launch rollback directory changed");
      };
      for (let i = 0; i < paths.length; i++) {
        if (!await directoryIsCurrent()) return;
        if (previous[i] === null) await fs__namespace.promises.rm(paths[i], { force: true });
        else await taskHistory.atomicWriteAsync(paths[i], previous[i], { beforeCommit: beforeRollbackCommit });
      }
    };
    if (options.isAuthorized?.() === false) return false;
    try {
      await taskHistory.atomicWriteAsync(
        statePath,
        `${JSON.stringify({ ...snapshot, publicationRunId: options.runId }, null, 2)}
`,
        { beforeCommit }
      );
      await taskHistory.atomicWriteAsync(
        summaryPath,
        `${JSON.stringify({ ...taskHistory.createPersistedLaunchSummaryProjection(snapshot), publicationRunId: options.runId }, null, 2)}
`,
        { beforeCommit }
      );
      if (beginsLaunch) {
        await taskHistory.atomicWriteAsync(
          getTeamLaunchFreshnessPath(teamName2),
          JSON.stringify({
            version: 1,
            teamName: teamName2,
            kind: "launch",
            runId: options.runId
          }),
          { beforeCommit, durability: "strict", syncDirectory: true }
        );
        if (options.isAuthorized?.() !== false) await removeStoppedMarkerIfPresent(teamName2);
      }
      if (options.isAuthorized?.() === false) {
        await rollback();
        return false;
      }
      return true;
    } catch (error) {
      if (await isMissingTeamDirectoryWriteRace(statePath, error)) return false;
      await rollback();
      if (options.isAuthorized?.() === false || !await directoryIsCurrent()) return false;
      logger$4.warn(
        `[${teamName2}] Failed to persist launch-state: ${error instanceof Error ? error.message : String(error)}`
      );
      throw error;
    }
  }
  /** Admit before runtime/cleanup awaits, revoking pending earlier publications. */
  beginStop(teamName2) {
    const stopIntent = (stopIntentByTeam.get(teamName2) ?? 0) + 1;
    stopIntentByTeam.set(teamName2, stopIntent);
    return enqueuePublication(teamName2, async () => {
      const freshness = await readTeamLaunchFreshness(teamName2);
      const publication = freshness?.kind === "launch" ? await this.readResult(teamName2) : null;
      const transcriptBindings = freshness?.kind === "stop" ? freshness.transcriptBindings : publication?.status === "snapshot" && publication.snapshot.publicationRunId === freshness?.runId ? captureOpenCodeTranscriptBindings(publication.snapshot) : [];
      return { teamName: teamName2, stopIntent, freshness, transcriptBindings };
    });
  }
  /** A cleanup tail retains its admission; it cannot stop a successor publication. */
  async markStopped(teamName2, authority, nativeRelease) {
    const stopIntent = authority?.stopIntent ?? (stopIntentByTeam.get(teamName2) ?? 0) + 1;
    if (!authority) stopIntentByTeam.set(teamName2, stopIntent);
    await enqueuePublication(teamName2, async () => {
      const previous = await readTeamLaunchFreshness(teamName2);
      const admitted = authority ?? {
        teamName: teamName2,
        stopIntent,
        freshness: previous
      };
      if (admitted.teamName !== teamName2 || admitted.stopIntent !== stopIntentByTeam.get(teamName2) || JSON.stringify(previous) !== JSON.stringify(admitted.freshness))
        return;
      const markerPath = getTeamLaunchStoppedMarkerPath(teamName2);
      const selected = selectLegacyNativeStopReleaseProof({
        teamDir: path__namespace$1.dirname(markerPath),
        teamName: teamName2,
        freshness: previous,
        provided: nativeRelease
      });
      const assertCurrent = () => {
        if (admitted.stopIntent !== stopIntentByTeam.get(teamName2))
          throw new Error("Stop publication authority changed");
        selected?.assertCurrent();
      };
      assertCurrent();
      const revocations = await Promise.allSettled([
        fs__namespace.promises.rm(getTeamLaunchStatePath(teamName2), { force: true }),
        fs__namespace.promises.rm(getTeamLaunchSummaryPath(teamName2), { force: true })
      ]);
      const stopId = crypto$1.randomUUID();
      try {
        await taskHistory.atomicWriteAsync(
          getTeamLaunchFreshnessPath(teamName2),
          JSON.stringify({
            version: 1,
            teamName: teamName2,
            kind: "stop",
            stopId,
            stoppedRunId: previous?.kind === "launch" ? previous.runId : previous?.stoppedRunId,
            ...selected ? {
              nativeReleaseOwnerIncarnation: selected.proof.process.ownerIncarnation,
              nativeReleaseDigest: nativeReleaseDigest(selected.proof)
            } : {},
            transcriptBindings: previous?.kind === "stop" ? previous.transcriptBindings : admitted.transcriptBindings
          }),
          { durability: "strict", syncDirectory: true, assertCurrent }
        );
        await taskHistory.atomicWriteAsync(
          markerPath,
          `${JSON.stringify({ version: 1, teamName: teamName2, stopId, stoppedAt: (/* @__PURE__ */ new Date()).toISOString(), ...selected ? { nativeRelease: selected.proof } : {} }, null, 2)}
`,
          { durability: "strict", syncDirectory: true, assertCurrent }
        );
      } catch (error) {
        if (await isMissingTeamDirectoryWriteRace(markerPath, error)) {
          return;
        }
        throw error;
      }
      throwPublicationRevocationFailure(teamName2, revocations);
    });
  }
  async isStopped(teamName2) {
    return fs__namespace.existsSync(getTeamLaunchStoppedMarkerPath(teamName2)) || (await readTeamLaunchFreshness(teamName2))?.kind === "stop";
  }
  /**
   * Removes the launch publication only. The stop marker survives a clear:
   * stop flows and stale-write cleanups clear the publication after the team
   * was marked stopped, and only a real launch (an 'active' write) may lift
   * the marker again. Recovery clears additionally compare the persisted run and
   * live freshness inside the publication queue before deleting either file.
   */
  async clear(teamName2, isAuthorized, persistedRunId) {
    await enqueuePublication(teamName2, async () => {
      if (isAuthorized?.() === false) return;
      if (persistedRunId !== void 0) {
        const current = await this.read(teamName2);
        const freshness = await readTeamLaunchFreshness(teamName2);
        if (current?.publicationRunId !== persistedRunId || freshness !== null && (freshness.kind !== "launch" || freshness.runId !== persistedRunId) || isAuthorized?.() === false)
          return;
      }
      throwPublicationRevocationFailure(
        teamName2,
        await Promise.allSettled([
          fs__namespace.promises.rm(getTeamLaunchStatePath(teamName2), { force: true }),
          fs__namespace.promises.rm(getTeamLaunchSummaryPath(teamName2), { force: true })
        ])
      );
    });
  }
}
const pricingData = {
  "anthropic.claude-3-5-haiku-20241022-v1:0": { "cache_creation_input_token_cost": 1e-6, "cache_read_input_token_cost": 8e-8, "input_cost_per_token": 8e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 4e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "prompt_cache_min_tokens": 2048 },
  "anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "anthropic.claude-haiku-4-5@20251001": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_streaming": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e6, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 3e-5, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7 },
  "anthropic.claude-3-5-sonnet-20241022-v2:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e6, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 3e-5, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7 },
  "anthropic.claude-3-7-sonnet-20240620-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "anthropic.claude-3-7-sonnet-20250219-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "anthropic.claude-3-haiku-20240307-v1:0": { "input_cost_per_token": 25e-8, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 25e-9, "cache_creation_input_token_cost": 3125e-10 },
  "anthropic.claude-3-opus-20240229-v1:0": { "input_cost_per_token": 15e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_function_calling": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 15e-7, "cache_creation_input_token_cost": 1875e-8 },
  "anthropic.claude-3-sonnet-20240229-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "anthropic.claude-instant-v1": { "input_cost_per_token": 8e-7, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-7, "supports_tool_choice": true },
  "anthropic.claude-opus-4-1-20250805-v1:0": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-opus-4-20250514-v1:0": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-opus-4-5-20251101-v1:0": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "high", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "anthropic.claude-opus-4-6-v1": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "bedrock_output_config_effort_ceiling": "max", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "global.anthropic.claude-opus-4-6-v1": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "bedrock_output_config_effort_ceiling": "max", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "us.anthropic.claude-opus-4-6-v1": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "bedrock_output_config_effort_ceiling": "max", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "eu.anthropic.claude-opus-4-6-v1": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "bedrock_output_config_effort_ceiling": "max", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "au.anthropic.claude-opus-4-6-v1": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "bedrock_output_config_effort_ceiling": "max", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "anthropic.claude-opus-4-7": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 2048 },
  "anthropic.claude-mythos-preview": { "input_cost_per_token": 0, "output_cost_per_token": 0, "litellm_provider": "bedrock", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": false, "supports_reasoning": true, "supports_tool_choice": true, "supports_output_config": true },
  "global.anthropic.claude-opus-4-7": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 2048 },
  "us.anthropic.claude-opus-4-7": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 2048 },
  "eu.anthropic.claude-opus-4-7": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 2048 },
  "au.anthropic.claude-opus-4-7": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 2048 },
  "anthropic.claude-fable-5": { "cache_creation_input_token_cost": 125e-7, "cache_creation_input_token_cost_above_1hr": 2e-5, "cache_read_input_token_cost": 1e-6, "input_cost_per_token": 1e-5, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 5e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "global.anthropic.claude-fable-5": { "cache_creation_input_token_cost": 125e-7, "cache_creation_input_token_cost_above_1hr": 2e-5, "cache_read_input_token_cost": 1e-6, "input_cost_per_token": 1e-5, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 5e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "us.anthropic.claude-fable-5": { "cache_creation_input_token_cost": 1375e-8, "cache_creation_input_token_cost_above_1hr": 22e-6, "cache_read_input_token_cost": 11e-7, "input_cost_per_token": 11e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 55e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-fable-5": { "cache_creation_input_token_cost": 1375e-8, "cache_creation_input_token_cost_above_1hr": 22e-6, "cache_read_input_token_cost": 11e-7, "input_cost_per_token": 11e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 55e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-opus-5": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 512 },
  "global.anthropic.claude-opus-5": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 512 },
  "us.anthropic.claude-opus-5": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 512 },
  "eu.anthropic.claude-opus-5": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 512 },
  "au.anthropic.claude-opus-5": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 512 },
  "jp.anthropic.claude-opus-5": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 512 },
  "anthropic.claude-opus-4-8": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "global.anthropic.claude-opus-4-8": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "us.anthropic.claude-opus-4-8": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-opus-4-8": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "au.anthropic.claude-opus-4-8": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "jp.anthropic.claude-opus-4-8": { "bedrock_converse_supports_strict_tools": false, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "jp.anthropic.claude-opus-4-7": { "bedrock_converse_supports_strict_tools": false, "cache_creation_input_token_cost": 6875e-9, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_minimal_reasoning_effort": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 2048 },
  "anthropic.claude-sonnet-5": { "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_1hr": 4e-6, "cache_read_input_token_cost": 2e-7, "input_cost_per_token": 2e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 1e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "global.anthropic.claude-sonnet-5": { "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_1hr": 4e-6, "cache_read_input_token_cost": 2e-7, "input_cost_per_token": 2e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 1e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "us.anthropic.claude-sonnet-5": { "cache_creation_input_token_cost": 275e-8, "cache_creation_input_token_cost_above_1hr": 44e-7, "cache_read_input_token_cost": 22e-8, "input_cost_per_token": 22e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 11e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-sonnet-5": { "cache_creation_input_token_cost": 275e-8, "cache_creation_input_token_cost_above_1hr": 44e-7, "cache_read_input_token_cost": 22e-8, "input_cost_per_token": 22e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 11e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "au.anthropic.claude-sonnet-5": { "cache_creation_input_token_cost": 275e-8, "cache_creation_input_token_cost_above_1hr": 44e-7, "cache_read_input_token_cost": 22e-8, "input_cost_per_token": 22e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 11e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "jp.anthropic.claude-sonnet-5": { "cache_creation_input_token_cost": 275e-8, "cache_creation_input_token_cost_above_1hr": 44e-7, "cache_read_input_token_cost": 22e-8, "input_cost_per_token": 22e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 11e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_mid_conversation_system": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "xhigh", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "global.anthropic.claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "us.anthropic.claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "au.anthropic.claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "jp.anthropic.claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-sonnet-4-20250514-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "bedrock_converse_supports_strict_tools": false, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 12e-6, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "anthropic.claude-v1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6 },
  "anthropic.claude-v2:1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "apac.anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "apac.anthropic.claude-3-5-sonnet-20241022-v2:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "apac.anthropic.claude-3-haiku-20240307-v1:0": { "input_cost_per_token": 25e-8, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 25e-9, "cache_creation_input_token_cost": 3125e-10 },
  "apac.anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 1375e-9, "cache_read_input_token_cost": 11e-8, "input_cost_per_token": 11e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 55e-7, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "apac.anthropic.claude-3-sonnet-20240229-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "apac.anthropic.claude-sonnet-4-20250514-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "bedrock_converse_supports_strict_tools": false, "prompt_cache_min_tokens": 1024 },
  "au.anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "input_cost_per_token_above_200k_tokens": 66e-7, "output_cost_per_token_above_200k_tokens": 2475e-8, "cache_creation_input_token_cost_above_200k_tokens": 825e-8, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 132e-7, "cache_read_input_token_cost_above_200k_tokens": 66e-8, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "azure_ai/claude-haiku-4-5": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "azure_ai", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "azure_ai/claude-opus-4-5": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "azure_ai", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true },
  "azure_ai/claude-opus-4-6": { "supports_adaptive_thinking": true, "input_cost_per_token": 5e-6, "output_cost_per_token": 25e-6, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "supports_max_reasoning_effort": true },
  "azure_ai/claude-opus-4-7": { "supports_adaptive_thinking": true, "input_cost_per_token": 5e-6, "output_cost_per_token": 25e-6, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true },
  "azure_ai/claude-fable-5": { "supports_mid_conversation_system": true, "input_cost_per_token": 1e-5, "output_cost_per_token": 5e-5, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "cache_creation_input_token_cost": 125e-7, "cache_creation_input_token_cost_above_1hr": 2e-5, "cache_read_input_token_cost": 1e-6, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true },
  "azure_ai/claude-opus-5": { "supports_mid_conversation_system": true, "supports_adaptive_thinking": true, "input_cost_per_token": 5e-6, "output_cost_per_token": 25e-6, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 512 },
  "azure_ai/claude-opus-4-8": { "supports_mid_conversation_system": true, "supports_adaptive_thinking": true, "input_cost_per_token": 5e-6, "output_cost_per_token": 25e-6, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true },
  "azure_ai/claude-opus-4-1": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "azure_ai", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "azure_ai/claude-sonnet-4-5": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "azure_ai", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "azure_ai/claude-sonnet-5": { "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_1hr": 4e-6, "cache_read_input_token_cost": 2e-7, "input_cost_per_token": 2e-6, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 1e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true },
  "azure_ai/claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "azure_ai", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true },
  "bedrock/ap-northeast-1/anthropic.claude-instant-v1": { "input_cost_per_token": 223e-8, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 755e-8, "supports_tool_choice": true },
  "bedrock/ap-northeast-1/anthropic.claude-v1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/ap-northeast-1/anthropic.claude-v2:1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/eu-central-1/anthropic.claude-instant-v1": { "input_cost_per_token": 248e-8, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 838e-8, "supports_tool_choice": true },
  "bedrock/eu-central-1/anthropic.claude-v1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6 },
  "bedrock/eu-central-1/anthropic.claude-v2:1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/invoke/anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "metadata": { "notes": "Anthropic via Invoke route does not currently support pdf input." }, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "bedrock/us-east-1/anthropic.claude-instant-v1": { "input_cost_per_token": 8e-7, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-7, "supports_tool_choice": true },
  "bedrock/us-east-1/anthropic.claude-v1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/us-east-1/anthropic.claude-v2:1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/us-gov-east-1/anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 36e-8, "cache_creation_input_token_cost": 45e-7 },
  "bedrock/us-gov-east-1/anthropic.claude-3-haiku-20240307-v1:0": { "input_cost_per_token": 3e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-7, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-8, "cache_creation_input_token_cost": 375e-9 },
  "bedrock/us-gov-east-1/anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_creation_input_token_cost_above_1hr": 72e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "bedrock/us-gov-east-1/claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_creation_input_token_cost_above_1hr": 72e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "bedrock/us-gov-west-1/anthropic.claude-3-7-sonnet-20250219-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "bedrock/us-gov-west-1/anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 36e-8, "cache_creation_input_token_cost": 45e-7 },
  "bedrock/us-gov-west-1/anthropic.claude-3-haiku-20240307-v1:0": { "input_cost_per_token": 3e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-7, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-8, "cache_creation_input_token_cost": 375e-9 },
  "bedrock/us-gov-west-1/anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_creation_input_token_cost_above_1hr": 72e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "bedrock/us-gov-west-1/claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_creation_input_token_cost_above_1hr": 72e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "bedrock/us-west-2/anthropic.claude-instant-v1": { "input_cost_per_token": 8e-7, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-7, "supports_tool_choice": true },
  "bedrock/us-west-2/anthropic.claude-v1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/us-west-2/anthropic.claude-v2:1": { "input_cost_per_token": 8e-6, "litellm_provider": "bedrock", "max_input_tokens": 1e5, "max_output_tokens": 8191, "max_tokens": 8191, "mode": "chat", "output_cost_per_token": 24e-6, "supports_tool_choice": true },
  "bedrock/us.anthropic.claude-3-5-haiku-20241022-v1:0": { "cache_creation_input_token_cost": 1e-6, "cache_read_input_token_cost": 8e-8, "input_cost_per_token": 8e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 4e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "prompt_cache_min_tokens": 2048 },
  "claude-haiku-4-5-20251001": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_computer_use": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 4096 },
  "claude-haiku-4-5": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_computer_use": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 4096 },
  "claude-3-7-sonnet-20250219": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "deprecation_date": "2026-02-19", "input_cost_per_token": 3e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true },
  "claude-3-haiku-20240307": { "cache_creation_input_token_cost": 3e-7, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-8, "input_cost_per_token": 25e-8, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "claude-3-opus-20240229": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 15e-7, "deprecation_date": "2026-05-01", "input_cost_per_token": 15e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "claude-4-opus-20250514": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "claude-4-sonnet-20250514": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost": 3e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "prompt_cache_min_tokens": 1024 },
  "claude-sonnet-4-5": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 12e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "claude-sonnet-4-5-20250929": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 12e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "prompt_cache_min_tokens": 1024 },
  "claude-sonnet-5": { "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_1hr": 4e-6, "cache_read_input_token_cost": 2e-7, "input_cost_per_token": 2e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 1e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "provider_specific_entry": { "us": 1.1 }, "supports_output_config": true, "prompt_cache_min_tokens": 1024 },
  "claude-sonnet-4-6": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "prompt_cache_min_tokens": 1024 },
  "claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 12e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "claude-opus-4-1": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "claude-opus-4-1-20250805": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "deprecation_date": "2026-08-05", "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "claude-opus-4-20250514": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "deprecation_date": "2026-05-14", "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "claude-opus-4-5-20251101": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "prompt_cache_min_tokens": 4096 },
  "claude-opus-4-5": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "prompt_cache_min_tokens": 4096 },
  "claude-opus-4-6": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "provider_specific_entry": { "us": 1.1, "fast": 6 }, "supports_output_config": true, "supports_max_reasoning_effort": true, "supports_speed": true, "prompt_cache_min_tokens": 4096 },
  "claude-opus-4-6-20260205": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_tool_choice": true, "supports_vision": true, "provider_specific_entry": { "us": 1.1, "fast": 6 }, "supports_max_reasoning_effort": true, "supports_output_config": true, "supports_speed": true, "prompt_cache_min_tokens": 4096 },
  "claude-opus-4-7": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "provider_specific_entry": { "us": 1.1, "fast": 6 }, "supports_output_config": true, "supports_speed": true, "prompt_cache_min_tokens": 2048 },
  "claude-opus-4-7-20260416": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "provider_specific_entry": { "us": 1.1, "fast": 6 }, "supports_output_config": true, "supports_speed": true, "prompt_cache_min_tokens": 2048 },
  "claude-fable-5": { "cache_creation_input_token_cost": 125e-7, "cache_creation_input_token_cost_above_1hr": 2e-5, "cache_read_input_token_cost": 1e-6, "input_cost_per_token": 1e-5, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 5e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "provider_specific_entry": { "us": 1.1 }, "supports_output_config": true, "prompt_cache_min_tokens": 512 },
  "claude-opus-5": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "provider_specific_entry": { "us": 1.1, "fast": 2 }, "supports_output_config": true, "supports_speed": true, "prompt_cache_min_tokens": 512 },
  "claude-opus-4-8": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_native_structured_output": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "provider_specific_entry": { "us": 1.1, "fast": 2 }, "supports_output_config": true, "supports_speed": true, "prompt_cache_min_tokens": 1024 },
  "claude-sonnet-4-20250514": { "deprecation_date": "2026-05-14", "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "anthropic", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "databricks/databricks-claude-3-7-sonnet": { "input_cost_per_token": 29999900000000002e-22, "input_dbu_cost_per_token": 42857e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 128e3, "max_tokens": 128e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 15000020000000002e-21, "output_dbu_cost_per_token": 214286e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "databricks/databricks-claude-haiku-4-5": { "input_cost_per_token": 100002e-11, "input_dbu_cost_per_token": 14286e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 500003e-11, "output_dbu_cost_per_token": 71429e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "databricks/databricks-claude-opus-4": { "input_cost_per_token": 15000020000000002e-21, "input_dbu_cost_per_token": 214286e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 7500003000000001e-20, "output_dbu_cost_per_token": 1071429e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "databricks/databricks-claude-opus-4-1": { "input_cost_per_token": 15000020000000002e-21, "input_dbu_cost_per_token": 214286e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 7500003000000001e-20, "output_dbu_cost_per_token": 1071429e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "databricks/databricks-claude-opus-4-5": { "input_cost_per_token": 500003e-11, "input_dbu_cost_per_token": 71429e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 25000010000000002e-21, "output_dbu_cost_per_token": 357143e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_output_config": true },
  "databricks/databricks-claude-sonnet-4": { "input_cost_per_token": 29999900000000002e-22, "input_dbu_cost_per_token": 42857e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 15000020000000002e-21, "output_dbu_cost_per_token": 214286e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "databricks/databricks-claude-sonnet-4-1": { "input_cost_per_token": 29999900000000002e-22, "input_dbu_cost_per_token": 42857e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 15000020000000002e-21, "output_dbu_cost_per_token": 214286e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "databricks/databricks-claude-sonnet-4-5": { "input_cost_per_token": 29999900000000002e-22, "input_dbu_cost_per_token": 42857e-9, "litellm_provider": "databricks", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "metadata": { "notes": "Input/output cost per token is dbu cost * $0.070. Number provided for reference, '*_dbu_cost_per_token' used in actual calculation." }, "mode": "chat", "output_cost_per_token": 15000020000000002e-21, "output_dbu_cost_per_token": 214286e-9, "source": "https://www.databricks.com/product/pricing/proprietary-foundation-model-serving", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true },
  "deepinfra/anthropic/claude-3-7-sonnet-latest": { "max_tokens": 2e5, "max_input_tokens": 2e5, "max_output_tokens": 2e5, "input_cost_per_token": 33e-7, "output_cost_per_token": 165e-7, "cache_read_input_token_cost": 33e-8, "litellm_provider": "deepinfra", "mode": "chat", "supports_tool_choice": true, "supports_function_calling": true },
  "deepinfra/anthropic/claude-4-opus": { "max_tokens": 2e5, "max_input_tokens": 2e5, "max_output_tokens": 2e5, "input_cost_per_token": 165e-7, "output_cost_per_token": 825e-7, "litellm_provider": "deepinfra", "mode": "chat", "supports_tool_choice": true, "supports_function_calling": true },
  "deepinfra/anthropic/claude-4-sonnet": { "max_tokens": 2e5, "max_input_tokens": 2e5, "max_output_tokens": 2e5, "input_cost_per_token": 33e-7, "output_cost_per_token": 165e-7, "litellm_provider": "deepinfra", "mode": "chat", "supports_tool_choice": true, "supports_function_calling": true },
  "eu.anthropic.claude-3-5-haiku-20241022-v1:0": { "input_cost_per_token": 25e-8, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 125e-8, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "cache_read_input_token_cost": 25e-9, "cache_creation_input_token_cost": 3125e-10, "prompt_cache_min_tokens": 2048 },
  "eu.anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 1375e-9, "cache_creation_input_token_cost_above_1hr": 22e-7, "cache_read_input_token_cost": 11e-8, "input_cost_per_token": 11e-7, "deprecation_date": "2026-10-15", "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 55e-7, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "eu.anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "eu.anthropic.claude-3-5-sonnet-20241022-v2:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "eu.anthropic.claude-3-7-sonnet-20250219-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "eu.anthropic.claude-3-haiku-20240307-v1:0": { "input_cost_per_token": 25e-8, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 25e-9, "cache_creation_input_token_cost": 3125e-10 },
  "eu.anthropic.claude-3-opus-20240229-v1:0": { "input_cost_per_token": 15e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_function_calling": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 15e-7, "cache_creation_input_token_cost": 1875e-8 },
  "eu.anthropic.claude-3-sonnet-20240229-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "eu.anthropic.claude-opus-4-1-20250805-v1:0": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-opus-4-20250514-v1:0": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-sonnet-4-20250514-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "bedrock_converse_supports_strict_tools": false, "prompt_cache_min_tokens": 1024 },
  "eu.anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "input_cost_per_token_above_200k_tokens": 66e-7, "output_cost_per_token_above_200k_tokens": 2475e-8, "cache_creation_input_token_cost_above_200k_tokens": 825e-8, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 132e-7, "cache_read_input_token_cost_above_200k_tokens": 66e-8, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "gemini-2.5-flash": { "cache_read_input_token_cost": 3e-8, "input_cost_per_audio_token": 1e-6, "input_cost_per_token": 3e-7, "litellm_provider": "vertex_ai-language-models", "max_input_tokens": 1048576, "max_output_tokens": 65535, "max_tokens": 65535, "mode": "chat", "output_cost_per_reasoning_token": 25e-7, "output_cost_per_token": 25e-7, "source": "https://ai.google.dev/gemini-api/docs/models#gemini-2.5-flash-preview", "supported_endpoints": ["/v1/chat/completions", "/v1/completions", "/v1/batch"], "supported_modalities": ["text", "image", "audio", "video"], "supported_output_modalities": ["text"], "supports_audio_output": false, "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_url_context": true, "supports_vision": true, "supports_web_search": true, "search_context_cost_per_query": { "search_context_size_low": 0.035, "search_context_size_medium": 0.035, "search_context_size_high": 0.035 }, "supports_image_size": false },
  "gemini-2.5-flash-lite": { "cache_read_input_token_cost": 1e-8, "input_cost_per_audio_token": 3e-7, "input_cost_per_token": 1e-7, "litellm_provider": "vertex_ai-language-models", "max_input_tokens": 1048576, "max_output_tokens": 65535, "max_tokens": 65535, "mode": "chat", "output_cost_per_reasoning_token": 4e-7, "output_cost_per_token": 4e-7, "source": "https://ai.google.dev/gemini-api/docs/models#gemini-2.5-flash-preview", "supported_endpoints": ["/v1/chat/completions", "/v1/completions", "/v1/batch"], "supported_modalities": ["text", "image", "audio", "video"], "supported_output_modalities": ["text"], "supports_audio_output": false, "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_url_context": true, "supports_vision": true, "supports_web_search": true, "search_context_cost_per_query": { "search_context_size_low": 0.035, "search_context_size_medium": 0.035, "search_context_size_high": 0.035 }, "supports_image_size": false },
  "gemini-2.5-pro": { "cache_read_input_token_cost": 125e-9, "cache_read_input_token_cost_above_200k_tokens": 25e-8, "cache_creation_input_token_cost_above_200k_tokens": 25e-8, "input_cost_per_token": 125e-8, "input_cost_per_token_above_200k_tokens": 25e-7, "litellm_provider": "vertex_ai-language-models", "max_input_tokens": 1048576, "max_output_tokens": 65535, "max_tokens": 65535, "mode": "chat", "output_cost_per_token": 1e-5, "output_cost_per_token_above_200k_tokens": 15e-6, "source": "https://cloud.google.com/vertex-ai/generative-ai/pricing", "supported_endpoints": ["/v1/chat/completions", "/v1/completions"], "supported_modalities": ["text", "image", "audio", "video"], "supported_output_modalities": ["text"], "supports_audio_input": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_video_input": true, "supports_vision": true, "supports_web_search": true, "search_context_cost_per_query": { "search_context_size_low": 0.035, "search_context_size_medium": 0.035, "search_context_size_high": 0.035 } },
  "gmi/anthropic/claude-opus-4.5": { "input_cost_per_token": 5e-6, "litellm_provider": "gmi", "max_input_tokens": 409600, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_function_calling": true, "supports_vision": true, "supports_output_config": true },
  "gmi/anthropic/claude-sonnet-4.5": { "input_cost_per_token": 3e-6, "litellm_provider": "gmi", "max_input_tokens": 409600, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_vision": true },
  "gmi/anthropic/claude-sonnet-4": { "input_cost_per_token": 3e-6, "litellm_provider": "gmi", "max_input_tokens": 409600, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_vision": true },
  "gmi/anthropic/claude-opus-4": { "input_cost_per_token": 15e-6, "litellm_provider": "gmi", "max_input_tokens": 409600, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_function_calling": true, "supports_vision": true },
  "global.anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 12e-6, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "global.anthropic.claude-sonnet-4-20250514-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "bedrock_converse_supports_strict_tools": false, "prompt_cache_min_tokens": 1024 },
  "global.anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "gpt-5.2": { "cache_read_input_token_cost": 175e-9, "cache_read_input_token_cost_priority": 35e-8, "input_cost_per_token": 175e-8, "input_cost_per_token_priority": 35e-7, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 14e-6, "output_cost_per_token_priority": 28e-6, "supported_endpoints": ["/v1/chat/completions", "/v1/batch", "/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text", "image"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": true, "supports_xhigh_reasoning_effort": true, "supports_minimal_reasoning_effort": true },
  "gpt-5.6-sol": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_272k_tokens": 125e-7, "cache_creation_input_token_cost_above_272k_tokens_flex": 625e-8, "cache_creation_input_token_cost_flex": 3125e-9, "cache_creation_input_token_cost_priority": 125e-7, "cache_read_input_token_cost": 5e-7, "cache_read_input_token_cost_above_272k_tokens": 1e-6, "cache_read_input_token_cost_above_272k_tokens_flex": 5e-7, "cache_read_input_token_cost_flex": 25e-8, "cache_read_input_token_cost_priority": 1e-6, "input_cost_per_token": 5e-6, "input_cost_per_token_above_272k_tokens": 1e-5, "input_cost_per_token_above_272k_tokens_flex": 5e-6, "input_cost_per_token_batches": 25e-7, "input_cost_per_token_flex": 25e-7, "input_cost_per_token_priority": 1e-5, "litellm_provider": "openai", "max_input_tokens": 105e4, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 3e-5, "output_cost_per_token_above_272k_tokens": 45e-6, "output_cost_per_token_above_272k_tokens_flex": 225e-7, "output_cost_per_token_batches": 15e-6, "output_cost_per_token_flex": 15e-6, "output_cost_per_token_priority": 6e-5, "regional_processing_uplift_multiplier_eu": 1.1, "regional_processing_uplift_multiplier_us": 1.1, "supported_endpoints": ["/v1/chat/completions", "/v1/batch", "/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_minimal_reasoning_effort": false, "supports_native_streaming": true, "supports_none_reasoning_effort": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_xhigh_reasoning_effort": true },
  "gpt-5.6-terra": { "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_272k_tokens": 5e-6, "cache_creation_input_token_cost_above_272k_tokens_flex": 25e-7, "cache_creation_input_token_cost_flex": 125e-8, "cache_creation_input_token_cost_priority": 5e-6, "cache_read_input_token_cost": 2e-7, "cache_read_input_token_cost_above_272k_tokens": 4e-7, "cache_read_input_token_cost_above_272k_tokens_flex": 2e-7, "cache_read_input_token_cost_flex": 1e-7, "cache_read_input_token_cost_priority": 4e-7, "input_cost_per_token": 2e-6, "input_cost_per_token_above_272k_tokens": 4e-6, "input_cost_per_token_above_272k_tokens_flex": 2e-6, "input_cost_per_token_batches": 1e-6, "input_cost_per_token_flex": 1e-6, "input_cost_per_token_priority": 4e-6, "litellm_provider": "openai", "max_input_tokens": 105e4, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 12e-6, "output_cost_per_token_above_272k_tokens": 18e-6, "output_cost_per_token_above_272k_tokens_flex": 9e-6, "output_cost_per_token_batches": 6e-6, "output_cost_per_token_flex": 6e-6, "output_cost_per_token_priority": 24e-6, "regional_processing_uplift_multiplier_eu": 1.1, "regional_processing_uplift_multiplier_us": 1.1, "supported_endpoints": ["/v1/chat/completions", "/v1/batch", "/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_minimal_reasoning_effort": false, "supports_native_streaming": true, "supports_none_reasoning_effort": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_xhigh_reasoning_effort": true },
  "gpt-5.6-luna": { "cache_creation_input_token_cost": 25e-8, "cache_creation_input_token_cost_above_272k_tokens": 5e-7, "cache_creation_input_token_cost_above_272k_tokens_flex": 25e-8, "cache_creation_input_token_cost_flex": 125e-9, "cache_creation_input_token_cost_priority": 5e-7, "cache_read_input_token_cost": 2e-8, "cache_read_input_token_cost_above_272k_tokens": 4e-8, "cache_read_input_token_cost_above_272k_tokens_flex": 2e-8, "cache_read_input_token_cost_flex": 1e-8, "cache_read_input_token_cost_priority": 4e-8, "input_cost_per_token": 2e-7, "input_cost_per_token_above_272k_tokens": 4e-7, "input_cost_per_token_above_272k_tokens_flex": 2e-7, "input_cost_per_token_batches": 1e-7, "input_cost_per_token_flex": 1e-7, "input_cost_per_token_priority": 4e-7, "litellm_provider": "openai", "max_input_tokens": 105e4, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 12e-7, "output_cost_per_token_above_272k_tokens": 18e-7, "output_cost_per_token_above_272k_tokens_flex": 9e-7, "output_cost_per_token_batches": 6e-7, "output_cost_per_token_flex": 6e-7, "output_cost_per_token_priority": 24e-7, "regional_processing_uplift_multiplier_eu": 1.1, "regional_processing_uplift_multiplier_us": 1.1, "supported_endpoints": ["/v1/chat/completions", "/v1/batch", "/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_minimal_reasoning_effort": false, "supports_native_streaming": true, "supports_none_reasoning_effort": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_xhigh_reasoning_effort": true },
  "gpt-5.4": { "cache_read_input_token_cost": 25e-8, "cache_read_input_token_cost_above_272k_tokens": 5e-7, "cache_read_input_token_cost_flex": 13e-8, "cache_read_input_token_cost_priority": 5e-7, "input_cost_per_token": 25e-7, "input_cost_per_token_above_272k_tokens": 5e-6, "input_cost_per_token_flex": 125e-8, "input_cost_per_token_batches": 125e-8, "input_cost_per_token_priority": 5e-6, "litellm_provider": "openai", "max_input_tokens": 105e4, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 15e-6, "output_cost_per_token_above_272k_tokens": 225e-7, "output_cost_per_token_flex": 75e-7, "output_cost_per_token_batches": 75e-7, "output_cost_per_token_priority": 3e-5, "regional_processing_uplift_multiplier_eu": 1.1, "regional_processing_uplift_multiplier_us": 1.1, "supported_endpoints": ["/v1/chat/completions", "/v1/batch", "/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_vision": true, "supports_none_reasoning_effort": true, "supports_xhigh_reasoning_effort": true, "supports_minimal_reasoning_effort": true },
  "gpt-5.4-mini": { "cache_read_input_token_cost": 75e-9, "cache_read_input_token_cost_flex": 375e-10, "cache_read_input_token_cost_priority": 15e-8, "input_cost_per_token": 75e-8, "input_cost_per_token_flex": 375e-9, "input_cost_per_token_batches": 375e-9, "input_cost_per_token_priority": 15e-7, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 45e-7, "output_cost_per_token_flex": 225e-8, "output_cost_per_token_batches": 225e-8, "output_cost_per_token_priority": 9e-6, "regional_processing_uplift_multiplier_eu": 1.1, "regional_processing_uplift_multiplier_us": 1.1, "supported_endpoints": ["/v1/chat/completions", "/v1/batch", "/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": true, "supports_xhigh_reasoning_effort": true, "supports_minimal_reasoning_effort": false },
  "gpt-5.1-codex-max": { "cache_read_input_token_cost": 125e-9, "input_cost_per_token": 125e-8, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "responses", "output_cost_per_token": 1e-5, "supported_endpoints": ["/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": false, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": false, "supports_xhigh_reasoning_effort": true, "supports_minimal_reasoning_effort": true },
  "gpt-5.1-codex-mini": { "cache_read_input_token_cost": 25e-9, "cache_read_input_token_cost_priority": 45e-9, "input_cost_per_token": 25e-8, "input_cost_per_token_priority": 45e-8, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "responses", "output_cost_per_token": 2e-6, "output_cost_per_token_priority": 36e-7, "supported_endpoints": ["/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": false, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": false, "supports_xhigh_reasoning_effort": false, "supports_minimal_reasoning_effort": true },
  "gpt-5.2-codex": { "cache_read_input_token_cost": 175e-9, "cache_read_input_token_cost_priority": 35e-8, "input_cost_per_token": 175e-8, "input_cost_per_token_priority": 35e-7, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "responses", "output_cost_per_token": 14e-6, "output_cost_per_token_priority": 28e-6, "supported_endpoints": ["/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": false, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": false, "supports_xhigh_reasoning_effort": true, "supports_minimal_reasoning_effort": true },
  "gpt-5.3-codex": { "cache_read_input_token_cost": 175e-9, "cache_read_input_token_cost_priority": 35e-8, "input_cost_per_token": 175e-8, "input_cost_per_token_priority": 35e-7, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "responses", "output_cost_per_token": 14e-6, "output_cost_per_token_priority": 28e-6, "supported_endpoints": ["/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": false, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": false, "supports_xhigh_reasoning_effort": false, "supports_minimal_reasoning_effort": true },
  "gradient_ai/anthropic-claude-3-opus": { "input_cost_per_token": 15e-6, "litellm_provider": "gradient_ai", "max_tokens": 1024, "mode": "chat", "output_cost_per_token": 75e-6, "supported_endpoints": ["/v1/chat/completions"], "supported_modalities": ["text"], "supports_tool_choice": false, "max_input_tokens": 2e5, "max_output_tokens": 1024 },
  "gradient_ai/anthropic-claude-3.5-haiku": { "input_cost_per_token": 8e-7, "litellm_provider": "gradient_ai", "max_tokens": 1024, "mode": "chat", "output_cost_per_token": 4e-6, "supported_endpoints": ["/v1/chat/completions"], "supported_modalities": ["text"], "supports_tool_choice": false, "max_input_tokens": 2e5, "max_output_tokens": 1024 },
  "gradient_ai/anthropic-claude-3.5-sonnet": { "input_cost_per_token": 3e-6, "litellm_provider": "gradient_ai", "max_tokens": 1024, "mode": "chat", "output_cost_per_token": 15e-6, "supported_endpoints": ["/v1/chat/completions"], "supported_modalities": ["text"], "supports_tool_choice": false, "max_input_tokens": 2e5, "max_output_tokens": 1024 },
  "gradient_ai/anthropic-claude-3.7-sonnet": { "input_cost_per_token": 3e-6, "litellm_provider": "gradient_ai", "max_tokens": 1024, "mode": "chat", "output_cost_per_token": 15e-6, "supported_endpoints": ["/v1/chat/completions"], "supported_modalities": ["text"], "supports_tool_choice": false, "max_input_tokens": 2e5, "max_output_tokens": 1024 },
  "jp.anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "input_cost_per_token_above_200k_tokens": 66e-7, "output_cost_per_token_above_200k_tokens": 2475e-8, "cache_creation_input_token_cost_above_200k_tokens": 825e-8, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 132e-7, "cache_read_input_token_cost_above_200k_tokens": 66e-8, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "jp.anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 1375e-9, "cache_creation_input_token_cost_above_1hr": 22e-7, "cache_read_input_token_cost": 11e-8, "input_cost_per_token": 11e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 55e-7, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "openrouter/anthropic/claude-3-haiku": { "input_cost_per_image": 4e-4, "input_cost_per_token": 25e-8, "litellm_provider": "openrouter", "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true, "max_input_tokens": 2e5, "max_output_tokens": 4096 },
  "openrouter/anthropic/claude-3.5-sonnet": { "input_cost_per_token": 3e-6, "litellm_provider": "openrouter", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-3.7-sonnet": { "input_cost_per_image": 48e-4, "input_cost_per_token": 3e-6, "litellm_provider": "openrouter", "max_input_tokens": 2e5, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-opus-4": { "input_cost_per_image": 48e-4, "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "openrouter", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-opus-4.1": { "input_cost_per_image": 48e-4, "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "openrouter", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-sonnet-4": { "input_cost_per_image": 48e-4, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost": 3e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "litellm_provider": "openrouter", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-sonnet-4.6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost": 3e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "litellm_provider": "openrouter", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 15e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "source": "https://openrouter.ai/anthropic/claude-sonnet-4.6", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-opus-4.5": { "cache_creation_input_token_cost": 625e-8, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "openrouter", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true },
  "openrouter/anthropic/claude-opus-4.6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "openrouter", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-sonnet-4.5": { "input_cost_per_image": 48e-4, "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "openrouter", "max_input_tokens": 1e6, "max_output_tokens": 1e6, "max_tokens": 1e6, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-haiku-4.5": { "cache_creation_input_token_cost": 125e-8, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "openrouter", "max_input_tokens": 2e5, "max_output_tokens": 2e5, "max_tokens": 2e5, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "openrouter/anthropic/claude-opus-4.7": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "openrouter", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true },
  "replicate/anthropic/claude-4.5-haiku": { "input_cost_per_token": 1e-6, "output_cost_per_token": 5e-6, "litellm_provider": "replicate", "mode": "chat", "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_vision": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_response_schema": true, "supports_prompt_caching": true },
  "replicate/anthropic/claude-4-sonnet": { "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "litellm_provider": "replicate", "mode": "chat", "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_vision": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_response_schema": true, "supports_prompt_caching": true },
  "replicate/anthropic/claude-3.7-sonnet": { "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "litellm_provider": "replicate", "mode": "chat", "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_vision": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_response_schema": true, "supports_prompt_caching": true },
  "replicate/anthropic/claude-3.5-haiku": { "input_cost_per_token": 1e-6, "output_cost_per_token": 5e-6, "litellm_provider": "replicate", "mode": "chat", "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_vision": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_response_schema": true, "supports_prompt_caching": true },
  "replicate/anthropic/claude-3.5-sonnet": { "input_cost_per_token": 375e-8, "output_cost_per_token": 1875e-8, "litellm_provider": "replicate", "mode": "chat", "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_vision": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_response_schema": true, "supports_prompt_caching": true },
  "replicate/anthropic/claude-4.5-sonnet": { "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "litellm_provider": "replicate", "mode": "chat", "supports_function_calling": true, "supports_parallel_function_calling": true, "supports_vision": true, "supports_system_messages": true, "supports_tool_choice": true, "supports_response_schema": true, "supports_prompt_caching": true },
  "snowflake/claude-3-5-sonnet": { "litellm_provider": "snowflake", "max_input_tokens": 2e5, "max_output_tokens": 16384, "max_tokens": 16384, "mode": "chat", "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "cache_read_input_token_cost": 3e-7, "supports_computer_use": true, "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_response_schema": true },
  "us.anthropic.claude-3-5-haiku-20241022-v1:0": { "cache_creation_input_token_cost": 1e-6, "cache_read_input_token_cost": 8e-8, "input_cost_per_token": 8e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 4e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "prompt_cache_min_tokens": 2048 },
  "us.anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 1375e-9, "cache_creation_input_token_cost_above_1hr": 22e-7, "cache_read_input_token_cost": 11e-8, "input_cost_per_token": 11e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 55e-7, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "us.anthropic.claude-3-5-sonnet-20240620-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "us.anthropic.claude-3-5-sonnet-20241022-v2:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "us.anthropic.claude-3-7-sonnet-20250219-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "us.anthropic.claude-3-haiku-20240307-v1:0": { "input_cost_per_token": 25e-8, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 25e-9, "cache_creation_input_token_cost": 3125e-10 },
  "us.anthropic.claude-3-opus-20240229-v1:0": { "input_cost_per_token": 15e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_function_calling": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 15e-7, "cache_creation_input_token_cost": 1875e-8 },
  "us.anthropic.claude-3-sonnet-20240229-v1:0": { "input_cost_per_token": 3e-6, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_pdf_input": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "cache_read_input_token_cost": 3e-7, "cache_creation_input_token_cost": 375e-8 },
  "us.anthropic.claude-opus-4-1-20250805-v1:0": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "us.anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 4125e-9, "cache_creation_input_token_cost_above_1hr": 66e-7, "cache_read_input_token_cost": 33e-8, "input_cost_per_token": 33e-7, "input_cost_per_token_above_200k_tokens": 66e-7, "output_cost_per_token_above_200k_tokens": 2475e-8, "cache_creation_input_token_cost_above_200k_tokens": 825e-8, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 132e-7, "cache_read_input_token_cost_above_200k_tokens": 66e-8, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 165e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "us-gov.anthropic.claude-sonnet-4-5-20250929-v1:0": { "cache_creation_input_token_cost": 45e-7, "cache_creation_input_token_cost_above_1hr": 72e-7, "cache_read_input_token_cost": 36e-8, "input_cost_per_token": 36e-7, "input_cost_per_token_above_200k_tokens": 72e-7, "output_cost_per_token_above_200k_tokens": 27e-6, "cache_creation_input_token_cost_above_200k_tokens": 9e-6, "cache_creation_input_token_cost_above_1hr_above_200k_tokens": 144e-7, "cache_read_input_token_cost_above_200k_tokens": 72e-8, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 18e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 1024 },
  "au.anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 1375e-9, "cache_creation_input_token_cost_above_1hr": 22e-7, "cache_read_input_token_cost": 11e-8, "input_cost_per_token": 11e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 55e-7, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "us.anthropic.claude-opus-4-20250514-v1:0": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "us.anthropic.claude-opus-4-5-20251101-v1:0": { "cache_creation_input_token_cost": 6875e-9, "cache_creation_input_token_cost_above_1hr": 11e-6, "cache_read_input_token_cost": 55e-8, "input_cost_per_token": 55e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 275e-7, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "high", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "global.anthropic.claude-opus-4-5-20251101-v1:0": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "high", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "eu.anthropic.claude-opus-4-5-20251101-v1:0": { "cache_creation_input_token_cost": 625e-8, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "bedrock_converse", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_output_config": true, "bedrock_output_config_effort_ceiling": "high", "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "us.anthropic.claude-sonnet-4-20250514-v1:0": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "bedrock_converse", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "bedrock_converse_supports_strict_tools": false, "prompt_cache_min_tokens": 1024 },
  "vercel_ai_gateway/anthropic/claude-3-haiku": { "cache_creation_input_token_cost": 3e-7, "cache_read_input_token_cost": 3e-8, "input_cost_per_token": 25e-8, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_vision": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_response_schema": true },
  "vercel_ai_gateway/anthropic/claude-3-opus": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_vision": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_response_schema": true },
  "vercel_ai_gateway/anthropic/claude-3.5-haiku": { "cache_creation_input_token_cost": 1e-6, "cache_read_input_token_cost": 8e-8, "input_cost_per_token": 8e-7, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 4e-6, "supports_vision": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_response_schema": true },
  "vercel_ai_gateway/anthropic/claude-3.5-sonnet": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_vision": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_response_schema": true },
  "vercel_ai_gateway/anthropic/claude-3.7-sonnet": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_vision": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_response_schema": true },
  "vercel_ai_gateway/anthropic/claude-4-opus": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_vision": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_response_schema": true },
  "vercel_ai_gateway/anthropic/claude-4-sonnet": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_function_calling": true, "supports_tool_choice": true },
  "vercel_ai_gateway/anthropic/claude-3-5-sonnet": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-3-5-sonnet-20241022": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-3-7-sonnet": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-haiku-4.5": { "cache_creation_input_token_cost": 125e-8, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-opus-4": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-opus-4.1": { "cache_creation_input_token_cost": 1875e-8, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-opus-4.5": { "cache_creation_input_token_cost": 625e-8, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true },
  "vercel_ai_gateway/anthropic/claude-opus-4.6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true },
  "vercel_ai_gateway/anthropic/claude-sonnet-4": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vercel_ai_gateway/anthropic/claude-sonnet-4.5": { "cache_creation_input_token_cost": 375e-8, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vercel_ai_gateway", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-5-haiku": { "input_cost_per_token": 1e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_tool_choice": true },
  "vertex_ai/claude-3-5-haiku@20241022": { "input_cost_per_token": 1e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 5e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_tool_choice": true },
  "vertex_ai/claude-haiku-4-5": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 5e-6, "source": "https://cloud.google.com/vertex-ai/generative-ai/docs/partner-models/claude/haiku-4-5", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_native_streaming": true, "supports_vision": true, "prompt_cache_min_tokens": 4096 },
  "vertex_ai/claude-haiku-4-5@20251001": { "cache_creation_input_token_cost": 125e-8, "cache_creation_input_token_cost_above_1hr": 2e-6, "cache_read_input_token_cost": 1e-7, "input_cost_per_token": 1e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 5e-6, "source": "https://cloud.google.com/vertex-ai/generative-ai/docs/partner-models/claude/haiku-4-5", "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_native_streaming": true, "supports_vision": true, "prompt_cache_min_tokens": 4096 },
  "vertex_ai/claude-3-5-sonnet": { "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-5-sonnet@20240620": { "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-7-sonnet@20250219": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "deprecation_date": "2026-05-11", "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 8192, "max_tokens": 8192, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-haiku": { "input_cost_per_token": 25e-8, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-haiku@20240307": { "input_cost_per_token": 25e-8, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 125e-8, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-opus": { "input_cost_per_token": 15e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-opus@20240229": { "input_cost_per_token": 15e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 75e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-sonnet": { "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-3-sonnet@20240229": { "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 4096, "max_tokens": 4096, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-opus-4": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-opus-4-1": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "input_cost_per_token_batches": 75e-7, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "output_cost_per_token_batches": 375e-7, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-opus-4-1@20250805": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "input_cost_per_token_batches": 75e-7, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "output_cost_per_token_batches": 375e-7, "supports_assistant_prefill": true, "supports_function_calling": true, "supports_tool_choice": true, "supports_vision": true },
  "vertex_ai/claude-opus-4-5": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "prompt_cache_min_tokens": 4096 },
  "vertex_ai/claude-opus-4-5@20251101": { "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_streaming": true, "supports_output_config": true, "prompt_cache_min_tokens": 4096 },
  "vertex_ai/claude-opus-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 4096 },
  "vertex_ai/claude-opus-4-6@default": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_output_config": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 4096 },
  "vertex_ai/claude-opus-4-7": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 2048 },
  "vertex_ai/claude-opus-4-7@default": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 2048 },
  "vertex_ai/claude-fable-5": { "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 125e-7, "cache_creation_input_token_cost_above_1hr": 2e-5, "cache_read_input_token_cost": 1e-6, "input_cost_per_token": 1e-5, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 5e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true },
  "vertex_ai/claude-fable-5@default": { "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 125e-7, "cache_creation_input_token_cost_above_1hr": 2e-5, "cache_read_input_token_cost": 1e-6, "input_cost_per_token": 1e-5, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 5e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true },
  "vertex_ai/claude-opus-5": { "supports_mid_conversation_system": true, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 512 },
  "vertex_ai/claude-opus-5@default": { "supports_mid_conversation_system": true, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 512 },
  "vertex_ai/claude-opus-4-8": { "supports_mid_conversation_system": true, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-opus-4-8@default": { "supports_mid_conversation_system": true, "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 625e-8, "cache_creation_input_token_cost_above_1hr": 1e-5, "cache_read_input_token_cost": 5e-7, "input_cost_per_token": 5e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 25e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-4-5": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "input_cost_per_token_batches": 15e-7, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "output_cost_per_token_batches": 75e-7, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-5": { "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_1hr": 4e-6, "cache_read_input_token_cost": 2e-7, "input_cost_per_token": 2e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 1e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-4-6": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_output_config": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-4-5@20250929": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "input_cost_per_token_batches": 15e-7, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "output_cost_per_token_batches": 75e-7, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_streaming": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-opus-4@20250514": { "cache_creation_input_token_cost": 1875e-8, "cache_creation_input_token_cost_above_1hr": 3e-5, "cache_read_input_token_cost": 15e-7, "input_cost_per_token": 15e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 2e5, "max_output_tokens": 32e3, "max_tokens": 32e3, "mode": "chat", "output_cost_per_token": 75e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-4": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-4@20250514": { "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "input_cost_per_token_above_200k_tokens": 6e-6, "output_cost_per_token_above_200k_tokens": 225e-7, "cache_creation_input_token_cost_above_200k_tokens": 75e-7, "cache_read_input_token_cost_above_200k_tokens": 6e-7, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-5@default": { "supports_mid_conversation_system": true, "cache_creation_input_token_cost": 25e-7, "cache_creation_input_token_cost_above_1hr": 4e-6, "cache_read_input_token_cost": 2e-7, "input_cost_per_token": 2e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "chat", "output_cost_per_token": 1e-5, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_adaptive_thinking": true, "supports_assistant_prefill": false, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_sampling_params": false, "supports_tool_choice": true, "supports_vision": true, "supports_xhigh_reasoning_effort": true, "supports_max_reasoning_effort": true, "prompt_cache_min_tokens": 1024 },
  "vertex_ai/claude-sonnet-4-6@default": { "supports_adaptive_thinking": true, "cache_creation_input_token_cost": 375e-8, "cache_creation_input_token_cost_above_1hr": 6e-6, "cache_read_input_token_cost": 3e-7, "input_cost_per_token": 3e-6, "litellm_provider": "vertex_ai-anthropic_models", "max_input_tokens": 1e6, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 15e-6, "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_max_reasoning_effort": true, "supports_tool_choice": true, "supports_vision": true, "search_context_cost_per_query": { "search_context_size_high": 0.01, "search_context_size_low": 0.01, "search_context_size_medium": 0.01 }, "supports_output_config": true, "prompt_cache_min_tokens": 1024 },
  "bedrock/us-gov-east-1/anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 15e-7, "cache_creation_input_token_cost_above_1hr": 24e-7, "cache_read_input_token_cost": 12e-8, "input_cost_per_token": 12e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 6e-6, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_pdf_input": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "bedrock/us-gov-west-1/anthropic.claude-haiku-4-5-20251001-v1:0": { "cache_creation_input_token_cost": 15e-7, "cache_creation_input_token_cost_above_1hr": 24e-7, "cache_read_input_token_cost": 12e-8, "input_cost_per_token": 12e-7, "litellm_provider": "bedrock", "max_input_tokens": 2e5, "max_output_tokens": 64e3, "max_tokens": 64e3, "mode": "chat", "output_cost_per_token": 6e-6, "source": "https://aws.amazon.com/about-aws/whats-new/2025/10/claude-4-5-haiku-anthropic-amazon-bedrock", "supports_assistant_prefill": true, "supports_computer_use": true, "supports_function_calling": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_tool_choice": true, "supports_vision": true, "supports_native_structured_output": true, "supports_pdf_input": true, "supports_parallel_tool_use_config": true, "prompt_cache_min_tokens": 4096 },
  "snowflake/claude-sonnet-4-5": { "max_tokens": 16384, "max_input_tokens": 2e5, "max_output_tokens": 16384, "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "cache_read_input_token_cost": 3e-7, "litellm_provider": "snowflake", "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_response_schema": true },
  "snowflake/claude-sonnet-4-6": { "supports_adaptive_thinking": true, "max_tokens": 16384, "max_input_tokens": 2e5, "max_output_tokens": 16384, "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "cache_read_input_token_cost": 3e-7, "litellm_provider": "snowflake", "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_response_schema": true },
  "snowflake/claude-4-sonnet": { "max_tokens": 16384, "max_input_tokens": 2e5, "max_output_tokens": 16384, "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "cache_read_input_token_cost": 3e-7, "litellm_provider": "snowflake", "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_response_schema": true },
  "snowflake/claude-4-opus": { "max_tokens": 16384, "max_input_tokens": 2e5, "max_output_tokens": 16384, "input_cost_per_token": 5e-6, "output_cost_per_token": 25e-6, "cache_read_input_token_cost": 5e-7, "litellm_provider": "snowflake", "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_reasoning": true, "supports_response_schema": true },
  "snowflake/claude-haiku-4-5": { "max_tokens": 16384, "max_input_tokens": 2e5, "max_output_tokens": 16384, "input_cost_per_token": 1e-6, "output_cost_per_token": 5e-6, "cache_read_input_token_cost": 1e-7, "litellm_provider": "snowflake", "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_response_schema": true },
  "snowflake/claude-3-7-sonnet": { "max_tokens": 16384, "max_input_tokens": 2e5, "max_output_tokens": 16384, "input_cost_per_token": 3e-6, "output_cost_per_token": 15e-6, "cache_read_input_token_cost": 3e-7, "litellm_provider": "snowflake", "mode": "chat", "supports_function_calling": true, "supports_vision": true, "supports_prompt_caching": true, "supports_system_messages": true, "supports_reasoning": true, "supports_response_schema": true },
  "gpt-5.3-codex-spark": { "cache_read_input_token_cost": 175e-9, "cache_read_input_token_cost_priority": 35e-8, "input_cost_per_token": 175e-8, "input_cost_per_token_priority": 35e-7, "litellm_provider": "openai", "max_input_tokens": 272e3, "max_output_tokens": 128e3, "max_tokens": 128e3, "mode": "responses", "output_cost_per_token": 14e-6, "output_cost_per_token_priority": 28e-6, "supported_endpoints": ["/v1/responses"], "supported_modalities": ["text", "image"], "supported_output_modalities": ["text"], "supports_function_calling": true, "supports_native_streaming": true, "supports_parallel_function_calling": true, "supports_pdf_input": true, "supports_prompt_caching": true, "supports_reasoning": true, "supports_response_schema": true, "supports_system_messages": false, "supports_tool_choice": true, "supports_vision": true, "supports_web_search": true, "supports_none_reasoning_effort": false, "supports_xhigh_reasoning_effort": false, "supports_minimal_reasoning_effort": true }
};
const TIER_THRESHOLD = 2e5;
const PRICING_MAP = pricingData;
const PRICING_ALIASES = {
  "gpt-5.3-codex-spark": "gpt-5.3-codex"
};
const LOWERCASE_KEY_MAP = /* @__PURE__ */ new Map();
for (const key of Object.keys(PRICING_MAP)) {
  if (!LOWERCASE_KEY_MAP.has(key.toLowerCase())) {
    LOWERCASE_KEY_MAP.set(key.toLowerCase(), key);
  }
}
function isLiteLLMPricing(entry) {
  return !!entry && typeof entry === "object" && "input_cost_per_token" in entry && "output_cost_per_token" in entry;
}
function tryGetPricing(key) {
  const entry = PRICING_MAP[key];
  return isLiteLLMPricing(entry) ? entry : null;
}
function getPricing(modelName) {
  const exact = tryGetPricing(modelName);
  if (exact) return exact;
  const lowerName = modelName.toLowerCase();
  const originalKey = LOWERCASE_KEY_MAP.get(lowerName);
  if (originalKey) {
    return tryGetPricing(originalKey);
  }
  const alias = PRICING_ALIASES[lowerName];
  if (alias) {
    const aliased = tryGetPricing(alias);
    if (aliased) return aliased;
  }
  return null;
}
function calculateTieredCost(tokens, baseRate, tieredRate) {
  if (tokens <= 0) return 0;
  if (tieredRate == null || tokens <= TIER_THRESHOLD) {
    return tokens * baseRate;
  }
  const costBelow = TIER_THRESHOLD * baseRate;
  const costAbove = (tokens - TIER_THRESHOLD) * tieredRate;
  return costBelow + costAbove;
}
function calculateMessageCost(modelName, inputTokens, outputTokens, cacheReadTokens, cacheCreationTokens) {
  if (modelName === "<synthetic>") {
    return 0;
  }
  const pricing = getPricing(modelName);
  if (!pricing) {
    if (inputTokens > 0 || outputTokens > 0 || cacheReadTokens > 0 || cacheCreationTokens > 0) {
      console.warn(`[pricing] No pricing data for model "${modelName}", cost will be $0`);
    }
    return 0;
  }
  const inputCost = calculateTieredCost(
    inputTokens,
    pricing.input_cost_per_token,
    pricing.input_cost_per_token_above_200k_tokens
  );
  const outputCost = calculateTieredCost(
    outputTokens,
    pricing.output_cost_per_token,
    pricing.output_cost_per_token_above_200k_tokens
  );
  const cacheCreationCost = calculateTieredCost(
    cacheCreationTokens,
    pricing.cache_creation_input_token_cost ?? 0,
    pricing.cache_creation_input_token_cost_above_200k_tokens
  );
  const cacheReadCost = calculateTieredCost(
    cacheReadTokens,
    pricing.cache_read_input_token_cost ?? 0,
    pricing.cache_read_input_token_cost_above_200k_tokens
  );
  return inputCost + outputCost + cacheCreationCost + cacheReadCost;
}
function validMessagePosition(message) {
  return Number.isFinite(Date.parse(message.timestamp)) && typeof message.messageId === "string" && message.messageId.trim().length > 0;
}
function compareNewestFirst(left, right) {
  return Date.parse(right.timestamp) - Date.parse(left.timestamp) || (left.messageId ?? "").localeCompare(right.messageId ?? "");
}
function isMessageAfterCursor(message, cursor) {
  if (!cursor) return true;
  const time = Date.parse(message.timestamp);
  return time < cursor.timestampMs || time === cursor.timestampMs && (message.messageId ?? "").localeCompare(cursor.messageId) > 0;
}
function parseHistoryCursor(value) {
  if (value == null) return { kind: "cursor", cursor: null };
  const separator = value.indexOf("|");
  const timestampMs = Date.parse(value.slice(0, separator));
  const messageId = value.slice(separator + 1);
  if (separator < 1 || !Number.isFinite(timestampMs) || !messageId.trim()) {
    return { kind: "invalid-request", reason: "invalid_cursor" };
  }
  return { kind: "cursor", cursor: { timestampMs, messageId } };
}
function provenPagePrefix(windows) {
  let frontier;
  const sourceTruncated = windows.some((window) => window.truncated);
  for (const window of windows) {
    if (window.messages.some((message) => !validMessagePosition(message))) {
      return { kind: "unavailable", reason: "invalid_message" };
    }
    if (!window.truncated) continue;
    if (!window.messages.length) return { kind: "busy", reason: "no_progress" };
    const oldest = window.messages.reduce((a, b) => compareNewestFirst(a, b) > 0 ? a : b);
    if (!frontier || compareNewestFirst(oldest, frontier) < 0) frontier = oldest;
  }
  return {
    kind: "prefix",
    sourceTruncated,
    messages: windows.flatMap((window) => window.messages).filter((message) => !frontier || compareNewestFirst(message, frontier) <= 0)
  };
}
const semanticFields = {
  // Captured destinations affect navigation/reply availability, not durable message identity.
  crossTeamNavigation: true,
  from: true,
  to: true,
  text: true,
  timestamp: true,
  read: true,
  taskRefs: true,
  actionMode: true,
  commentId: true,
  summary: true,
  color: true,
  messageId: true,
  groupChatId: true,
  groupChatName: true,
  groupMessageId: true,
  groupChatProtocolVersion: true,
  groupRunKey: true,
  groupRecipientNames: true,
  groupRecipientRunKeys: true,
  groupDeliverySummary: true,
  groupHandoffStartedAt: true,
  relayOfMessageId: true,
  source: true,
  attachments: true,
  fileReferences: true,
  nativeAttachmentDelivery: true,
  leadSessionId: true,
  conversationId: true,
  replyToConversationId: true,
  toolSummary: true,
  toolCalls: true,
  messageKind: true,
  agentError: true,
  runtimeRecovery: true,
  workSyncIntent: true,
  workSyncIntentKey: true,
  workSyncReviewRequestEventIds: true,
  workSyncRuntimeTicketId: true,
  workSyncRuntimeGeneration: true,
  workSyncRuntimeInstanceId: true,
  workSyncAdmissionPayloadHash: true,
  workSyncTeamIncarnation: true,
  workSyncControlRevision: true,
  workSyncPayloadHash: true,
  slashCommand: true,
  commandOutput: true
};
function canonicalSemanticValue(value) {
  if (value == null) return "null";
  if (Array.isArray(value)) return `[${value.map(canonicalSemanticValue).join(",")}]`;
  if (typeof value === "object") {
    const row2 = value;
    return `{${Object.keys(row2).sort().map((key) => `${JSON.stringify(key)}:${canonicalSemanticValue(row2[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}
function messageSemanticEntry(message) {
  return canonicalSemanticValue(
    Object.fromEntries(
      Object.keys(semanticFields).map((key) => [key, message[key]])
    )
  );
}
function sourceSemanticEntry(message) {
  return {
    identity: message.messageId ?? "",
    semantic: messageSemanticEntry(message),
    // Lead-copy selection and slash/session annotation can depend on source order.
    orderSensitive: !!message.leadSessionId || !!message.slashCommand || message.source === "lead_session" || message.source === "lead_process" || message.source === "user_sent" && message.text.trim().startsWith("/")
  };
}
function orderedSourceSemantics(entries) {
  if (entries.some((entry) => entry.orderSensitive)) return entries.map((entry) => entry.semantic);
  return [...entries].sort((a, b) => a.identity.localeCompare(b.identity)).map((entry) => entry.semantic);
}
class TeamHistoryError extends Error {
  constructor(reason) {
    super(`TEAM_HISTORY_UNAVAILABLE:${reason}`);
    this.reason = reason;
    this.name = "TeamHistoryError";
  }
  reason;
}
function sourceEntriesRevision(entries) {
  const hash2 = crypto$1.createHash("sha256");
  for (const entry of orderedSourceSemantics(entries)) hash2.update(entry).update("\n");
  return hash2.digest("hex").slice(0, 24);
}
function toFeedRevision(messages) {
  const hash2 = crypto$1.createHash("sha256");
  for (const message of messages) hash2.update(messageSemanticEntry(message)).update("\n");
  return hash2.digest("hex").slice(0, 24);
}
function toSourceRevision(sources, precomputed = {}, normalizationContext = null) {
  const hash2 = crypto$1.createHash("sha256").update(canonicalSemanticValue(normalizationContext));
  const names2 = [.../* @__PURE__ */ new Set([...Object.keys(sources), ...Object.keys(precomputed)])].sort();
  for (const name2 of names2) {
    const revision = precomputed[name2] ?? sourceEntriesRevision(
      (sources[name2] ?? []).filter((message) => !taskHistory.isTeamInternalControlMessageEnvelope(message)).map(sourceSemanticEntry)
    );
    hash2.update(canonicalSemanticValue([name2, revision]));
  }
  return hash2.digest("hex").slice(0, 24);
}
async function readInboxWindow(ports, options) {
  const limit = Math.max(1, Math.floor(options.limit));
  const cursor = options.cursor ?? null;
  if (cursor && (!Number.isFinite(cursor.timestampMs) || !cursor.messageId.trim())) {
    return { kind: "unavailable", reason: "invalid_cursor" };
  }
  let members;
  try {
    members = (await ports.listMembers()).sort((a, b) => a.localeCompare(b));
  } catch {
    return { kind: "unavailable", reason: "listing_failed" };
  }
  const revisions = /* @__PURE__ */ new Map();
  let messages = [];
  let sourceMessageCount = 0;
  let truncated = false;
  try {
    for (const member2 of members) {
      const data = await ports.readMember(member2);
      const entries = [];
      try {
        assertValidGroupInboxRows(JSON.parse(data.raw));
      } catch {
        return { kind: "unavailable", reason: "invalid_json" };
      }
      let invalidPosition = false;
      const consume = (message) => {
        ports.assignRecipient(message, member2);
        if (!validMessagePosition(message)) {
          invalidPosition = true;
          return;
        }
        sourceMessageCount += 1;
        if (!taskHistory.isTeamInternalControlMessageEnvelope(message))
          entries.push(sourceSemanticEntry(message));
        if (message.groupChatId && message.groupMessageId !== message.messageId) return;
        if (options.groupChatId && message.groupChatId !== options.groupChatId) return;
        if (!isMessageAfterCursor(message, cursor)) return;
        messages.push(message);
        if (messages.length > limit) {
          truncated = true;
          messages.sort(compareNewestFirst);
          messages = messages.slice(0, limit);
        }
      };
      if (!ports.visit(data.raw, (item) => {
        const message = ports.normalize(item);
        if (message) consume(message);
      })) {
        return { kind: "unavailable", reason: "invalid_json" };
      }
      if (invalidPosition) return { kind: "unavailable", reason: "invalid_message" };
      revisions.set(member2, sourceEntriesRevision(entries));
    }
  } catch (error) {
    return {
      kind: "unavailable",
      reason: error instanceof TeamHistoryError ? error.reason : "read_failed"
    };
  }
  messages.sort(compareNewestFirst);
  return {
    kind: "window",
    inboxCompleteness: "complete",
    window: {
      messages,
      truncated,
      sourceMessageCount,
      sourceRevision: toSourceRevision({}, Object.fromEntries(revisions))
    }
  };
}
function unwrapInboxWindow(outcome) {
  if (outcome.kind === "unavailable") throw new TeamHistoryError(outcome.reason);
  return outcome.window;
}
function readTeamInboxWorkSyncFields(row2) {
  return {
    ...row2.workSyncIntent === "agenda_sync" || row2.workSyncIntent === "review_pickup" ? { workSyncIntent: row2.workSyncIntent } : {},
    ...typeof row2.workSyncIntentKey === "string" ? { workSyncIntentKey: row2.workSyncIntentKey } : {},
    ...Array.isArray(row2.workSyncReviewRequestEventIds) ? {
      workSyncReviewRequestEventIds: row2.workSyncReviewRequestEventIds.filter(
        (id2) => typeof id2 === "string" && id2.length > 0
      )
    } : {},
    ...typeof row2.workSyncPayloadHash === "string" ? { workSyncPayloadHash: row2.workSyncPayloadHash } : {},
    ...typeof row2.workSyncRuntimeTicketId === "string" ? { workSyncRuntimeTicketId: row2.workSyncRuntimeTicketId } : {},
    ...typeof row2.workSyncRuntimeGeneration === "number" && Number.isInteger(row2.workSyncRuntimeGeneration) ? { workSyncRuntimeGeneration: row2.workSyncRuntimeGeneration } : {},
    ...typeof row2.workSyncRuntimeInstanceId === "string" ? { workSyncRuntimeInstanceId: row2.workSyncRuntimeInstanceId } : {},
    ...typeof row2.workSyncAdmissionPayloadHash === "string" ? { workSyncAdmissionPayloadHash: row2.workSyncAdmissionPayloadHash } : {},
    ...typeof row2.workSyncTeamIncarnation === "string" ? { workSyncTeamIncarnation: row2.workSyncTeamIncarnation } : {},
    ...typeof row2.workSyncControlRevision === "number" && Number.isInteger(row2.workSyncControlRevision) ? { workSyncControlRevision: row2.workSyncControlRevision } : {}
  };
}
function pickTeamInboxWorkSyncFields(request) {
  return {
    ...request.workSyncIntent ? { workSyncIntent: request.workSyncIntent } : {},
    ...request.workSyncIntentKey ? { workSyncIntentKey: request.workSyncIntentKey } : {},
    ...request.workSyncReviewRequestEventIds?.length ? { workSyncReviewRequestEventIds: request.workSyncReviewRequestEventIds } : {},
    ...request.workSyncRuntimeTicketId ? { workSyncRuntimeTicketId: request.workSyncRuntimeTicketId } : {},
    ...typeof request.workSyncRuntimeGeneration === "number" ? { workSyncRuntimeGeneration: request.workSyncRuntimeGeneration } : {},
    ...request.workSyncRuntimeInstanceId ? { workSyncRuntimeInstanceId: request.workSyncRuntimeInstanceId } : {},
    ...typeof request.workSyncControlRevision === "number" ? { workSyncControlRevision: request.workSyncControlRevision } : {},
    ...request.workSyncPayloadHash ? { workSyncPayloadHash: request.workSyncPayloadHash } : {},
    ...request.workSyncAdmissionPayloadHash ? { workSyncAdmissionPayloadHash: request.workSyncAdmissionPayloadHash } : {},
    ...request.workSyncTeamIncarnation ? { workSyncTeamIncarnation: request.workSyncTeamIncarnation } : {}
  };
}
const MAX_INBOX_FILE_BYTES = 10 * 1024 * 1024;
const INBOX_READ_CONCURRENCY = process.platform === "win32" ? 4 : 12;
const INBOX_FILE_CACHE_MAX_ENTRIES = 64;
const INBOX_FILE_CACHE_MAX_BYTES = 32 * 1024 * 1024;
const INBOX_FILE_CACHE_MAX_ENTRY_BYTES = 4 * 1024 * 1024;
function buildInboxFileSignature(stat) {
  return {
    size: stat.size,
    mtimeMs: stat.mtimeMs,
    ctimeMs: stat.ctimeMs,
    dev: stat.dev,
    ino: stat.ino
  };
}
function inboxFileSignaturesEqual(a, b) {
  return a.size === b.size && a.mtimeMs === b.mtimeMs && a.ctimeMs === b.ctimeMs && a.dev === b.dev && a.ino === b.ino;
}
function cloneInboxMessages(messages) {
  return structuredClone([...messages]);
}
function estimateInboxMessagesBytes(messages) {
  return taskHistory.estimateCachedValueBytes(messages);
}
function assignImpliedInboxRecipient(message, member2) {
  if (message.to) {
    return;
  }
  if (taskHistory.isLeadThoughtSourceMessage(message)) {
    return;
  }
  message.to = member2;
}
function normalizeInboxMessageItem(item) {
  if (!item || typeof item !== "object") {
    return null;
  }
  const row2 = item;
  if (typeof row2.from !== "string" || typeof row2.text !== "string" || typeof row2.timestamp !== "string") {
    return null;
  }
  const messageId = getEffectiveInboxMessageId(row2);
  if (!messageId) {
    return null;
  }
  return {
    from: row2.from,
    to: typeof row2.to === "string" ? row2.to : void 0,
    text: row2.text,
    timestamp: row2.timestamp,
    read: typeof row2.read === "boolean" ? row2.read : false,
    taskRefs: Array.isArray(row2.taskRefs) ? row2.taskRefs : void 0,
    actionMode: row2.actionMode === "do" || row2.actionMode === "ask" || row2.actionMode === "delegate" ? row2.actionMode : void 0,
    commentId: typeof row2.commentId === "string" ? row2.commentId : void 0,
    summary: typeof row2.summary === "string" ? row2.summary : void 0,
    color: typeof row2.color === "string" ? row2.color : void 0,
    messageId,
    ...copyGroupChatEnvelope(row2),
    relayOfMessageId: typeof row2.relayOfMessageId === "string" ? row2.relayOfMessageId : void 0,
    source: typeof row2.source === "string" ? row2.source : void 0,
    leadSessionId: typeof row2.leadSessionId === "string" ? row2.leadSessionId : void 0,
    conversationId: typeof row2.conversationId === "string" ? row2.conversationId : void 0,
    replyToConversationId: typeof row2.replyToConversationId === "string" ? row2.replyToConversationId : void 0,
    attachments: Array.isArray(row2.attachments) ? row2.attachments : void 0,
    fileReferences: Array.isArray(row2.fileReferences) ? row2.fileReferences : void 0,
    toolSummary: typeof row2.toolSummary === "string" ? row2.toolSummary : void 0,
    toolCalls: Array.isArray(row2.toolCalls) ? row2.toolCalls.filter(
      (tc) => tc != null && typeof tc === "object" && typeof tc.name === "string"
    ).map((tc) => ({
      name: tc.name,
      preview: typeof tc.preview === "string" ? tc.preview : void 0
    })) : void 0,
    messageKind: row2.messageKind === "slash_command" || row2.messageKind === "slash_command_result" || row2.messageKind === "task_comment_notification" || row2.messageKind === "task_stall_remediation" || row2.messageKind === "member_work_sync_nudge" || row2.messageKind === "runtime_recovery_nudge" || row2.messageKind === "agent_error" ? row2.messageKind : row2.messageKind === "default" ? "default" : void 0,
    agentError: row2.agentError?.schemaVersion === 1 && (row2.agentError.type === "api_error" || row2.agentError.type === "codex_native_timeout") && row2.agentError.phase === "terminal" && typeof row2.agentError.detail === "string" && typeof row2.agentError.failedMessageId === "string" && typeof row2.agentError.innerRecoveryAttempts === "number" && Number.isInteger(row2.agentError.innerRecoveryAttempts) && row2.agentError.innerRecoveryAttempts >= 0 && (row2.agentError.runtimeSessionId == null || typeof row2.agentError.runtimeSessionId === "string") && (row2.agentError.bootstrapRunId == null || typeof row2.agentError.bootstrapRunId === "string") ? row2.agentError : void 0,
    runtimeRecovery: row2.runtimeRecovery?.schemaVersion === 1 && typeof row2.runtimeRecovery.recoveryId === "string" && typeof row2.runtimeRecovery.sourceFailureId === "string" && typeof row2.runtimeRecovery.attempt === "number" && Number.isInteger(row2.runtimeRecovery.attempt) && row2.runtimeRecovery.attempt >= 1 && typeof row2.runtimeRecovery.reasonCode === "string" && row2.runtimeRecovery.reasonCode.length > 0 && typeof row2.runtimeRecovery.payloadHash === "string" ? row2.runtimeRecovery : void 0,
    ...readTeamInboxWorkSyncFields(row2),
    slashCommand: row2.slashCommand && typeof row2.slashCommand === "object" && typeof row2.slashCommand.name === "string" && typeof row2.slashCommand.command === "string" ? {
      name: row2.slashCommand.name,
      command: row2.slashCommand.command,
      args: typeof row2.slashCommand.args === "string" ? row2.slashCommand.args : void 0,
      knownDescription: typeof row2.slashCommand.knownDescription === "string" ? row2.slashCommand.knownDescription : void 0
    } : void 0,
    commandOutput: row2.commandOutput && typeof row2.commandOutput === "object" && (row2.commandOutput.stream === "stdout" || row2.commandOutput.stream === "stderr") && typeof row2.commandOutput.commandLabel === "string" ? {
      stream: row2.commandOutput.stream,
      commandLabel: row2.commandOutput.commandLabel
    } : void 0
  };
}
function visitInboxJsonArrayItems(raw, onItem) {
  let index = 0;
  const isJsonWhitespace = (char) => char === " " || char === "\n" || char === "\r" || char === "	";
  const skipWhitespace = () => {
    while (index < raw.length && isJsonWhitespace(raw[index])) {
      index += 1;
    }
  };
  const finishArray = () => {
    index += 1;
    skipWhitespace();
    return index >= raw.length;
  };
  skipWhitespace();
  if (raw[index] !== "[") {
    return false;
  }
  index += 1;
  const scanString = () => {
    if (raw[index] !== '"') {
      return false;
    }
    index += 1;
    let escaped = false;
    while (index < raw.length) {
      const char = raw[index];
      if (escaped) {
        escaped = false;
        index += 1;
        continue;
      }
      if (char === "\\") {
        escaped = true;
        index += 1;
        continue;
      }
      if (char === '"') {
        index += 1;
        return true;
      }
      index += 1;
    }
    return false;
  };
  const scanComposite = () => {
    let depth = 0;
    let inString = false;
    let escaped = false;
    while (index < raw.length) {
      const char = raw[index];
      if (inString) {
        if (escaped) {
          escaped = false;
        } else if (char === "\\") {
          escaped = true;
        } else if (char === '"') {
          inString = false;
        }
        index += 1;
        continue;
      }
      if (char === '"') {
        inString = true;
        index += 1;
        continue;
      }
      if (char === "{" || char === "[") {
        depth += 1;
        index += 1;
        continue;
      }
      if (char === "}" || char === "]") {
        depth -= 1;
        if (depth === 0) {
          index += 1;
          return true;
        }
        if (depth < 0) {
          return false;
        }
      }
      index += 1;
    }
    return false;
  };
  const scanNumber = () => {
    const start = index;
    while (index < raw.length && /[-+0-9.eE]/.test(raw[index] ?? "")) {
      index += 1;
    }
    return index > start;
  };
  const scanLiteral = (literal) => {
    if (!raw.startsWith(literal, index)) {
      return false;
    }
    index += literal.length;
    return true;
  };
  let expectingValue = true;
  let seenValue = false;
  while (index < raw.length) {
    skipWhitespace();
    if (raw[index] === "]") {
      if (expectingValue && seenValue) {
        return false;
      }
      return finishArray();
    }
    if (raw[index] === ",") {
      if (expectingValue) {
        return false;
      }
      index += 1;
      expectingValue = true;
      continue;
    }
    if (!expectingValue) {
      return false;
    }
    const start = index;
    const char = raw[index];
    const scanned = char === "{" || char === "[" ? scanComposite() : char === '"' ? scanString() : char === "t" ? scanLiteral("true") : char === "f" ? scanLiteral("false") : char === "n" ? scanLiteral("null") : scanNumber();
    if (!scanned) {
      return false;
    }
    try {
      onItem(JSON.parse(raw.slice(start, index)));
    } catch {
      return false;
    }
    seenValue = true;
    expectingValue = false;
  }
  return false;
}
async function mapLimit$2(items, limit, fn) {
  const results = new Array(items.length);
  let index = 0;
  const workerCount = Math.max(1, Math.min(limit, items.length));
  const workers = new Array(workerCount).fill(0).map(async () => {
    while (true) {
      const i = index++;
      if (i >= items.length) return;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}
class TeamInboxReader {
  inboxFileCache = /* @__PURE__ */ new Map();
  inboxFileCacheBytes = 0;
  deleteCachedMessages(inboxPath) {
    const cached = this.inboxFileCache.get(inboxPath);
    if (!cached) {
      return;
    }
    this.inboxFileCacheBytes = Math.max(0, this.inboxFileCacheBytes - cached.estimatedBytes);
    this.inboxFileCache.delete(inboxPath);
  }
  evictOldestCachedInboxFile() {
    const oldestKey = this.inboxFileCache.keys().next().value;
    if (oldestKey === void 0) {
      return false;
    }
    this.deleteCachedMessages(oldestKey);
    return true;
  }
  trimInboxFileCache() {
    while (this.inboxFileCache.size > INBOX_FILE_CACHE_MAX_ENTRIES || this.inboxFileCacheBytes > INBOX_FILE_CACHE_MAX_BYTES) {
      if (!this.evictOldestCachedInboxFile()) {
        return;
      }
    }
  }
  getCachedMessages(inboxPath, signature) {
    const cached = this.inboxFileCache.get(inboxPath);
    if (!cached) {
      return void 0;
    }
    if (!inboxFileSignaturesEqual(cached.signature, signature)) {
      this.deleteCachedMessages(inboxPath);
      return void 0;
    }
    this.inboxFileCache.delete(inboxPath);
    this.inboxFileCache.set(inboxPath, cached);
    return cloneInboxMessages(cached.messages);
  }
  setCachedMessages(inboxPath, signature, messages) {
    const estimatedBytes = estimateInboxMessagesBytes(messages);
    this.deleteCachedMessages(inboxPath);
    if (estimatedBytes > INBOX_FILE_CACHE_MAX_ENTRY_BYTES) {
      return;
    }
    this.inboxFileCache.set(inboxPath, {
      signature,
      messages: cloneInboxMessages(messages),
      estimatedBytes
    });
    this.inboxFileCacheBytes += estimatedBytes;
    this.trimInboxFileCache();
  }
  /**
   * Expose inbox owners as team members only when the member-name contract accepts them.
   * Keep non-member inbox files available to the message-history readers.
   */
  async listInboxNames(teamName2) {
    return (await this.listInboxFileNames(teamName2)).filter(
      (name2) => name2.length > 0 && name2.trim() === name2 && validateTeamMemberNameFormat(name2) === null
    );
  }
  async listInboxFileNames(teamName2) {
    const inboxDir = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "inboxes");
    let entries;
    try {
      entries = await fs__namespace.promises.readdir(inboxDir);
    } catch (error) {
      if (error.code === "ENOENT") {
        return [];
      }
      throw error;
    }
    return entries.filter((name2) => name2.endsWith(".json") && !name2.startsWith(".")).map((name2) => name2.replace(/\.json$/, "")).filter((name2) => name2 !== "*");
  }
  async getMessagesFor(teamName2, member2) {
    const inboxPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "inboxes", `${member2}.json`);
    let raw;
    let signature;
    try {
      const stat = await fs__namespace.promises.stat(inboxPath);
      if (!stat.isFile() || stat.size > MAX_INBOX_FILE_BYTES) {
        this.deleteCachedMessages(inboxPath);
        return [];
      }
      signature = buildInboxFileSignature(stat);
      const cached = this.getCachedMessages(inboxPath, signature);
      if (cached) {
        return cached;
      }
      raw = await readFileUtf8WithTimeout(inboxPath, 5e3);
    } catch (error) {
      if (error.code === "ENOENT") {
        this.deleteCachedMessages(inboxPath);
        return [];
      }
      if (error instanceof FileReadTimeoutError) {
        return [];
      }
      throw error;
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      this.setCachedMessages(inboxPath, signature, []);
      return [];
    }
    if (!Array.isArray(parsed)) {
      this.setCachedMessages(inboxPath, signature, []);
      return [];
    }
    try {
      assertValidGroupInboxRows(parsed);
    } catch {
      this.deleteCachedMessages(inboxPath);
      throw new TeamHistoryError("invalid_message");
    }
    const messages = [];
    for (const item of parsed) {
      const message = normalizeInboxMessageItem(item);
      if (message) {
        messages.push(message);
      }
    }
    messages.sort((a, b) => {
      const bt = Date.parse(b.timestamp);
      const at = Date.parse(a.timestamp);
      if (Number.isNaN(bt) || Number.isNaN(at)) {
        return 0;
      }
      return bt - at;
    });
    this.setCachedMessages(inboxPath, signature, messages);
    return cloneInboxMessages(messages);
  }
  async getMessages(teamName2) {
    const members = await this.listInboxFileNames(teamName2);
    const chunks = await mapLimit$2(members, INBOX_READ_CONCURRENCY, async (member2) => {
      try {
        const msgs = await this.getMessagesFor(teamName2, member2);
        for (const msg of msgs) {
          assignImpliedInboxRecipient(msg, member2);
        }
        return msgs;
      } catch (error) {
        if (error instanceof TeamHistoryError) throw error;
        return [];
      }
    });
    const merged = chunks.flat().filter((message) => !message.groupChatId || message.groupMessageId === message.messageId);
    merged.sort((a, b) => {
      const bt = Date.parse(b.timestamp);
      const at = Date.parse(a.timestamp);
      if (Number.isNaN(bt) || Number.isNaN(at)) {
        return 0;
      }
      return bt - at;
    });
    return merged;
  }
  async getMessagesWindow(teamName2, options) {
    const inboxDir = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "inboxes");
    return unwrapInboxWindow(
      await readInboxWindow(
        {
          listMembers: async () => {
            if (options.groupChatId) return ["user"];
            let entries;
            try {
              entries = await fs__namespace.promises.readdir(inboxDir);
            } catch (error) {
              if (error.code === "ENOENT") return [];
              throw error;
            }
            return entries.filter((name2) => name2.endsWith(".json") && !name2.startsWith(".")).map((name2) => name2.replace(/\.json$/, "")).filter((name2) => name2 !== "*");
          },
          readMember: async (member2) => {
            const inboxPath = path__namespace$1.join(inboxDir, `${member2}.json`);
            try {
              const stat = await fs__namespace.promises.stat(inboxPath);
              if (!stat.isFile() || stat.size > MAX_INBOX_FILE_BYTES) {
                this.deleteCachedMessages(inboxPath);
                throw new TeamHistoryError(stat.isFile() ? "oversized" : "non_file");
              }
              return { kind: "raw", raw: await readFileUtf8WithTimeout(inboxPath, 5e3) };
            } catch (error) {
              this.deleteCachedMessages(inboxPath);
              if (error instanceof TeamHistoryError) throw error;
              if (error instanceof FileReadTimeoutError) throw new TeamHistoryError("timeout");
              if (options.groupChatId && error.code === "ENOENT")
                return { kind: "raw", raw: "[]" };
              throw new TeamHistoryError(
                error.code === "ENOENT" ? "missing_source" : "read_failed"
              );
            }
          },
          normalize: normalizeInboxMessageItem,
          assignRecipient: assignImpliedInboxRecipient,
          visit: visitInboxJsonArrayItems
        },
        options
      )
    );
  }
}
const TEAMMATE_BLOCK_RE = /<teammate-message\s+teammate_id="([^"]+)"([^>]*)>([\s\S]*?)<\/teammate-message>/g;
const COLOR_RE = /color="([^"]*)"/;
const SUMMARY_RE = /summary="([^"]*)"/;
function parseAllTeammateMessages(rawContent) {
  const results = [];
  const regex = new RegExp(TEAMMATE_BLOCK_RE.source, TEAMMATE_BLOCK_RE.flags);
  let match;
  while ((match = regex.exec(rawContent)) !== null) {
    const teammateId = match[1];
    const attrs = match[2];
    const content = match[3].trim();
    const colorMatch = COLOR_RE.exec(attrs);
    const summaryMatch = SUMMARY_RE.exec(attrs);
    results.push({
      teammateId,
      color: colorMatch?.[1] ?? "",
      summary: summaryMatch?.[1] ?? "",
      content
    });
  }
  return results;
}
const LOCAL_COMMAND_STDOUT_TAG = "local-command-stdout";
const LOCAL_COMMAND_STDERR_TAG = "local-command-stderr";
const BASH_STDOUT_TAG = "bash-stdout";
const BASH_STDERR_TAG = "bash-stderr";
const TEAMMATE_MESSAGE_TAG = "teammate-message";
const TASK_NOTIFICATION_TAG = "task-notification";
const CHANNEL_MESSAGE_TAG = "channel-message";
const CROSS_SESSION_MESSAGE_TAG = "cross-session-message";
const TICK_TAG = "tick";
function classifyUserTurnProvenance(message) {
  if (hasToolResultProvenance(message)) {
    return "tool-result";
  }
  if (hasSystemOutputContent(getMessageContent(message))) {
    return "local-command-output";
  }
  if (message.isCompactSummary === true) {
    return "synthetic-replay";
  }
  const protocolKind = normalizeProtocolKind(message.protocolKind);
  if (protocolKind) {
    return protocolKind;
  }
  const originKind = normalizeOriginKind(message.origin);
  if (originKind) {
    return originKind;
  }
  const legacyProtocolKind = classifyLegacyProtocolText(getTextContent(getMessageContent(message)));
  if (legacyProtocolKind) {
    return legacyProtocolKind;
  }
  if (message.isSynthetic === true) {
    return "synthetic-replay";
  }
  if (message.isMeta === true) {
    return "coordinator";
  }
  return "human";
}
function isHumanAuthoredUserTurn(message) {
  return classifyUserTurnProvenance(message) === "human";
}
function isSyntheticReplayNoise(message) {
  return message.isSynthetic === true && message.isReplay === true && !hasToolResultPayload(message) && !hasSystemOutputContent(getMessageContent(message));
}
function isDisplayableTeammateProtocol(message) {
  return classifyUserTurnProvenance(message) === "teammate-protocol" && message.isMeta !== true && message.isSynthetic !== true;
}
function normalizeProtocolKind(protocolKind) {
  switch (protocolKind) {
    case TEAMMATE_MESSAGE_TAG:
      return "teammate-protocol";
    case TASK_NOTIFICATION_TAG:
      return "task-notification";
    case CHANNEL_MESSAGE_TAG:
      return "channel";
    case CROSS_SESSION_MESSAGE_TAG:
      return "cross-session";
    case TICK_TAG:
      return "tick";
    default:
      return void 0;
  }
}
function normalizeOriginKind(origin) {
  switch (origin?.kind) {
    case void 0:
    case "human":
      return void 0;
    case "task-notification":
      return "task-notification";
    case "channel":
      return "channel";
    case "cross-session":
      return "cross-session";
    case "tick":
      return "tick";
    case "teammate":
      return "teammate-protocol";
    case "coordinator":
    default:
      return "coordinator";
  }
}
function classifyLegacyProtocolText(text2) {
  if (!text2) {
    return void 0;
  }
  const normalized = stripTranscriptSpeakerPrefix(text2.trimStart());
  if (normalized.startsWith(`<${TEAMMATE_MESSAGE_TAG}`)) {
    return "teammate-protocol";
  }
  if (normalized.startsWith(`<${TASK_NOTIFICATION_TAG}`)) {
    return "task-notification";
  }
  if (normalized.startsWith(`<${CHANNEL_MESSAGE_TAG}`)) {
    return "channel";
  }
  if (normalized.startsWith(`<${CROSS_SESSION_MESSAGE_TAG}`)) {
    return "cross-session";
  }
  if (normalized.startsWith(`<${TICK_TAG}`)) {
    return "tick";
  }
  return void 0;
}
function stripTranscriptSpeakerPrefix(text2) {
  return text2.replace(/^(?:Human|User):\s*/i, "").trimStart();
}
function hasToolResultProvenance(message) {
  if (message.toolUseResult !== void 0 || message.sourceToolUseID !== void 0) {
    return true;
  }
  if ((message.toolResults?.length ?? 0) > 0) {
    return true;
  }
  return hasToolResultContent(message);
}
function hasToolResultPayload(message) {
  return message.toolUseResult !== void 0 || message.sourceToolUseID !== void 0 || (message.toolResults?.length ?? 0) > 0 || hasToolResultContent(message);
}
function hasToolResultContent(message) {
  const content = getMessageContent(message);
  return Array.isArray(content) && content.some((block) => isContentBlock(block) && block.type === "tool_result");
}
function hasSystemOutputContent(content) {
  if (typeof content === "string") {
    return startsWithSystemOutputTag(content);
  }
  return Array.isArray(content) && content.some(
    (block) => isContentBlock(block) && block.type === "text" && startsWithSystemOutputTag(block.text)
  );
}
function startsWithSystemOutputTag(text2) {
  if (!text2) {
    return false;
  }
  return text2.startsWith(`<${LOCAL_COMMAND_STDOUT_TAG}>`) || text2.startsWith(`<${LOCAL_COMMAND_STDERR_TAG}>`) || text2.startsWith(`<${BASH_STDOUT_TAG}>`) || text2.startsWith(`<${BASH_STDERR_TAG}>`);
}
function getMessageContent(message) {
  return message.message?.content ?? message.content;
}
function getTextContent(content) {
  if (typeof content === "string") {
    return content;
  }
  if (!Array.isArray(content)) {
    return void 0;
  }
  return content.filter(isContentBlock).filter((block) => block.type === "text").map((block) => block.text ?? "").join("\n");
}
function isContentBlock(value) {
  return value !== null && typeof value === "object";
}
const AGENT_TEAMS_PREFIXES = [
  "mcp__agent-teams__",
  "mcp__agent_teams__",
  "agent-teams_",
  "agent_teams_"
];
const TASK_BOUNDARY_TOOL_NAMES = ["task_start", "task_complete", "task_set_status"];
const TASK_BOUNDARY_TOOL_SET = new Set(TASK_BOUNDARY_TOOL_NAMES);
function escapeRegex$1(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
const TASK_BOUNDARY_TOOL_LINE_PATTERN = new RegExp(
  `"name"\\s*:\\s*"(?:${[
    ...TASK_BOUNDARY_TOOL_NAMES,
    ...TASK_BOUNDARY_TOOL_NAMES.map((toolName) => `proxy_${toolName}`),
    ...AGENT_TEAMS_PREFIXES.flatMap(
      (prefix) => TASK_BOUNDARY_TOOL_NAMES.map((toolName) => `${prefix}${toolName}`)
    ),
    ...AGENT_TEAMS_PREFIXES.flatMap(
      (prefix) => TASK_BOUNDARY_TOOL_NAMES.map((toolName) => `proxy_${prefix}${toolName}`)
    )
  ].map(escapeRegex$1).join("|")})"`
);
function canonicalizeAgentTeamsToolName(rawName) {
  const normalized = rawName.trim().replace(/^proxy_/, "");
  for (const prefix of AGENT_TEAMS_PREFIXES) {
    if (normalized.startsWith(prefix)) {
      return normalized.slice(prefix.length);
    }
  }
  return normalized;
}
function isAgentTeamsToolName(rawName, canonicalName) {
  return canonicalizeAgentTeamsToolName(rawName).toLowerCase() === canonicalName.toLowerCase();
}
function isAgentTeamsToolUse(input) {
  const rawName = input.rawName.trim();
  const normalizedRawName = rawName.replace(/^proxy_/, "");
  const canonical = canonicalizeAgentTeamsToolName(rawName);
  if (canonical.toLowerCase() !== input.canonicalName.toLowerCase()) {
    return false;
  }
  const hasKnownPrefix = AGENT_TEAMS_PREFIXES.some(
    (prefix) => normalizedRawName.startsWith(prefix)
  );
  if (hasKnownPrefix) {
    return true;
  }
  if (input.canonicalName === "message_send") {
    return typeof input.toolInput?.teamName === "string" && input.toolInput.teamName === input.currentTeamName && typeof input.toolInput?.to === "string" && typeof input.toolInput?.text === "string";
  }
  if (input.canonicalName === "cross_team_send") {
    return typeof input.toolInput?.teamName === "string" && input.toolInput.teamName === input.currentTeamName && typeof input.toolInput?.toTeam === "string" && typeof input.toolInput?.text === "string";
  }
  return false;
}
function isAgentTeamsTaskBoundaryToolName(rawName) {
  return TASK_BOUNDARY_TOOL_SET.has(canonicalizeAgentTeamsToolName(rawName));
}
function lineHasAgentTeamsTaskBoundaryToolName(line) {
  return TASK_BOUNDARY_TOOL_LINE_PATTERN.test(line);
}
const BOARD_TASK_LOG_FRESHNESS_DIRNAME = ".board-task-log-freshness";
const TEAM_TASK_LOG_FRESHNESS_DIRNAME = "task-log-freshness";
const BOARD_TASK_CHANGE_FRESHNESS_DIRNAME = ".board-task-change-freshness";
const BOARD_TASK_CHANGES_DIRNAME = ".board-task-changes";
const BOARD_TASK_LOG_FRESHNESS_FILE_SUFFIX = ".json";
const MAX_LOG_SOURCE_WATCH_SESSION_IDS = 24;
const MAX_PENDING_UNKNOWN_ROOT_SESSIONS = 16;
const PENDING_UNKNOWN_ROOT_SESSION_TTL_MS = 15e3;
const MAX_PENDING_UNKNOWN_ROOT_REFRESH_ATTEMPTS = 4;
const SAFE_SESSION_ID_RE = /^[A-Za-z0-9_-]{1,200}$/;
const AGENT_TRANSCRIPT_RE = /^agent-(?!acompact).*\.jsonl$/;
function normalizeLogSourceSessionId(value) {
  if (typeof value !== "string") {
    return null;
  }
  const trimmed = value.trim();
  if (!trimmed || !SAFE_SESSION_ID_RE.test(trimmed)) {
    return null;
  }
  return trimmed;
}
function getLeadSessionIds(config) {
  const history = Array.isArray(config.sessionHistory) ? config.sessionHistory : [];
  const ids = /* @__PURE__ */ new Set();
  for (const candidate of [config.leadSessionId, ...history]) {
    const sessionId = normalizeLogSourceSessionId(candidate);
    if (sessionId) ids.add(sessionId);
  }
  return ids;
}
function pushSessionId(ids, seen, value, limit) {
  if (ids.length >= limit) {
    return;
  }
  const normalized = normalizeLogSourceSessionId(value);
  if (!normalized || seen.has(normalized)) {
    return;
  }
  seen.add(normalized);
  ids.push(normalized);
}
function shouldIncludeRuntimeMember(member2) {
  return Boolean(
    member2.runtimeSessionId && !member2.hardFailure && member2.launchState !== "skipped_for_launch" && member2.launchState !== "failed_to_start"
  );
}
function extractRuntimeSessionIds(snapshot) {
  if (!snapshot?.members) {
    return [];
  }
  const ids = [];
  const seen = /* @__PURE__ */ new Set();
  for (const member2 of Object.values(snapshot.members)) {
    if (!shouldIncludeRuntimeMember(member2)) {
      continue;
    }
    pushSessionId(ids, seen, member2.runtimeSessionId, MAX_LOG_SOURCE_WATCH_SESSION_IDS);
  }
  return ids;
}
function buildTeamLogWatchSessionIds(input, limit = MAX_LOG_SOURCE_WATCH_SESSION_IDS) {
  const ids = [];
  const seen = /* @__PURE__ */ new Set();
  pushSessionId(ids, seen, input.configLeadSessionId, limit);
  pushSessionId(ids, seen, input.launchLeadSessionId, limit);
  for (const sessionId of input.launchRuntimeSessionIds ?? []) {
    pushSessionId(ids, seen, sessionId, limit);
  }
  for (const sessionId of input.bootstrapRuntimeSessionIds ?? []) {
    pushSessionId(ids, seen, sessionId, limit);
  }
  const history = Array.isArray(input.sessionHistory) ? input.sessionHistory : [];
  for (let index = history.length - 1; index >= 0; index -= 1) {
    pushSessionId(ids, seen, history[index], limit);
  }
  return ids;
}
function isAgentTranscriptFileName(fileName) {
  return AGENT_TRANSCRIPT_RE.test(fileName);
}
function getRelativeLogSourceParts(projectDir, targetPath) {
  const relativePath = path__namespace$1.relative(projectDir, targetPath);
  if (!relativePath || relativePath.startsWith("..") || path__namespace$1.isAbsolute(relativePath)) {
    return null;
  }
  return relativePath.split(/[/\\]+/).filter(Boolean);
}
function classifyLogSourceWatcherEvent(input) {
  const parts = getRelativeLogSourceParts(input.projectDir, input.changedPath);
  if (!parts) {
    return { kind: "ignore" };
  }
  const first = parts[0];
  if (first === BOARD_TASK_LOG_FRESHNESS_DIRNAME || first === BOARD_TASK_CHANGE_FRESHNESS_DIRNAME) {
    return { kind: "task-freshness" };
  }
  if (first === BOARD_TASK_CHANGES_DIRNAME || parts.includes("tool-results") || parts.includes("memory")) {
    return { kind: "ignore" };
  }
  if (parts.length === 1 && first.endsWith(".jsonl")) {
    const sessionId = normalizeLogSourceSessionId(first.slice(0, -".jsonl".length));
    if (!sessionId) {
      return { kind: "ignore" };
    }
    if (input.scopedSessionIds.has(sessionId)) {
      return { kind: "scoped-recompute" };
    }
    if (input.eventName === "add" || input.pendingUnknownSessionIds.has(sessionId)) {
      return { kind: "context-refresh", candidateSessionId: sessionId };
    }
    return { kind: "ignore" };
  }
  if (input.scopedSessionIds.has(first)) {
    if (parts.length === 1) {
      return { kind: "scoped-recompute" };
    }
    if (parts[1] === "subagents") {
      if (parts.length === 2) {
        return { kind: "context-refresh" };
      }
      if (parts.length === 3 && isAgentTranscriptFileName(parts[2])) {
        return { kind: "scoped-recompute" };
      }
    }
  }
  return { kind: "ignore" };
}
const NOISE_TAG_PATTERNS = [
  /<local-command-caveat>[\s\S]*?<\/local-command-caveat>/gi,
  /<system-reminder>[\s\S]*?<\/system-reminder>/gi,
  /<task-notification>[\s\S]*?<\/task-notification>/gi,
  /<opencode_runtime_identity>[\s\S]*?<\/opencode_runtime_identity>/gi,
  /<opencode_app_message_delivery>[\s\S]*?<\/opencode_app_message_delivery>/gi,
  /<opencode_delivery_context>[\s\S]*?<\/opencode_delivery_context>/gi,
  /<opencode_delivery_retry>[\s\S]*?<\/opencode_delivery_retry>/gi
];
const TASK_OUTPUT_INSTRUCTION_PATTERN = / ?Read the output file to retrieve the result: [^\s]+/g;
const OPENCODE_INBOUND_APP_MESSAGE_PATTERN = /<opencode_inbound_app_message>\s*([\s\S]*?)\s*<\/opencode_inbound_app_message>/gi;
function extractCommandOutputInfo(content) {
  const match = /<local-command-stdout>([\s\S]*?)<\/local-command-stdout>/i.exec(content);
  const matchStderr = /<local-command-stderr>([\s\S]*?)<\/local-command-stderr>/i.exec(content);
  if (match) {
    return {
      stream: "stdout",
      output: match[1].trim()
    };
  }
  if (matchStderr) {
    return {
      stream: "stderr",
      output: matchStderr[1].trim()
    };
  }
  return null;
}
function extractCommandDisplay(content) {
  const commandNameMatch = /<command-name>\/([^<]+)<\/command-name>/.exec(content);
  const commandArgsMatch = /<command-args>([^<]*)<\/command-args>/.exec(content);
  if (commandNameMatch) {
    const commandName = `/${commandNameMatch[1].trim()}`;
    const args = commandArgsMatch?.[1]?.trim();
    return args ? `${commandName} ${args}` : commandName;
  }
  return null;
}
function isCommandContent(content) {
  return content.startsWith("<command-name>") || content.startsWith("<command-message>");
}
function isCommandOutputContent(content) {
  return content.startsWith("<local-command-stdout>") || content.startsWith("<local-command-stderr>");
}
function sanitizeDisplayContent(content) {
  if (isCommandOutputContent(content)) {
    const commandOutput = extractCommandOutputInfo(content);
    if (commandOutput) {
      return commandOutput.output;
    }
  }
  if (isCommandContent(content)) {
    const commandDisplay = extractCommandDisplay(content);
    if (commandDisplay) {
      return commandDisplay;
    }
  }
  let sanitized = content;
  for (const pattern of NOISE_TAG_PATTERNS) {
    sanitized = sanitized.replace(pattern, "");
  }
  sanitized = sanitized.replace(
    OPENCODE_INBOUND_APP_MESSAGE_PATTERN,
    (_match, innerContent) => innerContent?.trim() ?? ""
  );
  sanitized = sanitized.replace(/<command-name>[\s\S]*?<\/command-name>/gi, "").replace(/<command-message>[\s\S]*?<\/command-message>/gi, "").replace(/<command-args>[\s\S]*?<\/command-args>/gi, "");
  sanitized = sanitized.replace(TASK_OUTPUT_INSTRUCTION_PATTERN, "");
  return sanitized.replace(/\n{3,}/g, "\n\n").trim();
}
function extractSlashInfo(content) {
  const nameMatch = /<command-name>\/([^<]+)<\/command-name>/.exec(content);
  if (!nameMatch) return null;
  const name2 = nameMatch[1].trim();
  const messageMatch = /<command-message>([^<]*)<\/command-message>/.exec(content);
  const argsMatch = /<command-args>([^<]*)<\/command-args>/.exec(content);
  return {
    name: name2,
    message: messageMatch?.[1]?.trim() ?? void 0,
    args: argsMatch?.[1]?.trim() ?? void 0
  };
}
const STAT_CONCURRENCY = process.platform === "win32" ? 32 : 128;
const STAT_TIMEOUT_MS = 2e3;
const STAT_PREFETCH_LIMIT = 1500;
async function statWithTimeout(filePath, timeoutMs) {
  let timer = null;
  const timeout = new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error("stat timeout")), timeoutMs);
  });
  try {
    return await Promise.race([fs__namespace.promises.stat(filePath), timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
async function mapLimit$1(items, limit, fn) {
  const results = new Array(items.length);
  let index = 0;
  const workerCount = Math.max(1, Math.min(limit, items.length));
  const workers = new Array(workerCount).fill(0).map(async () => {
    while (true) {
      const i = index++;
      if (i >= items.length) return;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}
class LocalFileSystemProvider {
  type = "local";
  async exists(filePath) {
    try {
      await fs__namespace.promises.access(filePath, fs__namespace.constants.F_OK);
      return true;
    } catch {
      return false;
    }
  }
  async readFile(filePath, encoding = "utf8") {
    return fs__namespace.promises.readFile(filePath, encoding);
  }
  async stat(filePath) {
    const stats = await statWithTimeout(filePath, STAT_TIMEOUT_MS);
    return {
      size: stats.size,
      mtimeMs: stats.mtimeMs,
      birthtimeMs: stats.birthtimeMs,
      isFile: () => stats.isFile(),
      isDirectory: () => stats.isDirectory()
    };
  }
  async readdir(dirPath, options = {}) {
    const entries = await fs__namespace.promises.readdir(dirPath, { withFileTypes: true });
    if (options.prefetchEntryStats === false || entries.length > STAT_PREFETCH_LIMIT) {
      return entries.map((entry) => ({
        name: entry.name,
        isFile: () => entry.isFile(),
        isDirectory: () => entry.isDirectory()
      }));
    }
    return mapLimit$1(entries, STAT_CONCURRENCY, async (entry) => {
      let mtimeMs;
      let birthtimeMs;
      let size;
      try {
        const fullPath = path__namespace.join(dirPath, entry.name);
        const stat = await statWithTimeout(fullPath, STAT_TIMEOUT_MS);
        mtimeMs = stat.mtimeMs;
        birthtimeMs = stat.birthtimeMs;
        size = stat.size;
      } catch {
      }
      return {
        name: entry.name,
        mtimeMs,
        birthtimeMs,
        size,
        isFile: () => entry.isFile(),
        isDirectory: () => entry.isDirectory()
      };
    });
  }
  createReadStream(filePath, opts) {
    return fs__namespace.createReadStream(filePath, {
      start: opts?.start,
      encoding: opts?.encoding
    });
  }
  dispose() {
  }
}
function isTextContent(content) {
  return content.type === "text";
}
function isToolResultContent(content) {
  return content.type === "tool_result";
}
function isConversationalEntry(entry) {
  return entry.type === "user" || entry.type === "assistant" || entry.type === "system";
}
const logger$3 = createLogger("Util:metadataExtraction");
function normalizeDriveLetter(p) {
  if (p.length >= 2 && p[1] === ":") {
    return p[0].toUpperCase() + p.slice(1);
  }
  return p;
}
const defaultProvider = new LocalFileSystemProvider();
const JSONL_HEAD_TIMEOUT_MS = 5e3;
const JSONL_HEAD_MAX_BYTES = 256 * 1024;
const JSONL_HEAD_MAX_LINES = 400;
function byteLen(chunk) {
  return Buffer.byteLength(chunk, "utf8");
}
function createStreamCleanup(rl, fileStream) {
  let cleaned = false;
  return () => {
    if (cleaned) return;
    cleaned = true;
    rl.close();
    fileStream.destroy();
  };
}
function extractCwdFromBufferedText(text2) {
  const lines = text2.split(/\r?\n/, JSONL_HEAD_MAX_LINES);
  for (const line of lines) {
    if (!line.trim()) continue;
    let entry;
    try {
      entry = JSON.parse(line);
    } catch {
      continue;
    }
    if ("cwd" in entry && entry.cwd) {
      return normalizeDriveLetter(taskHistory.translateWslMountPath(entry.cwd));
    }
  }
  return null;
}
async function extractCwdFromLocalFile(filePath) {
  const handle = await fs__namespace$2.open(filePath, "r");
  try {
    const buffer = Buffer.alloc(JSONL_HEAD_MAX_BYTES);
    const { bytesRead } = await handle.read(buffer, 0, JSONL_HEAD_MAX_BYTES, 0);
    if (bytesRead <= 0) {
      return null;
    }
    return extractCwdFromBufferedText(buffer.toString("utf8", 0, bytesRead));
  } finally {
    await handle.close().catch(() => void 0);
  }
}
async function extractCwdFromReadableFile(filePath, fsProvider) {
  if (fsProvider.type === "local") {
    try {
      return await extractCwdFromLocalFile(filePath);
    } catch (error) {
      logger$3.debug(`Error extracting cwd from local file ${filePath}:`, error);
      return null;
    }
  }
  const fileStream = fsProvider.createReadStream(filePath, { encoding: "utf8" });
  const rl = readline__namespace.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });
  let bytes = 0;
  let timedOut = false;
  const cleanup = createStreamCleanup(rl, fileStream);
  const timer = setTimeout(() => {
    timedOut = true;
    cleanup();
  }, JSONL_HEAD_TIMEOUT_MS);
  fileStream.on("data", (chunk) => {
    bytes += byteLen(chunk);
    if (bytes > JSONL_HEAD_MAX_BYTES) {
      cleanup();
    }
  });
  try {
    let lines = 0;
    for await (const line of rl) {
      if (++lines > JSONL_HEAD_MAX_LINES) {
        break;
      }
      if (!line.trim()) continue;
      let entry;
      try {
        entry = JSON.parse(line);
      } catch {
        continue;
      }
      if ("cwd" in entry && entry.cwd) {
        return normalizeDriveLetter(taskHistory.translateWslMountPath(entry.cwd));
      }
    }
  } catch (error) {
    if (!timedOut) {
      logger$3.debug(`Error extracting cwd from ${filePath}:`, error);
    }
  } finally {
    clearTimeout(timer);
    cleanup();
  }
  return null;
}
async function extractCwdFromKnownJsonlFile(filePath, fsProvider = defaultProvider) {
  return extractCwdFromReadableFile(filePath, fsProvider);
}
async function extractCwd(filePath, fsProvider = defaultProvider) {
  if (!await fsProvider.exists(filePath)) {
    return null;
  }
  try {
    const stat = await fsProvider.stat(filePath);
    if (!stat.isFile()) {
      return null;
    }
  } catch {
    return null;
  }
  return extractCwdFromReadableFile(filePath, fsProvider);
}
async function extractFirstUserMessagePreview(filePath, fsProvider = defaultProvider, maxLines = 200) {
  const safeMaxLines = Math.max(1, maxLines);
  try {
    const stat = await fsProvider.stat(filePath);
    if (!stat.isFile()) {
      return null;
    }
  } catch {
    return null;
  }
  const fileStream = fsProvider.createReadStream(filePath, { encoding: "utf8" });
  const rl = readline__namespace.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });
  let bytes = 0;
  let timedOut = false;
  const cleanup = createStreamCleanup(rl, fileStream);
  const timer = setTimeout(() => {
    timedOut = true;
    cleanup();
  }, JSONL_HEAD_TIMEOUT_MS);
  fileStream.on("data", (chunk) => {
    bytes += byteLen(chunk);
    if (bytes > JSONL_HEAD_MAX_BYTES) {
      cleanup();
    }
  });
  let commandFallback = null;
  let linesRead = 0;
  try {
    for await (const line of rl) {
      if (linesRead++ >= safeMaxLines) {
        break;
      }
      const trimmed = line.trim();
      if (!trimmed) continue;
      let entry;
      try {
        entry = JSON.parse(trimmed);
      } catch {
        continue;
      }
      if (entry.type !== "user") {
        continue;
      }
      const preview = extractPreviewFromUserEntry(entry);
      if (!preview) {
        continue;
      }
      if (!preview.isCommand) {
        return { text: preview.text, timestamp: preview.timestamp };
      }
      if (!commandFallback) {
        commandFallback = { text: preview.text, timestamp: preview.timestamp };
      }
    }
  } catch (error) {
    if (!timedOut) {
      logger$3.debug(`Error extracting first user preview from ${filePath}:`, error);
    }
    return commandFallback;
  } finally {
    clearTimeout(timer);
    cleanup();
  }
  return commandFallback;
}
function extractPreviewFromUserEntry(entry) {
  if (!isHumanAuthoredUserTurn(entry)) {
    return null;
  }
  const timestamp2 = entry.timestamp ?? (/* @__PURE__ */ new Date()).toISOString();
  const message = entry.message;
  if (!message) {
    return null;
  }
  const content = message.content;
  if (typeof content === "string") {
    if (isCommandOutputContent(content) || content.startsWith("[Request interrupted by user")) {
      return null;
    }
    if (content.startsWith("<command-name>")) {
      return {
        text: extractCommandName(content),
        timestamp: timestamp2,
        isCommand: true
      };
    }
    const sanitized2 = sanitizeDisplayContent(content).trim();
    if (!sanitized2) {
      return null;
    }
    return {
      text: sanitized2.substring(0, 500),
      timestamp: timestamp2,
      isCommand: false
    };
  }
  if (!Array.isArray(content)) {
    return null;
  }
  const textContent = content.filter(isTextContent).map((block) => block.text).join(" ").trim();
  if (!textContent || textContent.startsWith("[Request interrupted by user")) {
    return null;
  }
  if (textContent.startsWith("<command-name>")) {
    return {
      text: extractCommandName(textContent),
      timestamp: timestamp2,
      isCommand: true
    };
  }
  const sanitized = sanitizeDisplayContent(textContent).trim();
  if (!sanitized) {
    return null;
  }
  return {
    text: sanitized.substring(0, 500),
    timestamp: timestamp2,
    isCommand: false
  };
}
function extractCommandName(content) {
  const commandMatch = /<command-name>\/([^<]+)<\/command-name>/.exec(content);
  return commandMatch?.[1] ? `/${commandMatch[1]}` : "/command";
}
const TEAM_TRANSCRIPT_AFFINITY_INDEX_SCHEMA_VERSION = 1;
const TEAM_TRANSCRIPT_AFFINITY_INDEX_MAX_ENTRIES_PER_PROJECT = 2e4;
function isIsoString(value) {
  return typeof value === "string" && value.trim().length > 0 && Number.isFinite(Date.parse(value));
}
function isFiniteNonNegativeNumber(value) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0;
}
function isValidFileName(value) {
  return typeof value === "string" && value.length > ".jsonl".length && value.endsWith(".jsonl") && !value.includes("/") && !value.includes("\\");
}
function sessionIdFromFileName(fileName) {
  return fileName.slice(0, -".jsonl".length);
}
function normalizeVerdict(value) {
  return value === "belongs" || value === "does_not_belong" ? value : null;
}
function normalizeMatchSource(value) {
  return value === "nested_team_name" || value === "text_team_mention" || value === "none" ? value : null;
}
function normalizeSignature(value) {
  if (!value || typeof value !== "object") {
    return null;
  }
  const raw = value;
  if (!isFiniteNonNegativeNumber(raw.size) || !isFiniteNonNegativeNumber(raw.mtimeMs)) {
    return null;
  }
  if (raw.ctimeMs != null && !isFiniteNonNegativeNumber(raw.ctimeMs)) {
    return null;
  }
  return {
    size: raw.size,
    mtimeMs: raw.mtimeMs,
    ...raw.ctimeMs != null ? { ctimeMs: raw.ctimeMs } : {}
  };
}
function normalizeTeamTranscriptAffinityEntry(fileName, value) {
  if (!isValidFileName(fileName) || !value || typeof value !== "object") {
    return null;
  }
  const raw = value;
  const verdict = normalizeVerdict(raw.verdict);
  const signature = normalizeSignature(raw.signature);
  const matchSource = normalizeMatchSource(raw.matchSource);
  const expectedSessionId = sessionIdFromFileName(fileName);
  if (raw.fileName !== fileName || raw.sessionId !== expectedSessionId || !signature || !verdict || typeof raw.headWindowFull !== "boolean" || !Number.isInteger(raw.inspectedLineCount) || !isFiniteNonNegativeNumber(raw.inspectedLineCount) || !matchSource || !isIsoString(raw.writtenAt)) {
    return null;
  }
  return {
    fileName,
    sessionId: expectedSessionId,
    signature,
    verdict,
    headWindowFull: raw.headWindowFull,
    inspectedLineCount: raw.inspectedLineCount,
    matchSource,
    writtenAt: raw.writtenAt
  };
}
function normalizeTeamTranscriptAffinityIndex(value) {
  if (!value || typeof value !== "object") {
    return null;
  }
  const raw = value;
  if (raw.version !== TEAM_TRANSCRIPT_AFFINITY_INDEX_SCHEMA_VERSION || typeof raw.teamName !== "string" || raw.teamName.length === 0 || typeof raw.projectId !== "string" || raw.projectId.length === 0 || typeof raw.projectDir !== "string" || raw.projectDir.length === 0 || !isIsoString(raw.writtenAt) || !raw.entries || typeof raw.entries !== "object") {
    return null;
  }
  const entries = {};
  for (const [fileName, entry] of Object.entries(raw.entries)) {
    const normalized = normalizeTeamTranscriptAffinityEntry(fileName, entry);
    if (normalized) {
      entries[fileName] = normalized;
    }
  }
  return {
    version: TEAM_TRANSCRIPT_AFFINITY_INDEX_SCHEMA_VERSION,
    teamName: raw.teamName,
    projectId: raw.projectId,
    projectDir: raw.projectDir,
    writtenAt: raw.writtenAt,
    entries
  };
}
function toTeamTranscriptAffinityIndex(value) {
  const entries = {};
  for (const [fileName, entry] of Object.entries(value.entries)) {
    const normalized = normalizeTeamTranscriptAffinityEntry(fileName, entry);
    if (normalized) {
      entries[fileName] = normalized;
    }
  }
  return {
    version: TEAM_TRANSCRIPT_AFFINITY_INDEX_SCHEMA_VERSION,
    teamName: value.teamName,
    projectId: value.projectId,
    projectDir: value.projectDir,
    writtenAt: value.writtenAt,
    entries
  };
}
const logger$2 = createLogger("Service:JsonTeamTranscriptAffinityIndexStore");
const READ_TIMEOUT_MS = 5e3;
function encodeFileSegment(value) {
  return encodeURIComponent(value);
}
function sortEntriesByFreshness(entries) {
  return [...entries].sort((left, right) => {
    const rightWrittenAt = Date.parse(right.writtenAt);
    const leftWrittenAt = Date.parse(left.writtenAt);
    return rightWrittenAt - leftWrittenAt || right.fileName.localeCompare(left.fileName);
  });
}
class JsonTeamTranscriptAffinityIndexStore {
  constructor(options = {}) {
    this.options = options;
  }
  options;
  writeChains = /* @__PURE__ */ new Map();
  get maxEntriesPerProject() {
    return Math.max(
      1,
      this.options.maxEntriesPerProject ?? TEAM_TRANSCRIPT_AFFINITY_INDEX_MAX_ENTRIES_PER_PROJECT
    );
  }
  filePath(teamName2, projectId) {
    return path__namespace$1.join(
      taskHistory.getTeamsBasePath(),
      teamName2,
      "cache",
      "transcript-affinity",
      `${encodeFileSegment(projectId)}.json`
    );
  }
  writeChainKey(teamName2, projectId) {
    return `${teamName2}\0${projectId}`;
  }
  async readIndex(teamName2, projectId) {
    const filePath = this.filePath(teamName2, projectId);
    let content;
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), READ_TIMEOUT_MS);
      try {
        content = await fs__namespace$2.readFile(filePath, {
          encoding: "utf8",
          signal: controller.signal
        });
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (error) {
      if (error.code === "ENOENT") {
        return null;
      }
      logger$2.debug(`Failed to read transcript affinity index ${filePath}: ${String(error)}`);
      return null;
    }
    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch (error) {
      logger$2.debug(`Corrupted transcript affinity index ${filePath}: ${String(error)}`);
      return null;
    }
    const normalized = normalizeTeamTranscriptAffinityIndex(parsed);
    if (!normalized || normalized.teamName !== teamName2 || normalized.projectId !== projectId) {
      return null;
    }
    return normalized;
  }
  async loadProject(teamName2, projectId) {
    return this.readIndex(teamName2, projectId);
  }
  async upsertProjectEntries(input) {
    const chainKey = this.writeChainKey(input.teamName, input.projectId);
    const write = async () => {
      const current = await this.readIndex(input.teamName, input.projectId);
      const entries = /* @__PURE__ */ new Map();
      for (const [fileName, entry] of Object.entries(current?.entries ?? {})) {
        if (input.rootFileNames.has(fileName)) {
          entries.set(fileName, entry);
        }
      }
      for (const entry of input.entries) {
        if (input.rootFileNames.has(entry.fileName)) {
          entries.set(entry.fileName, entry);
        }
      }
      const cappedEntries = sortEntriesByFreshness([...entries.values()]).slice(
        0,
        this.maxEntriesPerProject
      );
      const next2 = toTeamTranscriptAffinityIndex({
        teamName: input.teamName,
        projectId: input.projectId,
        projectDir: input.projectDir,
        writtenAt: (/* @__PURE__ */ new Date()).toISOString(),
        entries: Object.fromEntries(cappedEntries.map((entry) => [entry.fileName, entry]))
      });
      await taskHistory.atomicWriteAsync(
        this.filePath(input.teamName, input.projectId),
        `${JSON.stringify(next2, null, 2)}
`
      );
    };
    const previous = this.writeChains.get(chainKey) ?? Promise.resolve();
    const next = previous.catch(() => void 0).then(write).finally(() => {
      if (this.writeChains.get(chainKey) === next) {
        this.writeChains.delete(chainKey);
      }
    });
    this.writeChains.set(chainKey, next);
    await next;
  }
}
async function mayWriteTeamFiles(policy2, teamName2) {
  try {
    return await policy2(teamName2) === true;
  } catch {
    return false;
  }
}
const logger$1 = createLogger("Service:TeamTranscriptProjectResolver");
const SESSION_DISCOVERY_CACHE_TTL = 3e4;
const TEAM_AFFINITY_SCAN_LINES = 40;
const TEAM_AFFINITY_READ_CHUNK_BYTES = 64 * 1024;
const TEAM_AFFINITY_FILE_CACHE_MAX_ENTRIES = 4096;
const TEAM_AFFINITY_HEAD_METADATA_CACHE_MAX_ENTRIES = 4096;
const TEAM_AFFINITY_TEXT_MENTION_MAX_VALUE_LENGTH = 160;
const TEAM_AFFINITY_TEXT_MENTION_MAX_PER_LINE = 64;
const ROOT_DISCOVERY_CONCURRENCY = 12;
const FAST_CONTEXT_ROOT_DISCOVERY_MTIME_GRACE_MS = 24 * 60 * 6e4;
function trimTrailingSlashes(value) {
  let end = value.length;
  while (end > 0) {
    const ch = value.charCodeAt(end - 1);
    if (ch === 47 || ch === 92) {
      end -= 1;
      continue;
    }
    break;
  }
  return end === value.length ? value : value.slice(0, end);
}
function isSessionDirectoryName(name2) {
  return name2 !== "memory" && !name2.startsWith(".");
}
function buildContextCacheKey(teamName2, options) {
  const subagentMode = options?.includeTeamSubagentSessionDiscovery === false ? "known" : "full";
  return `${teamName2}\0${subagentMode}`;
}
function parseTimestampMs(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim().length > 0) {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function teamLifecycleMtimeCutoffMs(config) {
  const timestamps = [];
  const createdAt = parseTimestampMs(config.createdAt);
  if (createdAt !== null) {
    timestamps.push(createdAt);
  }
  for (const member2 of config.members ?? []) {
    const joinedAt = parseTimestampMs(member2.joinedAt);
    if (joinedAt !== null) {
      timestamps.push(joinedAt);
    }
  }
  if (timestamps.length === 0) {
    return null;
  }
  return Math.max(0, Math.min(...timestamps) - FAST_CONTEXT_ROOT_DISCOVERY_MTIME_GRACE_MS);
}
function normalizeProjectPathCandidate(value) {
  if (typeof value !== "string") {
    return null;
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }
  return trimTrailingSlashes(trimmed);
}
function extractTextContent(entry) {
  if (typeof entry.content === "string") {
    return entry.content;
  }
  if (Array.isArray(entry.content)) {
    const textParts = entry.content.filter((part) => part.type === "text" && typeof part.text === "string").map((part) => part.text);
    if (textParts.length > 0) {
      return textParts.join(" ");
    }
  }
  if (entry.message && typeof entry.message === "object") {
    return extractTextContent(entry.message);
  }
  return null;
}
function addTextMentionTeamName(teamNames, value) {
  const normalized = value.trim().toLowerCase();
  if (!normalized || normalized.length > TEAM_AFFINITY_TEXT_MENTION_MAX_VALUE_LENGTH) {
    return teamNames.size >= TEAM_AFFINITY_TEXT_MENTION_MAX_PER_LINE;
  }
  teamNames.add(normalized);
  return teamNames.size >= TEAM_AFFINITY_TEXT_MENTION_MAX_PER_LINE;
}
function collectTextMentionTeamNames(textContent) {
  const normalizedText = textContent?.trim().toLowerCase();
  if (!normalizedText) {
    return /* @__PURE__ */ new Set();
  }
  const teamNames = /* @__PURE__ */ new Set();
  const quotedPattern = /\b(?:team name|on team|team)\s+["']([^"'\r\n]{1,160})["']/g;
  let match;
  let reachedLimit = false;
  while (match = quotedPattern.exec(normalizedText)) {
    if (addTextMentionTeamName(teamNames, match[1] ?? "")) {
      reachedLimit = true;
      break;
    }
  }
  if (!reachedLimit) {
    const colonPattern = /\bteam name:\s*["']?([^"'\r\n,.;|)\]}]{1,160})/g;
    while (match = colonPattern.exec(normalizedText)) {
      if (addTextMentionTeamName(teamNames, match[1] ?? "")) {
        reachedLimit = true;
        break;
      }
    }
  }
  if (!reachedLimit) {
    const parentheticalPattern = /\(([^()\r\n]{1,160})\)/g;
    while (match = parentheticalPattern.exec(normalizedText)) {
      if (addTextMentionTeamName(teamNames, match[1] ?? "")) {
        break;
      }
    }
  }
  return teamNames;
}
function collectNestedTeamNames(value, teamNames, depth = 0) {
  if (!value || depth > 8 || typeof value !== "object") {
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      collectNestedTeamNames(item, teamNames, depth + 1);
    }
    return;
  }
  const entry = value;
  if (typeof entry.teamName === "string") {
    const normalizedTeamName = entry.teamName.trim().toLowerCase();
    if (normalizedTeamName) {
      teamNames.add(normalizedTeamName);
    }
  }
  for (const [key, nested] of Object.entries(entry)) {
    if (key === "teamName") {
      continue;
    }
    collectNestedTeamNames(nested, teamNames, depth + 1);
  }
}
function parseTeamAffinityHeadLine(rawLine) {
  const empty = {
    nestedTeamNames: /* @__PURE__ */ new Set(),
    textMentionTeamNames: /* @__PURE__ */ new Set()
  };
  try {
    const entry = JSON.parse(rawLine);
    const nestedTeamNames = /* @__PURE__ */ new Set();
    collectNestedTeamNames(entry, nestedTeamNames);
    const textContent = extractTextContent(entry);
    return {
      nestedTeamNames,
      textMentionTeamNames: collectTextMentionTeamNames(textContent)
    };
  } catch {
    return empty;
  }
}
function collectKnownSessionIds(config) {
  const knownSessionIds = /* @__PURE__ */ new Set();
  const push = (value) => {
    const sessionId = normalizeLogSourceSessionId(value);
    if (sessionId) knownSessionIds.add(sessionId);
  };
  push(config.leadSessionId);
  if (Array.isArray(config.sessionHistory)) {
    for (let index = config.sessionHistory.length - 1; index >= 0; index -= 1) {
      const sessionId = config.sessionHistory[index];
      push(sessionId);
    }
  }
  return [...knownSessionIds];
}
class TeamTranscriptProjectResolver {
  constructor(canWriteTeamFiles, configReader = new TeamConfigReader(), affinityIndexStore = new JsonTeamTranscriptAffinityIndexStore()) {
    this.canWriteTeamFiles = canWriteTeamFiles;
    this.configReader = configReader;
    this.affinityIndexStore = affinityIndexStore;
  }
  canWriteTeamFiles;
  configReader;
  affinityIndexStore;
  contextCache = /* @__PURE__ */ new Map();
  teamAffinityFileCache = /* @__PURE__ */ new Map();
  teamAffinityHeadMetadataCache = /* @__PURE__ */ new Map();
  readConfigForObservation(teamName2) {
    return typeof this.configReader.getConfigSnapshot === "function" ? this.configReader.getConfigSnapshot(teamName2) : this.configReader.getConfig(teamName2);
  }
  deleteContextCacheForTeam(teamName2) {
    this.contextCache.delete(teamName2);
    for (const key of this.contextCache.keys()) {
      if (key === teamName2 || key.startsWith(`${teamName2}\0`)) {
        this.contextCache.delete(key);
      }
    }
  }
  async getLiveBaseContext(teamName2, options) {
    if (options?.forceRefresh) {
      this.deleteContextCacheForTeam(teamName2);
    }
    const config = await this.readConfigForObservation(teamName2);
    if (!config) {
      return null;
    }
    const projectPathCandidates = this.collectLiveProjectPathCandidates(
      config,
      options?.extraProjectPathCandidates ?? []
    );
    const resolution = await this.resolveLiveProjectDirectoryFromCandidates(projectPathCandidates);
    if (!resolution) {
      return null;
    }
    const resolvedConfig = trimTrailingSlashes(config.projectPath ?? "") !== trimTrailingSlashes(resolution.effectiveProjectPath) ? { ...config, projectPath: resolution.effectiveProjectPath } : config;
    return {
      projectDir: resolution.projectDir,
      projectId: resolution.projectId,
      config: resolvedConfig
    };
  }
  async getContext(teamName2, options) {
    const cacheKey = buildContextCacheKey(teamName2, options);
    if (options?.forceRefresh) {
      this.deleteContextCacheForTeam(teamName2);
    }
    const cached = this.contextCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.value;
    }
    const config = await this.readConfigForObservation(teamName2);
    if (!config) {
      return null;
    }
    const resolution = await this.resolveProjectDirectory(teamName2, config);
    if (!resolution) {
      return null;
    }
    const resolvedConfig = resolution.effectiveProjectPath && trimTrailingSlashes(resolution.effectiveProjectPath) !== trimTrailingSlashes(config.projectPath ?? "") ? {
      ...config,
      projectPath: resolution.effectiveProjectPath,
      projectPathHistory: this.buildRepairedProjectPathHistory(
        config.projectPath,
        config.projectPathHistory,
        resolution.effectiveProjectPath
      )
    } : config;
    const sessionIds = await this.discoverSessionIds(
      teamName2,
      resolution.projectDir,
      resolution.projectId,
      resolvedConfig,
      options
    );
    const value = {
      projectDir: resolution.projectDir,
      projectId: resolution.projectId,
      config: resolvedConfig,
      sessionIds
    };
    this.contextCache.set(cacheKey, {
      value,
      expiresAt: Date.now() + SESSION_DISCOVERY_CACHE_TTL
    });
    return value;
  }
  async resolveProjectDirectory(teamName2, config) {
    const sessionIds = collectKnownSessionIds(config);
    const pathCandidates = this.collectProjectPathCandidates(config);
    const currentCandidate = pathCandidates[0] ?? null;
    if (sessionIds.length === 0) {
      return this.buildFallbackResolution(teamName2, pathCandidates);
    }
    const rankBySessionId = new Map(sessionIds.map((sessionId, index) => [sessionId, index]));
    const getMatchRank = (match) => match ? rankBySessionId.get(match.matchedSessionId) ?? Number.POSITIVE_INFINITY : Number.POSITIVE_INFINITY;
    const toResolution = (match) => ({
      projectDir: match.projectDir,
      projectId: match.projectId,
      ...match.projectPath ? { effectiveProjectPath: match.projectPath } : {}
    });
    let currentMatch = null;
    if (currentCandidate) {
      const resolvedCurrentMatch = await this.findMatchInProjectPathCandidate(
        currentCandidate,
        sessionIds
      );
      if (resolvedCurrentMatch && getMatchRank(resolvedCurrentMatch) === 0) {
        return toResolution(resolvedCurrentMatch);
      }
      if (resolvedCurrentMatch) {
        currentMatch = resolvedCurrentMatch;
      }
    }
    const configuredMatches = pathCandidates.length > 1 ? await this.findMatchesInProjectPathCandidates(pathCandidates.slice(1), sessionIds) : [];
    const scannedMatches = await this.findMatchesByScanningProjects(sessionIds);
    const candidateMatchesByProjectDir = /* @__PURE__ */ new Map();
    for (const match of configuredMatches) {
      if (match.projectDir === currentMatch?.projectDir) {
        continue;
      }
      candidateMatchesByProjectDir.set(match.projectDir, match);
    }
    for (const match of scannedMatches) {
      if (match.projectDir === currentMatch?.projectDir) {
        continue;
      }
      if (!candidateMatchesByProjectDir.has(match.projectDir)) {
        candidateMatchesByProjectDir.set(match.projectDir, match);
      }
    }
    const alternateMatches = [...candidateMatchesByProjectDir.values()];
    const bestAlternateRank = alternateMatches.reduce(
      (best, match) => Math.min(best, getMatchRank(match)),
      Number.POSITIVE_INFINITY
    );
    const currentRank = getMatchRank(currentMatch);
    if (currentMatch && currentRank <= bestAlternateRank) {
      return toResolution(currentMatch);
    }
    if (bestAlternateRank !== Number.POSITIVE_INFINITY) {
      const bestAlternates = alternateMatches.filter(
        (match) => getMatchRank(match) === bestAlternateRank
      );
      if (bestAlternates.length === 1) {
        const winner = bestAlternates[0];
        if (winner.projectPath) {
          await this.persistResolvedProjectPath(teamName2, config, winner.projectPath);
        }
        return toResolution(winner);
      }
      logger$1.warn(
        `[${teamName2}] Transcript project resolution ambiguous across exact-session candidates; keeping current path`
      );
      return currentMatch ? toResolution(currentMatch) : this.buildFallbackResolution(teamName2, pathCandidates);
    }
    if (currentMatch) {
      return toResolution(currentMatch);
    }
    return this.buildFallbackResolution(teamName2, pathCandidates);
  }
  async buildFallbackResolution(teamName2, candidates) {
    let firstResolution = null;
    let firstExistingResolution = null;
    for (const candidate of candidates) {
      for (const dirCandidate of this.buildProjectDirCandidates(candidate.projectPath)) {
        const resolution = {
          projectDir: dirCandidate.projectDir,
          projectId: dirCandidate.projectId,
          effectiveProjectPath: candidate.projectPath
        };
        if (!firstResolution) {
          firstResolution = resolution;
        }
        if (!await this.projectDirExists(dirCandidate.projectDir)) {
          continue;
        }
        if (!firstExistingResolution) {
          firstExistingResolution = resolution;
        }
        const teamRootSessionIds = await this.listTeamRootSessionIds(
          dirCandidate.projectDir,
          dirCandidate.projectId,
          teamName2
        );
        if (teamRootSessionIds.length > 0) {
          return resolution;
        }
      }
    }
    return firstExistingResolution ?? firstResolution;
  }
  collectProjectPathCandidates(config) {
    const candidates = [];
    const seen = /* @__PURE__ */ new Set();
    const push = (value, source) => {
      const normalized = normalizeProjectPathCandidate(value);
      if (!normalized || seen.has(normalized)) {
        return;
      }
      seen.add(normalized);
      candidates.push({ projectPath: normalized, source });
    };
    push(config.projectPath, "projectPath");
    if (Array.isArray(config.projectPathHistory)) {
      for (let index = config.projectPathHistory.length - 1; index >= 0; index -= 1) {
        push(config.projectPathHistory[index], "projectPathHistory");
      }
    }
    const leadCwd = (config.members ?? []).find((member2) => taskHistory.isLeadMember(member2))?.cwd;
    push(leadCwd, "leadCwd");
    const distinctMemberCwds = Array.from(
      new Set(
        (config.members ?? []).map((member2) => normalizeProjectPathCandidate(member2.cwd)).filter((cwd) => Boolean(cwd))
      )
    );
    if (distinctMemberCwds.length === 1) {
      push(distinctMemberCwds[0], "memberCwd");
    }
    return candidates;
  }
  collectLiveProjectPathCandidates(config, extraCandidates) {
    const candidates = [];
    const seen = /* @__PURE__ */ new Set();
    const push = (value) => {
      const normalized = normalizeProjectPathCandidate(value);
      if (!normalized || seen.has(normalized)) {
        return;
      }
      seen.add(normalized);
      candidates.push(normalized);
    };
    push(config.projectPath);
    const history = Array.isArray(config.projectPathHistory) ? config.projectPathHistory : [];
    for (let index = history.length - 1; index >= Math.max(0, history.length - 5); index -= 1) {
      push(history[index]);
    }
    push((config.members ?? []).find((member2) => taskHistory.isLeadMember(member2))?.cwd);
    const distinctMemberCwds = new Set(
      (config.members ?? []).map((member2) => normalizeProjectPathCandidate(member2.cwd)).filter((cwd) => Boolean(cwd))
    );
    if (distinctMemberCwds.size === 1) {
      push([...distinctMemberCwds][0]);
    }
    for (const candidate of extraCandidates.slice(0, 64)) {
      push(candidate);
    }
    return candidates;
  }
  buildProjectDirCandidates(projectPath) {
    const normalizedProjectPath = trimTrailingSlashes(projectPath);
    const projectId = taskHistory.extractBaseDir(taskHistory.encodePath(normalizedProjectPath));
    const baseCandidates = [
      { projectDir: path__namespace$1.join(taskHistory.getProjectsBasePath(), projectId), projectId },
      ...projectId.includes("_") ? [
        {
          projectDir: path__namespace$1.join(taskHistory.getProjectsBasePath(), projectId.replace(/_/g, "-")),
          projectId: projectId.replace(/_/g, "-")
        }
      ] : []
    ];
    const seen = /* @__PURE__ */ new Set();
    return baseCandidates.filter((candidate) => {
      if (seen.has(candidate.projectDir)) {
        return false;
      }
      seen.add(candidate.projectDir);
      return true;
    }).map((candidate) => ({
      projectPath: normalizedProjectPath,
      projectDir: candidate.projectDir,
      projectId: candidate.projectId,
      source: "projectPath"
    }));
  }
  async resolveLiveProjectDirectoryFromCandidates(candidates) {
    for (const projectPath of candidates) {
      for (const dirCandidate of this.buildProjectDirCandidates(projectPath)) {
        const resolution = {
          projectDir: dirCandidate.projectDir,
          projectId: dirCandidate.projectId,
          effectiveProjectPath: projectPath
        };
        if (await this.projectDirExists(dirCandidate.projectDir)) {
          return resolution;
        }
      }
    }
    return null;
  }
  async findMatchInProjectPathCandidate(candidate, sessionIds) {
    const rankBySessionId = new Map(sessionIds.map((sessionId, index) => [sessionId, index]));
    let bestMatch = null;
    for (const projectCandidate of this.buildProjectDirCandidates(candidate.projectPath)) {
      const matchedSessionId = await this.findMatchingSessionId(
        projectCandidate.projectDir,
        sessionIds
      );
      if (!matchedSessionId) {
        continue;
      }
      const match = {
        ...projectCandidate,
        source: candidate.source,
        matchedSessionId
      };
      const matchRank = rankBySessionId.get(match.matchedSessionId) ?? Number.POSITIVE_INFINITY;
      const bestRank = bestMatch ? rankBySessionId.get(bestMatch.matchedSessionId) ?? Number.POSITIVE_INFINITY : Number.POSITIVE_INFINITY;
      if (!bestMatch || matchRank < bestRank) {
        bestMatch = match;
      }
      if (matchRank === 0) {
        break;
      }
    }
    return bestMatch;
  }
  async findMatchesInProjectPathCandidates(candidates, sessionIds) {
    const matches = [];
    const seenProjectDirs = /* @__PURE__ */ new Set();
    for (const candidate of candidates) {
      const match = await this.findMatchInProjectPathCandidate(candidate, sessionIds);
      if (!match || seenProjectDirs.has(match.projectDir)) {
        continue;
      }
      seenProjectDirs.add(match.projectDir);
      matches.push(match);
    }
    return matches;
  }
  async findMatchingSessionId(projectDir, sessionIds) {
    for (const sessionId of sessionIds) {
      try {
        const stat = await fs__namespace$2.stat(path__namespace$1.join(projectDir, `${sessionId}.jsonl`));
        if (stat.isFile()) {
          return sessionId;
        }
      } catch {
      }
    }
    return null;
  }
  async findMatchesByScanningProjects(sessionIds) {
    let projectEntries;
    try {
      projectEntries = await fs__namespace$2.readdir(taskHistory.getProjectsBasePath(), { withFileTypes: true });
    } catch {
      return [];
    }
    const directories = projectEntries.filter((entry) => entry.isDirectory());
    const matches = [];
    let nextIndex = 0;
    const worker = async () => {
      while (nextIndex < directories.length) {
        const index = nextIndex++;
        const entry = directories[index];
        const projectDir = path__namespace$1.join(taskHistory.getProjectsBasePath(), entry.name);
        const matchedSessionId = await this.findMatchingSessionId(projectDir, sessionIds);
        if (!matchedSessionId) {
          continue;
        }
        const jsonlPath = path__namespace$1.join(projectDir, `${matchedSessionId}.jsonl`);
        const cwd = await extractCwd(jsonlPath);
        matches.push({
          projectPath: cwd ?? void 0,
          projectDir,
          projectId: entry.name,
          source: "projectsScan",
          matchedSessionId
        });
      }
    };
    await Promise.all(
      Array.from(
        { length: Math.min(ROOT_DISCOVERY_CONCURRENCY, directories.length) },
        () => worker()
      )
    );
    const deduped = /* @__PURE__ */ new Map();
    for (const match of matches) {
      if (!deduped.has(match.projectDir)) {
        deduped.set(match.projectDir, match);
      }
    }
    return [...deduped.values()];
  }
  async persistResolvedProjectPath(teamName2, config, nextProjectPath) {
    const normalizedNextPath = normalizeProjectPathCandidate(nextProjectPath);
    const currentProjectPath = normalizeProjectPathCandidate(config.projectPath);
    if (!normalizedNextPath || currentProjectPath === normalizedNextPath) {
      return;
    }
    if (!await mayWriteTeamFiles(this.canWriteTeamFiles, teamName2)) {
      return;
    }
    const configPath = path__namespace$1.join(taskHistory.getTeamsBasePath(), teamName2, "config.json");
    try {
      const raw = await fs__namespace$2.readFile(configPath, "utf8");
      const parsed = JSON.parse(raw);
      const rawProjectPath = normalizeProjectPathCandidate(parsed.projectPath) ?? currentProjectPath ?? null;
      parsed.projectPath = normalizedNextPath;
      parsed.projectPathHistory = this.buildRepairedProjectPathHistory(
        rawProjectPath,
        parsed.projectPathHistory,
        normalizedNextPath
      );
      await taskHistory.atomicWriteAsync(configPath, JSON.stringify(parsed, null, 2));
      TeamConfigReader.invalidateTeam(teamName2);
      logger$1.info(
        `[${teamName2}] Repaired transcript projectPath via exact session match: ${normalizedNextPath}`
      );
    } catch (error) {
      logger$1.warn(
        `[${teamName2}] Failed to persist repaired transcript projectPath: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  }
  async discoverSessionIds(teamName2, projectDir, projectId, config, options) {
    const knownSessionIds = collectKnownSessionIds(config);
    const includeTeamSubagentSessionDiscovery = options?.includeTeamSubagentSessionDiscovery !== false;
    const rootMtimeSinceMs = includeTeamSubagentSessionDiscovery ? null : teamLifecycleMtimeCutoffMs(config);
    const [teamRootSessionIds, teamSubagentSessionIds] = await Promise.all([
      this.listTeamRootSessionIds(projectDir, projectId, teamName2, rootMtimeSinceMs),
      includeTeamSubagentSessionDiscovery ? this.listTeamSubagentSessionIds(projectDir, teamName2) : Promise.resolve([])
    ]);
    const orderedSessionIds = [];
    const seen = /* @__PURE__ */ new Set();
    const push = (sessionId) => {
      const normalized = normalizeLogSourceSessionId(sessionId);
      if (!normalized || seen.has(normalized)) {
        return;
      }
      seen.add(normalized);
      orderedSessionIds.push(normalized);
    };
    for (const sessionId of knownSessionIds) {
      push(sessionId);
    }
    for (const sessionId of [...teamRootSessionIds, ...teamSubagentSessionIds].sort(
      (left, right) => left.localeCompare(right)
    )) {
      push(sessionId);
    }
    return orderedSessionIds;
  }
  buildRepairedProjectPathHistory(currentProjectPath, rawProjectPathHistory, nextProjectPath) {
    const normalizedNextPath = normalizeProjectPathCandidate(nextProjectPath);
    const history = [];
    const seen = /* @__PURE__ */ new Set();
    const pushHistory = (value) => {
      const normalized = normalizeProjectPathCandidate(value);
      if (!normalized || normalized === normalizedNextPath || seen.has(normalized)) {
        return;
      }
      seen.add(normalized);
      history.push(normalized);
    };
    if (Array.isArray(rawProjectPathHistory)) {
      for (const value of rawProjectPathHistory) {
        pushHistory(value);
      }
    }
    pushHistory(currentProjectPath);
    return history.slice(-500);
  }
  async projectDirExists(projectDir) {
    try {
      const stat = await fs__namespace$2.stat(projectDir);
      return stat.isDirectory();
    } catch {
      return false;
    }
  }
  async readProjectDirEntries(projectDir) {
    try {
      return await fs__namespace$2.readdir(projectDir, { withFileTypes: true });
    } catch {
      logger$1.debug(`Cannot read transcript project dir: ${projectDir}`);
      return null;
    }
  }
  async listTeamSubagentSessionIds(projectDir, teamName2) {
    const dirEntries = await this.readProjectDirEntries(projectDir);
    if (!dirEntries) {
      return [];
    }
    const sessionDirEntries = dirEntries.filter(
      (entry) => entry.isDirectory() && isSessionDirectoryName(entry.name)
    );
    const discovered = /* @__PURE__ */ new Set();
    let nextIndex = 0;
    const scanNextSessionDir = async () => {
      while (nextIndex < sessionDirEntries.length) {
        const entry = sessionDirEntries[nextIndex++];
        const subagentsDir = path__namespace$1.join(projectDir, entry.name, "subagents");
        let subagentEntries;
        try {
          subagentEntries = await fs__namespace$2.readdir(subagentsDir, { withFileTypes: true });
        } catch {
          continue;
        }
        for (const subagentEntry of subagentEntries) {
          if (!subagentEntry.isFile()) {
            continue;
          }
          if (!subagentEntry.name.endsWith(".jsonl")) {
            continue;
          }
          if (!subagentEntry.name.startsWith("agent-")) {
            continue;
          }
          if (subagentEntry.name.startsWith("agent-acompact")) {
            continue;
          }
          const filePath = path__namespace$1.join(subagentsDir, subagentEntry.name);
          if (await this.fileBelongsToTeam(filePath, teamName2)) {
            discovered.add(entry.name);
            break;
          }
        }
      }
    };
    await Promise.all(
      Array.from(
        { length: Math.min(ROOT_DISCOVERY_CONCURRENCY, sessionDirEntries.length) },
        () => scanNextSessionDir()
      )
    );
    return [...discovered];
  }
  async collectRootJsonlSessionIds(rootJsonlEntries, projectDir, projectId, teamName2, mtimeSinceMs) {
    const discovered = /* @__PURE__ */ new Set();
    const rootFileNames = new Set(rootJsonlEntries.map((entry) => entry.name));
    const indexEnabled = this.isPersistentAffinityIndexEnabled();
    const affinityIndex = indexEnabled ? await this.loadTeamTranscriptAffinityIndex(teamName2, projectId) : null;
    const shouldPruneAffinityIndex = Boolean(
      affinityIndex && Object.keys(affinityIndex.entries).some((fileName) => !rootFileNames.has(fileName))
    );
    const pendingIndexEntries = [];
    let nextIndex = 0;
    const scanNextRootEntry = async () => {
      while (nextIndex < rootJsonlEntries.length) {
        const entry = rootJsonlEntries[nextIndex++];
        const filePath = path__namespace$1.join(projectDir, entry.name);
        let fileStat;
        try {
          fileStat = await fs__namespace$2.stat(filePath);
        } catch {
          continue;
        }
        if (!fileStat.isFile() || mtimeSinceMs != null && fileStat.mtimeMs < mtimeSinceMs) {
          continue;
        }
        const indexedBelongsToTeam = indexEnabled ? this.decideTeamAffinityFromIndex(affinityIndex?.entries[entry.name], fileStat) : null;
        if (indexedBelongsToTeam !== null) {
          if (indexedBelongsToTeam) {
            discovered.add(entry.name.slice(0, -".jsonl".length));
          }
          continue;
        }
        const inspection = await this.inspectFileTeamAffinity(filePath, teamName2, fileStat);
        if (inspection.belongsToTeam) {
          discovered.add(entry.name.slice(0, -".jsonl".length));
        }
        if (inspection.indexable) {
          const indexEntry = this.buildTeamAffinityIndexEntry(entry.name, fileStat, inspection);
          if (indexEntry) {
            pendingIndexEntries.push(indexEntry);
          }
        }
      }
    };
    await Promise.all(
      Array.from(
        { length: Math.min(ROOT_DISCOVERY_CONCURRENCY, rootJsonlEntries.length) },
        () => scanNextRootEntry()
      )
    );
    const writeIndex = indexEnabled && (pendingIndexEntries.length > 0 || shouldPruneAffinityIndex);
    if (writeIndex && await mayWriteTeamFiles(this.canWriteTeamFiles, teamName2)) {
      await this.affinityIndexStore.upsertProjectEntries({
        teamName: teamName2,
        projectId,
        projectDir,
        rootFileNames,
        entries: pendingIndexEntries
      }).catch((error) => {
        logger$1.debug(`Failed to write transcript affinity index: ${String(error)}`);
      });
    }
    return [...discovered];
  }
  async listTeamRootSessionIds(projectDir, projectId, teamName2, mtimeSinceMs) {
    const dirEntries = await this.readProjectDirEntries(projectDir);
    if (!dirEntries) {
      return [];
    }
    const rootJsonlEntries = dirEntries.filter(
      (entry) => entry.isFile() && entry.name.endsWith(".jsonl")
    );
    return this.collectRootJsonlSessionIds(
      rootJsonlEntries,
      projectDir,
      projectId,
      teamName2,
      mtimeSinceMs
    );
  }
  async fileBelongsToTeam(filePath, teamName2, precomputedStat) {
    return (await this.inspectFileTeamAffinity(filePath, teamName2, precomputedStat)).belongsToTeam;
  }
  async inspectFileTeamAffinity(filePath, teamName2, precomputedStat) {
    const emptyResult = {
      belongsToTeam: false,
      inspectedLineCount: 0,
      matchSource: "none",
      headWindowFull: false,
      indexable: false
    };
    const normalizedTeam = teamName2.trim().toLowerCase();
    if (!normalizedTeam) {
      return emptyResult;
    }
    let fileStat;
    if (precomputedStat) {
      fileStat = precomputedStat;
    } else {
      try {
        fileStat = await fs__namespace$2.stat(filePath);
      } catch {
        return emptyResult;
      }
    }
    if (!fileStat.isFile()) {
      return emptyResult;
    }
    const cacheKey = this.buildTeamAffinityFileCacheKey(filePath, normalizedTeam);
    const cached = this.teamAffinityFileCache.get(cacheKey);
    if (cached) {
      if (this.teamTranscriptFileSignaturesMatch(cached, fileStat)) {
        return {
          belongsToTeam: cached.belongsToTeam,
          inspectedLineCount: 0,
          matchSource: "none",
          headWindowFull: cached.headWindowFull,
          indexable: false
        };
      }
      if (cached.belongsToTeam && fileStat.size >= cached.size && await this.isCachedTeamAffinityHeadCurrent(filePath, cached)) {
        return {
          belongsToTeam: true,
          inspectedLineCount: 0,
          matchSource: "none",
          headWindowFull: cached.headWindowFull,
          indexable: false
        };
      }
      if (!cached.belongsToTeam && cached.headWindowFull && fileStat.size >= cached.size && await this.isCachedTeamAffinityHeadCurrent(filePath, cached)) {
        return {
          belongsToTeam: false,
          inspectedLineCount: 0,
          matchSource: "none",
          headWindowFull: true,
          indexable: false
        };
      }
    }
    const headMetadata = await this.getTeamAffinityHeadMetadata(filePath, fileStat);
    if (!headMetadata) {
      return emptyResult;
    }
    const evaluation = this.evaluateTeamAffinityHeadMetadata(headMetadata, normalizedTeam);
    const headWindowFull = evaluation.inspectedLineCount >= TEAM_AFFINITY_SCAN_LINES;
    this.setTeamAffinityFileCacheEntry(cacheKey, {
      mtimeMs: fileStat.mtimeMs,
      size: fileStat.size,
      ...fileStat.ctimeMs != null && Number.isFinite(fileStat.ctimeMs) ? { ctimeMs: fileStat.ctimeMs } : {},
      belongsToTeam: evaluation.belongsToTeam,
      inspectedLineCount: headMetadata.inspectedLineCount,
      headFingerprint: headMetadata.headFingerprint,
      headWindowFull
    });
    return {
      ...evaluation,
      headWindowFull,
      indexable: true
    };
  }
  evaluateTeamAffinityHeadMetadata(metadata, normalizedTeam) {
    let inspectedLineCount = 0;
    for (const line of metadata.lines) {
      inspectedLineCount += 1;
      if (line.nestedTeamNames.has(normalizedTeam)) {
        return { belongsToTeam: true, inspectedLineCount, matchSource: "nested_team_name" };
      }
      if (line.textMentionTeamNames.has(normalizedTeam)) {
        return { belongsToTeam: true, inspectedLineCount, matchSource: "text_team_mention" };
      }
    }
    return {
      belongsToTeam: false,
      inspectedLineCount: metadata.inspectedLineCount,
      matchSource: "none"
    };
  }
  isPersistentAffinityIndexEnabled() {
    return process.env.CLAUDE_TEAM_TRANSCRIPT_AFFINITY_INDEX !== "0";
  }
  async loadTeamTranscriptAffinityIndex(teamName2, projectId) {
    try {
      return await this.affinityIndexStore.loadProject(teamName2, projectId);
    } catch (error) {
      logger$1.debug(`Failed to load transcript affinity index: ${String(error)}`);
      return null;
    }
  }
  decideTeamAffinityFromIndex(entry, fileStat) {
    if (!entry) {
      return null;
    }
    if (!this.teamTranscriptFileSignaturesMatch(entry.signature, fileStat)) {
      return null;
    }
    return entry.verdict === "belongs";
  }
  teamTranscriptFileSignaturesMatch(cached, fileStat) {
    if (cached.size !== fileStat.size || cached.mtimeMs !== fileStat.mtimeMs) {
      return false;
    }
    const cachedCtimeMs = cached.ctimeMs != null && Number.isFinite(cached.ctimeMs) ? cached.ctimeMs : null;
    const currentCtimeMs = fileStat.ctimeMs != null && Number.isFinite(fileStat.ctimeMs) ? fileStat.ctimeMs : null;
    if (cachedCtimeMs !== null || currentCtimeMs !== null) {
      return cachedCtimeMs !== null && currentCtimeMs !== null && cachedCtimeMs === currentCtimeMs;
    }
    return true;
  }
  buildTeamAffinityIndexEntry(fileName, fileStat, inspection) {
    if (fileName.length <= ".jsonl".length || !fileName.endsWith(".jsonl") || fileName.includes("/") || fileName.includes("\\")) {
      return null;
    }
    const sessionId = fileName.slice(0, -".jsonl".length);
    const signature = {
      size: fileStat.size,
      mtimeMs: fileStat.mtimeMs,
      ...fileStat.ctimeMs != null && Number.isFinite(fileStat.ctimeMs) ? { ctimeMs: fileStat.ctimeMs } : {}
    };
    return {
      fileName,
      sessionId,
      signature,
      verdict: inspection.belongsToTeam ? "belongs" : "does_not_belong",
      headWindowFull: inspection.headWindowFull,
      inspectedLineCount: inspection.inspectedLineCount,
      matchSource: inspection.matchSource,
      writtenAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  async isCachedTeamAffinityHeadCurrent(filePath, cached) {
    if (cached.inspectedLineCount <= 0) {
      return false;
    }
    const fingerprint = require$$0.createHash("sha256");
    let inspectedLineCount = 0;
    const inspectHeadLine = (rawLine) => {
      const trimmed = rawLine.trim();
      if (!trimmed) {
        return false;
      }
      inspectedLineCount += 1;
      fingerprint.update(trimmed);
      fingerprint.update("\n");
      return inspectedLineCount >= cached.inspectedLineCount;
    };
    let handle = null;
    try {
      handle = await fs__namespace$2.open(filePath, "r");
      const decoder = new string_decoder.StringDecoder("utf8");
      const chunk = Buffer.allocUnsafe(TEAM_AFFINITY_READ_CHUNK_BYTES);
      let pending = "";
      let position = 0;
      let stop = false;
      while (!stop) {
        const { bytesRead } = await handle.read(chunk, 0, chunk.length, position);
        if (bytesRead <= 0) {
          pending += decoder.end();
          if (pending.length > 0) {
            inspectHeadLine(pending);
          }
          break;
        }
        position += bytesRead;
        pending += decoder.write(chunk.subarray(0, bytesRead));
        let newlineIndex = pending.indexOf("\n");
        while (newlineIndex !== -1) {
          const line = pending.slice(0, newlineIndex);
          pending = pending.slice(newlineIndex + 1);
          if (inspectHeadLine(line)) {
            stop = true;
            break;
          }
          newlineIndex = pending.indexOf("\n");
        }
      }
    } catch {
      return false;
    } finally {
      await handle?.close().catch(() => void 0);
    }
    return inspectedLineCount === cached.inspectedLineCount && fingerprint.digest("hex") === cached.headFingerprint;
  }
  async getTeamAffinityHeadMetadata(filePath, fileStat) {
    const cached = this.teamAffinityHeadMetadataCache.get(filePath);
    if (cached && this.teamTranscriptFileSignaturesMatch(cached, fileStat)) {
      return cached;
    }
    if (cached) {
      this.teamAffinityHeadMetadataCache.delete(filePath);
    }
    const lines = [];
    const fingerprint = require$$0.createHash("sha256");
    let inspectedLineCount = 0;
    const inspectHeadLine = (rawLine) => {
      const trimmed = rawLine.trim();
      if (!trimmed) {
        return false;
      }
      inspectedLineCount += 1;
      fingerprint.update(trimmed);
      fingerprint.update("\n");
      lines.push(parseTeamAffinityHeadLine(trimmed));
      return inspectedLineCount >= TEAM_AFFINITY_SCAN_LINES;
    };
    let handle = null;
    try {
      handle = await fs__namespace$2.open(filePath, "r");
      const decoder = new string_decoder.StringDecoder("utf8");
      const chunk = Buffer.allocUnsafe(TEAM_AFFINITY_READ_CHUNK_BYTES);
      let pending = "";
      let position = 0;
      let stop = false;
      while (!stop) {
        const { bytesRead } = await handle.read(chunk, 0, chunk.length, position);
        if (bytesRead <= 0) {
          pending += decoder.end();
          if (pending.length > 0) {
            inspectHeadLine(pending);
          }
          break;
        }
        position += bytesRead;
        pending += decoder.write(chunk.subarray(0, bytesRead));
        let newlineIndex = pending.indexOf("\n");
        while (newlineIndex !== -1) {
          const line = pending.slice(0, newlineIndex);
          pending = pending.slice(newlineIndex + 1);
          if (inspectHeadLine(line)) {
            stop = true;
            break;
          }
          newlineIndex = pending.indexOf("\n");
        }
      }
    } catch {
      return null;
    } finally {
      await handle?.close().catch(() => void 0);
    }
    const entry = {
      mtimeMs: fileStat.mtimeMs,
      size: fileStat.size,
      ...fileStat.ctimeMs != null && Number.isFinite(fileStat.ctimeMs) ? { ctimeMs: fileStat.ctimeMs } : {},
      inspectedLineCount,
      headFingerprint: fingerprint.digest("hex"),
      lines
    };
    this.setTeamAffinityHeadMetadataCacheEntry(filePath, entry);
    return entry;
  }
  buildTeamAffinityFileCacheKey(filePath, normalizedTeam) {
    return `${normalizedTeam}\0${filePath}`;
  }
  setTeamAffinityFileCacheEntry(cacheKey, entry) {
    if (!this.teamAffinityFileCache.has(cacheKey) && this.teamAffinityFileCache.size >= TEAM_AFFINITY_FILE_CACHE_MAX_ENTRIES) {
      const oldestKey = this.teamAffinityFileCache.keys().next().value;
      if (oldestKey) {
        this.teamAffinityFileCache.delete(oldestKey);
      }
    }
    this.teamAffinityFileCache.set(cacheKey, entry);
  }
  setTeamAffinityHeadMetadataCacheEntry(filePath, entry) {
    if (!this.teamAffinityHeadMetadataCache.has(filePath) && this.teamAffinityHeadMetadataCache.size >= TEAM_AFFINITY_HEAD_METADATA_CACHE_MAX_ENTRIES) {
      const oldestKey = this.teamAffinityHeadMetadataCache.keys().next().value;
      if (oldestKey) {
        this.teamAffinityHeadMetadataCache.delete(oldestKey);
      }
    }
    this.teamAffinityHeadMetadataCache.set(filePath, entry);
  }
}
const logger = createLogger("Service:TeamMemberLogsFinder");
const ATTRIBUTION_SCAN_LINES = 50;
const TASK_SINCE_GRACE_MS = 2 * 60 * 1e3;
const TASK_MENTION_INDEX_CACHE_MAX = 1e3;
const ATTRIBUTION_CACHE_MAX = 5e3;
const SCAN_CONCURRENCY = 15;
const DISCOVERY_CACHE_TTL = 3e4;
const MAX_TASK_FRESHNESS_ROOT_DIRS = 64;
const SIGNAL_PRECEDENCE = [
  "process_team",
  "routing_sender",
  "teammate_id",
  "text_mention"
];
async function mapLimit(items, limit, fn) {
  const results = new Array(items.length);
  let index = 0;
  const workerCount = Math.max(1, Math.min(limit, items.length));
  const workers = new Array(workerCount).fill(0).map(async () => {
    while (true) {
      const currentIndex = index;
      index += 1;
      if (currentIndex >= items.length) {
        return;
      }
      results[currentIndex] = await fn(items[currentIndex], currentIndex);
    }
  });
  await Promise.all(workers);
  return results;
}
function collectTaskFreshnessRootDirs(candidates) {
  const roots = [];
  const seen = /* @__PURE__ */ new Set();
  for (const candidate of candidates) {
    if (typeof candidate !== "string") {
      continue;
    }
    const trimmed = candidate.trim();
    if (!trimmed || !path__namespace$1.isAbsolute(trimmed)) {
      continue;
    }
    const normalized = path__namespace$1.normalize(trimmed);
    if (seen.has(normalized)) {
      continue;
    }
    seen.add(normalized);
    roots.push(normalized);
    if (roots.length >= MAX_TASK_FRESHNESS_ROOT_DIRS) {
      break;
    }
  }
  return roots;
}
function buildProjectSessionDiscoveryCacheKey(teamName2, options) {
  const subagentMode = options?.includeTeamSubagentSessionDiscovery === false ? "known" : "full";
  return `${teamName2}\0${subagentMode}`;
}
class TeamMemberLogsFinder {
  constructor(configReader = new TeamConfigReader(), inboxReader = new TeamInboxReader(), membersMetaStore = new TeamMembersMetaStore(), projectResolver = new TeamTranscriptProjectResolver(
    () => Promise.resolve(false),
    { getConfig: (teamName2) => configReader.getConfigSnapshot(teamName2) }
  ), launchStateStore = new TeamLaunchStateStore()) {
    this.configReader = configReader;
    this.inboxReader = inboxReader;
    this.membersMetaStore = membersMetaStore;
    this.projectResolver = projectResolver;
    this.launchStateStore = launchStateStore;
  }
  configReader;
  inboxReader;
  membersMetaStore;
  projectResolver;
  launchStateStore;
  taskMentionIndexCache = /* @__PURE__ */ new Map();
  taskMentionIndexInFlight = /* @__PURE__ */ new Map();
  attributionCache = /* @__PURE__ */ new Map();
  attributionInFlight = /* @__PURE__ */ new Map();
  discoveryCache = /* @__PURE__ */ new Map();
  discoveryInFlight = /* @__PURE__ */ new Map();
  discoveryGenerationByTeam = /* @__PURE__ */ new Map();
  async findMemberLogs(teamName2, memberName2, mtimeSinceMs) {
    const discovery = await this.discoverMemberFiles(teamName2, memberName2);
    if (!discovery) return [];
    const { projectDir, projectId, config, sessionIds, knownMembers, isLeadMember } = discovery;
    const results = [];
    const leadMemberName = config.members?.find((m) => taskHistory.isLeadMember(m))?.name?.trim() || "team-lead";
    if (isLeadMember && config.leadSessionId) {
      const leadJsonl = path__namespace$1.join(projectDir, `${config.leadSessionId}.jsonl`);
      const leadSummary = await this.parseLeadSessionSummary(
        leadJsonl,
        projectId,
        config.leadSessionId,
        leadMemberName
      );
      if (leadSummary) {
        results.push(leadSummary);
      }
    }
    const candidates = await this.collectLogCandidates(projectDir, sessionIds, config);
    const settled = Array(candidates.length).fill(null);
    let nextIdx = 0;
    const scanWorker = async () => {
      while (nextIdx < candidates.length) {
        const idx = nextIdx++;
        const c = candidates[idx];
        try {
          if (mtimeSinceMs != null) {
            try {
              const stat = await fs__namespace$2.stat(c.filePath);
              if (stat.mtimeMs < mtimeSinceMs) continue;
            } catch {
              continue;
            }
          }
          const summary = c.kind === "subagent" ? await this.parseSubagentSummary(
            c.filePath,
            projectId,
            c.sessionId,
            c.fileName,
            memberName2,
            knownMembers
          ) : await this.parseMemberSessionSummary(
            c.filePath,
            projectId,
            c.sessionId,
            memberName2,
            teamName2,
            knownMembers
          );
          if (summary) settled[idx] = summary;
        } catch (err) {
          logger.warn(`Failed to parse member log summary: ${c.filePath}`, err);
        }
      }
    };
    await Promise.all(
      Array.from({ length: Math.min(SCAN_CONCURRENCY, candidates.length) }, () => scanWorker())
    );
    for (const s of settled) {
      if (s) results.push(s);
    }
    return results.sort(
      (a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
    );
  }
  async getLogSourceWatchContext(teamName2, options) {
    if (options?.forceRefresh) {
      this.discoveryCache.delete(teamName2);
    }
    const discovery = await this.discoverProjectSessions(teamName2, options);
    if (!discovery) {
      return null;
    }
    return {
      projectDir: discovery.projectDir,
      projectPath: discovery.config.projectPath,
      leadSessionId: discovery.config.leadSessionId,
      sessionIds: [...discovery.sessionIds]
    };
  }
  async getLiveLogSourceWatchContext(teamName2, options) {
    const [launchSnapshot, bootstrapSnapshot] = await Promise.all([
      this.launchStateStore.read(teamName2).catch(() => null),
      taskHistory.readBootstrapLaunchSnapshot(teamName2).catch(() => null)
    ]);
    const preferredSnapshot = taskHistory.choosePreferredLaunchSnapshot(bootstrapSnapshot, launchSnapshot);
    const runtimeMemberCwdCandidates = Object.values(preferredSnapshot?.members ?? {}).map(
      (member2) => member2.cwd
    );
    const base = await this.projectResolver.getLiveBaseContext(teamName2, {
      forceRefresh: options?.forceRefresh,
      extraProjectPathCandidates: runtimeMemberCwdCandidates
    });
    if (!base) {
      return null;
    }
    const watchSessionIds = buildTeamLogWatchSessionIds({
      configLeadSessionId: base.config.leadSessionId,
      launchLeadSessionId: preferredSnapshot?.leadSessionId,
      sessionHistory: base.config.sessionHistory,
      launchRuntimeSessionIds: extractRuntimeSessionIds(preferredSnapshot)
    });
    return {
      projectDir: base.projectDir,
      projectPath: base.config.projectPath,
      taskFreshnessRootDirs: collectTaskFreshnessRootDirs([
        base.config.projectPath,
        ...(base.config.members ?? []).map((member2) => member2.cwd),
        ...runtimeMemberCwdCandidates
      ]),
      leadSessionId: base.config.leadSessionId ?? preferredSnapshot?.leadSessionId,
      sessionIds: watchSessionIds,
      watchSessionIds
    };
  }
  /**
   * Returns session logs that reference the given task (TaskCreate, TaskUpdate, comments, etc.).
   * When the task is in_progress and has an owner, also includes that owner's session logs so
   * the executor's current activity is visible even before the JSONL mentions the task id.
   */
  async findLogsForTask(teamName2, taskId, options) {
    const t0 = performance.now();
    const discovery = await this.discoverProjectSessions(teamName2);
    const tDiscovery = performance.now();
    if (!discovery) {
      console.log(
        `[perf] findLogsForTask(${taskId}) discovery=null ${(tDiscovery - t0).toFixed(0)}ms`
      );
      return [];
    }
    const sinceMs = this.deriveSinceMs(options);
    const { projectDir, projectId, config, sessionIds, knownMembers } = discovery;
    const results = [];
    const leadMemberName = config.members?.find((m) => taskHistory.isLeadMember(m))?.name?.trim() || "team-lead";
    for (const leadSessionId of getLeadSessionIds(config)) {
      const leadJsonl = path__namespace$1.join(projectDir, `${leadSessionId}.jsonl`);
      try {
        await fs__namespace$2.access(leadJsonl);
        if (await this.fileMentionsTaskIdCached(leadJsonl, teamName2, taskId, true, sinceMs)) {
          const leadSummary = await this.parseLeadSessionSummary(
            leadJsonl,
            projectId,
            leadSessionId,
            leadMemberName
          );
          if (leadSummary) results.push(leadSummary);
        }
      } catch {
      }
    }
    const candidates = await this.collectLogCandidates(projectDir, sessionIds, config);
    const settled = Array(candidates.length).fill(null);
    let nextIdx = 0;
    let mentionHits = 0;
    const scanWorker = async () => {
      while (nextIdx < candidates.length) {
        const idx = nextIdx++;
        const c = candidates[idx];
        try {
          if (!await this.fileMentionsTaskIdCached(c.filePath, teamName2, taskId, false, sinceMs))
            continue;
          mentionHits++;
          const summary = c.kind === "subagent" ? await (async () => {
            const attribution = await this.attributeSubagent(c.filePath, knownMembers);
            if (!attribution) return null;
            return this.parseSubagentSummary(
              c.filePath,
              projectId,
              c.sessionId,
              c.fileName,
              attribution.detectedMember,
              knownMembers,
              attribution
            );
          })() : await (async () => {
            const attribution = await this.attributeMemberSession(
              c.filePath,
              teamName2,
              knownMembers
            );
            if (!attribution) return null;
            return this.parseMemberSessionSummary(
              c.filePath,
              projectId,
              c.sessionId,
              attribution.detectedMember,
              teamName2,
              knownMembers,
              attribution
            );
          })();
          if (summary) settled[idx] = summary;
        } catch (err) {
          logger.warn(`Failed to scan member log file: ${c.filePath}`, err);
        }
      }
    };
    await Promise.all(
      Array.from({ length: Math.min(SCAN_CONCURRENCY, candidates.length) }, () => scanWorker())
    );
    for (const s of settled) {
      if (s) results.push(s);
    }
    const totalFiles = candidates.length;
    const step2Count = results.length;
    const normalizedOwner = typeof options?.owner === "string" ? options.owner.trim() : options?.owner;
    const isLeadOwner = typeof normalizedOwner === "string" && normalizedOwner.length > 0 && normalizedOwner.toLowerCase() === leadMemberName.toLowerCase();
    const ownerRelevantStatus = options?.status === "in_progress" || options?.status === "completed";
    const includeOwnerSessions = ownerRelevantStatus && typeof normalizedOwner === "string" && normalizedOwner.length > 0 && !isLeadOwner;
    if (includeOwnerSessions) {
      const ownerLogs = await this.findMemberLogs(teamName2, normalizedOwner, sinceMs);
      const TASK_LOG_INTERVAL_GRACE_MS = 1e4;
      const fallbackRecentMs = 30 * 6e4;
      const now = Date.now();
      const normalizedIntervals = Array.isArray(options?.intervals) ? options.intervals.map((i) => {
        const startMs = Date.parse(i.startedAt);
        const endMsRaw = typeof i.completedAt === "string" ? Date.parse(i.completedAt) : Number.NaN;
        const endMs = i.completedAt === void 0 ? null : Number.isFinite(endMsRaw) ? Math.max(endMsRaw, startMs) : startMs;
        return Number.isFinite(startMs) ? { startMs, endMs } : null;
      }).filter((v) => v !== null) : [];
      const sinceMsRaw = typeof options?.since === "string" ? Date.parse(options.since) : NaN;
      const sinceStartMs = Number.isFinite(sinceMsRaw) ? sinceMsRaw : null;
      const effectiveIntervals = normalizedIntervals.length > 0 ? normalizedIntervals : sinceStartMs != null ? [{ startMs: sinceStartMs, endMs: null }] : [];
      const filteredOwnerLogs = ownerLogs.filter((log) => {
        const startMs = new Date(log.startTime).getTime();
        if (!Number.isFinite(startMs)) return false;
        const durationMs = typeof log.durationMs === "number" && log.durationMs > 0 ? log.durationMs : 0;
        const rawEndMs = startMs + durationMs;
        const endMs = log.isOngoing ? Math.max(rawEndMs, now) : rawEndMs;
        if (effectiveIntervals.length > 0) {
          return this.logOverlapsIntervals(
            startMs,
            endMs,
            effectiveIntervals,
            now,
            TASK_LOG_INTERVAL_GRACE_MS
          );
        }
        if (log.isOngoing) return true;
        return startMs >= now - fallbackRecentMs;
      });
      const seen = /* @__PURE__ */ new Set();
      for (const log of results) {
        const key = log.kind === "subagent" ? `subagent:${log.sessionId}:${log.subagentId}` : log.kind === "member_session" ? `member:${log.sessionId}` : `lead:${log.sessionId}`;
        seen.add(key);
      }
      for (const log of filteredOwnerLogs) {
        const key = log.kind === "subagent" ? `subagent:${log.sessionId}:${log.subagentId}` : log.kind === "member_session" ? `member:${log.sessionId}` : `lead:${log.sessionId}`;
        if (!seen.has(key)) {
          seen.add(key);
          results.push(log);
        }
      }
    }
    const preDedupCount = results.length;
    {
      const subagentsByKey = /* @__PURE__ */ new Map();
      const nonSubagent = [];
      for (const r of results) {
        if (r.kind !== "subagent") {
          nonSubagent.push(r);
          continue;
        }
        const memberKey = r.memberName ? r.memberName.toLowerCase() : `_${r.subagentId}`;
        const key = `${r.sessionId}:${memberKey}`;
        const existing = subagentsByKey.get(key);
        if (!existing || r.messageCount > existing.messageCount) {
          subagentsByKey.set(key, r);
        }
      }
      results.length = 0;
      results.push(...nonSubagent, ...subagentsByKey.values());
    }
    const sorted = [...results].sort(
      (a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
    );
    const tTotal = performance.now();
    console.log(
      `[findLogsForTask] task=${taskId}@${teamName2} | step2=${step2Count} (scan ${mentionHits}/${totalFiles} files) | step3=${preDedupCount - step2Count} (owner=${normalizedOwner ?? "none"}, includeOwner=${includeOwnerSessions}) | dedup=${preDedupCount}→${sorted.length} | total=${sorted.length} | ${(tTotal - t0).toFixed(0)}ms`
    );
    return sorted;
  }
  /**
   * Fast path for change extraction: returns task-related JSONL file refs directly without
   * building full LegacyMemberLogSummary metadata for every matched log.
   */
  async findLogFileRefsForTask(teamName2, taskId, options) {
    const discovery = await this.discoverProjectSessions(teamName2);
    if (!discovery) {
      return [];
    }
    const sinceMs = this.deriveSinceMs(options);
    const { projectDir, config, sessionIds, knownMembers } = discovery;
    const refs2 = [];
    const seen = /* @__PURE__ */ new Set();
    const leadMemberName = config.members?.find((m) => taskHistory.isLeadMember(m))?.name?.trim() || "team-lead";
    const pushRef = (filePath, memberName2, sortTime = 0, kind = "member_session", sessionId = "") => {
      const key = `${kind}:${sessionId}:${memberName2.toLowerCase()}:${filePath}`;
      if (seen.has(key)) return;
      seen.add(key);
      refs2.push({ kind, filePath, memberName: memberName2, sessionId, sortTime });
    };
    const leadSessionIds = getLeadSessionIds(config);
    for (const leadSessionId of leadSessionIds) {
      const leadJsonl = path__namespace$1.join(projectDir, `${leadSessionId}.jsonl`);
      try {
        await fs__namespace$2.access(leadJsonl);
        if (await this.fileMentionsTaskIdCached(leadJsonl, teamName2, taskId, true, sinceMs)) {
          const firstTimestamp = await this.probeFirstTimestamp(leadJsonl);
          pushRef(
            leadJsonl,
            leadMemberName,
            await this.getSortTime(leadJsonl, firstTimestamp),
            "lead_session",
            leadSessionId
          );
        }
      } catch {
      }
    }
    const candidates = await this.collectLogCandidates(projectDir, sessionIds, config);
    let nextIdx = 0;
    const scanWorker = async () => {
      while (nextIdx < candidates.length) {
        const idx = nextIdx++;
        const c = candidates[idx];
        try {
          if (!await this.fileMentionsTaskIdCached(c.filePath, teamName2, taskId, false, sinceMs))
            continue;
          const attribution = c.kind === "subagent" ? await this.attributeSubagent(c.filePath, knownMembers) : await this.attributeMemberSession(c.filePath, teamName2, knownMembers);
          if (!attribution) continue;
          pushRef(
            c.filePath,
            attribution.detectedMember,
            await this.getSortTime(c.filePath, attribution.firstTimestamp),
            c.kind,
            c.sessionId
          );
        } catch (err) {
          logger.warn(`Failed to scan member log file: ${c.filePath}`, err);
        }
      }
    };
    await Promise.all(
      Array.from({ length: Math.min(SCAN_CONCURRENCY, candidates.length) }, () => scanWorker())
    );
    const normalizedOwner = typeof options?.owner === "string" ? options.owner.trim() : options?.owner;
    const isLeadOwner = typeof normalizedOwner === "string" && normalizedOwner.length > 0 && normalizedOwner.toLowerCase() === leadMemberName.toLowerCase();
    const ownerRelevantStatus = options?.status === "in_progress" || options?.status === "completed";
    const includeOwnerSessions = ownerRelevantStatus && typeof normalizedOwner === "string" && normalizedOwner.length > 0 && !isLeadOwner;
    if (includeOwnerSessions) {
      const ownerLogs = await this.findMemberLogs(teamName2, normalizedOwner, sinceMs);
      const TASK_LOG_INTERVAL_GRACE_MS = 1e4;
      const fallbackRecentMs = 30 * 6e4;
      const now = Date.now();
      const normalizedIntervals = Array.isArray(options?.intervals) ? options.intervals.map((i) => {
        const startMs = Date.parse(i.startedAt);
        const endMsRaw = typeof i.completedAt === "string" ? Date.parse(i.completedAt) : Number.NaN;
        const endMs = i.completedAt === void 0 ? null : Number.isFinite(endMsRaw) ? Math.max(endMsRaw, startMs) : startMs;
        return Number.isFinite(startMs) ? { startMs, endMs } : null;
      }).filter((v) => v !== null) : [];
      const sinceMsRaw = typeof options?.since === "string" ? Date.parse(options.since) : NaN;
      const sinceStartMs = Number.isFinite(sinceMsRaw) ? sinceMsRaw : null;
      const effectiveIntervals = normalizedIntervals.length > 0 ? normalizedIntervals : sinceStartMs != null ? [{ startMs: sinceStartMs, endMs: null }] : [];
      for (const log of ownerLogs) {
        if (!log.filePath) continue;
        const startMs = new Date(log.startTime).getTime();
        if (!Number.isFinite(startMs)) continue;
        const durationMs = typeof log.durationMs === "number" && log.durationMs > 0 ? log.durationMs : 0;
        const rawEndMs = startMs + durationMs;
        const endMs = log.isOngoing ? Math.max(rawEndMs, now) : rawEndMs;
        if (effectiveIntervals.length > 0) {
          if (!this.logOverlapsIntervals(
            startMs,
            endMs,
            effectiveIntervals,
            now,
            TASK_LOG_INTERVAL_GRACE_MS
          )) {
            continue;
          }
        } else if (!log.isOngoing && startMs < now - fallbackRecentMs) {
          continue;
        }
        pushRef(
          log.filePath,
          log.memberName ?? normalizedOwner,
          Number.isFinite(new Date(log.startTime).getTime()) ? new Date(log.startTime).getTime() : 0,
          log.kind === "lead_session" ? "lead_session" : log.kind,
          log.sessionId
        );
      }
    }
    {
      const refsByKey = /* @__PURE__ */ new Map();
      const leadRefs = [];
      const memberSessionRefsByKey = /* @__PURE__ */ new Map();
      for (const ref of refs2) {
        if (ref.kind === "lead_session") {
          leadRefs.push(ref);
          continue;
        }
        if (ref.kind === "member_session") {
          const key2 = `member:${ref.sessionId}:${ref.memberName.toLowerCase()}`;
          const existing2 = memberSessionRefsByKey.get(key2);
          if (!existing2 || ref.sortTime > existing2.sortTime) {
            memberSessionRefsByKey.set(key2, ref);
          }
          continue;
        }
        const key = `${ref.sessionId}:${ref.memberName.toLowerCase()}`;
        const existing = refsByKey.get(key);
        if (!existing || ref.sortTime > existing.sortTime) {
          refsByKey.set(key, ref);
        }
      }
      refs2.length = 0;
      refs2.push(...leadRefs, ...memberSessionRefsByKey.values(), ...refsByKey.values());
    }
    const sortedRefs = [...refs2].sort((a, b) => b.sortTime - a.sortTime);
    return sortedRefs.map(({ filePath, memberName: memberName2 }) => ({ filePath, memberName: memberName2 }));
  }
  /**
   * Returns absolute paths to all JSONL files belonging to the specified member.
   * Uses the same discovery logic as findMemberLogs but collects file paths.
   */
  async findMemberLogPaths(teamName2, memberName2) {
    const discovery = await this.discoverMemberFiles(teamName2, memberName2);
    if (!discovery) return [];
    const { projectDir, config, sessionIds, knownMembers, isLeadMember } = discovery;
    const paths = [];
    if (isLeadMember && config.leadSessionId) {
      const leadJsonl = path__namespace$1.join(projectDir, `${config.leadSessionId}.jsonl`);
      try {
        await fs__namespace$2.access(leadJsonl);
        paths.push(leadJsonl);
      } catch {
      }
    }
    const candidates = await this.collectLogCandidates(projectDir, sessionIds, config);
    for (const candidate of candidates) {
      let mtimeMs = 0;
      try {
        mtimeMs = (await fs__namespace$2.stat(candidate.filePath)).mtimeMs;
      } catch {
        continue;
      }
      const attribution = candidate.kind === "subagent" ? await this.getCachedSubagentAttribution(candidate.filePath, knownMembers, mtimeMs) : await this.getCachedMemberSessionAttribution(
        candidate.filePath,
        teamName2,
        knownMembers,
        mtimeMs
      );
      if (attribution?.detectedMember.toLowerCase() === memberName2.trim().toLowerCase()) {
        paths.push(candidate.filePath);
      }
    }
    return paths;
  }
  async listAttributedMemberFiles(teamName2) {
    const discovery = await this.discoverProjectSessions(teamName2);
    if (!discovery) return [];
    const { projectDir, sessionIds, knownMembers, config } = discovery;
    const currentLeadSessionId = typeof config.leadSessionId === "string" && config.leadSessionId.trim().length > 0 ? config.leadSessionId.trim() : null;
    const candidates = await this.collectLogCandidates(projectDir, sessionIds, config);
    const results = [];
    const settled = await Promise.all(
      candidates.map(async (candidate) => {
        try {
          if (candidate.kind === "subagent" && currentLeadSessionId && candidate.sessionId !== currentLeadSessionId) {
            return null;
          }
          const stat = await fs__namespace$2.stat(candidate.filePath);
          const attribution = candidate.kind === "subagent" ? await this.getCachedSubagentAttribution(
            candidate.filePath,
            knownMembers,
            stat.mtimeMs
          ) : await this.getCachedMemberSessionAttribution(
            candidate.filePath,
            teamName2,
            knownMembers,
            stat.mtimeMs
          );
          if (!attribution) return null;
          return {
            memberName: attribution.detectedMember,
            sessionId: candidate.sessionId,
            filePath: candidate.filePath,
            mtimeMs: stat.mtimeMs
          };
        } catch {
          return null;
        }
      })
    );
    for (const item of settled) {
      if (item) results.push(item);
    }
    const latestRootSessionsByMember = /* @__PURE__ */ new Map();
    const passthrough = [];
    for (const item of results) {
      if (!item.filePath.endsWith(".jsonl") || item.filePath.includes(`${path__namespace$1.sep}subagents${path__namespace$1.sep}`)) {
        passthrough.push(item);
        continue;
      }
      const key = item.memberName.toLowerCase();
      const existing = latestRootSessionsByMember.get(key);
      if (!existing || item.mtimeMs > existing.mtimeMs) {
        latestRootSessionsByMember.set(key, item);
      }
    }
    return [...passthrough, ...latestRootSessionsByMember.values()];
  }
  async listAttributedSubagentFiles(teamName2) {
    return this.listAttributedMemberFiles(teamName2);
  }
  async findRecentMemberLogFileRefsByMember(teamName2, memberNames, options) {
    const parsedOptions = typeof options === "number" || options === null ? {
      mtimeSinceMs: options ?? null,
      forceRefresh: false,
      includeTeamSubagentSessionDiscovery: true
    } : {
      mtimeSinceMs: options?.mtimeSinceMs ?? null,
      forceRefresh: options?.forceRefresh === true,
      includeTeamSubagentSessionDiscovery: options?.includeTeamSubagentSessionDiscovery !== false
    };
    const requestedMembersByKey = /* @__PURE__ */ new Map();
    for (const memberName2 of memberNames) {
      const trimmed = memberName2.trim();
      if (!trimmed) {
        continue;
      }
      const key = trimmed.toLowerCase();
      if (!requestedMembersByKey.has(key)) {
        requestedMembersByKey.set(key, trimmed);
      }
    }
    if (requestedMembersByKey.size === 0) {
      return [];
    }
    const discovery = await this.discoverProjectSessions(teamName2, {
      forceRefresh: parsedOptions.forceRefresh,
      includeTeamSubagentSessionDiscovery: parsedOptions.includeTeamSubagentSessionDiscovery
    });
    if (!discovery) {
      return [];
    }
    const { projectDir, sessionIds, knownMembers, config } = discovery;
    const scopedKnownMembers = new Set(knownMembers);
    for (const memberKey of requestedMembersByKey.keys()) {
      scopedKnownMembers.add(memberKey);
    }
    const refs2 = [];
    const seenFilePaths = /* @__PURE__ */ new Set();
    const pushRef = (ref) => {
      if (seenFilePaths.has(ref.filePath)) {
        return;
      }
      seenFilePaths.add(ref.filePath);
      refs2.push(ref);
    };
    const leadMemberName = config.members?.find((member2) => taskHistory.isLeadMember(member2))?.name?.trim() || "team-lead";
    const leadKey = leadMemberName.toLowerCase();
    if (requestedMembersByKey.has(leadKey) && config.leadSessionId) {
      const leadJsonl = path__namespace$1.join(projectDir, `${config.leadSessionId}.jsonl`);
      try {
        const stat = await fs__namespace$2.stat(leadJsonl);
        if (stat.isFile() && (parsedOptions.mtimeSinceMs == null || stat.mtimeMs >= parsedOptions.mtimeSinceMs)) {
          pushRef({
            memberName: requestedMembersByKey.get(leadKey) ?? leadMemberName,
            sessionId: config.leadSessionId,
            filePath: leadJsonl,
            mtimeMs: stat.mtimeMs,
            sizeBytes: stat.size,
            kind: "lead_session"
          });
        }
      } catch {
      }
    }
    const candidates = await this.collectLogCandidates(projectDir, sessionIds, config);
    const settled = await mapLimit(candidates, SCAN_CONCURRENCY, async (candidate) => {
      try {
        const stat = await fs__namespace$2.stat(candidate.filePath);
        if (!stat.isFile()) {
          return null;
        }
        if (parsedOptions.mtimeSinceMs != null && stat.mtimeMs < parsedOptions.mtimeSinceMs) {
          return null;
        }
        const attribution = candidate.kind === "subagent" ? await this.getCachedSubagentAttribution(
          candidate.filePath,
          scopedKnownMembers,
          stat.mtimeMs
        ) : await this.getCachedMemberSessionAttribution(
          candidate.filePath,
          teamName2,
          scopedKnownMembers,
          stat.mtimeMs
        );
        if (!attribution) {
          return null;
        }
        const memberKey = attribution.detectedMember.trim().toLowerCase();
        const requestedMemberName = requestedMembersByKey.get(memberKey);
        if (!requestedMemberName) {
          return null;
        }
        return {
          memberName: requestedMemberName,
          sessionId: candidate.sessionId,
          filePath: candidate.filePath,
          mtimeMs: stat.mtimeMs,
          sizeBytes: stat.size,
          kind: candidate.kind
        };
      } catch {
        return null;
      }
    });
    for (const ref of settled) {
      if (ref) {
        pushRef(ref);
      }
    }
    return refs2.sort((left, right) => {
      const byTime = right.mtimeMs - left.mtimeMs;
      return byTime !== 0 ? byTime : left.filePath.localeCompare(right.filePath);
    });
  }
  /**
   * Fast marker probe for task-related logs.
   * Prefer structured MCP/TaskUpdate markers for modern sessions.
   */
  async hasTaskUpdateMarker(filePath, taskId) {
    const stream = fs.createReadStream(filePath, { encoding: "utf8" });
    const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
    const trimmedId = taskId.trim();
    const displayId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
      trimmedId
    ) ? trimmedId.slice(0, 8).toLowerCase() : null;
    const idAlternation = displayId ? `(?:${trimmedId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}|${displayId})` : trimmedId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = new RegExp(`"taskId"\\s*:\\s*"${idAlternation}"`);
    try {
      for await (const line of rl) {
        if (line.includes("TaskUpdate") && pattern.test(line)) {
          rl.close();
          stream.destroy();
          return true;
        }
        if (lineHasAgentTeamsTaskBoundaryToolName(line) && pattern.test(line)) {
          rl.close();
          stream.destroy();
          return true;
        }
      }
    } catch {
    }
    rl.close();
    stream.destroy();
    return false;
  }
  async discoverProjectSessions(teamName2, options) {
    const cacheKey = buildProjectSessionDiscoveryCacheKey(teamName2, options);
    let generation = this.discoveryGenerationByTeam.get(cacheKey) ?? 0;
    if (options?.forceRefresh) {
      const inFlight = this.discoveryInFlight.get(cacheKey);
      if (inFlight?.forceRefresh === true) {
        return inFlight.promise;
      }
      generation += 1;
      this.discoveryGenerationByTeam.set(cacheKey, generation);
      this.discoveryCache.delete(cacheKey);
    } else {
      const cached = this.discoveryCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        return cached.result;
      }
      const inFlight = this.discoveryInFlight.get(cacheKey);
      if (inFlight) {
        return inFlight.promise;
      }
    }
    const promise = this.loadProjectSessionDiscovery(teamName2, options, generation).finally(() => {
      const current = this.discoveryInFlight.get(cacheKey);
      if (current?.promise === promise) {
        this.discoveryInFlight.delete(cacheKey);
      }
    });
    this.discoveryInFlight.set(cacheKey, {
      generation,
      promise,
      forceRefresh: options?.forceRefresh === true
    });
    return promise;
  }
  async loadProjectSessionDiscovery(teamName2, options, generation) {
    const cacheKey = buildProjectSessionDiscoveryCacheKey(teamName2, options);
    const context = await this.projectResolver.getContext(teamName2, options);
    if (!context) {
      logger.debug(`No transcript context for team "${teamName2}"`);
      return null;
    }
    const { config, projectDir, projectId, sessionIds } = context;
    const knownMembers = new Set(
      (config.members ?? []).map((member2) => member2.name?.trim().toLowerCase()).filter((name2) => Boolean(name2 && name2.length > 0))
    );
    try {
      const metaMembers = await this.membersMetaStore.getMembers(teamName2);
      for (const member2 of metaMembers) {
        const normalized = member2.name.trim().toLowerCase();
        if (normalized.length > 0) knownMembers.add(normalized);
      }
    } catch {
    }
    try {
      const inboxMembers = await this.inboxReader.listInboxNames(teamName2);
      for (const name2 of inboxMembers) {
        const normalized = name2.trim().toLowerCase();
        if (normalized.length > 0) knownMembers.add(normalized);
      }
    } catch {
    }
    const discovery = { projectDir, projectId, config, sessionIds, knownMembers };
    if ((this.discoveryGenerationByTeam.get(cacheKey) ?? 0) === generation) {
      this.discoveryCache.set(cacheKey, {
        result: discovery,
        expiresAt: Date.now() + DISCOVERY_CACHE_TTL
      });
    }
    return discovery;
  }
  async discoverMemberFiles(teamName2, memberName2) {
    const discovery = await this.discoverProjectSessions(teamName2);
    if (!discovery) return null;
    const { config } = discovery;
    const leadMemberName = config.members?.find((m) => taskHistory.isLeadMember(m))?.name?.trim() || "team-lead";
    const isLeadMember = leadMemberName.toLowerCase() === memberName2.trim().toLowerCase();
    return { ...discovery, isLeadMember };
  }
  async collectLogCandidates(projectDir, sessionIds, config) {
    const candidates = [];
    const leadSessionIds = getLeadSessionIds(config);
    for (const sessionId of sessionIds) {
      const mainTranscript = path__namespace$1.join(projectDir, `${sessionId}.jsonl`);
      if (!leadSessionIds.has(sessionId)) {
        try {
          const stat = await fs__namespace$2.stat(mainTranscript);
          if (stat.isFile()) {
            candidates.push({
              kind: "member_session",
              filePath: mainTranscript,
              sessionId,
              fileName: path__namespace$1.basename(mainTranscript)
            });
          }
        } catch {
        }
      }
      const subagentsDir = path__namespace$1.join(projectDir, sessionId, "subagents");
      let dirFiles;
      try {
        dirFiles = await fs__namespace$2.readdir(subagentsDir);
      } catch {
        continue;
      }
      for (const f of dirFiles) {
        if (!f.startsWith("agent-") || !f.endsWith(".jsonl") || f.startsWith("agent-acompact"))
          continue;
        candidates.push({
          kind: "subagent",
          filePath: path__namespace$1.join(subagentsDir, f),
          sessionId,
          fileName: f
        });
      }
    }
    return candidates;
  }
  deriveSinceMs(options) {
    const sinceRaw = typeof options?.since === "string" ? options.since : null;
    if (sinceRaw) {
      const ms = Date.parse(sinceRaw);
      return Number.isFinite(ms) ? ms : null;
    }
    const intervals = options?.intervals;
    if (!Array.isArray(intervals) || intervals.length === 0) return null;
    let earliest = Number.POSITIVE_INFINITY;
    for (const i of intervals) {
      if (typeof i.startedAt === "string") {
        const ms = Date.parse(i.startedAt);
        if (Number.isFinite(ms) && ms < earliest) earliest = ms;
      }
    }
    if (!Number.isFinite(earliest) || earliest === Number.POSITIVE_INFINITY) return null;
    return earliest - TASK_SINCE_GRACE_MS;
  }
  logOverlapsIntervals(logStartMs, logEndMs, intervals, now, graceMs) {
    for (const it of intervals) {
      const start = it.startMs - graceMs;
      const end = (it.endMs ?? now) + graceMs;
      if (logStartMs <= end && logEndMs >= start) return true;
    }
    return false;
  }
  async fileMentionsTaskIdCached(filePath, teamName2, taskId, assumeTeam, sinceMs) {
    let mtimeMs;
    try {
      const stat = await fs__namespace$2.stat(filePath);
      mtimeMs = stat.mtimeMs;
    } catch {
      return false;
    }
    if (sinceMs != null && mtimeMs < sinceMs - TASK_SINCE_GRACE_MS) {
      return false;
    }
    const cacheKey = `${filePath}:${mtimeMs}:${teamName2}:${assumeTeam}`;
    const index = await this.getTaskMentionIndex(cacheKey, filePath, teamName2, assumeTeam);
    return this.taskMentionIndexHasTaskId(index, taskId);
  }
  async getTaskMentionIndex(cacheKey, filePath, teamName2, assumeTeam) {
    const cached = this.taskMentionIndexCache.get(cacheKey);
    if (cached) return cached;
    const inFlight = this.taskMentionIndexInFlight.get(cacheKey);
    if (inFlight) return inFlight;
    const promise = this.buildTaskMentionIndex(filePath, teamName2, assumeTeam).then((index) => {
      this.taskMentionIndexCache.set(cacheKey, index);
      while (this.taskMentionIndexCache.size > TASK_MENTION_INDEX_CACHE_MAX) {
        const oldestKey = this.taskMentionIndexCache.keys().next().value;
        if (!oldestKey) break;
        this.taskMentionIndexCache.delete(oldestKey);
      }
      return index;
    }).finally(() => {
      if (this.taskMentionIndexInFlight.get(cacheKey) === promise) {
        this.taskMentionIndexInFlight.delete(cacheKey);
      }
    });
    this.taskMentionIndexInFlight.set(cacheKey, promise);
    return promise;
  }
  taskMentionIndexHasTaskId(index, taskId) {
    const taskIdStr = taskId.trim();
    if (!taskIdStr) return false;
    if (index.exactTaskIds.has(taskIdStr)) return true;
    const taskIdDisplayForm = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(taskIdStr) ? taskIdStr.slice(0, 8).toLowerCase() : null;
    return taskIdDisplayForm !== null && index.lowerTaskIds.has(taskIdDisplayForm);
  }
  addTaskMention(index, rawTaskId) {
    const taskId = rawTaskId.trim();
    if (!taskId) return;
    index.exactTaskIds.add(taskId);
    index.lowerTaskIds.add(taskId.toLowerCase());
  }
  async buildTaskMentionIndex(filePath, teamName2, assumeTeam) {
    const teamLower = teamName2.trim().toLowerCase();
    const index = {
      exactTaskIds: /* @__PURE__ */ new Set(),
      lowerTaskIds: /* @__PURE__ */ new Set()
    };
    const pendingTaskIdsWithoutTeam = /* @__PURE__ */ new Set();
    const extractTaskIdFromUnknown = (raw) => {
      if (typeof raw === "string") return raw.trim();
      if (typeof raw === "number" && Number.isFinite(raw)) return String(raw);
      return null;
    };
    const extractTeamFromInput = (input) => {
      const raw = typeof input.team_name === "string" ? input.team_name : typeof input.teamName === "string" ? input.teamName : typeof input.team === "string" ? input.team : null;
      return typeof raw === "string" ? raw.trim() : null;
    };
    const matchesTeamMentionText = (text2) => {
      const t = text2.toLowerCase();
      if (!t.includes(teamLower)) return false;
      if (t.includes(`on team "${teamLower}"`)) return true;
      if (t.includes(`on team '${teamLower}'`)) return true;
      if (t.includes(`on team ${teamLower}`)) return true;
      if (t.includes(`(${teamLower})`)) return true;
      return false;
    };
    const extractTeamFromProcess = (entry) => {
      const init = entry.init;
      const process2 = entry.process ?? init?.process;
      const team = process2?.team;
      const raw = typeof team?.teamName === "string" ? team.teamName : typeof team?.team_name === "string" ? team.team_name : typeof team?.name === "string" ? team.name : null;
      return typeof raw === "string" ? raw.trim() : null;
    };
    try {
      const stream = fs.createReadStream(filePath, { encoding: "utf8" });
      const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
      let teamSeen = assumeTeam;
      const acceptPendingTaskIds = () => {
        if (!teamSeen || pendingTaskIdsWithoutTeam.size === 0) return;
        for (const pendingTaskId of pendingTaskIdsWithoutTeam) {
          this.addTaskMention(index, pendingTaskId);
        }
        pendingTaskIdsWithoutTeam.clear();
      };
      for await (const line of rl) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          const entry = JSON.parse(trimmed);
          if (!teamSeen) {
            const procTeam = extractTeamFromProcess(entry);
            if (procTeam?.toLowerCase() === teamLower) {
              teamSeen = true;
            }
          }
          if (!teamSeen) {
            const msg = entry.message;
            const rawContent = msg?.content ?? entry.content;
            if (typeof rawContent === "string" && matchesTeamMentionText(rawContent)) {
              teamSeen = true;
            }
          }
          const content = this.extractEntryContent(entry);
          if (!Array.isArray(content)) continue;
          if (!teamSeen) {
            for (const block of content) {
              if (!block || typeof block !== "object") continue;
              const b = block;
              if (b.type === "text" && typeof b.text === "string" && matchesTeamMentionText(b.text)) {
                teamSeen = true;
                acceptPendingTaskIds();
                break;
              }
            }
          }
          acceptPendingTaskIds();
          for (const block of content) {
            if (!block || typeof block !== "object") continue;
            const b = block;
            if (b.type !== "tool_use") continue;
            const rawToolName = typeof b.name === "string" ? b.name : "";
            const toolName = canonicalizeAgentTeamsToolName(rawToolName);
            if (toolName === "task_get" || toolName === "TaskGet") continue;
            const input = b.input;
            if (!input) continue;
            const inputTeam = extractTeamFromInput(input);
            const rawTaskId = input.taskId ?? input.task_id;
            const inputTaskId = extractTaskIdFromUnknown(rawTaskId);
            if (inputTaskId) {
              if (inputTeam) {
                if (inputTeam.toLowerCase() === teamLower) {
                  this.addTaskMention(index, inputTaskId);
                }
              } else {
                if (teamSeen) {
                  this.addTaskMention(index, inputTaskId);
                } else {
                  pendingTaskIdsWithoutTeam.add(inputTaskId);
                }
              }
            }
          }
          acceptPendingTaskIds();
        } catch {
        }
      }
      rl.close();
      stream.destroy();
    } catch {
    }
    return index;
  }
  extractEntryContent(entry) {
    const message = entry.message;
    if (message && Array.isArray(message.content)) return message.content;
    if (Array.isArray(entry.content)) return entry.content;
    return null;
  }
  async getCachedSubagentAttribution(filePath, knownMembers, mtimeMs) {
    const cacheKey = `${filePath}:${mtimeMs}`;
    if (this.attributionCache.has(cacheKey)) {
      return this.attributionCache.get(cacheKey) ?? null;
    }
    const existing = this.attributionInFlight.get(cacheKey);
    if (existing) {
      return await existing;
    }
    const promise = this.attributeSubagent(filePath, knownMembers).finally(() => {
      this.attributionInFlight.delete(cacheKey);
    });
    this.attributionInFlight.set(cacheKey, promise);
    const attribution = await promise;
    this.attributionCache.set(cacheKey, attribution);
    if (this.attributionCache.size > ATTRIBUTION_CACHE_MAX) {
      const oldestKey = this.attributionCache.keys().next().value;
      if (oldestKey) this.attributionCache.delete(oldestKey);
    }
    return attribution;
  }
  async getCachedMemberSessionAttribution(filePath, teamName2, knownMembers, mtimeMs) {
    const cacheKey = `${filePath}:${mtimeMs}:${teamName2}:member-session`;
    if (this.attributionCache.has(cacheKey)) {
      return this.attributionCache.get(cacheKey) ?? null;
    }
    const existing = this.attributionInFlight.get(cacheKey);
    if (existing) {
      return await existing;
    }
    const promise = this.attributeMemberSession(filePath, teamName2, knownMembers).finally(() => {
      this.attributionInFlight.delete(cacheKey);
    });
    this.attributionInFlight.set(cacheKey, promise);
    const attribution = await promise;
    this.attributionCache.set(cacheKey, attribution);
    if (this.attributionCache.size > ATTRIBUTION_CACHE_MAX) {
      const oldestKey = this.attributionCache.keys().next().value;
      if (oldestKey) this.attributionCache.delete(oldestKey);
    }
    return attribution;
  }
  async parseSubagentSummary(filePath, projectId, sessionId, fileName, targetMember, knownMembers, precomputedAttribution) {
    const subagentId = fileName.replace(/^agent-/, "").replace(/\.jsonl$/, "");
    const attribution = precomputedAttribution ?? await this.attributeSubagent(filePath, knownMembers);
    if (!attribution) return null;
    const targetLower = targetMember.toLowerCase();
    if (attribution.detectedMember.toLowerCase() !== targetLower) {
      return null;
    }
    const metadata = await this.streamFileMetadata(filePath);
    const firstTimestamp = metadata.firstTimestamp ?? attribution.firstTimestamp ?? await this.getFileMtime(filePath);
    const lastTimestamp = metadata.lastTimestamp ?? firstTimestamp;
    const startTime = new Date(firstTimestamp);
    const endTime = new Date(lastTimestamp);
    const durationMs = endTime.getTime() - startTime.getTime();
    let isOngoing = false;
    try {
      const stat = await fs__namespace$2.stat(filePath);
      const ageMs = Date.now() - stat.mtimeMs;
      isOngoing = ageMs < 6e4;
    } catch {
    }
    return {
      kind: "subagent",
      subagentId,
      sessionId,
      projectId,
      description: attribution.description || `Subagent ${subagentId}`,
      memberName: targetMember,
      startTime: firstTimestamp,
      durationMs: Math.max(0, durationMs),
      messageCount: metadata.messageCount,
      isOngoing,
      filePath,
      lastOutputPreview: metadata.lastOutputPreview ?? void 0,
      lastThinkingPreview: metadata.lastThinkingPreview ?? void 0,
      recentPreviews: metadata.recentPreviews.length > 0 ? metadata.recentPreviews : void 0
    };
  }
  async parseMemberSessionSummary(filePath, projectId, sessionId, targetMember, teamName2, knownMembers, precomputedAttribution) {
    const attribution = precomputedAttribution ?? await this.attributeMemberSession(filePath, teamName2, knownMembers);
    if (!attribution) {
      return null;
    }
    if (attribution.detectedMember.toLowerCase() !== targetMember.toLowerCase()) {
      return null;
    }
    const metadata = await this.streamFileMetadata(filePath);
    const firstTimestamp = metadata.firstTimestamp ?? attribution.firstTimestamp ?? await this.getFileMtime(filePath);
    const lastTimestamp = metadata.lastTimestamp ?? firstTimestamp;
    const startTime = new Date(firstTimestamp);
    const endTime = new Date(lastTimestamp);
    const durationMs = endTime.getTime() - startTime.getTime();
    let isOngoing = false;
    try {
      const stat = await fs__namespace$2.stat(filePath);
      isOngoing = Date.now() - stat.mtimeMs < 6e4;
    } catch {
    }
    return {
      kind: "member_session",
      sessionId,
      projectId,
      description: attribution.description || `${targetMember} session`,
      memberName: targetMember,
      startTime: firstTimestamp,
      durationMs: Math.max(0, durationMs),
      messageCount: metadata.messageCount,
      isOngoing,
      filePath,
      lastOutputPreview: metadata.lastOutputPreview ?? void 0,
      lastThinkingPreview: metadata.lastThinkingPreview ?? void 0,
      recentPreviews: metadata.recentPreviews.length > 0 ? metadata.recentPreviews : void 0
    };
  }
  /**
   * Phase 1: Scan first ATTRIBUTION_SCAN_LINES lines for member detection signals
   * and extract a human-readable description from the first user message.
   * Returns null if the file is a warmup session or empty.
   *
   * Collects ALL detection signals, then selects the best one by precedence
   * (process_team > routing_sender > teammate_id > text_mention).
   */
  async attributeSubagent(filePath, knownMembers) {
    const lines = [];
    try {
      const stream = fs.createReadStream(filePath, { encoding: "utf8" });
      const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
      let count = 0;
      for await (const line of rl) {
        if (count >= ATTRIBUTION_SCAN_LINES) break;
        const trimmed = line.trim();
        if (trimmed) {
          lines.push(trimmed);
          count++;
        }
      }
      rl.close();
      stream.destroy();
    } catch {
      return null;
    }
    if (lines.length === 0) return null;
    let description = "";
    const signals = [];
    let firstTimestamp = null;
    for (const line of lines) {
      if (!firstTimestamp) {
        firstTimestamp = this.extractTimestampFromLine(line);
      }
      try {
        const msg = JSON.parse(line);
        const textContent = this.extractTextContent(msg);
        const isAuthoredUserText = this.isAuthoredUserTextEntry(msg);
        if (isAuthoredUserText && textContent?.trim() === "Warmup") {
          return null;
        }
        if (isAuthoredUserText && textContent) {
          if (textContent.trimStart().startsWith("<teammate-message")) {
            const parsed = parseAllTeammateMessages(textContent);
            if (!description) {
              description = parsed[0]?.summary || parsed[0]?.content?.slice(0, 200) || "Teammate spawn";
            }
            if (parsed[0]?.teammateId) {
              const tmId = parsed[0].teammateId.trim().toLowerCase();
              if (tmId.length > 0 && knownMembers.has(tmId)) {
                signals.push({ member: parsed[0].teammateId.trim(), source: "teammate_id" });
              }
            }
          } else if (!description) {
            description = textContent.slice(0, 200);
          }
        }
        const textMention = isAuthoredUserText ? this.detectMemberFromMessage(msg, knownMembers) : null;
        if (textMention) {
          signals.push({ member: textMention.name, source: "text_mention" });
        }
        if (msg.toolUseResult && typeof msg.toolUseResult === "object") {
          const routing = msg.toolUseResult.routing;
          if (routing && typeof routing.sender === "string") {
            const sender = routing.sender.toLowerCase();
            if (knownMembers.has(sender)) {
              signals.push({ member: routing.sender, source: "routing_sender" });
            }
          }
        }
        const init = msg.init;
        const process2 = msg.process ?? init?.process;
        const team = process2?.team;
        if (team && typeof team.memberName === "string") {
          const memberNameLower = team.memberName.trim().toLowerCase();
          if (memberNameLower.length > 0 && knownMembers.has(memberNameLower)) {
            signals.push({ member: team.memberName.trim(), source: "process_team" });
          }
        }
      } catch {
      }
      if (description && signals.some((s) => s.source === "process_team" || s.source === "routing_sender")) {
        break;
      }
    }
    if (signals.length === 0) return null;
    const best = TeamMemberLogsFinder.selectBestSignal(signals);
    if (!best) return null;
    return { detectedMember: best.member, description, firstTimestamp };
  }
  async attributeMemberSession(filePath, teamName2, knownMembers) {
    const lines = [];
    try {
      const stream = fs.createReadStream(filePath, { encoding: "utf8" });
      const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
      let count = 0;
      for await (const line of rl) {
        if (count >= ATTRIBUTION_SCAN_LINES) break;
        const trimmed = line.trim();
        if (!trimmed) continue;
        lines.push(trimmed);
        count++;
      }
      rl.close();
      stream.destroy();
    } catch {
      return null;
    }
    if (lines.length === 0) {
      return null;
    }
    const normalizedTeam = teamName2.trim().toLowerCase();
    let detectedMember = null;
    let description = "";
    let firstTimestamp = null;
    let teamMatched = false;
    for (const line of lines) {
      if (!firstTimestamp) {
        firstTimestamp = this.extractTimestampFromLine(line);
      }
      try {
        const entry = JSON.parse(line);
        const directTeamName = typeof entry.teamName === "string" ? entry.teamName.trim().toLowerCase() : null;
        if (directTeamName === normalizedTeam) {
          teamMatched = true;
        }
        if (!detectedMember && typeof entry.agentName === "string") {
          const normalizedMember = entry.agentName.trim().toLowerCase();
          if (normalizedMember.length > 0 && knownMembers.has(normalizedMember)) {
            detectedMember = entry.agentName.trim();
          }
        }
        const process2 = entry.process;
        const processTeam = process2?.team;
        if (!detectedMember && typeof processTeam?.memberName === "string") {
          const normalizedMember = processTeam.memberName.trim().toLowerCase();
          if (normalizedMember.length > 0 && knownMembers.has(normalizedMember)) {
            detectedMember = processTeam.memberName.trim();
          }
        }
        if (!teamMatched) {
          const processTeamName = typeof processTeam?.teamName === "string" ? processTeam.teamName.trim().toLowerCase() : null;
          if (processTeamName === normalizedTeam) {
            teamMatched = true;
          }
        }
        const textContent = this.extractTextContent(entry);
        const isAuthoredUserText = this.isAuthoredUserTextEntry(entry);
        const lowerTextContent = textContent?.toLowerCase();
        if (!teamMatched && isAuthoredUserText && lowerTextContent?.includes(normalizedTeam)) {
          if (lowerTextContent.includes(`on team "${normalizedTeam}"`) || lowerTextContent.includes(`on team '${normalizedTeam}'`) || lowerTextContent.includes(`(${normalizedTeam})`)) {
            teamMatched = true;
          }
        }
        if (isAuthoredUserText && textContent && !description) {
          const normalizedText = textContent.trim();
          if (normalizedText.length > 0 && normalizedText !== "Warmup" && !normalizedText.startsWith("You are bootstrapping into team") && !normalizedText.startsWith("Member briefing for ")) {
            description = normalizedText.slice(0, 200);
          }
        }
      } catch {
      }
      if (teamMatched && detectedMember && description) {
        break;
      }
    }
    if (!teamMatched || !detectedMember) {
      return null;
    }
    return {
      detectedMember,
      description: description || `${detectedMember} session`,
      firstTimestamp
    };
  }
  /**
   * Select the best detection signal by precedence.
   * Signals are collected in file order, so find() returns the earliest occurrence
   * of the highest-precedence source.
   */
  static selectBestSignal(signals) {
    for (const source of SIGNAL_PRECEDENCE) {
      const match = signals.find((s) => s.source === source);
      if (match) return match;
    }
    return null;
  }
  /**
   * Last-resort member detection from message text.
   * Only called when all structured signals (teammate_id, process.team, routing) failed.
   * Returns priority 1 (lowest) — only if exactly one known member name appears.
   */
  detectMemberFromMessage(msg, knownMembers) {
    if (!this.isAuthoredUserTextEntry(msg)) return null;
    const text2 = this.extractTextContent(msg);
    if (!text2) return null;
    const matches = [];
    for (const name2 of knownMembers) {
      const regex = new RegExp(`\\b${escapeRegex(name2)}\\b`, "i");
      if (regex.test(text2)) {
        matches.push(name2);
      }
    }
    if (matches.length === 1) {
      return { name: findOriginalCase(text2, matches[0]), priority: 1 };
    }
    return null;
  }
  isAuthoredUserTextEntry(msg) {
    if (this.extractRole(msg) !== "user") return false;
    return isHumanAuthoredUserTurn(msg) || isDisplayableTeammateProtocol(msg);
  }
  extractTextContent(msg) {
    if (typeof msg.content === "string") {
      return msg.content;
    }
    if (Array.isArray(msg.content)) {
      const textParts = msg.content.filter((part) => part.type === "text" && typeof part.text === "string").map((part) => part.text);
      if (textParts.length > 0) return textParts.join(" ");
    }
    if (msg.message && typeof msg.message === "object") {
      return this.extractTextContent(msg.message);
    }
    return null;
  }
  extractRole(msg) {
    if (typeof msg.role === "string") {
      return msg.role;
    }
    if (msg.message && typeof msg.message === "object") {
      const inner = msg.message;
      if (typeof inner.role === "string") {
        return inner.role;
      }
    }
    return null;
  }
  async parseLeadSessionSummary(jsonlPath, projectId, sessionId, memberName2) {
    try {
      await fs__namespace$2.access(jsonlPath);
    } catch {
      return null;
    }
    const metadata = await this.streamFileMetadata(jsonlPath);
    const firstTimestamp = metadata.firstTimestamp ?? await this.getFileMtime(jsonlPath);
    const lastTimestamp = metadata.lastTimestamp ?? firstTimestamp;
    const startTime = new Date(firstTimestamp);
    const endTime = new Date(lastTimestamp);
    const durationMs = endTime.getTime() - startTime.getTime();
    let isOngoing = false;
    try {
      const stat = await fs__namespace$2.stat(jsonlPath);
      const ageMs = Date.now() - stat.mtimeMs;
      isOngoing = ageMs < 6e4;
    } catch {
    }
    return {
      kind: "lead_session",
      sessionId,
      projectId,
      description: "Lead session",
      memberName: memberName2,
      startTime: firstTimestamp,
      durationMs: Math.max(0, durationMs),
      messageCount: metadata.messageCount,
      isOngoing,
      filePath: jsonlPath,
      lastOutputPreview: metadata.lastOutputPreview ?? void 0,
      lastThinkingPreview: metadata.lastThinkingPreview ?? void 0,
      recentPreviews: metadata.recentPreviews.length > 0 ? metadata.recentPreviews : void 0
    };
  }
  /**
   * Stream entire JSONL file collecting timestamps, message count, and last assistant output.
   * Lightweight — uses regex to extract fields without full JSON parse.
   */
  async streamFileMetadata(filePath) {
    let firstTimestamp = null;
    let lastTimestamp = null;
    let messageCount = 0;
    let lastOutputPreview = null;
    let lastThinkingPreview = null;
    const MAX_RECENT_PREVIEWS = 20;
    const recentPreviews = [];
    try {
      const stream = fs.createReadStream(filePath, { encoding: "utf8" });
      const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
      for await (const line of rl) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        messageCount++;
        const ts = this.extractTimestampFromLine(trimmed);
        if (ts) {
          if (!firstTimestamp) firstTimestamp = ts;
          lastTimestamp = ts;
        }
        if (trimmed.includes('"role":"assistant"') || trimmed.includes('"role": "assistant"')) {
          const preview = TeamMemberLogsFinder.extractAssistantPreview(trimmed);
          if (preview) {
            lastOutputPreview = preview;
            if (ts) {
              recentPreviews.push({ text: preview, timestamp: ts, kind: "output" });
              if (recentPreviews.length > MAX_RECENT_PREVIEWS) recentPreviews.shift();
            }
          }
        }
        if (trimmed.includes('"type":"thinking"') || trimmed.includes('"type": "thinking"')) {
          const thinkingPreview = TeamMemberLogsFinder.extractThinkingPreview(trimmed);
          if (thinkingPreview) {
            lastThinkingPreview = thinkingPreview;
            if (ts) {
              recentPreviews.push({ text: thinkingPreview, timestamp: ts, kind: "thinking" });
              if (recentPreviews.length > MAX_RECENT_PREVIEWS) recentPreviews.shift();
            }
          }
        }
      }
      rl.close();
      stream.destroy();
    } catch {
    }
    return {
      firstTimestamp,
      lastTimestamp,
      messageCount,
      lastOutputPreview,
      lastThinkingPreview,
      recentPreviews
    };
  }
  extractTimestampFromLine(line) {
    const tsMatch = /"timestamp"\s*:\s*"(\d{4}-\d{2}-\d{2}T[^"]+)"/.exec(line);
    return tsMatch?.[1] ?? null;
  }
  /**
   * Extract a short text preview from an assistant message line.
   * Looks for the first text block content via regex (avoids full JSON parse).
   */
  static extractAssistantPreview(line) {
    const textMatch = /"type"\s*:\s*"text"[^}]*"text"\s*:\s*"((?:[^"\\]|\\.){1,400})/.exec(line);
    if (textMatch?.[1]) {
      const raw = textMatch[1].replace(/\\"/g, '"').replace(/\\n/g, " ").replace(/\\t/g, " ").replace(/\\\\/g, "\\").replace(/\s+/g, " ").trim();
      if (!raw) return null;
      return raw.length > 1500 ? raw.slice(0, 1500) + "..." : raw;
    }
    if (line.includes('"tool_use"')) return null;
    const contentMatch = /"content"\s*:\s*"((?:[^"\\]|\\.){1,400})/.exec(line);
    if (contentMatch?.[1]) {
      const raw = contentMatch[1].replace(/\\"/g, '"').replace(/\\n/g, " ").replace(/\\t/g, " ").replace(/\\\\/g, "\\").replace(/\s+/g, " ").trim();
      if (!raw) return null;
      return raw.length > 1500 ? raw.slice(0, 1500) + "..." : raw;
    }
    return null;
  }
  /**
   * Extract a short preview from a thinking block line via regex.
   * Thinking blocks use {"type":"thinking","thinking":"..."}.
   */
  static extractThinkingPreview(line) {
    const match = /"thinking"\s*:\s*"((?:[^"\\]|\\.){1,400})/.exec(line);
    if (match?.[1]) {
      const raw = match[1].replace(/\\"/g, '"').replace(/\\n/g, " ").replace(/\\t/g, " ").replace(/\\\\/g, "\\").replace(/\s+/g, " ").trim();
      return raw.length > 1500 ? raw.slice(0, 1500) + "..." : raw;
    }
    return null;
  }
  async probeFirstTimestamp(filePath, maxLines = ATTRIBUTION_SCAN_LINES) {
    try {
      const stream = fs.createReadStream(filePath, { encoding: "utf8" });
      const rl = readline__namespace.createInterface({ input: stream, crlfDelay: Infinity });
      let seen = 0;
      for await (const line of rl) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        const ts = this.extractTimestampFromLine(trimmed);
        if (ts) {
          rl.close();
          stream.destroy();
          return ts;
        }
        seen++;
        if (seen >= maxLines) break;
      }
      rl.close();
      stream.destroy();
    } catch {
    }
    return null;
  }
  async getSortTime(filePath, timestamp2) {
    const resolvedTimestamp = timestamp2 ?? await this.getFileMtime(filePath);
    const sortTime = Date.parse(resolvedTimestamp);
    return Number.isFinite(sortTime) ? sortTime : 0;
  }
  async getFileMtime(filePath) {
    try {
      const stat = await fs__namespace$2.stat(filePath);
      return stat.mtime.toISOString();
    } catch {
      return (/* @__PURE__ */ new Date()).toISOString();
    }
  }
}
function findOriginalCase(text2, lowerName) {
  const regex = new RegExp(`\\b(${escapeRegex(lowerName)})\\b`, "i");
  const match = regex.exec(text2);
  return match ? match[1] : lowerName;
}
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function normalizeReviewState(value) {
  return value === "review" || value === "needsFix" || value === "approved" ? value : "none";
}
function getReviewStateFromTask(task) {
  const fallbackStatus = typeof task.status === "string" ? task.status : null;
  const normalizeForStatus = (value) => {
    const explicit2 = normalizeReviewState(value);
    if (explicit2 === "none") return null;
    if (fallbackStatus === "in_progress" || fallbackStatus === "deleted") {
      return "none";
    }
    if (fallbackStatus === "pending") {
      return explicit2 === "needsFix" ? "needsFix" : "none";
    }
    if (fallbackStatus === "completed") {
      return explicit2 === "review" || explicit2 === "approved" || explicit2 === "needsFix" ? explicit2 : "none";
    }
    return explicit2;
  };
  if (Array.isArray(task.historyEvents) && task.historyEvents.length > 0) {
    const derived = taskHistory.getDerivedReviewStateFromHistory({
      historyEvents: task.historyEvents
    });
    if (derived !== null) {
      return normalizeForStatus(derived) ?? "none";
    }
  }
  const explicit = normalizeForStatus(task.reviewState);
  if (explicit) return explicit;
  if (task.kanbanColumn === "review" || task.kanbanColumn === "approved") {
    return normalizeForStatus(task.kanbanColumn) ?? "none";
  }
  return "none";
}
function getEffectiveReviewState(task) {
  return getReviewStateFromTask(task);
}
function getTaskChangeStateBucket(task) {
  const reviewState = getEffectiveReviewState(task);
  const workflowColumn = getTeamTaskWorkflowColumn({
    status: task.status ?? "",
    reviewState,
    kanbanColumn: task.kanbanColumn,
    deletedAt: task.deletedAt
  });
  if (workflowColumn === "approved") return "approved";
  if (workflowColumn === "review") return "review";
  if (reviewState === "needsFix") return "active";
  return task.status === "completed" ? "completed" : "active";
}
function isTaskChangeSummaryCacheable(taskOrBucket) {
  const bucket = typeof taskOrBucket === "string" ? taskOrBucket : getTaskChangeStateBucket(taskOrBucket);
  return bucket === "completed" || bucket === "approved";
}
exports.ATTACHMENT_CHUNK_BYTES = ATTACHMENT_CHUNK_BYTES;
exports.ATTACHMENT_MAX_BYTES = ATTACHMENT_MAX_BYTES;
exports.BOARD_TASK_CHANGES_DIRNAME = BOARD_TASK_CHANGES_DIRNAME;
exports.BOARD_TASK_CHANGE_FRESHNESS_DIRNAME = BOARD_TASK_CHANGE_FRESHNESS_DIRNAME;
exports.BOARD_TASK_LOG_FRESHNESS_DIRNAME = BOARD_TASK_LOG_FRESHNESS_DIRNAME;
exports.BOARD_TASK_LOG_FRESHNESS_FILE_SUFFIX = BOARD_TASK_LOG_FRESHNESS_FILE_SUFFIX;
exports.CLAUDE_IMAGE_MIME_TYPES = CLAUDE_IMAGE_MIME_TYPES;
exports.FileReadTimeoutError = FileReadTimeoutError;
exports.GROUP_CHAT_CHANNELS = GROUP_CHAT_CHANNELS;
exports.LocalFileSystemProvider = LocalFileSystemProvider;
exports.MAX_AGENT_ATTACHMENT_DELIVERY_BYTES_TOTAL = MAX_AGENT_ATTACHMENT_DELIVERY_BYTES_TOTAL;
exports.MAX_AGENT_ATTACHMENT_SERIALIZED_PAYLOAD_BYTES = MAX_AGENT_ATTACHMENT_SERIALIZED_PAYLOAD_BYTES;
exports.MAX_AGENT_IPC_ATTACHMENTS = MAX_AGENT_IPC_ATTACHMENTS;
exports.MAX_AGENT_VIDEO_ATTACHMENT_BYTES = MAX_AGENT_VIDEO_ATTACHMENT_BYTES;
exports.MAX_CONFIG_READ_BYTES = MAX_CONFIG_READ_BYTES;
exports.MAX_INBOX_FILE_BYTES = MAX_INBOX_FILE_BYTES;
exports.MAX_PENDING_UNKNOWN_ROOT_REFRESH_ATTEMPTS = MAX_PENDING_UNKNOWN_ROOT_REFRESH_ATTEMPTS;
exports.MAX_PENDING_UNKNOWN_ROOT_SESSIONS = MAX_PENDING_UNKNOWN_ROOT_SESSIONS;
exports.MAX_TEAM_METADATA_BYTES = MAX_TEAM_METADATA_BYTES;
exports.NATIVE_IMAGE_MIME_TYPES = NATIVE_IMAGE_MIME_TYPES;
exports.NATIVE_VIDEO_MIME_TYPES = NATIVE_VIDEO_MIME_TYPES;
exports.PENDING_UNKNOWN_ROOT_SESSION_TTL_MS = PENDING_UNKNOWN_ROOT_SESSION_TTL_MS;
exports.TEAM_LAUNCH_FRESHNESS_FILE = TEAM_LAUNCH_FRESHNESS_FILE;
exports.TEAM_LAUNCH_STOPPED_MARKER_FILE = TEAM_LAUNCH_STOPPED_MARKER_FILE;
exports.TEAM_TASK_LOG_FRESHNESS_DIRNAME = TEAM_TASK_LOG_FRESHNESS_DIRNAME;
exports.TeamConfigReader = TeamConfigReader;
exports.TeamHistoryError = TeamHistoryError;
exports.TeamInboxReader = TeamInboxReader;
exports.TeamLaunchStateStore = TeamLaunchStateStore;
exports.TeamMemberLogsFinder = TeamMemberLogsFinder;
exports.TeamMembersMetaStore = TeamMembersMetaStore;
exports.TeamMetaStore = TeamMetaStore;
exports.TeamMetadataTooLargeError = TeamMetadataTooLargeError;
exports.TeamOwnerError = TeamOwnerError;
exports.TeamRuntimeSelectionError = TeamRuntimeSelectionError;
exports.TeamTranscriptProjectResolver = TeamTranscriptProjectResolver;
exports.addLogSink = addLogSink;
exports.assertSafeAttachmentStorageId = assertSafeAttachmentStorageId;
exports.assertValidGroupInboxRows = assertValidGroupInboxRows;
exports.attachmentMetadataSchema = attachmentMetadataSchema;
exports.attachmentReferenceSchema = attachmentReferenceSchema;
exports.attachmentReferencesSchema = attachmentReferencesSchema;
exports.attachmentUploadSchema = attachmentUploadSchema;
exports.buildTeamMemberMcpSettingSources = buildTeamMemberMcpSettingSources;
exports.calculateMessageCost = calculateMessageCost;
exports.canRestoreTeamStopMarker = canRestoreTeamStopMarker;
exports.canonicalizeAgentTeamsToolName = canonicalizeAgentTeamsToolName;
exports.captureLegacyNativeStop = captureLegacyNativeStop;
exports.captureStartupMemorySnapshot = captureStartupMemorySnapshot;
exports.captureTeamLaunchPublicationAuthority = captureTeamLaunchPublicationAuthority;
exports.classifyLegacySavedTeamNativeRecords = classifyLegacySavedTeamNativeRecords;
exports.classifyLogSourceWatcherEvent = classifyLogSourceWatcherEvent;
exports.classifyUserTurnProvenance = classifyUserTurnProvenance;
exports.copyGroupChatEnvelope = copyGroupChatEnvelope;
exports.createCliAutoSuffixNameGuard = createCliAutoSuffixNameGuard;
exports.createCliProvisionerNameGuard = createCliProvisionerNameGuard;
exports.createLogger = createLogger;
exports.createTeamRegistryPayloadSchema = createTeamRegistryPayloadSchema;
exports.digest = digest;
exports.effectId = effectId;
exports.exportStoppedTeam = exportStoppedTeam;
exports.extractCommandOutputInfo = extractCommandOutputInfo;
exports.extractCwd = extractCwd;
exports.extractCwdFromKnownJsonlFile = extractCwdFromKnownJsonlFile;
exports.extractFirstUserMessagePreview = extractFirstUserMessagePreview;
exports.extractSlashInfo = extractSlashInfo;
exports.formatCurrentProcessMemorySnapshot = formatCurrentProcessMemorySnapshot;
exports.formatEffortLevelListForProvider = formatEffortLevelListForProvider;
exports.formatStartupMemorySnapshot = formatStartupMemorySnapshot;
exports.getEffectiveInboxMessageId = getEffectiveInboxMessageId;
exports.getPricing = getPricing;
exports.getRelativeLogSourceParts = getRelativeLogSourceParts;
exports.getReviewStateFromTask = getReviewStateFromTask;
exports.getTaskChangeStateBucket = getTaskChangeStateBucket;
exports.getTeamFsWorkerClient = getTeamFsWorkerClient;
exports.getTeamLaunchStatePath = getTeamLaunchStatePath;
exports.getTeamLaunchSummaryPath = getTeamLaunchSummaryPath;
exports.getTeamTaskWorkflowColumn = getTeamTaskWorkflowColumn;
exports.hasGroupChatEnvelopeMarker = hasGroupChatEnvelopeMarker;
exports.hostedTeamDefinitionSchema = hostedTeamDefinitionSchema;
exports.importRequestSchema = importRequestSchema;
exports.isAgentTeamsTaskBoundaryToolName = isAgentTeamsTaskBoundaryToolName;
exports.isAgentTeamsToolName = isAgentTeamsToolName;
exports.isAgentTeamsToolUse = isAgentTeamsToolUse;
exports.isAgentTranscriptFileName = isAgentTranscriptFileName;
exports.isAgentVideoMimeType = isAgentVideoMimeType$1;
exports.isCommandOutputContent = isCommandOutputContent;
exports.isConversationalEntry = isConversationalEntry;
exports.isDisplayableTeammateProtocol = isDisplayableTeammateProtocol;
exports.isHumanAuthoredUserTurn = isHumanAuthoredUserTurn;
exports.isLegacySavedTeamProductRecords = isLegacySavedTeamProductRecords;
exports.isMessageAfterCursor = isMessageAfterCursor;
exports.isNativeImageMimeType = isNativeImageMimeType;
exports.isReadableTeamConfigPayload = isReadableTeamConfigPayload;
exports.isStopLaunchFreshness = isStopLaunchFreshness;
exports.isSyntheticReplayNoise = isSyntheticReplayNoise;
exports.isTaskChangeSummaryCacheable = isTaskChangeSummaryCacheable;
exports.isTeamEffortLevel = isTeamEffortLevel;
exports.isTeamEffortLevelForProvider = isTeamEffortLevelForProvider;
exports.isTeamTaskActivelyWorked = isTeamTaskActivelyWorked;
exports.isTeamTaskBlockedByUnfinishedDependency = isTeamTaskBlockedByUnfinishedDependency;
exports.isTeamTaskDeleted = isTeamTaskDeleted;
exports.isTeamTaskFinishedForDependency = isTeamTaskFinishedForDependency;
exports.isTeamTaskNeedsFixActionable = isTeamTaskNeedsFixActionable;
exports.isTeamTaskTerminalForActionableWork = isTeamTaskTerminalForActionableWork;
exports.isTextContent = isTextContent;
exports.isToolResultContent = isToolResultContent;
exports.isWindowsishPath = isWindowsishPath;
exports.liveRosterPrivateInputSchema = liveRosterPrivateInputSchema;
exports.messageAttachmentReferencesSchema = messageAttachmentReferencesSchema;
exports.nativeReleaseDigest = nativeReleaseDigest;
exports.normalizeLogSourceSessionId = normalizeLogSourceSessionId;
exports.normalizePathForComparison = normalizePathForComparison;
exports.normalizeRuntimeSelectionVersion = normalizeRuntimeSelectionVersion;
exports.normalizeTeamMemberMcpPolicy = normalizeTeamMemberMcpPolicy;
exports.parseAllTeammateMessages = parseAllTeammateMessages;
exports.parseGroupPayload = parseGroupPayload;
exports.parseHistoryCursor = parseHistoryCursor;
exports.parseLiveRosterResponse = parseLiveRosterResponse;
exports.parseNumericSuffixName = parseNumericSuffixName;
exports.pickTeamInboxWorkSyncFields = pickTeamInboxWorkSyncFields;
exports.plainImportAncestors = plainImportAncestors;
exports.provenPagePrefix = provenPagePrefix;
exports.readFileUtf8WithTimeout = readFileUtf8WithTimeout;
exports.readImportBytes = readImportBytes;
exports.readLegacyNativeStopRelease = readLegacyNativeStopRelease;
exports.readPersistedLaunchRuntimePidsSync = readPersistedLaunchRuntimePidsSync;
exports.readTeamLaunchFreshness = readTeamLaunchFreshness;
exports.readTeamLaunchFreshnessFromTeamDir = readTeamLaunchFreshnessFromTeamDir;
exports.requireTeamRuntimeSelection = requireTeamRuntimeSelection;
exports.requiresStrictTeamMemberMcpConfig = requiresStrictTeamMemberMcpConfig;
exports.resolveProjectPathFromConfig = resolveProjectPathFromConfig;
exports.resolveTeamMemberMcpScopes = resolveTeamMemberMcpScopes;
exports.resolveTeamRuntimeSelection = resolveTeamRuntimeSelection;
exports.sanitizeDisplayContent = sanitizeDisplayContent;
exports.stoppedImportReceiptSchema = stoppedImportReceiptSchema;
exports.taskAttachmentReadSchema = taskAttachmentReadSchema;
exports.teamProvisioningRequestAdmissionContext = teamProvisioningRequestAdmissionContext;
exports.teamRegistryListSchema = teamRegistryListSchema;
exports.teamRegistryReceiptSchema = teamRegistryReceiptSchema;
exports.teamRegistryRecordSchema = teamRegistryRecordSchema;
exports.teamRegistryScopeSchema = teamRegistryScopeSchema;
exports.toFeedRevision = toFeedRevision;
exports.toSourceRevision = toSourceRevision;
exports.validateAgentAttachmentIpcPayload = validateAgentAttachmentIpcPayload;
exports.validateStoppedSnapshot = validateStoppedSnapshot;
exports.validateTeamMemberNameFormat = validateTeamMemberNameFormat;
exports.withTeamLaunchStatePublicationLock = withTeamLaunchStatePublicationLock;
