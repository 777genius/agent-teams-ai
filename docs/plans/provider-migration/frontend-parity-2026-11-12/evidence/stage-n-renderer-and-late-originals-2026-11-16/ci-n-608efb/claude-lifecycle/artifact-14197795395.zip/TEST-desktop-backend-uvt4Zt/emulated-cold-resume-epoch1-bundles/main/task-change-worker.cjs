for (const k of ["CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_EXECPATH", "CLAUDE_CODE_VERSION", "CLAUDE_CODE_INVOKED_SKILLS", "CLAUDE_PID", "CLAUDE_EFFORT", "AI_AGENT", "TRACEPARENT"]) {
  delete process.env[k];
}
;
if (!process.env.UV_THREADPOOL_SIZE) {
  process.env.UV_THREADPOOL_SIZE = "24";
}
"use strict";
const node_worker_threads = require("node:worker_threads");
const TaskBoundaryParser = require("./chunks/TaskBoundaryParser-Zk2WZzJg.cjs");
const taskChangeState = require("./chunks/taskChangeState-rZolvpL6.cjs");
require("fs");
require("fs/promises");
require("readline");
require("./chunks/taskHistory-2kbwfqIg.cjs");
require("os");
require("node:crypto");
require("node:fs");
require("node:path");
require("crypto");
require("path");
require("node:async_hooks");
require("node:os");
require("node:fs/promises");
require("node:perf_hooks");
require("node:child_process");
require("node:stream");
require("node:events");
require("node:util");
require("node:diagnostics_channel");
require("node:module");
require("node:process");
require("events");
require("child_process");
require("util");
require("async_hooks");
require("buffer");
require("net");
require("module");
require("url");
require("string_decoder");
require("node:buffer");
require("node:timers/promises");
require("node:url");
const logsFinder = new taskChangeState.TeamMemberLogsFinder();
const boundaryParser = new TaskBoundaryParser.TaskBoundaryParser();
const computer = new TaskBoundaryParser.TaskChangeComputer(logsFinder, boundaryParser);
function postMessage(message) {
  node_worker_threads.parentPort?.postMessage(message);
}
node_worker_threads.parentPort?.on("message", async (message) => {
  if (message?.op !== "computeTaskChanges") {
    postMessage({
      id: message?.id ?? "unknown",
      ok: false,
      error: `Unsupported task change worker op: ${String(message?.op)}`
    });
    return;
  }
  try {
    const result = await computer.computeTaskChanges(message.payload);
    postMessage({ id: message.id, ok: true, result });
  } catch (error) {
    postMessage({
      id: message.id,
      ok: false,
      error: error instanceof Error ? error.message : String(error)
    });
  }
});
