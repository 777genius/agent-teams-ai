import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { test } from 'vitest';
import { InternalStorageJsonReplica } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/features/internal-storage/main/infrastructure/InternalStorageJsonReplica.ts';
import { isMemberWorkSyncStoreSnapshot } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/features/member-work-sync/main/infrastructure/JsonMemberWorkSyncStore.ts';
import { recordsToSnapshot } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/features/member-work-sync/main/infrastructure/memberWorkSyncSqliteMappers.ts';
import { readLegacyNativeWorkSyncCensus } from '/workspace/scratch/38cae95a211b/agent-teams-ai/src/main/services/team/provisioning/LegacyNativeStopWorkSyncCensus.ts';

test('actual unprepared SQLite replica writer output is refused solely when original backup identity already exists', async () => {
 const root=realpathSync(mkdtempSync(join(tmpdir(),'TEST-retained-work-sync-counterexample-')));
 try {
  const teamName='test-retained-original', teamDir=join(root,teamName); mkdirSync(teamDir);
  const marker={present:true,value:'TEST-existing-archive-incarnation'} as const;
  writeFileSync(join(teamDir,'config.json'),JSON.stringify({name:teamName,_backupIdentityId:marker.value}));
  const path=join(teamDir,'.member-work-sync/sqlite-fallback-replica.json');
  const writer=new InternalStorageJsonReplica(()=>path,isMemberWorkSyncStoreSnapshot);
  await writer.writeClean(teamName,recordsToSnapshot(teamName,{statuses:[],reportIntents:[],outboxItems:[],metricEvents:[]}));
  const target={teamName,leadName:'team-lead',runId:'TEST-run',sessionId:'TEST-session',rootPid:42001};
  const bytes=readFileSync(path,'utf8');
  const envelope=JSON.parse(bytes); assert.equal(Object.hasOwn(envelope,'incarnation'),false);
  assert.deepEqual(envelope.snapshot,{statuses:[],reportIntents:[],outboxItems:[],metricEvents:[],filesToArchive:[]});
  assert.equal((readLegacyNativeWorkSyncCensus(teamDir,target,{present:false}) as {kind:string}).kind,'empty-replica');
  assert.throws(()=>readLegacyNativeWorkSyncCensus(teamDir,target,marker),/Unqualified native WorkSync inventory/);
  assert.equal(readFileSync(path,'utf8'),bytes);
 } finally {rmSync(root,{recursive:true,force:true});}
});
