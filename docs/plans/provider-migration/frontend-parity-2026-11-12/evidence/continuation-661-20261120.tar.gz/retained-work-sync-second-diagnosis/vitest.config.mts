import original from '/workspace/scratch/38cae95a211b/agent-teams-ai/vitest.config.ts';
export default {...original, root:'/workspace/scratch/38cae95a211b/agent-teams-ai', test:{...original.test, environment:'node', include:['/workspace/scratch/38cae95a211b/retained-work-sync-second-diagnosis/counterexample.test.ts'], setupFiles:[], maxWorkers:1, fileParallelism:false}};
