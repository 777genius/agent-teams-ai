import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { stripTypeScriptTypes } from 'node:module';
import { isProductionSourcePath, countPhysicalLines } from './source/scripts/ci/check-source-file-size.mjs';
import { createDesktopOriginalActionReadTiming } from './candidate/scripts/legacy-agent-host/desktop-ui-read-observation.ts';

const head = '42a4ee210aff6ffa310025d024fd55cfbdbcd277';
const repo = '/workspace/scratch/1d5114b8d2ee/agent-teams-ai';
const root = new URL('./', import.meta.url);
const paths = execFileSync('git', ['ls-tree', '-r', '--name-only', head], { cwd: repo, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }).trim().split('\n');
const production = paths.filter(isProductionSourcePath);
const helper = 'scripts/legacy-agent-host/desktop-ui-read-observation.ts';
assert.equal(production.length, 5162);
assert.equal(paths.includes(helper), false);
assert.equal(isProductionSourcePath(helper), true);
const modified = ['scripts/legacy-agent-host/desktop-ui-controls.ts', 'scripts/legacy-agent-host/desktop-launch-ui-smoke.ts', 'scripts/legacy-agent-host/desktop-proof-sources.ts', helper];
const lineCounts = Object.fromEntries(modified.map((path) => [path, countPhysicalLines(readFileSync(new URL('candidate/' + path, root), 'utf8'))]));
assert.ok(Object.values(lineCounts).every((lines) => lines <= 800));

const modules = new Map();
function rosterModule(path, candidate) {
  const key = path + ':' + candidate;
  if (modules.has(key)) return modules.get(key);
  let source = path === 'desktop-proof-sources.ts'
    ? readFileSync(new URL((candidate ? 'candidate/' : 'source/') + 'scripts/legacy-agent-host/' + path, root), 'utf8')
    : execFileSync('git', ['show', head + ':scripts/legacy-agent-host/' + path], { cwd: repo, encoding: 'utf8', maxBuffer: 2 * 1024 * 1024 });
  source = source.replace(/from '\.\/([^']+)'/g, (_, dependency) => 'from ' + JSON.stringify(rosterModule(dependency, candidate)));
  const url = 'data:text/javascript;base64,' + Buffer.from(stripTypeScriptTypes(source)).toString('base64');
  modules.set(key, url);
  return url;
}
const before = (await import(rosterModule('desktop-proof-sources.ts', false))).desktopProofSources;
const after = (await import(rosterModule('desktop-proof-sources.ts', true))).desktopProofSources;
assert.equal(before.length, 1899);
assert.equal(after.length, 1900);
assert.deepEqual(after.filter((path) => path !== helper), before);
assert.equal(after.filter((path) => path === helper).length, 1);

const dto = createDesktopOriginalActionReadTiming(() => 0).data;
let spans = 0;
function widen(value) {
  if ('started' in value && 'resolved' in value) spans++;
  for (const [key, entry] of Object.entries(value)) {
    if (Array.isArray(entry)) entry.forEach(widen);
    else if (entry && typeof entry === 'object') widen(entry);
    else if (key !== 'schemaVersion' && (entry === null || typeof entry === 'number')) value[key] = ['started', 'resolved', 'waitCalls'].includes(key) ? 4096 : Number.MAX_SAFE_INTEGER;
  }
}
widen(dto);
const compactBytes = Buffer.byteLength(JSON.stringify(dto));
const prettyBytes = Buffer.byteLength(JSON.stringify(dto, null, 2));
assert.equal(spans, 22);
assert.ok(compactBytes <= 8192 && prettyBytes <= 16384);
const result = { sourceHead: head, scope: 'Read-only immutable original tree names/roster plus isolated candidate bytes; no project build, native process or source publication', productionPathsBefore: production.length, productionPathsAfter: production.length + 1, selectedSourcesBefore: before.length, selectedSourcesAfter: after.length, exactlyOneSelectedSourceAdded: helper, remainingRosterOrderIdentical: true, lineCounts, sourceSizeLimit: 800, newLegacyExceptions: 0, dto: { actionCount: dto.actions.length, phaseCountPerAction: dto.actions.map((a) => a.reads.length), spans, compactMaximumWidthBytes: compactBytes, prettyMaximumWidthBytes: prettyBytes, compactLimitBytes: 8192, prettyLimitBytes: 16384, method: 'Widen actual candidate plain DTO: all time values MAX_SAFE_INTEGER and bounded counters4096. False is wider than true for overflow flags.' } };
writeFileSync(new URL('static-schema-audit.json', root), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
