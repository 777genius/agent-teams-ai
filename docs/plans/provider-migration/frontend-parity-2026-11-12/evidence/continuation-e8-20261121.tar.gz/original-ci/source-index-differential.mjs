import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import * as fs from 'node:fs';
import { createRequire, stripTypeScriptTypes } from 'node:module';
import { tmpdir } from 'node:os';
import * as path from 'node:path';
import { performance } from 'node:perf_hooks';
import { Script } from 'node:vm';
import { runtimeDigest } from '../agent-teams-ai/packages/legacy-agent-host/dist/runtime/identity.js';
import { ManagementCommandError } from '../agent-teams-ai/packages/legacy-agent-host/dist/management/commandRecords.js';
import { runtimeSourceCandidateSchema, runtimeSourceGrantSchema } from '../agent-teams-ai/packages/legacy-agent-host/dist/composition/runtimeSourceContracts.js';

const repo = '/workspace/scratch/82699181f7b2/agent-teams-ai';
const selected = 'packages/legacy-agent-host/src/adapters/profile/FileRuntimeSourceIndex.ts';
const baselineSha = 'e8a07e76a3aa1bcdb54a59d2c6c920db3e29e637';
const source = fs.readFileSync(path.join(repo, selected), 'utf8');
const baseline = execFileSync('git', ['show', baselineSha + ':' + selected], { cwd: repo, encoding: 'utf8' });
const require = createRequire(path.join(repo, 'packages/legacy-agent-host/package.json'));
const { z } = require('zod');
const compile = text => new Script(stripTypeScriptTypes(text.slice(text.indexOf('const hash = ')), { mode: 'transform' })
  .replace(/^export /gm, '') + '\nFileRuntimeSourceIndex;');
const before = compile(baseline), after = compile(source);
const bindings = { ...fs, ...path, randomUUID, z, Buffer, TextDecoder, process,
  runtimeDigest, ManagementCommandError, runtimeSourceCandidateSchema, runtimeSourceGrantSchema };
const artifact = '/workspace/scratch/82699181f7b2/ci-audit/artifact-14691858680/TEST-desktop-backend-FefJdu/hoststore/runtime-sources/index.json';
const artifactBytes = fs.readFileSync(artifact);
const original = JSON.parse(artifactBytes.toString('utf8'));
const encoded = value => {
  const { digest: ignored, ...body } = value; void ignored;
  return Buffer.from(JSON.stringify({ ...body, digest: runtimeDigest(body) }));
};
const empty = encoded({ schemaVersion: 1, records: [], current: [] });
const modes = ['valid', 'empty', 'digest', 'utf8', 'json', 'schema', 'duplicate-revision', 'duplicate-command',
  'duplicate-pointer', 'record-digest', 'dangling-pointer', 'pointer-source', 'pointer-command', 'changed-observed',
  'missing-first', 'missing-observed', 'opened-inode', 'opened-size', 'oversized', 'symlink', 'hardlink',
  'public-mode', 'changed-size', 'changed-mtime', 'open-failed', 'read-failed', 'close-failed', 'writer-first', 'writer-last'];

function exercise(program, mode) {
  const trace = [], injected = new Error('TEST original filesystem failure');
  let active = false, guards = 0, stats = 0, digestCalls = 0, absent = false;
  let bytes = Buffer.from(artifactBytes);
  const stat = directory => ({ dev: 1, ino: directory ? 10 : 20, nlink: 1, mode: directory ? 0o700 : 0o600,
    size: bytes.length, mtimeMs: 2, isFile: () => !directory, isDirectory: () => directory, isSymbolicLink: () => false });
  const env = { ...bindings, runtimeDigest: value => { if (active) digestCalls++; return runtimeDigest(value); },
    mkdirSync: () => {}, realpathSync: target => { if (active) trace.push('realpath:' + target); return target; },
    lstatSync: target => {
      if (active) trace.push('lstat:' + target);
      if (!target.endsWith('index.json')) return stat(true);
      if (absent) throw Object.assign(new Error('TEST missing index'), { code: 'ENOENT' });
      const value = stat(false);
      if (mode === 'symlink') value.isSymbolicLink = () => true;
      if (mode === 'hardlink') value.nlink = 2;
      if (mode === 'public-mode') value.mode = 0o644;
      if (mode === 'oversized') value.size = 8 * 1024 * 1024 + 1;
      return value;
    },
    openSync: () => { trace.push('open'); if (mode === 'open-failed') throw injected; return 12; },
    fstatSync: () => {
      trace.push('fstat'); const value = stat(false); stats++;
      if (stats === 1 && mode === 'opened-inode') value.ino++;
      if (stats === 1 && mode === 'opened-size') value.size++;
      if (stats === 2 && mode === 'changed-size') value.size++;
      if (stats === 2 && mode === 'changed-mtime') value.mtimeMs++;
      return value;
    },
    readFileSync: () => { trace.push('read'); if (mode === 'read-failed') throw injected; return bytes; },
    closeSync: () => { trace.push('close'); if (mode === 'close-failed') throw injected; },
  };
  const Klass = program.runInNewContext(env);
  const index = new Klass('/TEST', () => {
    if (!active) return;
    trace.push('writer'); guards++;
    if (mode === 'writer-first' && guards === 1 || mode === 'writer-last' && guards === 2) throw injected;
  });
  if (mode === 'changed-observed' || mode === 'missing-observed') index.read();
  const value = structuredClone(original);
  if (mode === 'empty' || mode === 'changed-observed') bytes = empty;
  if (mode === 'digest') { value.digest = '0'.repeat(64); bytes = Buffer.from(JSON.stringify(value)); }
  if (mode === 'utf8') bytes = Buffer.from([0xff]);
  if (mode === 'json') bytes = Buffer.from('{');
  if (mode === 'schema') { value.unexpected = true; bytes = encoded(value); }
  if (mode === 'duplicate-revision') { value.records.push(value.records[0]); bytes = encoded(value); }
  if (mode === 'duplicate-command') {
    const record = { ...value.records[0], previousRevision: '0'.repeat(64) };
    const { revision, ...body } = record; void revision; record.revision = runtimeDigest(body);
    value.records.push(record); bytes = encoded(value);
  }
  if (mode === 'duplicate-pointer') { value.current.push(value.current[0]); bytes = encoded(value); }
  if (mode === 'record-digest') { value.records[0].revision = '0'.repeat(64); bytes = encoded(value); }
  if (mode === 'dangling-pointer') { value.current[0].revision = '0'.repeat(64); bytes = encoded(value); }
  if (mode === 'pointer-source') { value.current[0].sourceId = '0'.repeat(64); bytes = encoded(value); }
  if (mode === 'pointer-command') { value.current[0].commandId = 'TEST-wrong'; bytes = encoded(value); }
  absent = mode === 'missing-first' || mode === 'missing-observed';
  trace.length = 0; stats = 0; active = true;
  let result;
  try { result = { value: JSON.stringify(index.read()) }; }
  catch (error) { result = { error: { name: error.name, code: error.code ?? null, original: error === injected } }; }
  return { trace, result, digestCalls };
}

const cases = modes.map(mode => {
  const old = exercise(before, mode), next = exercise(after, mode);
  assert.deepEqual(next.trace, old.trace, mode + ' original I/O/authority order');
  assert.deepEqual(next.result, old.result, mode + ' result/error identity');
  assert.equal(next.digestCalls, old.digestCalls - (['valid', 'empty', 'close-failed'].includes(mode) ? 1 : 0), mode + ' digest count');
  return { mode, filesystemAndAuthorityCalls: next.trace.length, oldDigestCalls: old.digestCalls, newDigestCalls: next.digestCalls,
    outcome: next.result.error?.code ?? (next.result.error?.original ? 'original-io-error' : 'value') };
});

// One paired sample of real, fresh reads of the original 4.7 KiB CI index.
// This is a local measurement only; it cannot qualify Darwin or an E2E deadline.
const root = fs.realpathSync(fs.mkdtempSync(path.join(tmpdir(), 'TEST-index-measure-')));
let measurement;
try {
  fs.mkdirSync(path.join(root, 'runtime-sources'), { mode: 0o700 });
  fs.writeFileSync(path.join(root, 'runtime-sources/index.json'), artifactBytes, { mode: 0o600 });
  const Old = before.runInNewContext({ ...bindings }), Next = after.runInNewContext({ ...bindings });
  const old = new Old(root, () => {}), next = new Next(root, () => {});
  for (let warmup = 0; warmup < 20; warmup++) { old.read(); next.read(); }
  const count = 300;
  const timed = index => { const start = performance.now(); for (let i = 0; i < count; i++) index.read(); return performance.now() - start; };
  const oldMs = timed(old), newMs = timed(next);
  measurement = { pairedSamples: 1, order: ['baseline', 'candidate'], readsPerArm: count,
    bytes: artifactBytes.length, records: original.records.length, oldMs, newMs,
    limitation: 'One sequential local sample, no statistical confidence or Darwin/E2E qualification; fresh reads in both arms' };
} finally { fs.rmSync(root, { recursive: true, force: true }); }
const report = { baselineSha, candidateSha256: createHash('sha256').update(source).digest('hex'),
  passed: cases.length, failed: 0, cases, measurement };
fs.writeFileSync('/workspace/scratch/82699181f7b2/ci-audit/source-index-differential.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ passed: cases.length, failed: 0, measurement }, null, 2));
