import { readFileSync } from 'node:fs';
import base from '/workspace/scratch/82699181f7b2/agent-teams-ai/vitest.config.ts';
const baseline = readFileSync('/tmp/pr1192-cold-busy-baseline.ts', 'utf8');
const target = '/workspace/scratch/82699181f7b2/agent-teams-ai/src/main/services/team/provisioning/TeamProvisioningOpenCodeRuntimeDelivery.ts';
export default {
  ...base,
  root: '/workspace/scratch/82699181f7b2/agent-teams-ai',
  plugins: [{
    name: 'pr1192-e8-original-busy-source',
    enforce: 'pre',
    load(id) { if (id.split('?')[0] === target) return baseline; },
  }],
};
