import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { syncBuiltinESMExports } from 'node:module';
import { createHash } from 'node:crypto';
import { TeamOwnerStore } from '../agent-teams-ai/packages/legacy-agent-host/dist/adapters/team/TeamOwnerStore.js';
import { createFilesystemTeamOwner } from '../agent-teams-ai/packages/legacy-agent-host/dist/adapters/team/createFilesystemTeamOwner.js';
import { TeamOwnerError } from '../agent-teams-ai/packages/legacy-agent-host/dist/team/contracts.js';
import { beginModelReadinessNamespaceTiming } from '../agent-teams-ai/packages/legacy-agent-host/dist/diagnostics/modelReadinessTiming.js';

const receiptPath = new URL('./14636465657/agent-teams-ai/agent-teams-ai/process-acceptance-evidence/windows-source-opencode-receipt.json', import.meta.url);
const receipt = JSON.parse(fs.readFileSync(receiptPath, 'utf8').replace(/^\uFEFF/, ''));
const scenario = receipt.sourceScenarios[0];
const profilePin = scenario.pins.find(row => row.path.endsWith('TEST-source-profile.json'));
const originalRoot = path.win32.join(path.win32.dirname(profilePin.path), 'storage');
const originalDepth = originalRoot.slice(path.win32.parse(originalRoot).root.length).split(path.win32.sep).length;
const scratch = fs.mkdtempSync('/tmp/TEST-windows-namespace-');
let root = scratch;
while (root.slice(1).split('/').length < originalDepth - 2) root = path.join(root, 'ancestor');
root = path.join(root, path.win32.basename(path.win32.dirname(profilePin.path)), 'storage');
assert.equal(root.slice(1).split('/').length, originalDepth);
fs.mkdirSync(root, { recursive: true });
const teamName = 'test-source-team-a';
const binding = { backendId: 'TEST-characterization', teamId: 'TEST-source-team-A', teamName };
const runtimeBinding = { backendId: binding.backendId, teamId: binding.teamId,
  runId: scenario.lastLaunchReadiness.launchId, memberId: 'alice-id',
  generation: scenario.lastLaunchReadiness.lastRuntimeRead.generation };
const member = { memberId: 'alice-id', name: 'alice', role: 'lead', delivery: { ...runtimeBinding, teamName } };
const store = new TeamOwnerStore(root, teamName);
const owner = createFilesystemTeamOwner({ root, binding, store, members: [member], grants: [
  { principalId: 'human', memberName: 'user', permissions: ['read', 'admin'] },
  { principalId: 'alice-session', memberName: 'alice', permissions: ['read', 'task.write', 'message.write'] },
] });
const revision = owner.connect('human').readRoster().revision;
const original = TeamOwnerStore.prototype.validateNamespace;
const originalBody = original.toString().slice(original.toString().indexOf('{') + 1, -1);
const start = originalBody.indexOf('        const directoryPath =');
const end = originalBody.indexOf('        const tree =');
assert.ok(start >= 0 && end > start);
const originalDirectoryPath = originalBody.slice(start, end);
const originals = Object.fromEntries(['lstatSync', 'readdirSync', 'readFileSync', 'openSync', 'closeSync', 'linkSync', 'unlinkSync', 'statSync'].map(name => [name, fs[name]]));
let activeTrace = null, activeCost = null;
for (const [name, original] of Object.entries(originals)) fs[name] = (...args) => {
  if (activeTrace) activeTrace.push([name, typeof args[0] === 'string' ? args[0].replaceAll(root, '<root>') : args[0],
    name === 'lstatSync' ? null : args[1]]);
  const started = activeCost ? performance.now() : 0;
  try { return original(...args); }
  catch (error) { if (activeCost) activeCost.errors[error.code ?? error.name] = (activeCost.errors[error.code ?? error.name] ?? 0) + 1; throw error; }
  finally { if (activeCost) { activeCost.ms[name] = (activeCost.ms[name] ?? 0) + performance.now() - started; activeCost.calls[name] = (activeCost.calls[name] ?? 0) + 1; } }
};
syncBuiltinESMExports();
const ancestors = new Map();
for (const target of [store.directory, path.join(root, 'tasks', teamName)]) {
  let current = path.parse(target).root;
  const values = [];
  for (const segment of target.slice(current.length).split(path.sep)) { current = path.join(current, segment); values.push(current); }
  ancestors.set(target, values);
}
const cachedDirectoryPath = originalDirectoryPath.replace(
  /let part = parse\(target\)\.root;\s*for \(const segment of target\.slice\(part\.length\)\.split\(sep\)\) \{\s*part = join\(part, segment\);/,
  'for (const part of ancestors.get(target)) {');
const slicedDirectoryPath = originalDirectoryPath.replace(
  /let part = parse\(target\)\.root;\s*for \(const segment of target\.slice\(part\.length\)\.split\(sep\)\) \{\s*part = join\(part, segment\);/,
  `let cursor = parse(target).root.length;
            while (cursor <= target.length) {
                const next = target.indexOf(sep, cursor);
                const part = next < 0 ? target : target.slice(0, next);
                cursor = next < 0 ? target.length + 1 : next + 1;`);
const noThrowDirectoryPath = originalDirectoryPath.replace('const stat = lstatSync(part);',
  `const stat = lstatSync(part, { throwIfNoEntry: false });
                    if (stat === undefined) { if (required) throw new TeamOwnerError('hold'); return; }`);
function candidate(directoryPath) {
  assert.notEqual(directoryPath, originalDirectoryPath);
  const body = originalBody.slice(0, start) + directoryPath + originalBody.slice(end);
  return new Function('lstatSync', 'readdirSync', 'parse', 'join', 'sep', 'TeamOwnerError', 'beginModelReadinessNamespaceTiming', 'ancestors', body)(
    fs.lstatSync, fs.readdirSync, path.parse, path.join, path.sep, TeamOwnerError, beginModelReadinessNamespaceTiming, ancestors);
}
function compile(directoryPath) {
  assert.notEqual(directoryPath, originalDirectoryPath);
  const body = originalBody.slice(0, start) + directoryPath + originalBody.slice(end);
  return new Function('lstatSync', 'readdirSync', 'parse', 'join', 'sep', 'TeamOwnerError', 'beginModelReadinessNamespaceTiming', 'ancestors', 'return function () {' + body + '};')(
    fs.lstatSync, fs.readdirSync, path.parse, path.join, path.sep, TeamOwnerError, beginModelReadinessNamespaceTiming, ancestors);
}
const variants = { original, precomputedPathsUpperBound: compile(cachedDirectoryPath), slicedPaths: compile(slicedDirectoryPath), nonThrowingMissingLstat: compile(noThrowDirectoryPath) };
const traceResult = {};
const read = () => assert.equal(owner.capturedProviderAuthority('alice-session', runtimeBinding, revision, member), 'current');
try {
  for (const [name, validate] of Object.entries(variants)) {
    store.validateNamespace = validate; activeTrace = []; activeCost = { ms: {}, calls: {}, errors: {} };
    read(); traceResult[name] = { trace: activeTrace, cost: activeCost }; activeTrace = activeCost = null;
  }
  const normalize = rows => rows.filter(row => !row[0].includes('open') && !row[0].includes('close') && !row[0].includes('link'));
  for (const value of Object.values(traceResult)) assert.deepEqual(normalize(value.trace), normalize(traceResult.original.trace));
  const rounds = [];
  const order = ['original', 'slicedPaths', 'nonThrowingMissingLstat', 'precomputedPathsUpperBound',
    'precomputedPathsUpperBound', 'nonThrowingMissingLstat', 'slicedPaths', 'original',
    'slicedPaths', 'original', 'precomputedPathsUpperBound', 'nonThrowingMissingLstat'];
  for (const name of order) {
    store.validateNamespace = variants[name];
    for (let n = 0; n < 32; n++) read();
    const n = 384, started = performance.now();
    for (let count = 0; count < n; count++) read();
    rounds.push({ name, count: n, elapsedMs: performance.now() - started });
  }
  const result = { kind: 'TEST_WINDOWS_NAMESPACE_CHARACTERIZATION', sourceHead: receipt.sourceHead,
    node: process.version, platform: process.platform + '-' + process.arch,
    sourceArtifact: { id: 14636465657, sha256: '44b5406af328c89ffc04e0d32588d6eb91e87cd2a7d56029ff33c5eaabc7c1f9', originalRoot, rootDepth: originalDepth },
    scope: 'Original production TeamOwnerStore.fenced and TeamOwner.capturedProviderAuthority. A new finite one-member filesystem fixture uses artifact namespace depth/member binding; original persisted state was not in the artifact. No native processes, sockets, authority result caching, deadline changes, or source edits.',
    limitations: 'Linux Node24 allocation/path characterization; not native Windows timing or E2E. Filesystem cache not controlled. Precomputed paths are a performance upper bound only and not a proposed cached-authority implementation. Nonthrowing lstat changes only ENOENT result representation and needs separate contract qualification.',
    sourceHash: createHash('sha256').update(fs.readFileSync(new URL('../agent-teams-ai/packages/legacy-agent-host/src/adapters/team/TeamOwnerStore.ts', import.meta.url))).digest('hex'),
    traceResult, rounds };
  fs.writeFileSync(new URL('./windows-namespace-characterize-results.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ rounds, traceCounts: Object.fromEntries(Object.entries(traceResult).map(([name, row]) => [name, { calls: row.cost.calls, errors: row.cost.errors }])) }));
} finally {
  store.validateNamespace = original;
  Object.assign(fs, originals); syncBuiltinESMExports(); fs.rmSync(scratch, { recursive: true, force: true });
}
