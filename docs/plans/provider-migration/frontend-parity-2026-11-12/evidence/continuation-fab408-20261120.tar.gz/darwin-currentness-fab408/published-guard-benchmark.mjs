import assert from 'node:assert/strict';
import fs from 'node:fs';
import cp from 'node:child_process';
import net from 'node:net';
import { createRequire, syncBuiltinESMExports } from 'node:module';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { performance } from 'node:perf_hooks';

// Finite in-process diagnosis only. No provider/native launch or network listener is admitted.
let forbiddenEffects = 0;
for (const name of ['spawn', 'spawnSync', 'exec', 'execSync', 'execFile', 'execFileSync', 'fork'])
  cp[name] = () => { forbiddenEffects++; throw new Error('TEST native execution forbidden'); };
net.Server.prototype.listen = function () { forbiddenEffects++; throw new Error('TEST sockets forbidden'); };
net.Socket.prototype.connect = function () { forbiddenEffects++; throw new Error('TEST sockets forbidden'); };
syncBuiltinESMExports();

let active;
const frames = [];
function span(name, action) {
  if (!active) return action();
  const frame = { name, childMs: 0 }, start = performance.now();
  frames.push(frame);
  try { return action(); }
  finally {
    const ms = performance.now() - start; frames.pop();
    const row = active.spans[name] ??= { calls: 0, inclusiveMs: 0, selfMs: 0 };
    row.calls++; row.inclusiveMs += ms; row.selfMs += Math.max(0, ms - frame.childMs);
    if (frames.length) frames[frames.length - 1].childMs += ms;
  }
}
// Timing-only lexical wrapper around the unchanged controller implementation. This is
// installed in this child process before ControllerAdapter captures its CJS export.
const require = createRequire('/workspace/scratch/38cae95a211b/agent-teams-ai/package.json');
const lockPath = require.resolve('agent-teams-controller/src/internal/fileLock.js');
const lockOriginal = fs.readFileSync(lockPath, 'utf8');
globalThis.__TEST_CURRENTNESS_SPAN = span;
const lockTrailer = `
const __TEST_originalAcquire = acquireFileLockSync;
acquireFileLockSync = function (path, options) {
  const kind = path.endsWith('/authority') ? 'team' : 'other';
  const release = globalThis.__TEST_CURRENTNESS_SPAN('lock.' + kind + '.acquire', () => __TEST_originalAcquire(path, options));
  return () => globalThis.__TEST_CURRENTNESS_SPAN('lock.' + kind + '.release', release);
};
`;
const lockModule = { id: lockPath, filename: lockPath, exports: {}, loaded: false };
new Function('exports', 'require', 'module', '__filename', '__dirname', lockOriginal + lockTrailer)
  (lockModule.exports, createRequire(lockPath), lockModule, lockPath, dirname(lockPath));
lockModule.loaded = true; require.cache[lockPath] = lockModule;
const base = '/workspace/scratch/38cae95a211b/agent-teams-ai/packages/legacy-agent-host/dist';
const [{ createFilesystemTeamOwner }, { TeamOwnerStore }, { acquireProfileWriterLease },
  { RuntimeTeamCoordinator }, { RuntimeSourceIndex }, { captureOpenCodeConfigurationSource },
  { captureOpenCodeV2Configuration }, { captureOpenCodeV2SessionCredential },
  { FileRuntimeSourceIndex }, { FileManagementCommandStore }, { RuntimeOwner }] = await Promise.all([
  import(base + '/adapters/team/createFilesystemTeamOwner.js'),
  import(base + '/adapters/team/TeamOwnerStore.js'),
  import(base + '/adapters/profile/ProfileWriterLease.js'),
  import(base + '/composition/RuntimeTeamCoordinator.js'),
  import(base + '/composition/RuntimeSourceIndex.js'),
  import(base + '/adapters/providers/OpenCodeConfigurationSource.js'),
  import(base + '/adapters/providers/OpenCodeV2CapturedConfiguration.js'),
  import(base + '/adapters/providers/OpenCodeV2SessionCredential.js'),
  import(base + '/adapters/profile/FileRuntimeSourceIndex.js'),
  import(base + '/adapters/providers/FileManagementCommandStore.js'),
  import(base + '/runtime/RuntimeOwner.js'),
]);
const output = '/workspace/scratch/38cae95a211b/darwin-currentness-fab408';
const original = JSON.parse(fs.readFileSync('/workspace/scratch/38cae95a211b/ci-audit-1192/14675140379/TEST-desktop-backend-nG7N5B/host-profile.json', 'utf8'));
const scratch = fs.mkdtempSync(join(output, 'TEST-published-profile-'));
const root = join(scratch, 'Users', 'runner', 'work', 'agent-teams-ai', 'agent-teams-ai', 'TEST-original-length', 'TEST-desktop-backend');
fs.mkdirSync(root, { recursive: true });
const originalRoot = dirname(original.owner.storageRoot);
const profile = JSON.parse(JSON.stringify(original).replaceAll(originalRoot, root));
const definition = profile.teams[0], member = profile.runtime.members[0];
const linuxProfile = JSON.parse(fs.readFileSync('/workspace/scratch/38cae95a211b/ci-audit-1192/14675137567/TEST-desktop-backend-VGvPWI/host-profile.json', 'utf8'));
const linuxTemplate = linuxProfile.runtime.providerTemplates.find(value => value.provider === 'opencode' && value.nativeGeneration === 'v2');
assert.ok(linuxTemplate && linuxTemplate.embedded.platform === process.platform && linuxTemplate.embedded.arch === process.arch);
member.executable = structuredClone(linuxTemplate.executable);
for (const key of ['directory', 'manifestSha256', 'version', 'platform', 'arch', 'externalDirectory'])
  member.embedded[key] = linuxTemplate.embedded[key];
for (const path of [profile.owner.storageRoot, member.cwd, ...Object.entries(member.environment)
  .filter(([name]) => ['HOME', 'TMPDIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'XDG_CACHE_HOME'].includes(name)).map(([, value]) => value)])
  fs.mkdirSync(path, { recursive: true });
const providerId = member.nativeOptions.providerId;
member.environment.OPENCODE_CONFIG_CONTENT = JSON.stringify({ provider: { [providerId]: {
  npm: '@ai-sdk/openai-compatible', options: { baseURL: 'http://127.0.0.1:1/TEST', apiKey: 'TEST-benchmark-only-key' },
  models: { [member.model]: { name: member.model, limit: { context: 128000, output: 8192 } } },
} } });
// Same finite embedded graph producer shape as runtime-source-native-identity.test.ts.
// TEST text files are hashed and verified by the real publisher but never executed.
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const engineDirectory = join(root, 'resources', 'opencode-v2-engine');
const server = 'local-cli/node_modules/@opencode/server-v2.1.4', effect = 'local-cli/node_modules/effect';
const graphFiles = {
  [`${server}/package.json`]: JSON.stringify({ name: '@opencode/server', version: '2.1.4', dependencies: { effect: '4.0.1' } }),
  [`${server}/dist/process.js`]: 'export const TEST = true;\n',
  [`${effect}/package.json`]: JSON.stringify({ name: 'effect', version: '4.0.1', exports: './dist/index.js' }),
  [`${effect}/dist/index.js`]: 'export const TEST = true;\n',
};
for (const [path, bytes] of Object.entries(graphFiles)) {
  fs.mkdirSync(dirname(join(engineDirectory, path)), { recursive: true });
  fs.writeFileSync(join(engineDirectory, path), bytes);
}
const manifest = JSON.stringify({ schemaVersion: 1, platform: process.platform, arch: process.arch,
  requiredBunVersion: process.platform === 'darwin' ? '1.4.4' : '1.3.11', engineVersions: ['2.1.4'],
  files: Object.entries(graphFiles).map(([path, bytes]) => ({ path, bytes: Buffer.byteLength(bytes), sha256: hash(bytes), executable: false })) });
fs.writeFileSync(join(engineDirectory, 'opencode-v2-engine-manifest.json'), manifest);
const executableBytes = '#!/bin/sh\nprintf TEST-no-execution\n';
const executablePath = join(root, 'resources', 'runtime', 'bun', 'bun');
fs.mkdirSync(dirname(executablePath), { recursive: true });
fs.writeFileSync(executablePath, executableBytes, { mode: 0o700 });
member.executable = { path: executablePath, sha256: hash(executableBytes) };
member.embedded = { ...member.embedded, directory: engineDirectory, manifestSha256: hash(manifest) };
delete member.embedded.configurationSource;
const seed = profile.management[0];
for (const key of ['cwd', 'environment', 'executable', 'embedded', 'nativeGeneration', 'protocolRevision'])
  seed[key] = structuredClone(member[key]);
seed.nativeModel = { providerId, modelId: member.model };
const lease = acquireProfileWriterLease(profile.owner.storageRoot);
member.embedded.configurationSource = captureOpenCodeConfigurationSource(member, undefined, () => {
  lease.assertCurrent(); return true;
}).reference;
seed.embedded.configurationSource = captureOpenCodeConfigurationSource(seed).reference;
const store = new TeamOwnerStore(profile.owner.storageRoot, definition.binding.teamName);
const owner = createFilesystemTeamOwner({ root: profile.owner.storageRoot, store, binding: definition.binding,
  members: definition.members, grants: definition.grants, savedSettings: definition.savedSettings });
const team = { definition, owner, connection: owner.connect(profile.principalId) };
const sources = new RuntimeSourceIndex(profile, () => lease.assertCurrent());
const originalIndexPath = '/workspace/scratch/38cae95a211b/ci-audit-1192/14675140379/TEST-desktop-backend-nG7N5B/hoststore/runtime-sources/index.json';
const originalIndex = JSON.parse(fs.readFileSync(originalIndexPath, 'utf8'));
assert.equal(originalIndex.records.length, 2);
const publicationEvidence = [];
for (const originalRecord of originalIndex.records) {
  const grant = JSON.parse(JSON.stringify(originalRecord.grant).replaceAll(originalRoot, root));
  const commandId = `TEST-benchmark-${grant.projectPath === null ? 'global' : 'project'}`;
  let admissions = 0;
  const publication = await sources.refreshConfiguration({ grant, commandId,
    expectedRevision: sources.current({ grant }).revision }, () => { admissions++; });
  assert.equal(publication.phase, 'published'); assert.equal(admissions, 1);
  publicationEvidence.push({ scope: grant.projectPath === null ? 'global' : 'project', commandId,
    selection: publication.selection, admissions });
}
assert.equal(sources.store.read().records.length, 2);
assert.equal(sources.store.read().current.length, 2);
const coordinator = new RuntimeTeamCoordinator({ profile, teams: new Map([[definition.binding.teamId, team]]),
  sources, assertWriter: () => lease.assertCurrent(), createProvider() { forbiddenEffects++; throw new Error('TEST no provider open'); } });
const restorations = [];
const heldStores = new Map();
const storeIds = new WeakMap(); let nextStoreId = 1;
const storeId = store => { if (!storeIds.has(store)) storeIds.set(store, nextStoreId++); return storeIds.get(store); };
function instrument(object, method, label, customize) {
  const original = object[method];
  assert.equal(typeof original, 'function', `${label} implementation present`);
  object[method] = function (...args) {
    return span(typeof label === 'function' ? label.call(this, ...args) : label,
      () => customize ? customize.call(this, original, args) : original.apply(this, args));
  };
  restorations.push(() => { object[method] = original; });
}
const fsNames = ['realpathSync', 'lstatSync', 'readFileSync', 'readdirSync', 'openSync', 'closeSync',
  'readSync', 'fstatSync', 'mkdirSync', 'writeFileSync', 'renameSync', 'unlinkSync', 'rmdirSync', 'fsyncSync'];
for (const name of fsNames) {
  const native = name === 'realpathSync' ? fs[name].native : undefined;
  instrument(fs, name, `fs.${name}`);
  if (native) fs[name].native = native;
}
syncBuiltinESMExports();
instrument(TeamOwnerStore.prototype, 'validateNamespace', 'namespace.validate', function (original, args) {
  if (active?.observations) active.observations.push({ operation: 'namespace', store: storeId(this),
    depth: this.fenceDepth, heldStores: [...heldStores.keys()].map(storeId) });
  return original.apply(this, args);
});
instrument(TeamOwnerStore.prototype, 'fenced', function () { return `team.fenced.${this.fenceDepth ? 'nested' : 'outer'}`; },
  function (original, [action]) {
    return original.call(this, () => {
      heldStores.set(this, (heldStores.get(this) ?? 0) + 1);
      try { return action(); }
      finally { const depth = heldStores.get(this) - 1; if (depth) heldStores.set(this, depth); else heldStores.delete(this); }
    });
  });
for (const name of ['read', 'list']) instrument(TeamOwnerStore.prototype, name, `team.${name}`);
for (const name of ['read', 'check']) instrument(FileRuntimeSourceIndex.prototype, name, `source-file.${name}`);
for (const name of ['read', 'currentForRecipe', 'resolveRecipe', 'assertReferenceAvailable', 'retainedSeed', 'seed'])
  instrument(RuntimeSourceIndex.prototype, name, `source.${name}`);
for (const name of ['read', 'parse', 'checkDirectory'])
  instrument(FileManagementCommandStore.prototype, name, `journal.${name}`);
instrument(RuntimeOwner.prototype, 'readSession', 'runtime.readSession', function (original, args) {
  if (active) {
    const key = heldStores.size ? 'runtimeReadWithTeamFence' : 'runtimeReadWithoutTeamFence';
    active[key] = (active[key] ?? 0) + 1;
    if (active.observations) active.observations.push({ operation: 'runtime.readSession', heldStores: [...heldStores.keys()].map(storeId) });
  }
  return original.apply(this, args);
});
instrument(Object.getPrototypeOf(owner), 'withLaunchAuthority', function (_principal, action) { return `team.authority.${action}`; });
instrument(Object.getPrototypeOf(owner), 'runtimeCaptures', 'team.runtimeCaptures');
try {
  const view = await coordinator.executeLaunch(definition.binding.teamId, 'model.configuration.read', 'TEST-bench-config', {});
  const input = { launchId: view.source.sourceId, rosterRevision: view.source.rosterRevision, memberId: 'alice-id',
    model: `${providerId}/${member.model}`, draft: { providerId: 'opencode', target: { kind: 'lead' } } };
  const captured = coordinator.captureLaunchModelProbe(definition.binding.teamId, input, 'start');
  const savedCurrent = () => span('saved.current', captured.isCurrent);
  const configuration = captureOpenCodeV2Configuration(captured.profile, captured.profile.nativeModel, savedCurrent);
  const credential = captureOpenCodeV2SessionCredential(captured.profile, providerId, configuration.isCurrent,
    configuration.key, configuration.selectedFile);
  assert.equal(credential.isCurrent(), true);
  const rows = [];
  for (const operation of ['saved', 'credential']) {
    const current = operation === 'saved' ? savedCurrent : credential.isCurrent;
    for (let i = 0; i < 3; i++) assert.equal(current(), true);
    for (const instrumented of [false, true]) {
      for (let i = 0; i < 12; i++) {
        const row = { operation, instrumented, spans: {} };
        active = instrumented ? row : undefined;
        const start = performance.now(), cpu = process.cpuUsage();
        assert.equal(current(), true);
        const used = process.cpuUsage(cpu); row.wallMs = performance.now() - start; row.cpuMs = (used.user + used.system) / 1000;
        active = undefined; rows.push(row);
      }
    }
  }
  const observation = { spans: {}, observations: [] };
  active = observation; assert.equal(savedCurrent(), true); active = undefined;
  const summaries = [];
  for (const operation of ['saved', 'credential']) for (const instrumented of [false, true]) {
    const selected = rows.filter(row => row.operation === operation && row.instrumented === instrumented);
    const sorted = selected.map(row => row.wallMs).sort((a, b) => a - b);
    const mean = key => selected.reduce((sum, row) => sum + (row[key] ?? 0), 0) / selected.length;
    const names = new Set(selected.flatMap(row => Object.keys(row.spans)));
    summaries.push({ operation, instrumented, samples: selected.length, medianMs: (sorted[5] + sorted[6]) / 2,
      meanMs: mean('wallMs'), cpuMeanMs: mean('cpuMs'), runtimeReadWithTeamFence: mean('runtimeReadWithTeamFence'),
      runtimeReadWithoutTeamFence: mean('runtimeReadWithoutTeamFence'),
      spans: Object.fromEntries([...names].map(name => [name, Object.fromEntries(['calls', 'inclusiveMs', 'selfMs'].map(key =>
        [key, selected.reduce((sum, row) => sum + (row.spans[name]?.[key] ?? 0), 0) / selected.length]))])) });
  }
  const paths = [
    'src/composition/savedTeamModelProbe.ts', 'src/adapters/team/TeamOwnerStore.ts', 'src/team/TeamOwner.ts',
    'src/composition/RuntimeSourceIndex.ts', 'src/adapters/profile/FileRuntimeSourceIndex.ts',
    'src/adapters/providers/FileManagementCommandStore.ts', 'src/composition/runtimeSourceGrantAuthority.ts',
    'src/composition/runtimeCaptureSource.ts', 'src/composition/teamRoster.ts', 'src/runtime/RuntimeOwner.ts',
    'src/adapters/providers/OpenCodeV2CapturedConfiguration.ts', 'src/adapters/providers/OpenCodeV2SessionCredential.ts',
    'src/adapters/providers/OpenCodeV2CredentialScope.ts', 'src/adapters/team/ControllerAdapter.ts',
    'tests/runtime-source-native-identity.test.ts',
  ];
  const packageRoot = dirname(base);
  const sourcePins = paths.flatMap(relative => {
    const file = join(packageRoot, relative);
    const items = [{ path: file, bytes: fs.statSync(file).size, sha256: hash(fs.readFileSync(file)) }];
    if (relative.startsWith('src/')) {
      const dist = join(base, relative.slice(4).replace(/\.ts$/, '.js'));
      items.push({ path: dist, bytes: fs.statSync(dist).size, sha256: hash(fs.readFileSync(dist)) });
    }
    return items;
  });
  const evidence = { kind: 'FINITE_ACTUAL_WRITER_TWO_PUBLICATION_CURRENTNESS_PROFILE', node: process.version,
    platform: process.platform, architecture: process.arch,
    originalProfileSource: '14675140379/host-profile.json', originalSourceIndex: originalIndexPath,
    qualifications: [
      'Actual RuntimeSourceIndex.refreshConfiguration publishes one global and one project source through the real index, journal, executable and embedded graph verifiers.',
      'Actual file/writer/namespace/authority checks execute without cached results; production source and deadlines are unchanged.',
      'Original grant/profile/path geometry is adapted to a fresh Linux TEST namespace; original Darwin native binaries/account/history are not replayed.',
      'Finite schema-valid embedded graph and TEST executable bytes are verified but never executed; native, provider and sockets are prohibited.',
      'The same one-member saved-team selection and two publication scopes are reproduced. Runtime native/history remains unstarted and empty.',
      'Instrumented spans are nested. Sum selfMs only for disjoint time; inclusive values must not be added together.',
      'source.read selfMs is the residual history validation and function overhead after its actual file/journal reads, not a separate exclusive CPU profiler.',
      'Noninstrumented rows retain forwarding wrappers with timing disabled. Timing-only instrumentation overhead is shown separately.',
      'Controller code is source-pinned and evaluated unchanged plus a lexical acquire/release timing wrapper in this isolated child; no callback or IO is removed.',
      'No native catalog loop is run; do not extrapolate these local times or counts to the original44.470s interval.'
    ], controller: { path: lockPath, sourceSha256: hash(lockOriginal), timingTrailerSha256: hash(lockTrailer) },
    forbiddenEffects, publications: publicationEvidence, sourcePins, summaries, observation, rows };
  assert.equal(forbiddenEffects, 0);
  fs.writeFileSync(join(output, 'published-guard-benchmark.json'), JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify({ forbiddenEffects, publications: publicationEvidence.map(value => value.scope), summaries }, null, 2));
} finally {
  active = undefined;
  for (const restore of restorations.reverse()) restore();
  syncBuiltinESMExports();
  await coordinator.close(); await sources.close(); lease.release();
  delete globalThis.__TEST_CURRENTNESS_SPAN;
  fs.rmSync(scratch, { recursive: true, force: true });
}
