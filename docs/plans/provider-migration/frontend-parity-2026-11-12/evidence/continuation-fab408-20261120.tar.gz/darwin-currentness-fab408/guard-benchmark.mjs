import assert from 'node:assert/strict';
import fs from 'node:fs';
import cp from 'node:child_process';
import net from 'node:net';
import { syncBuiltinESMExports } from 'node:module';
import { dirname, join } from 'node:path';
import { performance } from 'node:perf_hooks';

// Finite in-process diagnosis only. No provider/native launch or network listener is admitted.
let forbiddenEffects = 0;
for (const name of ['spawn', 'spawnSync', 'exec', 'execSync', 'execFile', 'execFileSync', 'fork'])
  cp[name] = () => { forbiddenEffects++; throw new Error('TEST native execution forbidden'); };
net.Server.prototype.listen = function () { forbiddenEffects++; throw new Error('TEST sockets forbidden'); };
net.Socket.prototype.connect = function () { forbiddenEffects++; throw new Error('TEST sockets forbidden'); };
syncBuiltinESMExports();

const base = '/workspace/scratch/38cae95a211b/agent-teams-ai/packages/legacy-agent-host/dist';
const [{ createFilesystemTeamOwner }, { TeamOwnerStore }, { acquireProfileWriterLease },
  { RuntimeTeamCoordinator }, { RuntimeSourceIndex }, { captureOpenCodeConfigurationSource },
  { captureOpenCodeV2Configuration }, { captureOpenCodeV2SessionCredential }] = await Promise.all([
  import(base + '/adapters/team/createFilesystemTeamOwner.js'),
  import(base + '/adapters/team/TeamOwnerStore.js'),
  import(base + '/adapters/profile/ProfileWriterLease.js'),
  import(base + '/composition/RuntimeTeamCoordinator.js'),
  import(base + '/composition/RuntimeSourceIndex.js'),
  import(base + '/adapters/providers/OpenCodeConfigurationSource.js'),
  import(base + '/adapters/providers/OpenCodeV2CapturedConfiguration.js'),
  import(base + '/adapters/providers/OpenCodeV2SessionCredential.js'),
]);
const output = '/workspace/scratch/38cae95a211b/darwin-currentness-fab408';
const original = JSON.parse(fs.readFileSync('/workspace/scratch/38cae95a211b/ci-audit-1192/14675140379/TEST-desktop-backend-nG7N5B/host-profile.json', 'utf8'));
const scratch = fs.mkdtempSync(join(output, 'TEST-profile-'));
const root = join(scratch, 'Users', 'runner', 'work', 'agent-teams-ai', 'agent-teams-ai', 'TEST-original-length', 'TEST-desktop-backend');
fs.mkdirSync(root, { recursive: true });
const originalRoot = dirname(original.owner.storageRoot);
const profile = JSON.parse(JSON.stringify(original).replaceAll(originalRoot, root));
const definition = profile.teams[0], member = profile.runtime.members[0];
const linuxProfile = JSON.parse(fs.readFileSync('/workspace/scratch/38cae95a211b/ci-audit-1192/14675137567/TEST-desktop-backend-VGvPWI/host-profile.json', 'utf8'));
const linuxTemplate = linuxProfile.runtime.providerTemplates.find(value => value.provider === 'opencode' && value.nativeGeneration === 'v2');
assert.ok(linuxTemplate && linuxTemplate.embedded.platform === process.platform && linuxTemplate.embedded.arch === process.arch);
member.executable = structuredClone(linuxTemplate.executable);
for (const key of ['directory', 'manifestSha256', 'version', 'platform', 'arch', 'externalDirectory'])
  member.embedded[key] = linuxTemplate.embedded[key];
for (const path of [profile.owner.storageRoot, member.cwd, ...Object.entries(member.environment)
  .filter(([name]) => ['HOME', 'TMPDIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'XDG_CACHE_HOME'].includes(name)).map(([, value]) => value)])
  fs.mkdirSync(path, { recursive: true });
const providerId = member.nativeOptions.providerId;
member.environment.OPENCODE_CONFIG_CONTENT = JSON.stringify({ provider: { [providerId]: {
  npm: '@ai-sdk/openai-compatible', options: { baseURL: 'http://127.0.0.1:1/TEST', apiKey: 'TEST-benchmark-only-key' },
  models: { [member.model]: { name: member.model, limit: { context: 128000, output: 8192 } } },
} } });
const lease = acquireProfileWriterLease(profile.owner.storageRoot);
member.embedded.configurationSource = captureOpenCodeConfigurationSource(member, undefined, () => {
  lease.assertCurrent(); return true;
}).reference;
const store = new TeamOwnerStore(profile.owner.storageRoot, definition.binding.teamName);
const owner = createFilesystemTeamOwner({ root: profile.owner.storageRoot, store, binding: definition.binding,
  members: definition.members, grants: definition.grants, savedSettings: definition.savedSettings });
const team = { definition, owner, connection: owner.connect(profile.principalId) };
const sources = new RuntimeSourceIndex(profile, () => lease.assertCurrent());
const coordinator = new RuntimeTeamCoordinator({ profile, teams: new Map([[definition.binding.teamId, team]]),
  sources, assertWriter: () => lease.assertCurrent(), createProvider() { forbiddenEffects++; throw new Error('TEST no provider open'); } });
let active, mode = 'js', stackSample = false;
const fsOriginals = Object.fromEntries(['realpathSync', 'lstatSync', 'readFileSync', 'readdirSync', 'openSync', 'closeSync', 'readSync', 'fstatSync']
  .map(name => [name, fs[name]]));
const nativeRealpath = fs.realpathSync.native;
const callsites = new Map();
for (const [name, originalFunction] of Object.entries(fsOriginals)) {
  const wrapped = function (...args) {
    if (name === 'realpathSync' && stackSample) {
      const stack = new Error().stack.split('\n').slice(2, 5).map(line => line.trim()).join(' <- ');
      callsites.set(stack, (callsites.get(stack) ?? 0) + 1);
    }
    const start = performance.now();
    try { return (name === 'realpathSync' && mode === 'native' ? nativeRealpath : originalFunction)(...args); }
    finally { if (active) { const row = active.fs[name] ??= { calls: 0, ms: 0 }; row.calls++; row.ms += performance.now() - start; } }
  };
  if (name === 'realpathSync') wrapped.native = nativeRealpath;
  fs[name] = wrapped;
}
syncBuiltinESMExports();
const namespace = TeamOwnerStore.prototype.validateNamespace;
TeamOwnerStore.prototype.validateNamespace = function (...args) {
  const start = performance.now();
  try { return namespace.apply(this, args); }
  finally { if (active) { active.namespaceCalls++; active.namespaceMs += performance.now() - start; } }
};
try {
  const view = await coordinator.executeLaunch(definition.binding.teamId, 'model.configuration.read', 'TEST-bench-config', {});
  const input = { launchId: view.source.sourceId, rosterRevision: view.source.rosterRevision, memberId: 'alice-id',
    model: `${providerId}/${member.model}`, draft: { providerId: 'opencode', target: { kind: 'lead' } } };
  const captured = coordinator.captureLaunchModelProbe(definition.binding.teamId, input, 'start');
  const savedCurrent = () => {
    const start = performance.now();
    try { return captured.isCurrent(); }
    finally { if (active) { active.savedCurrentCalls++; active.savedCurrentMs += performance.now() - start; } }
  };
  const configuration = captureOpenCodeV2Configuration(captured.profile, captured.profile.nativeModel, savedCurrent);
  const credential = captureOpenCodeV2SessionCredential(captured.profile, providerId, configuration.isCurrent,
    configuration.key, configuration.selectedFile);
  assert.ok(credential.isCurrent());
  const rows = [];
  for (const operation of ['saved', 'credential']) {
    const current = operation === 'saved' ? savedCurrent : credential.isCurrent;
    for (let i = 0; i < 3; i++) assert.equal(current(), true);
    stackSample = operation === 'credential'; assert.equal(current(), true); stackSample = false;
    for (const selectedMode of ['js', 'native', 'js', 'native']) {
      mode = selectedMode;
      for (let i = 0; i < 8; i++) {
        active = { operation, mode, fs: {}, namespaceCalls: 0, namespaceMs: 0, savedCurrentCalls: 0, savedCurrentMs: 0 };
        const start = performance.now(), cpu = process.cpuUsage();
        assert.equal(current(), true);
        const used = process.cpuUsage(cpu); active.wallMs = performance.now() - start; active.cpuMs = (used.user + used.system) / 1000;
        rows.push(active); active = undefined;
      }
    }
  }
  const summaries = [];
  for (const operation of ['saved', 'credential']) for (const selectedMode of ['js', 'native']) {
    const selected = rows.filter(row => row.operation === operation && row.mode === selectedMode);
    const sorted = selected.map(row => row.wallMs).sort((a, b) => a - b);
    const mean = key => selected.reduce((sum, row) => sum + row[key], 0) / selected.length;
    const names = new Set(selected.flatMap(row => Object.keys(row.fs)));
    summaries.push({ operation, mode: selectedMode, samples: selected.length, medianMs: (sorted[7] + sorted[8]) / 2,
      meanMs: mean('wallMs'), cpuMeanMs: mean('cpuMs'), savedCurrentCalls: mean('savedCurrentCalls'),
      savedCurrentMeanMs: mean('savedCurrentMs'), namespaceCalls: mean('namespaceCalls'), namespaceMeanMs: mean('namespaceMs'),
      fs: Object.fromEntries([...names].map(name => [name, {
        calls: selected.reduce((sum, row) => sum + (row.fs[name]?.calls ?? 0), 0) / selected.length,
        meanMs: selected.reduce((sum, row) => sum + (row.fs[name]?.ms ?? 0), 0) / selected.length,
      }])) });
  }
  const evidence = { kind: 'FINITE_IN_PROCESS_SAVED_PREFLIGHT_CURRENTNESS_BENCHMARK', node: process.version,
    platform: process.platform, originalProfileSource: '14675140379/host-profile.json', root,
    qualifications: ['Current Team/Runtime/SourceIndex/credential implementations; fresh temporary files and actual saved-model producer.',
      'Schema-valid Linux embedded metadata comes from14675137567; the enclosing TEST profile geometry comes from the Darwin artifact. No engine artifact is qualified or executed.',
      'No native process, HTTP catalog, network or original CI replay; original directory and account paths are replaced with controlled TEST roots.',
      'RuntimeSourceIndex is real but empty; original artifact history and native account do not become synthetic proof.',
      'Global realpath substitution is an in-process diagnostic upper bound, not a proposed production patch.',
      'Counts and CPU timings are local measurements; do not attribute the original44.470s interval to a single loop or GET.'],
    forbiddenEffects, summaries, callsites: [...callsites].map(([stack, count]) => ({ stack, count })), rows };
  assert.equal(forbiddenEffects, 0);
  fs.writeFileSync(join(output, 'guard-benchmark.json'), JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify({ forbiddenEffects, summaries }, null, 2));
} finally {
  active = undefined; mode = 'js';
  for (const [name, value] of Object.entries(fsOriginals)) fs[name] = value;
  syncBuiltinESMExports(); TeamOwnerStore.prototype.validateNamespace = namespace;
  await coordinator.close(); lease.release(); fs.rmSync(scratch, { recursive: true, force: true });
}
