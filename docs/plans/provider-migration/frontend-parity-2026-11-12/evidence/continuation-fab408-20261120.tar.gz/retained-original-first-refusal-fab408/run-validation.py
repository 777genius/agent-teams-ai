import os,subprocess,time,json,sys
from pathlib import Path
r=Path('/workspace/scratch/38cae95a211b/agent-teams-ai');e=Path('/workspace/scratch/38cae95a211b/retained-original-first-refusal-fab408')
node='/workspace/scratch/38cae95a211b/toolchain/node-v24.21.0-linux-x64/bin/node';corepack='/workspace/scratch/38cae95a211b/toolchain/node-v24.21.0-linux-x64/lib/node_modules/corepack/dist/corepack.js'
name=sys.argv[1]
commands={
 'green-final':[node,corepack,'pnpm','exec','vitest','run','test/main/services/team/LegacyNativeStopRelease.test.ts','test/main/services/team/LegacyNativeStopOrdering.test.ts','--maxWorkers=1'],
 'ts7':[node,'node_modules/@typescript/native/bin/tsc','--noEmit','--project',str(e/'tsconfig.json')],
 'lint':[node,corepack,'pnpm','lint:fast:files','--','src/main/services/team/provisioning/LegacyNativeStopRelease.ts','src/main/services/team/provisioning/LegacyNativeStopPublication.ts','src/main/services/team/provisioning/TeamProvisioningStopCleanupCompatibilityFacade.ts','test/main/services/team/LegacyNativeStopRelease.test.ts'],
}
cmd=commands[name];env={**os.environ,'PATH':str(Path(node).parent)+os.pathsep+os.environ['PATH'],'COREPACK_ENABLE_NETWORK':'0'};t=time.monotonic()
with (e/(name+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
(e/(name+'.json')).write_text(json.dumps({'argv':cmd,'exitCode':p.returncode,'durationSeconds':time.monotonic()-t},indent=2)+'\n')
print(name,'exit',p.returncode)
