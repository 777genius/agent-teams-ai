import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

evidence = Path(__file__).resolve().parent
repo = evidence.parent / 'agent-teams-ai'
node = evidence.parent / 'toolchain/node-v24.21.0-linux-x64/bin/node'
corepack = node.parent.parent / 'lib/node_modules/corepack/dist/corepack.js'
env = dict(os.environ, PATH=str(node.parent) + os.pathsep + os.environ.get('PATH', ''))
label, operation = sys.argv[1:3]
extra = sys.argv[3:]
if operation == 'pnpm':
    argv = [str(node), str(corepack), 'pnpm', *extra]
else:
    argv = [str(node), *extra]
paths = [value['path'] for value in json.loads((evidence / 'original-source-pins.json').read_text())['files']]
def pins():
    return [{'path': path, 'sha256': hashlib.sha256((repo / path).read_bytes()).hexdigest()} for path in paths]
before = pins()
started = time.monotonic()
with (evidence / (label + '.log')).open('wb') as output:
    result = subprocess.run(argv, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
after = pins()
receipt = {'argv': argv, 'cwd': str(repo), 'exitCode': result.returncode,
           'seconds': time.monotonic() - started, 'sourcePinsBefore': before,
           'sourcePinsAfter': after, 'sourceBytesUnchanged': before == after}
(evidence / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'label': label, 'exitCode': result.returncode,
                  'seconds': receipt['seconds'], 'sourceBytesUnchanged': before == after}))
print('\n'.join((evidence / (label + '.log')).read_text(errors='replace').splitlines()[-20:]))
sys.exit(result.returncode)
