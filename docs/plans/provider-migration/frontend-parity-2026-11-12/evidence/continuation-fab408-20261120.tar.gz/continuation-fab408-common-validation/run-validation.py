from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
w=Path('/workspace/scratch/38cae95a211b');repo=w/'agent-teams-ai';out=w/'continuation-fab408-common-validation'
name=sys.argv[1]
paths=json.loads((w/'continuation-fab408-expected-paths.json').read_text())
code=[x for x in paths if x.endswith(('.ts','.tsx','.mts','.cts'))]
node=w/'toolchain/node-v24.21.0-linux-x64/bin/node';corepack=w/'toolchain/node-v24.21.0-linux-x64/lib/node_modules/corepack/dist/corepack.js'
commands={'fast-lint':[str(node),str(corepack),'pnpm','lint:fast:files','--',*code],'source-size':[str(node),str(corepack),'pnpm','guard:source-file-size'],'architecture':[str(node),str(corepack),'pnpm','guard:team-provisioning-architecture'],'diff-check':['git','diff','--check']}
argv=commands[name]; env={**os.environ,'COREPACK_ENABLE_NETWORK':'0','PATH':str(node.parent)+os.pathsep+os.environ['PATH']}
for ext in ('json','log'):
 old=out/(name+'.'+ext); prior=out/('first13-'+name+'.'+ext)
 if old.exists() and not prior.exists():prior.write_bytes(old.read_bytes())
start=time.monotonic();when=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(name+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
result={'argv':argv,'startedAt':when,'exitCode':r.returncode,'durationSeconds':time.monotonic()-start,'sourcePins':[{'path':p,'sha256':hashlib.sha256((repo/p).read_bytes()).hexdigest()} for p in code]}
(out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'name':name,'exitCode':r.returncode,'durationSeconds':result['durationSeconds'],'codeFiles':len(code)}));print((out/(name+'.log')).read_text()[-3000:]);sys.exit(r.returncode)
