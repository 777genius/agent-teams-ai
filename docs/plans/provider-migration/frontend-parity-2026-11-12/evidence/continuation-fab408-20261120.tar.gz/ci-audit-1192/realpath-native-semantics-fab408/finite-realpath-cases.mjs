import * as fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { join, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const output = fileURLToPath(new URL('.', import.meta.url));
const root = fs.realpathSync(fs.mkdtempSync(join(output, 'TEST-realpath-')));
const cwd = process.cwd();
const hash = value => createHash('sha256').update(value).digest('hex');
const paths = new Map();
const normalize = path => typeof path === 'string' ? path.replaceAll(root, '<TEST-root>') : String(path);
const outcome = (resolver, path, options) => {
  try { const value = resolver(path, options); return { ok: true, value: normalize(Buffer.isBuffer(value) ? value.toString() : value), buffer: Buffer.isBuffer(value) }; }
  catch (error) { return { ok: false, code: error.code, syscall: error.syscall, path: normalize(error.path) }; }
};
const compare = (name, path, options) => {
  const js = outcome(fs.realpathSync, path, options), native = outcome(fs.realpathSync.native, path, options);
  return { name, input: normalize(path), lexicalCanonical: typeof path === 'string' && resolve(path) === path,
    js, native, sameResultOrCode: js.ok === native.ok && (js.ok ? js.value === native.value && js.buffer === native.buffer : js.code === native.code) };
};
const identity = path => { const s = fs.lstatSync(path, { bigint: true }); return { dev: String(s.dev), ino: String(s.ino), directory: s.isDirectory(), symlink: s.isSymbolicLink() }; };
const check = (resolver, path, captured) => {
  try { const current = identity(path); return !current.symlink && current.directory === captured.directory &&
    current.dev === captured.dev && current.ino === captured.ino && resolver(path) === path; }
  catch { return false; }
};
let report;
try {
  fs.mkdirSync(join(root, 'actual')); fs.mkdirSync(join(root, 'elsewhere')); fs.mkdirSync(join(root, 'elsewhere', 'nested'));
  fs.writeFileSync(join(root, 'actual', 'file'), 'AAAA');
  fs.writeFileSync(join(root, 'file'), 'ROOT');
  fs.writeFileSync(join(root, 'elsewhere', 'file'), 'ELSE');
  fs.writeFileSync(join(root, 'unicode-é'), 'UTF8');
  fs.linkSync(join(root, 'actual', 'file'), join(root, 'hardlink'));
  fs.symlinkSync(join(root, 'actual', 'file'), join(root, 'file-link'));
  fs.symlinkSync(join(root, 'actual'), join(root, 'ancestor-link'));
  fs.symlinkSync(join(root, 'elsewhere', 'nested'), join(root, 'dotdot-link'));
  fs.symlinkSync(join(root, 'absent'), join(root, 'broken'));
  fs.symlinkSync(join(root, 'cycle'), join(root, 'cycle'));
  paths.set('canonical-directory', join(root, 'actual'));
  paths.set('canonical-file', join(root, 'actual', 'file'));
  paths.set('hardlink', join(root, 'hardlink'));
  paths.set('file-symlink', join(root, 'file-link'));
  paths.set('ancestor-symlink', join(root, 'ancestor-link', 'file'));
  paths.set('broken-leaf', join(root, 'broken'));
  paths.set('broken-ancestor', join(root, 'broken', 'file'));
  paths.set('cycle', join(root, 'cycle'));
  paths.set('missing-leaf', join(root, 'actual', 'absent'));
  paths.set('missing-ancestor', join(root, 'absent', 'file'));
  paths.set('regular-file-as-ancestor', join(root, 'file', 'child'));
  paths.set('directory-trailing-slash', join(root, 'actual') + '/');
  paths.set('file-trailing-slash', join(root, 'file') + '/');
  paths.set('file-dotdot', root + '/file/../file');
  paths.set('missing-dotdot', root + '/missing/../file');
  paths.set('symlink-dotdot', root + '/dotdot-link/../file');
  paths.set('duplicate-slash', root + '//actual//file');
  paths.set('leading-double-slash', '/' + root + '/file');
  paths.set('utf8-string', join(root, 'unicode-é'));
  paths.set('empty-string', '');
  paths.set('dot', '.');
  process.chdir(root);
  paths.set('relative-file', 'actual/file');
  for (let i = 0; i <= 41; i++) {
    fs.mkdirSync(join(root, 'chain-' + i)); fs.writeFileSync(join(root, 'chain-' + i, 'file'), 'DATA');
    if (i > 0) fs.symlinkSync(join(root, 'chain-' + i), join(root, 'chain-' + (i - 1), 'next'));
  }
  for (const length of [1, 33, 40, 41]) paths.set('separate-ancestor-links-' + length, join(root, 'chain-0') + '/next'.repeat(length) + '/file');
  const cases = [...paths].map(([name, path]) => compare(name, path));
  cases.push(compare('buffer-input-valid-utf8', Buffer.from(join(root, 'actual', 'file'))));
  cases.push(compare('file-url-input', pathToFileURL(join(root, 'actual', 'file'))));
  cases.push(compare('buffer-output-option', join(root, 'actual', 'file'), { encoding: 'buffer' }));
  const original = join(root, 'actual', 'file'), capturedFile = identity(original), capturedDirectory = identity(join(root, 'actual'));
  const guards = [
    { name: 'canonical-unchanged', js: check(fs.realpathSync, original, capturedFile), native: check(fs.realpathSync.native, original, capturedFile) },
    { name: 'file-symlink-rejected', js: check(fs.realpathSync, join(root, 'file-link'), capturedFile), native: check(fs.realpathSync.native, join(root, 'file-link'), capturedFile) },
    { name: 'ancestor-symlink-rejected', js: check(fs.realpathSync, join(root, 'ancestor-link', 'file'), capturedFile), native: check(fs.realpathSync.native, join(root, 'ancestor-link', 'file'), capturedFile) },
  ];
  fs.renameSync(original, join(root, 'original-held'));
  fs.writeFileSync(original, 'BBBB');
  guards.push({ name: 'same-path-file-replacement', js: check(fs.realpathSync, original, capturedFile), native: check(fs.realpathSync.native, original, capturedFile), canonicalAlone: compare('same-path-file-replacement', original) });
  const beforeHash = hash(fs.readFileSync(original)), beforeMutation = identity(original);
  fs.writeFileSync(original, 'CCCC');
  guards.push({ name: 'same-inode-byte-mutation-needs-full-hash', js: check(fs.realpathSync, original, beforeMutation), native: check(fs.realpathSync.native, original, beforeMutation), sameInode: identity(original).ino === beforeMutation.ino, hashChanged: hash(fs.readFileSync(original)) !== beforeHash });
  fs.renameSync(join(root, 'actual'), join(root, 'original-directory-held'));
  fs.mkdirSync(join(root, 'actual'));
  guards.push({ name: 'same-path-directory-replacement', js: check(fs.realpathSync, join(root, 'actual'), capturedDirectory), native: check(fs.realpathSync.native, join(root, 'actual'), capturedDirectory) });
  assert(cases.find(x => x.name === 'symlink-dotdot').sameResultOrCode === false);
  assert(guards[0].js && guards[0].native);
  assert(guards.filter(x => x.name !== 'canonical-unchanged' && x.name !== 'same-inode-byte-mutation-needs-full-hash').every(x => !x.js && !x.native));
  assert(guards.find(x => x.name === 'same-inode-byte-mutation-needs-full-hash').hashChanged);
  const implementations = { js: fs.realpathSync.toString(), native: fs.realpathSync.native.toString() };
  fs.writeFileSync(join(output, 'pinned-node-realpath-implementations.json'), JSON.stringify(implementations, null, 2) + '\n');
  report = { kind: 'FINITE_FILESYSTEM_SEMANTICS_ONLY', node: process.version, uv: process.versions.uv,
    platform: process.platform, arch: process.arch, glibcVersionRuntime: process.report.getReport().header.glibcVersionRuntime,
    cases, guards, implementationsSha256: hash(JSON.stringify(implementations)),
    qualifications: ['No performance measurement, provider, socket, subprocess, Git or CI execution.',
      'Only Linux was executed. macOS and Windows outcomes are not inferred as equivalent.',
      'Guard rows exercise filesystem invariants; they are not native-runtime or complete Host admission tests.',
      'Calls run against fresh ordinary files between explicit mutations; no atomic replacement guarantee is claimed.'] };
} finally { process.chdir(cwd); fs.rmSync(root, { recursive: true, force: true }); }
report.cleanup = !fs.existsSync(root);
fs.writeFileSync(join(output, 'linux-realpath-semantics.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ node: report.node, platform: report.platform, cases: report.cases.length,
  different: report.cases.filter(x => !x.sameResultOrCode).map(x => ({ name: x.name, js: x.js, native: x.native })),
  guards: report.guards.length, cleanup: report.cleanup }));
