import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { closeSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { pathToFileURL } from 'node:url';

const image = '/workspace/scratch/38cae95a211b/darwin-digest-benchmark/bun-darwin-arm64-v1.4.4';
const expected = '0a2237cdcfa0d16ef501d9acca9f0026309ef348bea7393a64e8d1e3609565cc';
const iterations = 6;
const order = ['original', 'bounded', 'bounded', 'original', 'original', 'bounded'];
const helperModule = '/workspace/scratch/38cae95a211b/agent-teams-ai/packages/legacy-agent-host/dist/process/digestOpenExecutable.js';
const helperSource = '/workspace/scratch/38cae95a211b/agent-teams-ai/packages/legacy-agent-host/src/process/digestOpenExecutable.ts';
const { digestOpenExecutable: bounded } = await import(pathToFileURL(helperModule).href);
function original(fd) {
  return createHash('sha256').update(readFileSync(fd)).digest('hex');
}
if (process.argv[2]) {
  assert.ok(['original', 'bounded'].includes(process.argv[2]));
  global.gc();
  const before = process.memoryUsage();
  const cpuBefore = process.cpuUsage();
  const times = [];
  let maximumExternal = before.external;
  let maximumArrayBuffers = before.arrayBuffers;
  for (let i = 0; i < iterations; ++i) {
    const fd = openSync(image, 'r');
    try {
      const started = performance.now();
      const digest = (process.argv[2] === 'original' ? original : bounded)(fd);
      times.push(performance.now() - started);
      assert.equal(digest, expected);
      const memory = process.memoryUsage();
      maximumExternal = Math.max(maximumExternal, memory.external);
      maximumArrayBuffers = Math.max(maximumArrayBuffers, memory.arrayBuffers);
    } finally { closeSync(fd); }
  }
  console.log(JSON.stringify({ mode: process.argv[2], timesMs: times, before,
    maximumExternal, maximumArrayBuffers, resourceUsage: process.resourceUsage(),
    cpuMicroseconds: process.cpuUsage(cpuBefore), verifiedHashEveryIteration: true }));
} else {
  const results = [];
  for (const mode of order) {
    const child = spawnSync(process.execPath, ['--expose-gc', import.meta.filename, mode],
      { encoding: 'utf8', timeout: 45000, maxBuffer: 1024 * 1024 });
    assert.equal(child.error, undefined);
    assert.equal(child.status, 0, child.stderr);
    const result = JSON.parse(child.stdout);
    results.push(result);
    console.log(JSON.stringify({ mode, meanMs: result.timesMs.reduce((a, b) => a + b, 0) / iterations,
      maxRssKiB: result.resourceUsage.maxRSS, maximumExternal: result.maximumExternal,
      maximumArrayBuffers: result.maximumArrayBuffers }));
  }
  writeFileSync('/workspace/scratch/38cae95a211b/darwin-digest-benchmark/results.json',
    JSON.stringify({ image, expected, iterations, order, node: process.version, platform: process.platform,
      helperModule, helperModuleSha256: createHash('sha256').update(readFileSync(helperModule)).digest('hex'),
      helperSource, helperSourceSha256: createHash('sha256').update(readFileSync(helperSource)).digest('hex'),
      architecture: process.arch, note: 'Filesystem cache not controlled; balanced process order; Darwin executable bytes read on Linux, never executed; no native custody qualification.', results }, null, 2));
}
