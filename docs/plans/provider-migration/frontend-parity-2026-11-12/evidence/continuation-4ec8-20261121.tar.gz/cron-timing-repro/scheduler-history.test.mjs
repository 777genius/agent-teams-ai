import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { hostTeamSelectionKey } from '@features/agent-backend/contracts';
import { JsonScheduleRepository } from '@main/services/schedule/JsonScheduleRepository';
import { SchedulerService } from '@main/services/schedule/SchedulerService';
import { setClaudeBasePathOverride } from '@main/utils/pathDecoder';
import { afterAll, expect, test } from 'vitest';

import clockHarness from './clock-harness.cjs';

const { withClock, ARM, TARGET, END, EXPRESSION, iso } = clockHarness;
const repoRoot = '/workspace/scratch/82699181f7b2/agent-teams-ai';
const scratch = '/workspace/scratch/82699181f7b2/cron-timing-repro';
const variant = process.env.CRON_TEST_VARIANT;
const results = [];
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

function trackRepository(repository, clock) {
  const pending = new Set();
  const failures = [];
  const operations = [];
  // Observe public repository promises without replacing any persistence logic.
  const names = ['listSchedules', 'getSchedule', 'getSchedulesByTeam', 'saveSchedule',
    'deleteSchedule', 'updateSchedule', 'listRuns', 'getLatestRun', 'saveRun',
    'pruneOldRuns', 'saveRunLogs', 'getRunLogs'];
  const port = Object.fromEntries(names.map(name => [name, (...args) => {
    operations.push({ name, at: iso(clock.now()) });
    const result = repository[name](...args);
    pending.add(result);
    result.then(() => pending.delete(result), error => { pending.delete(result); failures.push(error); });
    return result;
  }]));
  return { port, operations, async settle() {
    for (let turn = 0; turn < 32; turn++) {
      await Promise.allSettled([...pending]);
      // A real event-loop turn drains continuations that start the next repository
      // operation. No fake clock advancement, action retry or private service call.
      await new Promise(resolve => setImmediate(resolve));
      if (failures.length) throw failures[0];
      if (pending.size === 0) return;
    }
    throw new Error('Finite repository settlement budget exhausted');
  } };
}

async function setup(clock, directory) {
  const actualRepository = new JsonScheduleRepository();
  const tracked = trackRepository(actualRepository, clock);
  const dispatches = [];
  const events = [];
  let oneShotCalls = 0;
  const scheduler = new SchedulerService(tracked.port, {
    async execute() { oneShotCalls++; throw new Error('No provider process is permitted in this test'); },
    cancel() { return false; }, cancelAll() {},
  }, undefined, {
    supportsHost: true,
    async assertCanSchedule() {},
    async dispatch(schedule, runId, isCancelled) {
      assert.equal(isCancelled(), false);
      dispatches.push({ runId, at: iso(clock.now()), hostTarget: schedule.hostTarget });
      return { kind: 'dispatched', taskId: `TEST-task-${runId}`, summary: 'TEST original scheduler occurrence admitted' };
    },
  });
  scheduler.setChangeEmitter(event => events.push(event));
  clock.cleanup.push(async () => { await tracked.settle(); await scheduler.stop(); await tracked.settle(); });
  await scheduler.start();
  const target = { kind: 'host', handleId: 'TEST-cron-handle', contextId: 'TEST-clock-context',
    ownerResourceRef: 'TEST-clock-owner', teamResourceRef: 'TEST-clock-team' };
  const admission = { target, isCurrent: () => true };
  const schedule = await scheduler.createSchedule({
    teamName: hostTeamSelectionKey(target.handleId),
    cronExpression: '0 0 1 1 *', timezone: 'UTC', warmUpMinutes: 0,
    executionMode: 'agent', taskFirst: true, reviewedSavedPrompt: true, targetMember: 'alice',
    launchConfig: { cwd: directory, prompt: 'TEST saved scheduled instructions' },
  }, admission);
  const manual = await scheduler.triggerNow(schedule.id);
  await tracked.settle();
  assert.equal((await scheduler.getRuns(schedule.id)).length, 1);
  assert.equal((await scheduler.getRuns(schedule.id))[0].status, 'dispatched');
  assert.equal(dispatches.length, 1);

  const armed = await scheduler.updateSchedule(schedule.id, { cronExpression: EXPRESSION }, admission);
  await tracked.settle();
  assert.equal(armed.nextRunAt, iso(TARGET));
  assert.equal(clock.pendingCount(), 1, 'Only the actual Croner timer remains after durable metadata settlement');

  async function driveUntil(end) {
    for (let turn = 0; turn < 12; turn++) {
      await tracked.settle();
      const due = clock.nextDue();
      if (due === undefined || due > end) { clock.moveTo(end); return; }
      await clock.fireNextAt(Math.max(clock.now(), due));
    }
    throw new Error('Finite scheduler timer budget exhausted');
  }
  return { scheduler, tracked, schedule, manual, admission, dispatches, events, driveUntil,
    oneShotCalls: () => oneShotCalls,
    async intermediate() {
      await clock.fireNextAt(ARM + 30_000);
      await tracked.settle();
      assert.equal(clock.nextDue(), TARGET);
    },
    async history() { await tracked.settle(); return scheduler.getRuns(schedule.id); },
  };
}

const scenarios = [
  ['normal automatic row after manual and edit', 'normal'],
  ['automatic row survives early-check crossing', 'early-cross'],
  ['automatic row survives split-calculation crossing', 'split-cross'],
  ['Stop prevents a subsequent automatic history row', 'stop'],
  ['pause and resume preserve the original manual history', 'pause'],
  ['replacement publishes only its own automatic occurrence', 'replace'],
];

for (const [name, mode] of scenarios) {
  test(name, async () => {
    const directory = await mkdtemp(join(tmpdir(), 'TEST-croner-scheduler-public-'));
    setClaudeBasePathOverride(directory);
    let history = [];
    let dispatches = [];
    let operations = [];
    let events = [];
    let outcome;
    try {
      outcome = await withClock(async clock => {
        const f = await setup(clock, directory);
        dispatches = f.dispatches;
        operations = f.tracked.operations;
        events = f.events;
        if (mode === 'replace') {
          clock.moveTo(ARM + 5000);
          const updated = await f.scheduler.updateSchedule(f.schedule.id,
            { cronExpression: '53 9 15 21 11 *' }, f.admission);
          await f.tracked.settle();
          assert.equal(updated.nextRunAt, '2026-11-21T15:09:53.000Z');
        } else {
          await f.intermediate();
          if (mode === 'early-cross') await clock.fireNextAt(TARGET - 1, [TARGET - 1, TARGET + 1]);
          if (mode === 'split-cross') await clock.fireNextAt(TARGET - 1,
            [TARGET - 1, TARGET - 1, TARGET - 1, TARGET + 1]);
          if (mode === 'stop') await f.scheduler.stop();
          if (mode === 'pause') await f.scheduler.pauseSchedule(f.schedule.id);
        }
        await f.driveUntil(END);
        if (mode === 'pause') {
          await f.scheduler.resumeSchedule(f.schedule.id);
          await f.driveUntil(END + 1000);
        }
        history = await f.history();
        assert.equal(f.oneShotCalls(), 0);
        const shouldRun = mode !== 'stop' && mode !== 'pause';
        assert.equal(history.length, shouldRun ? 2 : 1,
          'Public persisted scheduler history must contain exactly the original manual row and the admitted automatic row');
        assert.equal(dispatches.length, shouldRun ? 2 : 1);
        assert.equal(history.filter(row => row.id === f.manual.id).length, 1);
        assert.ok(history.every(row => row.status === 'dispatched'));
        if (shouldRun) {
          const automatic = history.find(row => row.id !== f.manual.id);
          const at = Date.parse(automatic.scheduledFor);
          const expected = mode === 'replace' ? TARGET + 1000 : TARGET;
          assert.ok(at >= expected && at < expected + 15_000);
          assert.deepEqual(automatic.hostTarget, f.admission.target);
        }
      });
    } finally {
      setClaudeBasePathOverride(null);
      await rm(directory, { recursive: true, force: true });
    }
    results.push({ name, mode, ...outcome, history, dispatches, operations, events });
    expect(outcome.status, outcome.failure?.message).toBe('PASS');
    expect(outcome.pendingTimersAfterCleanup).toBe(0);
  });
}

afterAll(() => {
  const paths = [
    join(repoRoot, 'src/main/services/schedule/SchedulerService.ts'),
    join(repoRoot, 'src/main/services/schedule/JsonScheduleRepository.ts'),
    join(scratch, 'scheduler-history.test.mjs'), join(scratch, 'vitest.scheduler.config.mjs'),
    join(scratch, 'clock-harness.cjs'),
    join(variant === 'baseline' ? join(repoRoot, 'node_modules/croner') : join(scratch, 'candidate'), 'dist/croner.js'),
  ];
  writeFileSync(join(scratch, `scheduler-${variant}-receipt.json`), JSON.stringify({
    schemaVersion: 1, variant, nodeVersion: process.version,
    boundary: 'Unmodified actual SchedulerService and JsonScheduleRepository; public methods and original captured Croner timer callbacks; controlled dispatcher port, no provider process',
    scope: 'Finite scheduler persistence qualification; not a Desktop or native-provider acceptance result',
    pins: paths.map(path => ({ path, sha256: digest(readFileSync(path)) })),
    totals: { cases: results.length, passed: results.filter(row => row.status === 'PASS').length,
      failed: results.filter(row => row.status !== 'PASS').length }, results,
  }, null, 2) + '\n');
});
