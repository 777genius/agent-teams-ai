'use strict';
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { readFileSync, writeFileSync } = require('node:fs');
const { join } = require('node:path');
const { pathToFileURL } = require('node:url');
const vm = require('node:vm');
const { withClock, real, ARM, TARGET, END, EXPRESSION, iso } = require('./clock-harness.cjs');

const variant = process.argv[2];
assert.ok(variant === 'baseline' || variant === 'candidate');
const root = variant === 'baseline'
  ? '/workspace/scratch/82699181f7b2/agent-teams-ai/node_modules/croner'
  : join(__dirname, 'candidate');
assert.equal(JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).version, '10.0.1');
const firstSecond = Math.ceil(ARM / 1000) * 1000;
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

async function load(format) {
  const file = format === 'cjs' ? 'croner.cjs' : format === 'esm' ? 'croner.js' : 'croner.umd.js';
  const path = join(root, 'dist', file);
  if (format === 'cjs') return { Cron: require(path).Cron, path };
  if (format === 'esm') return { Cron: (await import(pathToFileURL(path).href)).Cron, path };
  // Exercise the actual browser UMD build, not a transformed CJS surrogate.
  const context = {
    Intl,
    setTimeout: (...args) => globalThis.setTimeout(...args),
    clearTimeout: (...args) => globalThis.clearTimeout(...args),
  };
  Object.defineProperty(context, 'Date', { get: () => globalThis.Date });
  vm.runInNewContext(readFileSync(path, 'utf8'), context, { filename: path, timeout: 1000 });
  assert.equal(typeof context.Cron, 'function');
  return { Cron: context.Cron, path };
}

const cases = [
  ['normal exact target', async (clock, Cron) => {
    clock.create(Cron);
    await clock.intermediateWake();
    await clock.fireNextAt(TARGET);
    await clock.through(END);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(TARGET) }]);
  }],
  ['delayed target', async (clock, Cron) => {
    clock.create(Cron);
    await clock.intermediateWake();
    await clock.fireNextAt(TARGET + 5000);
    await clock.through(END);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(TARGET + 5000) }]);
  }],
  ['early wake without crossing', async (clock, Cron) => {
    clock.create(Cron);
    await clock.intermediateWake();
    await clock.fireNextAt(TARGET - 1);
    assert.equal(clock.calls.length, 0);
    await clock.through(END);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(TARGET) }]);
  }],
  ['crossing early wake check/reschedule', async (clock, Cron) => {
    clock.create(Cron);
    await clock.intermediateWake();
    await clock.fireNextAt(TARGET - 1, [TARGET - 1, TARGET + 1]);
    await clock.through(END);
    assert.equal(clock.calls.length, 1, 'The original admitted occurrence must survive the clock crossing');
    const at = real.Date.parse(clock.calls[0].at);
    assert.ok(at >= TARGET && at < TARGET + 15_000, 'The same occurrence must dispatch within the original bound');
  }],
  ['crossing msToNext/nextRun', async (clock, Cron) => {
    clock.create(Cron, { deferred: true });
    await clock.intermediateWake();
    await clock.fireNextAt(TARGET - 1, [TARGET - 1, TARGET - 1, TARGET - 1, TARGET + 1]);
    await clock.through(END);
    assert.equal(clock.calls.length, 1, 'The timer delay and captured target must refer to the same occurrence');
    const at = real.Date.parse(clock.calls[0].at);
    assert.ok(at >= TARGET && at < TARGET + 15_000);
  }],
  ['Stop cancels original timer', async (clock, Cron) => {
    const job = clock.create(Cron);
    await clock.intermediateWake();
    job.stop();
    assert.equal(clock.pendingCount(), 0);
    await clock.through(END);
    assert.deepEqual(clock.calls, []);
  }],
  ['pause/resume does not replay expired target', async (clock, Cron) => {
    const job = clock.create(Cron);
    await clock.intermediateWake();
    job.pause();
    await clock.fireNextAt(TARGET);
    job.resume();
    await clock.through(END);
    assert.deepEqual(clock.calls, []);
  }],
  ['replacement owns its single occurrence', async (clock, Cron) => {
    const job = clock.create(Cron);
    clock.moveTo(ARM + 5000);
    clock.create(Cron, { label: 'replacement', expression: '53 9 15 21 11 *' });
    job.stop();
    await clock.through(END);
    assert.deepEqual(clock.calls, [{ label: 'replacement', at: '2026-11-21T15:09:53.000Z' }]);
  }],
  ['interval first admission and currentRun spacing', async (clock, Cron) => {
    const job = clock.create(Cron, { expression: '* * * * * *', options: { interval: 3 } });
    await clock.through(firstSecond + 4000);
    assert.deepEqual(clock.calls.map(row => row.at), [iso(firstSecond), iso(firstSecond + 3000)]);
    assert.equal(job.currentRun().toISOString(), iso(firstSecond + 3000));
  }],
  ['startAt interval and exclusive stopAt', async (clock, Cron) => {
    const start = real.Date.parse('2026-11-21T15:09:00.000Z');
    const job = clock.create(Cron, { expression: '* * * * * *', options: {
      startAt: iso(start), interval: 3, stopAt: iso(start + 6000),
    } });
    assert.equal(job.nextRun().toISOString(), iso(start));
    await clock.through(start + 10_000);
    assert.deepEqual(clock.calls.map(row => row.at), [iso(start), iso(start + 3000)]);
    assert.equal(clock.pendingCount(), 0);
  }],
  ['maxRuns exhausted without rearm', async (clock, Cron) => {
    const job = clock.create(Cron, { expression: '* * * * * *', options: { maxRuns: 2 } });
    await clock.through(firstSecond + 5000);
    assert.deepEqual(clock.calls.map(row => row.at), [iso(firstSecond), iso(firstSecond + 1000)]);
    assert.equal(job.runsLeft(), 0);
    assert.equal(clock.pendingCount(), 0);
  }],
  ['unref on intermediate and early rearm', async (clock, Cron) => {
    clock.create(Cron, { options: { unref: true } });
    await clock.intermediateWake();
    await clock.fireNextAt(TARGET - 1);
    await clock.through(END);
    assert.equal(clock.calls.length, 1);
    assert.deepEqual(clock.trace.filter(row => row.event === 'unref').map(row => row.id),
      clock.trace.filter(row => row.event === 'timer-registered').map(row => row.id));
  }],
  ['protect preserves the in-flight callback', async (clock, Cron) => {
    let release;
    let protectedCount = 0;
    let callCount = 0;
    const job = clock.create(Cron, { expression: '* * * * * *', options: {
      protect: () => { protectedCount++; },
    }, callback: () => ++callCount === 1 ? new Promise(resolve => { release = resolve; }) : undefined });
    clock.cleanup.push(() => release?.());
    await clock.fireNextAt(firstSecond);
    assert.equal(job.isBusy(), true);
    await clock.fireNextAt(firstSecond + 1000);
    assert.equal(clock.calls.length, 1);
    await clock.through(firstSecond + 1001);
    assert.equal(protectedCount, 1);
    release();
    await Promise.resolve();
    await Promise.resolve();
    assert.equal(job.isBusy(), false);
    await clock.fireNextAt(firstSecond + 2000);
    assert.deepEqual(clock.calls.map(row => row.at), [iso(firstSecond), iso(firstSecond + 2000)]);
  }],
  ['public trigger invalidates a changed interval target', async (clock, Cron) => {
    const job = clock.create(Cron, { expression: '* * * * * *', options: { interval: 5 } });
    clock.moveTo(firstSecond - 100);
    await job.trigger();
    assert.equal(job.currentRun().toISOString(), iso(firstSecond - 100));
    await clock.fireNextAt(firstSecond - 1);
    assert.equal(clock.nextDue(), firstSecond + 4000);
    await clock.through(firstSecond + 5000);
    assert.deepEqual(clock.calls.map(row => row.at), [iso(firstSecond - 100), iso(firstSecond + 4000)]);
  }],
  ['dayOffset keeps the shifted callback target', async (clock, Cron) => {
    const job = clock.create(Cron, { options: { dayOffset: 1 } });
    const shifted = TARGET + 86_400_000;
    assert.equal(job.nextRun().toISOString(), iso(shifted));
    await clock.fireNextAt(shifted);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(shifted) }]);
  }],
];

(async () => {
  const results = [];
  const modules = [];
  for (const format of ['cjs', 'esm', 'umd']) {
    const { Cron, path } = await load(format);
    modules.push({ format, path, sha256: digest(readFileSync(path)) });
    for (const [name, action] of cases) {
      const result = await withClock(clock => action(clock, Cron));
      results.push({ format, name, ...result });
      console.log(`${result.status} ${format} ${name}: callbacks=${result.calls.length}; cleanup=${result.pendingTimersAfterCleanup}`);
    }
  }
  const failed = results.filter(row => row.status === 'FAIL').length;
  const receipt = { schemaVersion: 1, variant,
    claim: 'Finite defect/control comparison on a shared harness; original CI interleaving is not proved',
    version: '10.0.1', nodeVersion: process.version, modules,
    harness: [__filename, join(__dirname, 'clock-harness.cjs')].map(path => ({ path, sha256: digest(readFileSync(path)) })),
    observation: { arm: iso(ARM), target: iso(TARGET), end: iso(END), expression: EXPRESSION, timezone: 'UTC' },
    totals: { cases: results.length, passed: results.length - failed, failed }, results };
  writeFileSync(join(__dirname, `${variant}-common-receipt.json`), JSON.stringify(receipt, null, 2) + '\n');
  console.log(`TOTAL ${variant}: ${results.length - failed}/${results.length} PASS; ${failed} FAIL`);
  process.exitCode = failed ? 1 : 0;
})().catch(error => { console.error(error); process.exitCode = 2; });
