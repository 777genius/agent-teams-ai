'use strict';
const assert = require('node:assert/strict');

const real = { Date, setTimeout, clearTimeout };
const ARM = real.Date.parse('2026-11-21T15:08:54.853Z');
const TARGET = real.Date.parse('2026-11-21T15:09:52.000Z');
const END = real.Date.parse('2026-11-21T15:10:09.926Z');
const EXPRESSION = '52 9 15 21 11 *';
const iso = value => new real.Date(value).toISOString();

async function withClock(action) {
  let now = ARM;
  let scriptedReads = [];
  let timerId = 0;
  const pending = new Map();
  const calls = [];
  const trace = [];
  const cleanup = [];
  const sample = source => {
    const value = scriptedReads.length ? scriptedReads.shift() : now;
    assert.ok(value >= now, 'Controlled wall time must be monotonic');
    now = value;
    trace.push({ event: 'clock-read', source, at: iso(now) });
    return now;
  };
  class ControlledDate extends real.Date {
    constructor(...args) { super(...(args.length ? args : [sample('new Date()')])); }
    static now() { return sample('Date.now()'); }
  }
  globalThis.Date = ControlledDate;
  globalThis.setTimeout = (callback, delay, ...args) => {
    assert.equal(typeof callback, 'function');
    assert.ok(Number.isFinite(delay) && delay <= 2_147_483_647);
    const id = ++timerId;
    const token = { id, unref() { trace.push({ event: 'unref', id }); return this; } };
    const due = now + Math.max(1, Math.trunc(delay));
    pending.set(id, { callback, args, token, due });
    trace.push({ event: 'timer-registered', id, at: iso(now), rawDelayMs: delay, due: iso(due) });
    return token;
  };
  globalThis.clearTimeout = token => {
    trace.push({ event: 'timer-cleared', id: token?.id, existed: pending.delete(token?.id) });
  };
  const next = () => [...pending.values()].sort((a, b) => a.due - b.due || a.token.id - b.token.id)[0];
  const clock = {
    calls, trace, cleanup,
    now: () => now,
    pendingCount: () => pending.size,
    nextDue: () => next()?.due,
    record(label) {
      const call = { label, at: iso(now) };
      calls.push(call);
      trace.push({ event: 'user-callback', ...call });
    },
    moveTo(value) {
      assert.ok(value >= now, 'Controlled clock cannot move backward');
      assert.equal(scriptedReads.length, 0);
      now = value;
    },
    create(Cron, { label = 'original', expression = EXPRESSION, options = {}, deferred = false, callback } = {}) {
      const invoke = () => { clock.record(label); return callback?.(); };
      const job = deferred
        ? new Cron(expression, { timezone: 'UTC', paused: true, ...options })
        : new Cron(expression, { timezone: 'UTC', paused: true, ...options }, invoke);
      cleanup.push(() => job.stop());
      if (deferred) job.schedule(invoke);
      job.resume();
      trace.push({ event: 'public-arm', label, expression, via: deferred ? 'constructor/schedule/resume' : 'constructor/resume' });
      return job;
    },
    async fireNextAt(value, reads = []) {
      clock.moveTo(value);
      assert.ok(reads.every((item, index) => item >= (index ? reads[index - 1] : value)));
      scriptedReads = [...reads];
      const timer = next();
      assert.ok(timer, 'A captured pending timer must exist');
      pending.delete(timer.token.id);
      trace.push({ event: 'captured-timer-fired', id: timer.token.id, due: iso(timer.due),
        observedAt: iso(now), earlyByMs: Math.max(0, timer.due - now) });
      await timer.callback(...timer.args);
      // Clock samples are instrumentation, not a required implementation read count.
      // Every implementation experiences the same final wall-clock boundary even
      // if it removed the redundant Date reads that exposed the original defect.
      const remaining = scriptedReads.length;
      scriptedReads = [];
      if (reads.length) now = Math.max(now, reads.at(-1));
      trace.push({ event: 'clock-script-completed', requested: reads.length,
        consumed: reads.length - remaining, remaining, at: iso(now) });
    },
    async through(end) {
      for (let count = 0; count < 24; count++) {
        const timer = next();
        if (!timer || timer.due > end) { clock.moveTo(end); return; }
        await clock.fireNextAt(Math.max(now, timer.due));
      }
      throw new Error('Finite captured-timer budget exceeded');
    },
    async intermediateWake() {
      assert.equal(pending.size, 1);
      await clock.fireNextAt(ARM + 30_000);
      assert.equal(calls.length, 0);
      assert.equal(clock.nextDue(), TARGET);
    },
  };
  let failure;
  try { await action(clock); }
  catch (error) { failure = { name: error.name, message: error.message,
    expected: error.expected, actual: error.actual, stack: error.stack }; }
  finally {
    try {
      for (const close of cleanup.reverse()) await close();
      assert.equal(pending.size, 0, 'Owned timers must be empty after cleanup');
    } catch (error) { failure ??= { name: error.name, message: error.message, stack: error.stack }; }
    globalThis.Date = real.Date;
    globalThis.setTimeout = real.setTimeout;
    globalThis.clearTimeout = real.clearTimeout;
  }
  return { status: failure ? 'FAIL' : 'PASS', calls, trace, pendingTimersAfterCleanup: pending.size,
    ...(failure ? { failure } : {}) };
}

module.exports = { withClock, real, ARM, TARGET, END, EXPRESSION, iso };
