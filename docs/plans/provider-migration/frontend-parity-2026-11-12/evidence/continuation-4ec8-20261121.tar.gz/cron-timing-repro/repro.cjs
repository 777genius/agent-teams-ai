'use strict';

// Scratch-only regression: execute the installed, pinned Croner implementation.
// The harness replaces only the clock and timer transport, never Cron methods.
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { readFileSync, writeFileSync } = require('node:fs');
const { join } = require('node:path');

const repo = '/workspace/scratch/82699181f7b2/agent-teams-ai';
const cronerPath = require.resolve('croner', { paths: [repo] });
const { Cron } = require(cronerPath);
const packagePath = require.resolve('croner/package.json', { paths: [repo] });
assert.equal(JSON.parse(readFileSync(packagePath, 'utf8')).version, '10.0.1');
const original = { Date, setTimeout, clearTimeout };
const arm = original.Date.parse('2026-11-21T15:08:54.853Z');
const target = original.Date.parse('2026-11-21T15:09:52.000Z');
const observationEnd = original.Date.parse('2026-11-21T15:10:09.926Z');
const expression = '52 9 15 21 11 *';
const iso = value => new original.Date(value).toISOString();
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

async function scenario(name, action) {
  let now = arm;
  let scriptedReads = [];
  let nextTimerId = 0;
  const pending = new Map();
  const jobs = [];
  const calls = [];
  const trace = [];
  const nowSample = source => {
    const value = scriptedReads.length ? scriptedReads.shift() : now;
    assert.ok(value >= now, 'The controlled wall clock must be monotonic');
    now = value;
    trace.push({ event: 'clock-read', source, at: iso(now) });
    return now;
  };
  class ControlledDate extends original.Date {
    constructor(...args) { super(...(args.length ? args : [nowSample('new Date()')])); }
    static now() { return nowSample('Date.now()'); }
  }
  globalThis.Date = ControlledDate;
  globalThis.setTimeout = (callback, delay, ...args) => {
    assert.equal(typeof callback, 'function');
    assert.ok(Number.isFinite(delay), 'Croner must register a finite delay');
    const id = ++nextTimerId;
    const normalizedDelay = Math.max(1, Math.trunc(delay));
    const token = { id, unref() { return this; } };
    pending.set(id, { callback, args, token, due: now + normalizedDelay });
    trace.push({ event: 'timer-registered', id, at: iso(now), rawDelayMs: delay,
      due: iso(now + normalizedDelay) });
    return token;
  };
  globalThis.clearTimeout = token => {
    trace.push({ event: 'timer-cleared', id: token?.id, existed: pending.delete(token?.id) });
  };

  const clock = {
    calls,
    trace,
    pendingCount: () => pending.size,
    moveTo(value) {
      assert.ok(value >= now, 'The controlled wall clock cannot move backward');
      assert.equal(scriptedReads.length, 0, 'Previous clock script must be consumed');
      now = value;
    },
    create(label = 'original', pattern = expression, deferredCallback = false) {
      const callback = () => {
        calls.push({ label, at: iso(now) });
        trace.push({ event: 'user-callback', label, at: iso(now) });
      };
      const job = deferredCallback
        ? new Cron(pattern, { timezone: 'UTC', paused: true })
        : new Cron(pattern, { timezone: 'UTC', paused: true }, callback);
      jobs.push(job);
      if (deferredCallback) job.schedule(callback);
      job.resume();
      assert.equal(job.nextRun().toISOString(), pattern === expression
        ? iso(target) : '2026-11-21T15:09:53.000Z');
      trace.push({ event: 'public-arm', label, pattern, via: deferredCallback ? 'constructor/schedule/resume' : 'constructor/resume' });
      return job;
    },
    async fireNextAt(value, reads = []) {
      clock.moveTo(value);
      scriptedReads = [...reads];
      const timer = [...pending.values()].sort((a, b) => a.due - b.due || a.token.id - b.token.id)[0];
      assert.ok(timer, 'A real captured Croner timer must exist before firing');
      pending.delete(timer.token.id);
      trace.push({ event: 'captured-timer-fired', id: timer.token.id,
        due: iso(timer.due), observedAt: iso(now), earlyByMs: Math.max(0, timer.due - now) });
      // Invoke exactly the closure registered by Croner, with its original args.
      // No access to _checkTrigger, _trigger, _states or SchedulerService internals.
      await timer.callback(...timer.args);
      assert.equal(scriptedReads.length, 0, 'Every requested boundary sample must be observed');
    },
    async through(end) {
      for (let fired = 0; fired < 12; fired++) {
        const timer = [...pending.values()].sort((a, b) => a.due - b.due || a.token.id - b.token.id)[0];
        if (!timer || timer.due > end) { clock.moveTo(end); return; }
        await clock.fireNextAt(Math.max(now, timer.due));
      }
      throw new Error('Finite timer budget exceeded');
    },
    async initialThirtySecondWake() {
      assert.equal(pending.size, 1);
      await clock.fireNextAt(arm + 30_000);
      assert.equal(calls.length, 0, 'The intermediate 30s wake must not dispatch early');
      const [timer] = pending.values();
      assert.equal(timer.due, target, 'Croner should initially retain the exact second target');
    },
  };

  let error;
  try { await action(clock); }
  catch (failure) { error = { name: failure.name, message: failure.message,
    expected: failure.expected, actual: failure.actual, stack: failure.stack }; }
  finally {
    for (const job of jobs) job.stop();
    assert.equal(pending.size, 0, 'All scenario-owned Croner timers must be cleared');
    globalThis.Date = original.Date;
    globalThis.setTimeout = original.setTimeout;
    globalThis.clearTimeout = original.clearTimeout;
  }
  return { name, status: error ? 'FAIL' : 'PASS', calls, pendingTimersAfterCleanup: pending.size,
    ...(error ? { error } : {}), trace };
}

const cases = [
  ['normal exact target control', async clock => {
    clock.create();
    await clock.initialThirtySecondWake();
    await clock.fireNextAt(target);
    await clock.through(observationEnd);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(target) }]);
  }],
  ['delayed target control', async clock => {
    clock.create();
    await clock.initialThirtySecondWake();
    await clock.fireNextAt(target + 5_000);
    await clock.through(observationEnd);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(target + 5_000) }]);
  }],
  ['early wake without crossing control', async clock => {
    clock.create();
    await clock.initialThirtySecondWake();
    await clock.fireNextAt(target - 1);
    assert.equal(clock.calls.length, 0);
    await clock.through(observationEnd);
    assert.deepEqual(clock.calls, [{ label: 'original', at: iso(target) }]);
  }],
  ['RED crossing between early wake check and reschedule', async clock => {
    const job = clock.create();
    await clock.initialThirtySecondWake();
    await clock.fireNextAt(target - 1, [target - 1, target + 1]);
    await clock.through(observationEnd);
    clock.trace.push({ event: 'public-nextRun-after-observation', at: job.nextRun().toISOString() });
    assert.equal(clock.calls.length, 1,
      'The admitted original occurrence must not be lost when the wall clock crosses its target during an early wake');
  }],
  ['RED crossing between msToNext and nextRun', async clock => {
    const job = clock.create('original', expression, true);
    await clock.initialThirtySecondWake();
    await clock.fireNextAt(target - 1, [target - 1, target - 1, target - 1, target + 1]);
    await clock.through(observationEnd);
    clock.trace.push({ event: 'public-nextRun-after-observation', at: job.nextRun().toISOString() });
    assert.equal(clock.calls.length, 1,
      'The timer delay and its captured target must refer to the same occurrence');
  }],
  ['Stop cancels the owned timer control', async clock => {
    const job = clock.create();
    await clock.initialThirtySecondWake();
    job.stop();
    assert.equal(clock.pendingCount(), 0);
    await clock.through(observationEnd);
    assert.deepEqual(clock.calls, []);
  }],
  ['pause suppresses and resume does not replay the expired occurrence control', async clock => {
    const job = clock.create();
    await clock.initialThirtySecondWake();
    job.pause();
    await clock.fireNextAt(target);
    job.resume();
    await clock.through(observationEnd);
    assert.deepEqual(clock.calls, []);
  }],
  ['replacement clears the original timer and admits only its own occurrence control', async clock => {
    const originalJob = clock.create();
    clock.moveTo(arm + 5_000);
    clock.create('replacement', '53 9 15 21 11 *');
    originalJob.stop();
    await clock.through(observationEnd);
    assert.deepEqual(clock.calls, [{ label: 'replacement', at: '2026-11-21T15:09:53.000Z' }]);
  }],
];

(async () => {
  const results = [];
  for (const [name, action] of cases) {
    const result = await scenario(name, action);
    results.push(result);
    console.log(`${result.status} ${name}: callbacks=${result.calls.length}; cleanupTimers=${result.pendingTimersAfterCleanup}`);
  }
  const failed = results.filter(result => result.status === 'FAIL').length;
  const receipt = {
    schemaVersion: 1,
    purpose: 'Finite dependency regression; no assertion of the original CI event interleave',
    repositoryHead: '4ec8e74b9a6430143287baa5298a11ade98a5794',
    module: { path: cronerPath, packagePath, version: '10.0.1', sha256: sha256(readFileSync(cronerPath)) },
    harness: { path: __filename, sha256: sha256(readFileSync(__filename)) },
    nodeVersion: process.version,
    originalObservation: { arm: iso(arm), target: iso(target), end: iso(observationEnd), expression, timezone: 'UTC' },
    timerTransport: 'Captured real Croner setTimeout closures; controlled monotonic wall clock; Node delay truncation/minimum 1ms',
    runtimeEffects: { genuineProviderExecutions: 0, privateSchedulerCalls: 0, dependencyMutations: 0, networkCalls: 0 },
    totals: { cases: results.length, passed: results.length - failed, failed },
    results,
  };
  writeFileSync(join(__dirname, 'baseline-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(`TOTAL ${results.length - failed}/${results.length} PASS; ${failed} RED; actual Croner ${receipt.module.sha256}`);
  process.exitCode = failed ? 1 : 0;
})().catch(error => { console.error(error); process.exitCode = 2; });
