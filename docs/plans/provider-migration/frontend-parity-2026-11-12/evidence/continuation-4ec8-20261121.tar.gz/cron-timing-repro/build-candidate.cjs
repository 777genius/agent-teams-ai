'use strict';
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { mkdirSync, readFileSync, writeFileSync } = require('node:fs');
const { join } = require('node:path');
const repo = '/workspace/scratch/82699181f7b2/agent-teams-ai';
const source = join(repo, 'node_modules/croner');
const destination = join(__dirname, 'candidate');
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const formats = [
  ['croner.cjs', 'A', 'E', '00b9a0fa32bcbcab444841945b471e1555ed2faa84abe653bd80190b025b568c'],
  ['croner.js', 'W', 'x', 'a2eb1f669c605d4775116947209c91dfec4afdcc76fe8407134938bf5a09a600'],
  ['croner.umd.js', 'L', 'z', '0d55da4f90b684bcbc867da09efdb4ccca0a60507675c8b66fb344de1bd434a6'],
];
const prepared = formats.map(([file, cap, unref, expected]) => {
  const original = readFileSync(join(source, 'dist', file), 'utf8');
  assert.equal(digest(original), expected);
  const beforeSchedule = 'let t=this.msToNext(),r=this.nextRun(this._states.currentRun);';
  const afterSchedule = 'let n=this._next(),t=n?n.getTime()-new m().getTime():null,r=this._states.currentRun?this.nextRun(this._states.currentRun):n?this.applyDayOffset(n.getDate(!1)):null;';
  const beforeRearm = ',this.schedule()}_next(e)';
  const afterRearm = ',!this._states.kill&&!this._states.paused&&t.getTime()<e.getTime()&&(!this._states.currentRun||this.nextRun(this._states.currentRun)?.getTime()===e.getTime())?(this._states.currentTimeout=setTimeout(()=>this._checkTrigger(e),Math.min(e.getTime()-Date.now(),' + cap + ')),this._states.currentTimeout&&this.options.unref&&' + unref + '(this._states.currentTimeout)):this.schedule()}_next(e)';
  assert.equal(original.split(beforeSchedule).length, 2, `${file}: one exact schedule hunk`);
  assert.equal(original.split(beforeRearm).length, 2, `${file}: one exact rearm hunk`);
  const candidate = original.replace(beforeSchedule, afterSchedule).replace(beforeRearm, afterRearm);
  return { file, sourceSha256: expected, candidateSha256: digest(candidate),
    sourceBytes: Buffer.byteLength(original), candidateBytes: Buffer.byteLength(candidate), candidate };
});
mkdirSync(join(destination, 'dist'), { recursive: true });
const packageBytes = readFileSync(join(source, 'package.json'));
writeFileSync(join(destination, 'package.json'), packageBytes);
for (const item of prepared) writeFileSync(join(destination, 'dist', item.file), item.candidate);
const receipt = { schemaVersion: 1, sourceVersion: '10.0.1', productionModified: false,
  proposal: 'Single initial _next candidate; retain an active early target only while currentRun still resolves to it',
  packageSha256: digest(packageBytes), files: prepared.map(({ candidate, ...item }) => item) };
writeFileSync(join(__dirname, 'candidate-pins.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
