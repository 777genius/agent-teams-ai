import { join } from 'node:path';

const repo = '/workspace/scratch/82699181f7b2/agent-teams-ai';
const scratch = '/workspace/scratch/82699181f7b2/cron-timing-repro';
const variant = process.env.CRON_TEST_VARIANT;
if (variant !== 'baseline' && variant !== 'candidate') throw new Error('Explicit Croner variant required');

export default {
  root: repo,
  cacheDir: join(scratch, 'vite-cache', variant),
  test: {
    globals: false,
    environment: 'node',
    include: [join(scratch, 'scheduler-history.test.mjs')],
    setupFiles: [],
    testTimeout: 15000,
    fileParallelism: false,
    maxWorkers: 1,
  },
  resolve: { alias: {
    '@main': join(repo, 'src/main'),
    '@shared': join(repo, 'src/shared'),
    '@features': join(repo, 'src/features'),
    '@preload': join(repo, 'src/preload'),
    '@claude-teams/agent-graph': join(repo, 'packages/agent-graph/src/index.ts'),
    vitest: join(repo, 'node_modules/vitest/dist/index.js'),
    croner: join(variant === 'baseline' ? join(repo, 'node_modules/croner') : join(scratch, 'candidate'), 'dist/croner.js'),
  } },
};
