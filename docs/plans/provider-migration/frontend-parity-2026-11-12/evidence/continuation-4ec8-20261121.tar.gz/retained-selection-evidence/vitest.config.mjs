import base from '/workspace/scratch/82699181f7b2/agent-teams-ai-e2e-next/vitest.config.ts';

export default {
  ...base,
  root: '/workspace/scratch/82699181f7b2/agent-teams-ai-e2e-next',
  cacheDir: '/workspace/scratch/82699181f7b2/retained-selection-evidence/vite-cache',
  test: { ...base.test, maxWorkers: 1, fileParallelism: false, include: [
    'src/main/services/team/provisioning/__tests__/TeamProvisioningOpenCodeRuntimeAdapterTeamFlow.test.ts',
  ] },
};
