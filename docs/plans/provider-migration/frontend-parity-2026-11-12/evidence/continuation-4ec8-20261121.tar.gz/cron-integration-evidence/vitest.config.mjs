import base from '/workspace/scratch/82699181f7b2/agent-teams-ai-e2e-next/vitest.config.ts';

const root = '/workspace/scratch/82699181f7b2/agent-teams-ai-e2e-next';
const variant = process.env.CRON_TEST_VARIANT;
if (variant !== 'baseline' && variant !== 'candidate') throw new Error('Explicit variant required');
const croner = variant === 'baseline'
  ? '/workspace/scratch/82699181f7b2/agent-teams-ai/node_modules/croner/dist/croner.js'
  : '/workspace/scratch/82699181f7b2/cron-timing-repro/candidate/dist/croner.js';

export default {
  ...base,
  root,
  cacheDir: `/workspace/scratch/82699181f7b2/cron-integration-evidence/vite-cache-${variant}`,
  test: { ...base.test, fileParallelism: false, maxWorkers: 1, include: [
    'test/main/services/schedule/CronerTiming.test.ts',
    'test/main/services/schedule/CronerSchedulerHistory.test.ts',
  ] },
  resolve: { ...base.resolve, alias: { ...base.resolve.alias, croner } },
};
