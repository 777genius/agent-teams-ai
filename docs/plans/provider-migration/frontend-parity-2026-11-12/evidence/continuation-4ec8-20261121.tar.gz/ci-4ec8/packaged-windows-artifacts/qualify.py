"""Pure byte/readback qualification of two original CI ZIPs; no product execution."""
from collections import Counter
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import subprocess

ROOT = Path('/workspace/scratch/82699181f7b2')
BASE = ROOT / 'ci-4ec8'
OUT = BASE / 'packaged-windows-artifacts'
HELPER = BASE / 'packaged-windows/verify_artifacts.py'
spec = importlib.util.spec_from_file_location('byte_verifier', HELPER)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def save(name, value):
    path = OUT / name
    data = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    path.write_bytes(data)
    return {'path': str(path.relative_to(BASE)), 'bytes': len(data), 'sha256': v.digest(data)}


def ref(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': v.digest(data)}


def safe_relative(name):
    assert name and '\\' not in name and '\x00' not in name
    assert not PurePosixPath(name).is_absolute() and not PureWindowsPath(name).drive
    assert all(p not in ('', '.', '..') for p in name.split('/'))


def input_pins(proof, candidate):
    pins = proof['originalInputPins']
    assert len(pins) == len({p['path'] for p in pins}) == 17
    results = []
    for pin in pins:
        assert v.HEX.fullmatch(pin['sha256'])
        name = PureWindowsPath(pin['path']).name
        item = {'name': name, 'sha256': pin['sha256'], 'archiveContainsBytes': False}
        if name == 'providerPeer.mjs':
            rel = 'tools/owned-process-broker/fixtures/providerPeer.mjs'
            assert pin['path'].replace('\\', '/').endswith('/' + rel)
            item.update(localSource=rel, qualification='local-source-bytes',
                        matchForm=v.local_pin(v.REPO / rel, pin['sha256']))
        elif name == 'cli.js':
            assert pin['path'] == proof['packaged']['hostEntry']
            assert pin['sha256'] == candidate['hostEntrySha256']
            rel = 'packages/legacy-agent-host/dist/cli.js'
            item.update(localSource=rel, qualification='local-compiled-JS-bytes',
                        matchForm=v.local_pin(v.REPO / rel, pin['sha256']))
        elif name == 'node.exe':
            assert pin['path'] == proof['packaged']['node']
            assert pin['sha256'] == candidate['node']['binarySha256']
            item['qualification'] = 'original-runner-pin-crossbound-to-candidate'
        elif name == 'TEST-desktop-descriptor.json':
            assert pin['sha256'] == proof['descriptorSha256']
            item['qualification'] = 'original-runner-pin-crossbound-to-descriptor'
        else:
            assert name in {'TEST codex.cmd', 'TEST-profile.json', 'TEST-host.mjs',
                'owned-process-broker.exe', 'manifest.json', 'owned-process-gate-controller.exe',
                'owned-process-fixture.exe', 'ui-seed-receipt.json', 'TEST-codex-metadata.cjs',
                'TEST-codex-metadata.cmd', 'TEST-claude-metadata.cjs', 'TEST-claude-metadata.cmd', 'current.json'}
            item['qualification'] = 'original-runner-pin-only-bytes-unavailable'
        results.append(item)
    return results


def detailed_windows(entries, proof, wrapper):
    assert proof['appExit'] == {'code': 0, 'signal': None}
    final = proof['finalCensus']
    assert final['ownedRemaining'] == final['listenerPids'] == [] and final['drained'] is True
    assert proof['quit']['attempted'] is True and proof['quit']['command']['method'] == 'Browser.close'
    assert proof['quit']['command']['id'] == 1 and proof['quit']['socketClosed']['afterSend'] is True
    assert proof['originalDriver']['parent'] == proof['originalController']['pid']
    assert proof['originalMain']['parent'] == proof['originalDriver']['pid']
    old, new = proof['originalHost']['identity'], proof['successorHost']['identity']
    assert old['pid'] != new['pid'] and old['birth'] != new['birth']
    assert old['parent'] == new['parent'] == proof['originalMain']['pid']
    assert len(proof['hostBirths']) == 2
    assert proof['beforeCrashPublic'] == proof['afterRetryPublic']
    original = proof['beforeCrashPublic']['processes']
    assert len(original) == 2 and [s['role'] for s in proof['stops']] == ['primary', 'neighbor']
    stops = []
    for stop in proof['stops']:
        r = stop['receipt']
        before = next(p for p in original if p['id'] == r['original']['id'])
        assert r['schemaVersion'] == 1 and r['family'] == 'process' and r['operation'] == 'terminate'
        assert r['principalId'] == 'human' and r['phase'] == 'completed'
        assert r['state'] == {'phase': 'completed', 'native': 'observed-absent', 'signalAccepted': 'unknown'}
        assert r['processRef'] == before['processRef'] and r['original']['pid'] == before['pid']
        assert r['capture'] == r['original']['capturedNative']
        assert r['capture']['admission'] == 'main-owned-job-scope-v1'
        assert r['nativeIntent']['command'] == {'operation': 'stop', 'capture': r['capture']}
        assert r['nativeSettlement']['command'] == {'operation': 'settle', 'capture': r['capture']}
        assert r['nativeIntent']['operationRef'] != r['nativeSettlement']['operationRef']
        assert r['nativeSettlementConfirmed'] is True
        assert r['result']['observation'] == 'absent' and r['result']['canTerminate'] is False
        assert stop['renderer']['process'] == r['result']
        stops.append({'role': stop['role'], 'principal': r['principalId'], 'phase': r['phase'],
            'state': r['state'], 'originalCaptureRetained': True, 'distinctStopAndSettle': True,
            'nativeSettlementConfirmed': True, 'rendererResultBound': True})
    assert proof['peer']['metadata'] == {'events': 0, 'claudeVersions': 0, 'codexVersions': 0, 'refused': 0}
    assert proof['originalRuntime']['generation'] == '1'
    assert proof['originalRuntime']['inputs'][0]['terminal'] == 'succeeded'
    capture = proof['packaged']['capture']
    assert capture['appAsarSha256'] == proof['packaged']['artifact']['archive']['sha256'] == wrapper['appAsarSha256']
    assert len(proof['screenshots']) == 4
    screenshots = []
    for screenshot in proof['screenshots']:
        name, data = v.named(entries, PureWindowsPath(screenshot['path']).name)
        assert len(data) == screenshot['bytes'] and v.digest(data) == screenshot['sha256']
        assert data.startswith(b'\x89PNG\r\n\x1a\n')
        screenshots.append({'entry': name, 'bytes': len(data), 'sha256': v.digest(data), 'phase': screenshot['phase']})
    assert v.named(entries, PureWindowsPath(proof['appLog']).name)[1]
    log = v.named(entries, 'windows-same-main-process-ui.controller.log')[1]
    assert 0 < len(log) <= 65536
    rows = [json.loads(line) for line in log.decode('utf-8-sig').splitlines() if line.startswith('{')]
    phases = [r for r in rows if r.get('kind') == 'TEST_WINDOWS_PACKAGED_UI_PHASE']
    assert [{k: r[k] for k in ('phase', 'atMs', 'budgetMs')} for r in phases] == proof['phases']
    final_summary = [r for r in rows if r.get('kind') == proof['kind']]
    assert len(final_summary) == 1
    summary = final_summary[0]
    for k in ('status', 'cleanup', 'sourceHead', 'platform', 'counts', 'modelRequests', 'modelProbes',
              'realVendorExecutions', 'actualHostSuccessors'):
        assert summary[k] == proof[k]
    assert rows.index(summary) < next(i for i, r in enumerate(rows) if r.get('gateController') == 'drained')
    return {'sameMainIdentity': True, 'exactlyOneHostSuccessor': True, 'originalPublicProcessRefsRetained': True,
        'originalUIStops': stops, 'productQuitAndAppExit': {'command': 'Browser.close', 'code': 0, 'signal': None},
        'finalCensus': {'ownedRemaining': [], 'listenerPids': [], 'drained': True},
        'finalSummaryBeforeControllerDrain': True, 'metadataSentinelVersionExecutions': 0,
        'screenshots': screenshots, 'phases': proof['phases'], 'elapsedMs': proof['elapsedMs']}


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=v.REPO, text=True).strip() == v.HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=no'], cwd=v.REPO)
metadata_path = BASE / 'ci-audit-run-44912818208-terminal.json'
listing_path = BASE / 'ci-audit-run-44912818208-artifacts.json'
assert v.digest(metadata_path.read_bytes()) == '0622b4417eb36c33357bec962c0487e1393413646f77538e602074181dd9214c'
assert v.digest(listing_path.read_bytes()) == '6a27bfd4c0ec3a9656d131ddb9bb5780cf39168e576c9f9d1487e422e87bb429'
metadata, listing = v.read_json(metadata_path.read_bytes()), v.read_json(listing_path.read_bytes())
run = metadata['metadata']
assert run['id'] == v.RUN and run['run_attempt'] == 1 and run['head_sha'] == v.HEAD
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['path'] == '.github/workflows/electron-packaged-ci.yml'
assert metadata['jobs']['total_count'] == 7 and listing['total_count'] == 5
assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in metadata['jobs']['jobs'])
inventory, source_rows, dist_rows, inputs_by_platform, results = [], None, None, {}, []
for platform, aid, jid in [('win32-x64', 14712592783, 136875985769), ('win32-arm64', 14713518332, 136875985815)]:
    artifact = next(a for a in listing['artifacts'] if a['id'] == aid)
    job = next(j for j in metadata['jobs']['jobs'] if j['id'] == jid)
    assert artifact['name'] == f'packaged-v2-host-{platform}-{v.HEAD}' and artifact['expired'] is False
    assert artifact['workflow_run']['id'] == v.RUN and artifact['workflow_run']['head_sha'] == v.HEAD
    assert job['run_id'] == v.RUN and job['run_attempt'] == 1 and job['head_sha'] == v.HEAD
    assert job['name'] == f'packaged smoke ({platform})'
    assert job['started_at'] <= artifact['created_at'] <= job['completed_at']
    selected_steps = ['Qualify actual packaged V2 Host tools, MCP, Stop and cold Resume',
        'Qualify packaged Windows same-Main Retry and original Processes UI Kill with finite peers',
        'Preserve exact packaged Host evidence']
    assert all(next(s for s in job['steps'] if s['name'] == name)['conclusion'] == 'success' for name in selected_steps)
    archive_path = OUT / f'packaged-windows-{aid}.zip'
    entries = v.read_archive(archive_path, artifact)
    assert len(entries) == 11
    inventory.extend({'artifactId': aid, 'path': name, 'bytes': len(data), 'sha256': v.digest(data)} for name, data in entries.items())
    common, wrapper, native, candidate = v.common(entries, platform)
    proof, ui = v.windows(entries, platform, candidate)
    ui.update(detailed_windows(entries, proof, wrapper))
    pins = proof['selectedSourceHashes']
    assert pins == proof['selectedSourceHashesAfterFlow'] and len(pins) == len({p['path'] for p in pins}) == 2010
    readback = []
    for pin in pins:
        safe_relative(pin['path'])
        readback.append({**pin, 'matchForm': v.local_pin(v.REPO / pin['path'], pin['sha256'])})
    if source_rows is None:
        source_rows, dist_rows = readback, common['hostJsPins']
    else:
        assert source_rows == readback and dist_rows == common['hostJsPins']
    inputs_by_platform[platform] = input_pins(proof, candidate)
    assert len(entries) == len([name for name in entries if name.endswith(('.json', '.log', '.png'))])
    results.append({'platform': platform, 'artifactId': aid, 'jobId': jid,
        'artifact': ref(archive_path), 'publishedBytes': artifact['size_in_bytes'], 'publishedDigest': artifact['digest'],
        'jobStatus': job['status'], 'jobConclusion': job['conclusion'],
        'jobStartedAt': job['started_at'], 'jobCompletedAt': job['completed_at'], 'artifactCreatedAt': artifact['created_at'],
        'selectedOriginalSteps': selected_steps, 'zip': {'entries': len(entries), 'uncompressedBytes': sum(map(len, entries.values())),
            'sizeAndSha256': 'MATCH', 'CRC': 'PASS', 'safePaths': True, 'extractedOrExecuted': False},
        'sourcePins': {'beforeAfterEqual': True, 'count': len(readback), 'localMatchForms': dict(Counter(p['matchForm'] for p in readback))},
        'host': {'sourceDigest': candidate['hostSourceDigest'], 'sourceDigestForm': common['sourceDigestForm'],
            'distDigest': native['digests']['hostDist'], 'distDigestForm': common['distDigestForm'], 'localJsPins': len(common['hostJsPins'])},
        'candidate': {'manifestSha256': wrapper['candidateManifestSha256'], 'packages': common['packageCount'],
            'manifestFileEntries': common['packageFileCount'], 'wholeClosurePayloadLocallyRehashed': False,
            'providerArchiveBytes': 'MATCH', 'providerArchives': common['providerArchivePins'],
            'nodeVersion': candidate['node']['version'], 'bunVersion': candidate['bun']['version'],
            'engineVersion': candidate['engine']['version'], 'runtimeAndHostInputLocks': 'MATCH'},
        'originalNative': {'status': native['status'], 'cleanup': native['cleanup'], 'hosts': native['hosts'],
            'modelOrigin': native['modelOrigin'], 'modelRequests': native['modelRequests'], 'modelFailures': native['modelFailures'],
            'steps': native['steps'], 'phaseElapsedMs': native['phaseElapsedMs'], 'sourceCheckoutUnavailable': True,
            'legacyRuntimeUnavailable': True, 'wrapperCleanupObservation': wrapper['cleanupObservation'],
            'sourceBundleAndLegacyRuntimeRestored': True, 'coordination': native['coordination'],
            'desktopQualified': False, 'vendorAuthQualified': False, 'releaseQualified': False},
        'windowsSameMain': ui, 'inputPinCounts': dict(Counter(p['qualification'] for p in inputs_by_platform[platform]))})

inventory_ref = save('archive-entry-hashes.json', inventory)
source_ref = save('source-pin-readback.json', {'sourceHead': v.HEAD, 'sourcePins': source_rows, 'hostCompiledJsPins': dist_rows})
inputs_ref = save('original-input-pin-readback.json', inputs_by_platform)
source_references = ['.github/workflows/electron-packaged-ci.yml', 'runtime.lock.json', 'legacy-host.lock.json',
    'packages/legacy-agent-host/package.json', 'tools/owned-process-broker/nativeWindowsAppGate.mjs',
    'tools/owned-process-broker/nativeWindowsAppFixture.ts', 'tools/owned-process-broker/gateController.cpp']
qualification = {'schemaVersion': 1, 'kind': 'TEST_ORIGINAL_WINDOWS_PACKAGED_ARTIFACT_READBACK',
    'status': 'PASS_DECLARED_TEST_SCOPE', 'createdAt': datetime.now(timezone.utc).isoformat(),
    'sourceHead': v.HEAD, 'runId': v.RUN, 'runAttempt': 1, 'metadata': ref(metadata_path), 'artifactListing': ref(listing_path),
    'readbackActions': {'connectorDownloads': 2, 'signedReferenceTransfers': 2, 'newStatusReads': 0,
        'newListingReads': 0, 'newJobLogReads': 0, 'productOrNativeOrProviderExecutions': 0, 'sourceEdits': 0},
    'localFrozenHeadMatched': True, 'localTrackedFilesClean': True,
    'verifier': [ref(HELPER), ref(Path(__file__))], 'sourceReferences': [ref(v.REPO / p) for p in source_references],
    'archiveInventory': inventory_ref, 'sourcePinReadback': source_ref, 'originalInputPinReadback': inputs_ref,
    'artifacts': results,
    'temporalCleanupEvidence': [
        {'source': 'tools/owned-process-broker/nativeWindowsAppFixture.ts', 'lines': '477-489',
         'fact': 'afterQuit returns completed cleanup only after the original provider wait and all three original query witness exit waits; writer absence and original pins checked.'},
        {'source': 'tools/owned-process-broker/nativeWindowsAppGate.mjs', 'lines': '357-392,627-630,684-715',
         'fact': 'Actual product Quit and original Main exit precede final empty owned census/listeners; final JSON PASS follows native cleanup, closed observer and unchanged inputs/source.'},
        {'source': 'tools/owned-process-broker/gateController.cpp', 'lines': '63-108',
         'fact': 'drained is emitted after original root signaled exit, zero job membership and sandbox cleanup, with emergency=false; retained controller row follows UI final summary.'}],
    'limits': [
        'Qualification covers the two original attempt-1 Windows packaged TEST scopes at 4ec8 only; it does not transfer success to later source.',
        'ZIPs contain five JSON receipts/manifests, two logs and four PNGs each. App, app.asar, Node, Bun, engine, native broker/controller/query fixtures, bundled harness and complete package payload bytes are absent; their hashes are original-runner records/cross-bindings, not local rehashes.',
        'All 2010 selected source pins match frozen source after Windows CRLF normalization and are equal before/after flow. All 631 compiled Host JS hashes match frozen local build bytes. Provider archive bytes are locally available and match.',
        'The 120-package/8175-file candidate closure is checked structurally and cross-bound to native receipt, not remeasured as an absent whole payload.',
        'Each Windows UI input receipt has 17 pins: two locally rehashed source/compiled-JS inputs, two cross-bound runner-only hashes and thirteen additional runner-only inputs; final unchanged-input assertion is from the original runner.',
        'The native OpenCode scenario used the actual packaged engine against localhost scripted model responses (11 requests); its coordination, vendor authentication, desktop journey and release flags remain unqualified. The separate same-Main UI scenario used finite TEST codex peers, with zero model requests, probes, metadata version calls and genuine vendor executions.',
        'Final physical witness completion is not projected backward onto earlier cleanup phases. Native stop signalAccepted remains unknown; completed settlement and observed absence are retained separately.',
        'Other platform-specific or whole-workspace gates, macOS relaunch and production vendor behavior are outside this two-artifact readback. No new CI metadata/status/listing/log queries or runtime tests were performed.'
    ]}
result_ref = save('qualification.json', qualification)
print(json.dumps({'qualification': result_ref, 'platforms': [r['platform'] for r in results],
    'sourcePinsEach': len(source_rows), 'hostJsPinsEach': len(dist_rows), 'status': qualification['status']}))
