"""Read-only original Windows packaged artifact qualification; never imports product code."""
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import stat
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/82699181f7b2')
REPO = ROOT / 'agent-teams-ai'
OUT = ROOT / 'ci-4ec8/packaged-windows'
HEAD = '4ec8e74b9a6430143287baa5298a11ade98a5794'
RUN = 44912818208
HEX = re.compile(r'[a-f0-9]{64}\Z')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(data):
    return json.loads(data.decode('utf-8-sig'))


def read_archive(path, artifact):
    raw = path.read_bytes()
    expected = artifact['digest'].removeprefix('sha256:')
    assert len(raw) == artifact['size_in_bytes'] and digest(raw) == expected
    entries = {}
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        assert len(infos) <= 1000 and sum(x.file_size for x in infos) <= 256 * 1024 * 1024
        assert archive.testzip() is None
        names = set()
        for info in infos:
            name = info.filename
            parts = PurePosixPath(name).parts
            assert name and '\x00' not in name and '\\' not in name
            assert not PurePosixPath(name).is_absolute() and not PureWindowsPath(name).drive
            assert all(part not in ('.', '..') for part in parts)
            assert name.casefold() not in names
            names.add(name.casefold())
            mode = stat.S_IFMT(info.external_attr >> 16)
            assert mode in (0, stat.S_IFREG, stat.S_IFDIR) and not (info.flag_bits & 1)
            if not info.is_dir():
                entries[name] = archive.read(info)
    return entries


def named(entries, basename):
    matches = [(name, data) for name, data in entries.items() if PurePosixPath(name).name == basename]
    assert len(matches) == 1, (basename, [name for name, _ in matches])
    return matches[0]


def tree_digests(root, suffix):
    paths = sorted((p for p in root.rglob('*') if p.is_file() and p.name.endswith(suffix)),
                   key=lambda p: p.relative_to(root).as_posix())
    variants = {}
    for ending in ('local-bytes', 'CRLF-checkout'):
        value = hashlib.sha256()
        for path in paths:
            data = path.read_bytes()
            if ending == 'CRLF-checkout':
                data = data.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
            value.update(path.relative_to(root).as_posix().encode() + b'\0' + data + b'\0')
        variants[value.hexdigest()] = ending
    return variants, len(paths)


def local_pin(path, expected):
    assert HEX.fullmatch(expected)
    data = path.read_bytes()
    if digest(data) == expected:
        return 'byte-identical'
    if path.suffix.lower() in {'.ts', '.tsx', '.mts', '.js', '.mjs', '.cjs', '.json', '.yaml', '.yml',
                             '.md', '.cpp', '.c', '.h', '.hpp', '.txt', '.ps1'}:
        if digest(data.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')) == expected:
            return 'CRLF-checkout'
    raise AssertionError(('pin mismatch', str(path), expected, digest(data)))


def common(entries, platform):
    names = ['opencode-v2-packaged-inputs.json', 'opencode-v2-packaged.json',
             'opencode-v2-packaged-native.json', 'opencode-v2-candidate.json']
    located = [named(entries, name) for name in names]
    inputs, wrapper, native, candidate = [read_json(data) for _, data in located]
    for receipt in (inputs, wrapper, native, candidate):
        assert receipt['sourceHead'] == HEAD and receipt['platform'] == platform
    assert inputs['kind'] == 'TEST_NATIVE_V2_EMBEDDED_INPUTS'
    assert inputs['status'] == 'READY' and inputs['stage'] == 'prepared' and inputs['productQualified'] is False
    runtime = read_json((REPO / 'runtime.lock.json').read_bytes())
    delivery = runtime['opencodeV2Delivery'][platform]
    node = read_json((REPO / 'legacy-host.lock.json').read_bytes())
    assert inputs['baseArchiveSha256'] == runtime['assets'][platform]['sha256']
    assert inputs['runtimeSource'] == delivery['sourceCommit']
    assert inputs['supportArchiveSha256'] == delivery['archive']['sha256']
    assert inputs['manifestSha256'] == delivery['manifest']['sha256'] == candidate['engine']['manifestSha256'] == native['digests']['manifest']
    assert inputs['bun']['version'] == candidate['bun']['version'] == delivery['requiredBunVersion']
    assert inputs['bun']['sha256'] == candidate['bun']['sha256'] == native['digests']['bun']
    assert inputs['nodeVersion'] == native['nodeVersion'] == 'v' + node['nodeVersion']
    assert candidate['kind'] == 'TEST_PACKAGED_OPENCODE_V2_INPUTS' and candidate['schemaVersion'] == 1
    assert candidate['engine']['version'] == native['version'] == '2.1.4'
    assert candidate['node']['version'] == node['nodeVersion'] == '24.21.0'
    assert candidate['node']['platform'] == platform and candidate['node']['schemaVersion'] == 1
    assert candidate['node']['archiveSha256'] == node['platforms'][platform]['sha256'] == native['packaged']['nodeArchiveSha256']
    assert candidate['nodeExecutable'] == f'node/v24.21.0/{platform}/node.exe'
    assert wrapper['kind'] == 'TEST_PACKAGED_V2_QUALIFICATION'
    assert wrapper['status'] == 'PASS' and wrapper['cleanup'] is True and wrapper['phase'] == 'finished'
    assert wrapper['candidateManifestSha256'] == digest(located[3][1]) == native['packaged']['candidateManifestSha256']
    assert wrapper['nativeReceiptSha256'] == digest(located[2][1])
    assert wrapper['nativeExit'] == {'code':0, 'signal':None}
    assert wrapper['cleanupObservation'] == {'originalExitObserved':True, 'nativeReceiptParsed':True,
        'nativeReceiptBound':True, 'nativeCleanupConfirmed':True, 'firstFailure':None, 'firstRestorationFailure':None}
    assert wrapper['appAsarSha256'] == native['packaged']['appAsarSha256']
    assert wrapper['hostEntrySha256'] == candidate['hostEntrySha256'] == native['packaged']['hostEntrySha256']
    assert wrapper['nodeSha256'] == candidate['node']['binarySha256'] == native['digests']['node']
    assert candidate['harnessSha256'] == native['packaged']['harnessSha256']
    for key in ('sourceCheckoutUnavailable', 'legacyRuntimeUnavailable'):
        assert wrapper[key] is True and native['packaged'][key] is True
    for key in ('sourceRestored', 'bundleRestored', 'legacyRuntimeRestored'):
        assert wrapper[key] is True
    for key in ('desktopJourneyQualified', 'vendorAuthQualified', 'releaseQualified'):
        assert wrapper[key] is False
    assert native['kind'] == 'TEST_PACKAGED_NATIVE_V2_HOST'
    assert native['status'] == 'PASS' and native['cleanup'] is True and native['cancelled'] is False
    assert native['failureCode'] is None and native['modelFailures'] == []
    assert native['approvalMode'] == 'manual' and native['modelOrigin'] == 'localhost-scripted'
    assert native['modelRequests'] == 11
    assert native['modelSelection'] == {'providerId':'TEST-local', 'modelId':'TEST-model-B', 'variant':'high'}
    assert native['configurationSelection'] == {'scope':'project', 'original':'project-A', 'later':'project-B'}
    assert native['preferencesSelection'] == {'nativeDefault':'TEST-local/TEST-model', 'appDefault':'TEST-local/TEST-model-B'}
    expected_steps = ['original_host_embedded_native_and_mcp_ready',
        'native_model_tool_effect_permission_mcp_task_and_reply_completed_once',
        'changed_project_config_did_not_retarget_running_native_session',
        'original_uploaded_PNG_native_image_inference_and_public_readback',
        'all_image_MIMEs_exact_PDF_and_4MiB_PNG_native_normalization_and_public_readback',
        'checkpoint_and_original_host_native_cleanup_confirmed',
        'cold_host_restored_native_history_without_model_or_tool_replay']
    assert native['steps'] == list(native['phaseElapsedMs']) == expected_steps
    timings = list(native['phaseElapsedMs'].values())
    assert timings == sorted(timings) and timings[-1] <= native['elapsedMs']
    assert native['hosts'] == [{'exitCode': 0, 'signalCode': None, 'stdoutValid': True}] * 2
    assert native['coordination'] == {'status': 'unqualified', 'cleanup': None}
    for key in ('vendorAuthQualified', 'desktopQualified', 'releaseQualified'):
        assert native[key] is False
    assert native['packaged']['executionOrigin'] == 'packaged-extraResources'
    assert len(candidate['packages']) == native['packaged']['packages']
    assert sum(len(p['files']) for p in candidate['packages']) == native['packaged']['files']
    assert len({p['path'] for p in candidate['packages']}) == len(candidate['packages'])
    for package in candidate['packages']:
        assert re.fullmatch(r'packages/\d{4}', package['path'])
        assert len({f['path'] for f in package['files']}) == len(package['files'])
        for file in package['files']:
            assert HEX.fullmatch(file['sha256']) and type(file['executable']) is bool
            assert all(part not in ('', '.', '..', 'node_modules') for part in file['path'].split('/'))
    source_variants, source_count = tree_digests(REPO / 'packages/legacy-agent-host/src', '.ts')
    dist_variants, dist_count = tree_digests(REPO / 'packages/legacy-agent-host/dist', '.js')
    assert candidate['hostSourceDigest'] == native['digests']['hostSource']
    assert candidate['hostSourceDigest'] in source_variants and native['digests']['hostDist'] in dist_variants
    host = next(p for p in candidate['packages'] if p['name'] == '@agent-teams/legacy-agent-host')
    assert candidate['hostPackage'] == 'host/' + host['path']
    assert candidate['hostEntry'] == candidate['hostPackage'] + '/dist/cli.js'
    js = [f for f in host['files'] if f['path'].startswith('dist/') and f['path'].endswith('.js')]
    assert len(js) == source_count == dist_count == 631
    js_pins = [{'path':f['path'], 'sha256':f['sha256'], 'matchForm':local_pin(REPO / 'packages/legacy-agent-host' / f['path'], f['sha256'])} for f in js]
    local_pin(REPO / 'packages/legacy-agent-host/dist/cli.js', candidate['hostEntrySha256'])
    package = read_json((REPO / 'packages/legacy-agent-host/package.json').read_bytes())
    assert candidate['artifacts'] == native['packaged']['providerArtifacts']
    for artifact in candidate['artifacts']:
        reference = package['dependencies'][artifact['name']]
        assert reference.startswith('file:') and reference.endswith('.tgz')
        assert digest((REPO / 'packages/legacy-agent-host' / reference[5:]).resolve().read_bytes()) == artifact['sha256']
    assert native['digests']['provider'] == next(a['sha256'] for a in candidate['artifacts'] if a['name'] == '@agent-teams/provider-implementations')
    return {'sourceDigestForm': source_variants[candidate['hostSourceDigest']],
            'distDigestForm': dist_variants[native['digests']['hostDist']], 'hostJsPins': js_pins,
            'packageCount': len(candidate['packages']), 'packageFileCount': native['packaged']['files'],
            'providerArchivePins': candidate['artifacts'], 'modelRequests': native['modelRequests'],
            'steps': native['steps'], 'phaseElapsedMs': native['phaseElapsedMs'],
            'wrapperCleanupObservation': wrapper['cleanupObservation']}, wrapper, native, candidate


def windows(entries, platform, candidate):
    name, data = named(entries, 'windows-same-main-process-ui.json')
    proof = read_json(data)
    assert proof['kind'] == 'TEST_WINDOWS_PACKAGED_SAME_MAIN_PROCESS_UI'
    assert proof['status'] == 'PASS' and proof['cleanup'] is True
    assert proof['sourceHead'] == HEAD and proof['platform'] == platform
    assert proof['counts'] == {'mainStarts':1, 'initialRuntimeOpen':1, 'businessInput':1,
                               'refreshClicks':1, 'retryClicks':1, 'uiStops':2, 'quit':1}
    assert proof['actualHostSuccessors'] == proof['originalRuntimeGenerations'] == 1
    assert proof['modelRequests'] == proof['modelProbes'] == proof['realVendorExecutions'] == 0
    assert proof['peer']['provider'] == 'codex'
    assert proof['peer']['connected'] == proof['peer']['registrations'] == 1
    assert proof['peer']['serviceExitObservations'] == 2 and proof['peer']['failures'] == 0
    assert proof['nativeCleanup'] == {'phase':'completed', 'cleanup':True, 'originalQueryWitnesses':3,
                                     'runtimeGenerations':1, 'runtimeInputs':1, 'modelRequests':0, 'probes':0,
                                     'realVendorExecutions':0, 'originalUiStops':2, 'serviceExitObservations':2}
    assert proof['packagedAndNativeInputsUnchanged'] is True and proof['censusObserver']['closed'] is True
    for key in ('sourceFreezeFailure', 'peerEvidenceFailure', 'inputFreezeFailure', 'hostBirthFailure',
                'appLogFailure', 'fixtureCloseFailure', 'censusObserverFailure', 'qualificationFailure'):
        assert key not in proof
    for key in ('pid', 'birth'):
        assert proof['originalMain'][key] == proof['sameMainAfterRetry'][key]
    assert proof['packaged']['nodeSha256'] == candidate['node']['binarySha256']
    assert proof['packaged']['hostEntrySha256'] == candidate['hostEntrySha256']
    assert proof['packaged']['capture']['manifestSha256'] == digest(named(entries, 'opencode-v2-candidate.json')[1])
    _, controller = named(entries, 'windows-same-main-process-ui.controller.log')
    controller_rows = []
    for line in controller.decode('utf-8-sig').splitlines():
        if line.startswith('{'):
            row = json.loads(line)
            if 'gateController' in row:
                controller_rows.append(row)
    assert controller_rows == [{'gateController':'drained', 'rootExitCode':0, 'activeProcesses':0}]
    return proof, {'receipt':name, 'sha256':digest(data), 'counts':proof['counts'],
                   'nativeCleanup':proof['nativeCleanup'], 'finalController':controller_rows[0]}


if __name__ == '__main__':
    raise SystemExit('Prepared only: final original family metadata must be supplied before qualification.')
