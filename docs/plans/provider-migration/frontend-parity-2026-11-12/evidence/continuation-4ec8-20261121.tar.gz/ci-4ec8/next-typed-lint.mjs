import { writeFile, readFile } from 'node:fs/promises';
import { ESLint } from '../agent-teams-ai-e2e-next/node_modules/eslint/lib/api.js';

const cwd = '/workspace/scratch/82699181f7b2/agent-teams-ai-e2e-next';
const project = '/workspace/scratch/82699181f7b2/ci-4ec8/next-main-typed-lint-tsconfig.json';
const configuration = JSON.parse(await readFile(project, 'utf8'));
const selected = process.argv.slice(2);
const files = configuration.files.filter(file => !file.endsWith('.d.ts') &&
  (!selected.length || selected.includes(file.slice(cwd.length + 1))));
const eslint = new ESLint({ cwd, cache: false, fix: false, overrideConfig: [{
  files: ['**/*.ts'],
  languageOptions: { parserOptions: { projectService: false, project } },
}] });
const results = await eslint.lintFiles(files);
await writeFile(process.env.E2E_TYPED_LINT_RECEIPT ?? '/workspace/scratch/82699181f7b2/ci-4ec8/next-main-typed-lint.json', JSON.stringify({
  method: 'Original repository rules; explicit scoped TS project; no cache and no fixes',
  limitation: 'This is not whole-workspace typed lint',
  results: results.map(({ filePath, errorCount, warningCount, fatalErrorCount, messages }) =>
    ({ filePath, errorCount, warningCount, fatalErrorCount, messages })),
}, null, 2) + '\n');
console.log(await (await eslint.loadFormatter('stylish')).format(results));
console.log(JSON.stringify({ files: files.length, errors: results.reduce((n, row) => n + row.errorCount, 0),
  warnings: results.reduce((n, row) => n + row.warningCount, 0) }));
if (results.some(row => row.errorCount)) process.exitCode = 1;
