"""Read only original Teams CI outputs; never run product or provider code."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import struct
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/82699181f7b2/agent-teams-ai')
HEAD = '4ec8e74b9a6430143287baa5298a11ade98a5794'
BASE = '8d46f13fe87b4a25156b6be8331119eb8d0f790e'
RUN = 44912818150
PLATFORMS = [
    ('macos', 136872027951, 14711610619),
    ('windows', 136872027752, 14710798607),
    ('linux', 136872028019, 14710348816),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

run_path = ROOT.parent / f'ci-audit-run-{RUN}-terminal.json'
artifact_path = ROOT.parent / f'ci-audit-run-{RUN}-artifacts.json'
snapshot = json.loads(run_path.read_text())
metadata = snapshot['metadata']
jobs = {job['id']: job for job in snapshot['jobs']['jobs']}
artifacts = {row['id']: row for row in json.loads(artifact_path.read_text())['artifacts']}
download = json.loads((ROOT / 'download-verification.json').read_text())
downloads = {row['artifact_id']: row for row in download['artifacts']}
assert metadata['id'] == RUN and metadata['run_attempt'] == 1
assert metadata['head_sha'] == HEAD and metadata['conclusion'] == 'success'
assert metadata['pull_requests'][0]['head']['sha'] == HEAD
assert metadata['pull_requests'][0]['base']['sha'] == BASE
assert snapshot['jobs']['total_count'] == len(jobs) == len(PLATFORMS) == 3
assert len(artifacts) == len(downloads) == 3
tree = subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=REPO, text=True).strip()
assert tree == metadata['head_commit']['tree_id']

rows = []
reference_keys = None
reference_screenshots = None
for platform, job_id, artifact_id in PLATFORMS:
    job = jobs[job_id]
    artifact = artifacts[artifact_id]
    saved = downloads[artifact_id]
    assert job['run_attempt'] == 1 and job['run_id'] == RUN and job['head_sha'] == HEAD
    assert job['status'] == 'completed' and job['conclusion'] == 'success'
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    assert not artifact['expired']
    archive = ROOT / saved['zip']
    assert archive.stat().st_size == artifact['size_in_bytes'] == saved['bytes']
    assert 'sha256:' + digest(archive) == artifact['digest']
    result_path = ROOT / platform / 'teams-create-page-result.json'
    result = json.loads(result_path.read_text())
    keys = sorted(result)
    if reference_keys is None:
        reference_keys = keys
    assert keys == reference_keys
    booleans = {key: value for key, value in result.items() if isinstance(value, bool)}
    assert booleans and all(booleans.values())
    assert result['scheduleUiEvidence']['createdAndDeleted'] is True
    assert result['zhTwMcpUiEvidence']['locale'] == 'zh-TW'
    assert result['zhTwMcpUiEvidence']['strictAllowlistVisible'] is True
    assert result['zhTwMcpUiEvidence']['parsedServerNames'] == ['github', 'sentry']
    assert result['zhTwMcpUiEvidence']['controlEditedThroughNativeCdp'] is True
    assert result['zhTwMcpUiEvidence']['taskDetailUiEvidence']['nativeTaskTabVisible'] is True
    cleanup = result['cleanup']
    assert cleanup['temporaryProfileRemoved'] is True
    if platform == 'windows':
        assert cleanup['processGroupAbsent'] is None
        assert cleanup['windowsTaskkillExitedZero'] is True
        assert cleanup['windowsExactOwnedProcessesAbsent'] is True
        assert len(cleanup['windowsTeardowns']) == 3
        for teardown in cleanup['windowsTeardowns']:
            assert teardown['taskkillAttempted'] is True and teardown['taskkillExitCode'] == 0
            assert teardown['observedIdentityCount'] > 0
            assert teardown['exactOwnedProcessesAbsent'] is True and teardown['cdpPortAbsent'] is True
    else:
        assert cleanup['processGroupAbsent'] is True
        assert cleanup['windowsTeardowns'] is None
    log_path = ROOT / f'job-{job_id}-{platform}.log'
    log = log_path.read_text()
    lines = log.splitlines()
    plain = re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ', '', log, flags=re.MULTILINE)
    plain = re.sub(r'\x1b\[[0-9;]*m', '', plain)
    matching_receipts = []
    for match in re.finditer(r'\{\n\s*"success": true,', plain):
        candidate, _ = json.JSONDecoder().raw_decode(plain[match.start():])
        if candidate.get('unique') == result['unique']:
            matching_receipts.append(candidate)
    assert matching_receipts == [result], 'Artifact receipt differs from original job stdout'
    checkout_lines = [i + 1 for i, line in enumerate(lines) if line.rstrip().endswith('Z ' + HEAD)]
    assert checkout_lines
    assert 'node ./node_modules/@typescript/native/bin/tsc --noEmit' in plain
    assert '+ @typescript/native <- typescript 7.0.2' in plain
    assert '\u2139 tests 29' in plain and '\u2139 pass 29' in plain and '\u2139 fail 0' in plain
    screenshot_rows = []
    for image in sorted((ROOT / platform).glob('*.png')):
        image_bytes = image.read_bytes()
        assert image_bytes[:8] == b'\x89PNG\r\n\x1a\n' and image_bytes[12:16] == b'IHDR'
        width, height = struct.unpack('>II', image_bytes[16:24])
        assert width > 0 and height > 0
        screenshot_rows.append({'path': image.name, 'bytes': len(image_bytes), 'width': width,
                                'height': height, 'sha256': digest(image)})
    screenshot_names = [row['path'] for row in screenshot_rows]
    assert len(screenshot_names) == 40
    if reference_screenshots is None:
        reference_screenshots = screenshot_names
    assert screenshot_names == reference_screenshots
    assert not any('failure' in name for name in screenshot_names)
    for name in [result['zhTwMcpUiEvidence']['screenshot'],
                 result['zhTwMcpUiEvidence']['taskDetailUiEvidence']['dialogScreenshot'],
                 result['zhTwMcpUiEvidence']['taskDetailUiEvidence']['tabScreenshot']]:
        assert name in screenshot_names
    rows.append({
        'platformLabel': platform, 'jobId': job_id, 'jobName': job['name'],
        'jobStartedAt': job['started_at'], 'jobCompletedAt': job['completed_at'],
        'artifactId': artifact_id, 'artifactName': artifact['name'],
        'zip': saved['zip'], 'zipBytes': saved['bytes'], 'zipSha256': digest(archive),
        'zipMatchesOfficialMetadata': True, 'receipt': str(result_path.relative_to(ROOT)),
        'receiptSha256': digest(result_path), 'receiptEqualsOriginalJobStdout': True,
        'receiptSuccess': result['success'], 'topLevelBooleanCount': len(booleans),
        'allTopLevelBooleansTrue': True, 'scheduleCreatedAndDeleted': True,
        'zhTwNativeTaskTabAndMcpAllowlist': True, 'cleanup': cleanup,
        'originalFiniteVerifier': {'tests': 29, 'pass': 29, 'fail': 0},
        'originalApplicationTypecheck': 'TypeScript native 7.0.2 --noEmit, successful job step',
        'originalCheckoutShaLineNumbers': checkout_lines,
        'internalReceiptSourceShaPresent': any(key.lower() in ('sourcesha', 'sourcehead', 'sourcecommit') for key in result),
        'internalExecutablePinsPresent': False,
        'screenshots': screenshot_rows,
    })

shutil.copyfile(run_path, ROOT / 'original-run-terminal.json')
shutil.copyfile(artifact_path, ROOT / 'original-artifact-list.json')
summary = {
    'schemaVersion': 1, 'kind': 'READ_ONLY_ORIGINAL_TEAMS_ARTIFACT_QUALIFICATION',
    'runId': RUN, 'attempt': 1, 'sourceHead': HEAD, 'sourceBase': BASE, 'sourceTree': tree,
    'runConclusion': 'success', 'qualifiedPlatforms': 3,
    'scope': 'Original Electron Teams creation/config-only, draft persistence, copy/template/organization, schedules and zh-TW UI qualification',
    'sourceBinding': 'External: official run/job/artifact metadata plus exact checkout SHA in each original job log. Exact-Git producer/workflow helper snapshots are retained under source/. No receipt fields were modified.',
    'sourcePins': 'source/pins.json',
    'producerSemantics': {
        'receiptWrittenOnlyAfterUiAndCleanupSucceed': True,
        'unixCleanup': 'Detached fixture group SIGKILL followed by kill(-pgid, 0) ESRCH; EPERM refuses success',
        'windowsCleanup': 'Original launcher PID/birth guard, bounded retained child identities, OS census of exact PID/birth pairs and CDP absence; taskkill status alone is insufficient',
        'providerExecutionMode': 'Pinned source seeds explicit TEST deny/metadata peers and private managed Codex metadata; genuine provider execution is outside this qualification',
    },
    'platforms': rows,
    'representativeVisualReadback': [
        {'path': 'macos/teams-create-opened.png', 'observation': 'Create Team page rendered with member and project controls'},
        {'path': 'windows/teams-create-zh-tw-task-detail-dialog.png', 'observation': 'Traditional Chinese task dialog and separate-tab action rendered'},
        {'path': 'linux/teams-create-schedules-list-native-electron-zoom-200.png', 'observation': 'Schedule card and actions rendered at original 200 percent zoom'},
    ],
    'limitations': [
        'The original receipt schema contains no source SHA, runtime/executable digests, architecture or independent source-freeze attestation. Source association is external as described.',
        'Auditor-computed source Git blob/SHA256 values are exact source references, not original runtime executable attestations.',
        'Windows receipt retains counts and absence outcomes, not raw PID/birth census rows. Unix cleanup reports process-group absence and is not product Host lifecycle release proof.',
        'These are source-development Electron UI tests with finite TEST peers; no genuine provider, installed/packaged app, vendor-auth or release qualification is claimed.',
        'All 120 PNGs were verified present with valid PNG headers and hashed; only three representative screenshots were visually inspected.',
        'No new product, native, CLI or E2E execution occurred during this readback.',
    ],
    'readbackResult': 'PASS within the original Teams creation-page scope',
}
(ROOT / 'qualification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
manifest = []
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name != 'file-sha256.json':
        manifest.append({'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': digest(path)})
(ROOT / 'file-sha256.json').write_text(json.dumps({'files': manifest}, indent=2) + '\n')
print(json.dumps({'run': RUN, 'readbackResult': summary['readbackResult'], 'platforms': len(rows),
                  'receiptStdoutMatches': 3, 'zipDigestMatches': 3, 'screenshots': sum(len(row['screenshots']) for row in rows),
                  'rootBooleanCountPerReceipt': rows[0]['topLevelBooleanCount'],
                  'qualificationSha256': digest(ROOT / 'qualification.json'),
                  'indexedFiles': len(manifest)}, ensure_ascii=False))
