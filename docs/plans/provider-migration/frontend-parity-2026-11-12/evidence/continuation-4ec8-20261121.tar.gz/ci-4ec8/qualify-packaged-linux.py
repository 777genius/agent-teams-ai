import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path('/workspace/scratch/82699181f7b2')
REPO = ROOT / 'agent-teams-ai'
EVIDENCE = ROOT / 'ci-4ec8'
ARTIFACT = EVIDENCE / 'packaged-linux-14714501581'
HEAD = '4ec8e74b9a6430143287baa5298a11ade98a5794'
PLATFORM = 'linux-x64'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(name):
    paths = list(ARTIFACT.rglob(name))
    assert len(paths) == 1, (name, paths)
    return paths[0], json.loads(paths[0].read_text())

def tree_digest(root, suffix):
    paths = sorted((p for p in root.rglob('*') if p.is_file() and p.name.endswith(suffix)),
                   key=lambda p: p.relative_to(root).as_posix())
    h = hashlib.sha256()
    for p in paths:
        h.update(p.relative_to(root).as_posix().encode())
        h.update(b'\0')
        h.update(p.read_bytes())
        h.update(b'\0')
    return h.hexdigest(), len(paths)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
producer_paths = [
    '.github/workflows/electron-packaged-ci.yml',
    'scripts/legacy-agent-host/run-packaged-opencode-v2.ts',
    'scripts/legacy-agent-host/stage-opencode-v2-packaged.ts',
    'scripts/legacy-agent-host/packaged-opencode-v2-inputs.ts',
    'scripts/legacy-agent-host/stage-node.ts',
    'packages/legacy-agent-host/tests/opencode-v2-embedded-host.native.ts',
    'packages/legacy-agent-host/tests/fixtures/native-host.ts',
    'runtime.lock.json',
    'legacy-host.lock.json',
]
subprocess.run(['git', 'diff', '--exit-code', HEAD, '--', *producer_paths,
                'packages/legacy-agent-host/src'], cwd=REPO, check=True, capture_output=True)
source_pins = {p: sha(REPO / p) for p in producer_paths}

input_path, inputs = load('opencode-v2-packaged-inputs.json')
wrapper_path, wrapper = load('opencode-v2-packaged.json')
native_path, native = load('opencode-v2-packaged-native.json')
candidate_path, candidate = load('opencode-v2-candidate.json')
for receipt in [inputs, wrapper, native, candidate]:
    assert receipt['sourceHead'] == HEAD
    assert receipt['platform'] == PLATFORM

assert inputs['kind'] == 'TEST_NATIVE_V2_EMBEDDED_INPUTS'
assert inputs['status'] == 'READY' and inputs['stage'] == 'prepared'
assert inputs['nodeVersion'] == native['nodeVersion'] == 'v24.21.0'
assert inputs['productQualified'] is False
runtime_lock = json.loads((REPO / 'runtime.lock.json').read_text())
delivery = runtime_lock['opencodeV2Delivery'][PLATFORM]
assert inputs['baseArchiveSha256'] == runtime_lock['assets'][PLATFORM]['sha256']
assert inputs['runtimeSource'] == delivery['sourceCommit']
assert inputs['supportArchiveSha256'] == delivery['archive']['sha256']
assert inputs['manifestSha256'] == delivery['manifest']['sha256'] == candidate['engine']['manifestSha256'] == native['digests']['manifest']
assert inputs['bun']['version'] == candidate['bun']['version'] == delivery['requiredBunVersion'] == '1.3.11'
assert inputs['bun']['sha256'] == candidate['bun']['sha256'] == native['digests']['bun']
assert candidate['engine']['version'] == native['version'] == '2.1.4'
assert candidate['schemaVersion'] == 1 and candidate['kind'] == 'TEST_PACKAGED_OPENCODE_V2_INPUTS'

assert wrapper['kind'] == 'TEST_PACKAGED_V2_QUALIFICATION'
assert wrapper['status'] == 'PASS' and wrapper['cleanup'] is True and wrapper['phase'] == 'finished'
assert wrapper['cleanupObservation'] == {
    'originalExitObserved': True, 'nativeReceiptParsed': True, 'nativeReceiptBound': True,
    'nativeCleanupConfirmed': True, 'firstFailure': None, 'firstRestorationFailure': None,
}
assert wrapper['nativeExit'] == {'code': 0, 'signal': None}
assert wrapper['nativeReceiptSha256'] == sha(native_path)
assert wrapper['candidateManifestSha256'] == sha(candidate_path) == native['packaged']['candidateManifestSha256']
assert wrapper['appAsarSha256'] == native['packaged']['appAsarSha256']
assert wrapper['hostEntrySha256'] == candidate['hostEntrySha256'] == native['packaged']['hostEntrySha256']
assert wrapper['nodeSha256'] == candidate['node']['binarySha256'] == native['digests']['node']
assert native['packaged']['harnessSha256'] == candidate['harnessSha256']
for key in ['sourceCheckoutUnavailable', 'legacyRuntimeUnavailable']:
    assert wrapper[key] is True and native['packaged'][key] is True
for key in ['sourceRestored', 'bundleRestored', 'legacyRuntimeRestored']:
    assert wrapper[key] is True
for key in ['desktopJourneyQualified', 'vendorAuthQualified', 'releaseQualified']:
    assert wrapper[key] is False

assert native['kind'] == 'TEST_PACKAGED_NATIVE_V2_HOST'
assert native['status'] == 'PASS' and native['cleanup'] is True and native['cancelled'] is False
assert native['failureCode'] is None and native['modelFailures'] == []
assert native['approvalMode'] == 'manual' and native['modelOrigin'] == 'localhost-scripted'
assert native['modelRequests'] == 11
assert native['hosts'] == [{'exitCode': 0, 'signalCode': None, 'stdoutValid': True}] * 2
assert native['modelSelection'] == {'providerId': 'TEST-local', 'modelId': 'TEST-model-B', 'variant': 'high'}
assert native['configurationSelection'] == {'scope': 'project', 'original': 'project-A', 'later': 'project-B'}
assert native['preferencesSelection'] == {'nativeDefault': 'TEST-local/TEST-model', 'appDefault': 'TEST-local/TEST-model-B'}
steps = [
    'original_host_embedded_native_and_mcp_ready',
    'native_model_tool_effect_permission_mcp_task_and_reply_completed_once',
    'changed_project_config_did_not_retarget_running_native_session',
    'original_uploaded_PNG_native_image_inference_and_public_readback',
    'all_image_MIMEs_exact_PDF_and_4MiB_PNG_native_normalization_and_public_readback',
    'checkpoint_and_original_host_native_cleanup_confirmed',
    'cold_host_restored_native_history_without_model_or_tool_replay',
]
assert native['steps'] == steps
assert list(native['phaseElapsedMs']) == steps
timings = list(native['phaseElapsedMs'].values())
assert timings == sorted(timings) and timings[-1] <= native['elapsedMs']
assert native['coordination'] == {'status': 'unqualified', 'cleanup': None}
for key in ['vendorAuthQualified', 'desktopQualified', 'releaseQualified']:
    assert native[key] is False
assert native['packaged']['executionOrigin'] == 'packaged-extraResources'
assert len(candidate['packages']) == native['packaged']['packages'] == 120
assert sum(len(p['files']) for p in candidate['packages']) == native['packaged']['files'] == 8175
assert len({p['path'] for p in candidate['packages']}) == 120
for package in candidate['packages']:
    assert re.fullmatch(r'packages/\d{4}', package['path'])
    assert len({f['path'] for f in package['files']}) == len(package['files'])
    for file in package['files']:
        assert re.fullmatch(r'[0-9a-f]{64}', file['sha256'])
        assert type(file['executable']) is bool
        assert all(part not in ['', '.', '..', 'node_modules'] for part in file['path'].split('/'))

node_lock = json.loads((REPO / 'legacy-host.lock.json').read_text())
assert candidate['node']['version'] == node_lock['nodeVersion'] == '24.21.0'
assert candidate['node']['platform'] == PLATFORM and candidate['node']['schemaVersion'] == 1
assert candidate['node']['archiveSha256'] == node_lock['platforms'][PLATFORM]['sha256'] == native['packaged']['nodeArchiveSha256']
assert candidate['nodeExecutable'] == 'node/v24.21.0/linux-x64/node'

host_source, source_count = tree_digest(REPO / 'packages/legacy-agent-host/src', '.ts')
host_dist, dist_count = tree_digest(REPO / 'packages/legacy-agent-host/dist', '.js')
assert source_count == dist_count == 631
assert host_source == candidate['hostSourceDigest'] == native['digests']['hostSource']
assert host_dist == native['digests']['hostDist']
host = next(p for p in candidate['packages'] if p['name'] == '@agent-teams/legacy-agent-host')
assert candidate['hostPackage'] == 'host/' + host['path']
assert candidate['hostEntry'] == candidate['hostPackage'] + '/dist/cli.js'
host_js = [f for f in host['files'] if f['path'].startswith('dist/') and f['path'].endswith('.js')]
assert len(host_js) == 631
for file in host_js:
    assert sha(REPO / 'packages/legacy-agent-host' / file['path']) == file['sha256']
assert sha(REPO / 'packages/legacy-agent-host/dist/cli.js') == candidate['hostEntrySha256']
package_json = json.loads((REPO / 'packages/legacy-agent-host/package.json').read_text())
assert candidate['artifacts'] == native['packaged']['providerArtifacts']
for artifact in candidate['artifacts']:
    reference = package_json['dependencies'][artifact['name']]
    assert reference.startswith('file:') and reference.endswith('.tgz')
    assert sha((REPO / 'packages/legacy-agent-host' / reference[5:]).resolve()) == artifact['sha256']
assert native['digests']['provider'] == next(a['sha256'] for a in candidate['artifacts'] if a['name'] == '@agent-teams/provider-implementations')

snapshot = EVIDENCE / 'ci-audit-poll-20261121161438013.json'
run = next(r for r in json.loads(snapshot.read_text())['receipts'] if r['metadata']['id'] == 44912818208)
assert run['metadata']['head_sha'] == HEAD and run['metadata']['run_attempt'] == 1
job = next(j for j in run['jobs']['jobs'] if j['id'] == 136875985661)
assert job['status'] == 'completed' and job['conclusion'] == 'success'
assert job['head_sha'] == HEAD and job['run_attempt'] == 1
for step in job['steps']:
    if step['name'] == 'Qualify actual packaged V2 Host tools, MCP, Stop and cold Resume':
        assert step['conclusion'] == 'success'
    if step['name'] == 'Qualify original packaged macOS app relaunch with finite SDK peer':
        assert step['conclusion'] == 'skipped'
log_path = EVIDENCE / 'job-136875985661.log'
log = log_path.read_text()
assert f'git checkout --progress --force {HEAD}' in log
printed = [json.loads(line[line.index('{'):]) for line in log.splitlines()
           if '{"kind":"TEST_PACKAGED_V2_QUALIFICATION"' in line]
assert printed == [wrapper]
assert not list(ARTIFACT.rglob('packaged-app-relaunch.json'))

result = {
    'schemaVersion': 1, 'status': 'PASS_DECLARED_TEST_SCOPE', 'sourceHead': HEAD,
    'runId': 44912818208, 'attempt': 1, 'jobId': 136875985661, 'platform': PLATFORM,
    'artifact': {'id': 14714501581, 'zip': 'packaged-linux-14714501581.zip',
        'bytes': 349584, 'sha256': sha(EVIDENCE / 'packaged-linux-14714501581.zip'),
        'sizeHashCrcSafePaths': 'PASS', 'finalFamilyListingBinding': 'pending-family-terminal'},
    'files': {str(p.relative_to(ARTIFACT)): sha(p) for p in sorted(ARTIFACT.rglob('*')) if p.is_file()},
    'pins': {'hostSource': host_source, 'sourceFiles': source_count, 'hostDist': host_dist,
        'distJsFiles': dist_count, 'candidateHostDistJsCompared': len(host_js),
        'producerSource': source_pins},
    'results': {'wrapperReceiptMatchesOriginalJobStdout': True, 'candidateDigest': 'MATCH',
        'nativeReceiptDigest': 'MATCH', 'runtimeAndNodeLocks': 'MATCH',
        'providerArchiveBytes': 'MATCH', 'originalHostToolsMcpStopColdResume': 'PASS',
        'orderedSteps': steps, 'cleanHosts': 2, 'modelRequests': 11,
        'nativeCleanupConfirmed': True, 'inputRestoration': 'PASS',
        'macosAppRelaunch': 'NOT_SELECTED_LINUX'},
    'limitations': [
        'ZIP contains JSON only. Native executables, app.asar, complete packaged dependency closure and bundled harness bytes are original-runner pins, not locally remeasured bytes.',
        '631 Host compiled JavaScript entries match the exact frozen local build; all 8175 package file hashes are structurally checked but external package payloads are absent.',
        'Source checkout and intact legacy runtime isolation, complete package census and physical native cleanup are original verifier observations bound to this job; no product/native scenario was reexecuted.',
        'Coordination remains unqualified. Desktop journey, vendor authentication and release qualification flags remain false.',
        'The macOS app-relaunch scenario is correctly skipped on Linux and is not claimed by this receipt.',
    ],
    'jobSnapshot': snapshot.name, 'jobSnapshotSha256': sha(snapshot),
    'jobLog': log_path.name, 'jobLogSha256': sha(log_path),
    'verifierSha256': sha(pathlib.Path(__file__)),
}
out = EVIDENCE / 'packaged-linux-qualification.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'sourceFiles': source_count, 'distJsFiles': dist_count,
                  'output': str(out), 'sha256': sha(out)}))
