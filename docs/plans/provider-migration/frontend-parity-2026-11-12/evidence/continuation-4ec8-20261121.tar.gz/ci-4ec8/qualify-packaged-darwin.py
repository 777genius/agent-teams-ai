import hashlib
import json
import pathlib
import re
import stat
import subprocess
import zipfile
from PIL import Image

ROOT = pathlib.Path('/workspace/scratch/82699181f7b2')
REPO = ROOT / 'agent-teams-ai'
EVIDENCE = ROOT / 'ci-4ec8'
HEAD = '4ec8e74b9a6430143287baa5298a11ade98a5794'
RUN = 44912818208
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
subprocess.run(['git', 'diff', '--exit-code', HEAD], cwd=REPO, check=True, capture_output=True)
tracked = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0'))
listing_path = EVIDENCE / f'ci-audit-run-{RUN}-artifacts.json'
terminal_path = EVIDENCE / f'ci-audit-run-{RUN}-terminal.json'
listing, terminal = read(listing_path), read(terminal_path)
assert terminal['metadata']['head_sha'] == HEAD and terminal['metadata']['run_attempt'] == 1
assert terminal['metadata']['status'] == 'completed' and terminal['metadata']['conclusion'] == 'success'
assert listing['total_count'] == len(listing['artifacts']) == 5
runtime_lock, node_lock = read(REPO / 'runtime.lock.json'), read(REPO / 'legacy-host.lock.json')
host_package = read(REPO / 'packages/legacy-agent-host/package.json')

def tree_digest(root, suffix):
    paths = sorted((p for p in root.rglob('*') if p.is_file() and p.name.endswith(suffix)),
                   key=lambda p: p.relative_to(root).as_posix())
    h = hashlib.sha256()
    for p in paths:
        h.update(p.relative_to(root).as_posix().encode()); h.update(b'\0')
        h.update(p.read_bytes()); h.update(b'\0')
    return h.hexdigest(), len(paths)

source_digest, source_count = tree_digest(REPO / 'packages/legacy-agent-host/src', '.ts')
dist_digest, dist_count = tree_digest(REPO / 'packages/legacy-agent-host/dist', '.js')
assert source_count == dist_count == 631
steps = [
    'original_host_embedded_native_and_mcp_ready',
    'native_model_tool_effect_permission_mcp_task_and_reply_completed_once',
    'changed_project_config_did_not_retarget_running_native_session',
    'original_uploaded_PNG_native_image_inference_and_public_readback',
    'all_image_MIMEs_exact_PDF_and_4MiB_PNG_native_normalization_and_public_readback',
    'checkpoint_and_original_host_native_cleanup_confirmed',
    'cold_host_restored_native_history_without_model_or_tool_replay',
]
results = []
for platform, artifact_id, job_id in [
    ('darwin-x64', 14712412138, 136875985718),
    ('darwin-arm64', 14713403328, 136875985753),
]:
    artifact = next(a for a in listing['artifacts'] if a['id'] == artifact_id)
    assert artifact['workflow_run']['head_sha'] == HEAD and artifact['workflow_run']['id'] == RUN
    assert artifact['name'] == f'packaged-v2-host-{platform}-{HEAD}'
    job = next(j for j in terminal['jobs']['jobs'] if j['id'] == job_id)
    assert job['run_attempt'] == 1 and job['head_sha'] == HEAD and job['conclusion'] == 'success'
    for step_name in ['Qualify actual packaged V2 Host tools, MCP, Stop and cold Resume',
                      'Qualify original packaged macOS app relaunch with finite SDK peer']:
        assert next(s for s in job['steps'] if s['name'] == step_name)['conclusion'] == 'success'
    archive = EVIDENCE / f'packaged-{platform}-{artifact_id}.zip'
    directory = EVIDENCE / f'packaged-{platform}-{artifact_id}'
    assert archive.stat().st_size == artifact['size_in_bytes']
    assert 'sha256:' + sha(archive) == artifact['digest']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist())) == 9
        for entry in z.infolist():
            path = pathlib.PurePosixPath(entry.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in entry.filename
            assert not stat.S_ISLNK(entry.external_attr >> 16)
    def load(name):
        paths = list(directory.rglob(name)); assert len(paths) == 1
        return paths[0], read(paths[0])
    input_path, inputs = load('opencode-v2-packaged-inputs.json')
    wrapper_path, wrapper = load('opencode-v2-packaged.json')
    native_path, native = load('opencode-v2-packaged-native.json')
    candidate_path, candidate = load('opencode-v2-candidate.json')
    relaunch_path, relaunch = load('packaged-app-relaunch.json')
    for receipt in [inputs, wrapper, native, candidate, relaunch]:
        assert receipt['sourceHead'] == HEAD and receipt['platform'] == platform
    assert inputs['kind'] == 'TEST_NATIVE_V2_EMBEDDED_INPUTS' and inputs['status'] == 'READY'
    assert inputs['stage'] == 'prepared' and inputs['productQualified'] is False
    assert inputs['nodeVersion'] == native['nodeVersion'] == 'v24.21.0'
    delivery = runtime_lock['opencodeV2Delivery'][platform]
    assert inputs['baseArchiveSha256'] == runtime_lock['assets'][platform]['sha256']
    assert inputs['runtimeSource'] == delivery['sourceCommit']
    assert inputs['supportArchiveSha256'] == delivery['archive']['sha256']
    assert inputs['manifestSha256'] == delivery['manifest']['sha256'] == candidate['engine']['manifestSha256'] == native['digests']['manifest']
    assert inputs['bun']['sha256'] == candidate['bun']['sha256'] == native['digests']['bun']
    assert inputs['bun']['version'] == candidate['bun']['version'] == delivery['requiredBunVersion'] == '1.4.4'
    assert inputs['productTupleAdmitted'] is True
    process_artifact = inputs['processArtifact']; process_manifest = process_artifact['manifest']
    assert process_manifest['platform'] == 'darwin' and process_manifest['architecture'] == platform.split('-')[1]
    assert process_manifest['osBuild'] == inputs['osBuild']
    assert process_manifest['sourceSha256'] == sha(REPO / 'packages/legacy-agent-host/native/registered-process-darwin.c')
    assert process_artifact['manifestSha256'] == candidate['processCustody']['manifestSha256']
    assert process_manifest['binarySha256'] == candidate['processCustody']['binarySha256']
    assert candidate['schemaVersion'] == 1 and candidate['kind'] == 'TEST_PACKAGED_OPENCODE_V2_INPUTS'
    assert candidate['node']['platform'] == platform and candidate['node']['version'] == node_lock['nodeVersion'] == '24.21.0'
    assert candidate['node']['archiveSha256'] == node_lock['platforms'][platform]['sha256'] == native['packaged']['nodeArchiveSha256']
    assert candidate['nodeExecutable'] == f'node/v24.21.0/{platform}/node'
    assert wrapper['kind'] == 'TEST_PACKAGED_V2_QUALIFICATION' and wrapper['status'] == 'PASS'
    assert wrapper['cleanup'] is True and wrapper['phase'] == 'finished'
    assert wrapper['cleanupObservation'] == {'originalExitObserved': True, 'nativeReceiptParsed': True,
        'nativeReceiptBound': True, 'nativeCleanupConfirmed': True, 'firstFailure': None, 'firstRestorationFailure': None}
    assert wrapper['nativeExit'] == {'code': 0, 'signal': None}
    assert wrapper['nativeReceiptSha256'] == sha(native_path)
    assert wrapper['candidateManifestSha256'] == sha(candidate_path) == native['packaged']['candidateManifestSha256']
    assert wrapper['appAsarSha256'] == native['packaged']['appAsarSha256'] == relaunch['packedCandidate']['appAsarSha256']
    assert wrapper['hostEntrySha256'] == candidate['hostEntrySha256'] == native['packaged']['hostEntrySha256'] == relaunch['pins']['hostEntrySha256']
    assert wrapper['nodeSha256'] == candidate['node']['binarySha256'] == native['digests']['node'] == relaunch['pins']['nodeSha256']
    assert candidate['harnessSha256'] == native['packaged']['harnessSha256']
    for key in ['sourceCheckoutUnavailable', 'legacyRuntimeUnavailable']:
        assert wrapper[key] is True and native['packaged'][key] is True
    for key in ['sourceRestored', 'bundleRestored', 'legacyRuntimeRestored']:
        assert wrapper[key] is True
    for key in ['desktopJourneyQualified', 'vendorAuthQualified', 'releaseQualified']:
        assert wrapper[key] is False
    assert native['kind'] == 'TEST_PACKAGED_NATIVE_V2_HOST' and native['status'] == 'PASS'
    assert native['cleanup'] is True and native['cancelled'] is False and native['failureCode'] is None
    assert native['approvalMode'] == 'manual' and native['modelOrigin'] == 'localhost-scripted'
    assert native['modelRequests'] == 11 and native['modelFailures'] == []
    assert native['hosts'] == [{'exitCode': 0, 'signalCode': None, 'stdoutValid': True}] * 2
    assert native['steps'] == steps and list(native['phaseElapsedMs']) == steps
    assert list(native['phaseElapsedMs'].values()) == sorted(native['phaseElapsedMs'].values())
    assert native['coordination'] == {'status': 'unqualified', 'cleanup': None}
    for key in ['desktopQualified', 'vendorAuthQualified', 'releaseQualified']:
        assert native[key] is False
    assert candidate['hostSourceDigest'] == native['digests']['hostSource'] == source_digest
    assert native['digests']['hostDist'] == dist_digest
    assert native['packaged']['executionOrigin'] == 'packaged-extraResources'
    assert native['packaged']['packages'] == len(candidate['packages']) == 120
    assert native['packaged']['files'] == sum(len(p['files']) for p in candidate['packages']) == 8175
    assert len({p['path'] for p in candidate['packages']}) == 120
    for package in candidate['packages']:
        assert re.fullmatch(r'packages/\d{4}', package['path'])
        assert len(package['files']) == len({f['path'] for f in package['files']})
        for file in package['files']:
            assert re.fullmatch(r'[0-9a-f]{64}', file['sha256']) and type(file['executable']) is bool
            assert all(part not in ['', '.', '..', 'node_modules'] for part in file['path'].split('/'))
    host = next(p for p in candidate['packages'] if p['name'] == '@agent-teams/legacy-agent-host')
    host_js = [f for f in host['files'] if f['path'].startswith('dist/') and f['path'].endswith('.js')]
    assert len(host_js) == 631
    for file in host_js:
        assert file['sha256'] == sha(REPO / 'packages/legacy-agent-host' / file['path'])
    assert candidate['hostEntrySha256'] == sha(REPO / 'packages/legacy-agent-host/dist/cli.js')
    assert candidate['artifacts'] == native['packaged']['providerArtifacts']
    for artifact_pin in candidate['artifacts']:
        reference = host_package['dependencies'][artifact_pin['name']]
        assert reference.startswith('file:') and reference.endswith('.tgz')
        assert artifact_pin['sha256'] == sha((REPO / 'packages/legacy-agent-host' / reference[5:]).resolve())
    assert native['digests']['provider'] == relaunch['pins']['providerArchiveSha256']

    assert relaunch['kind'] == 'TEST_PACKAGED_APP_RELAUNCH' and relaunch['status'] == 'PASS'
    assert relaunch['mode'] == 'emulated-claude-lifecycle-ui' and relaunch['realVendorExecutions'] == 0
    assert relaunch['nativeProviderQualified'] is False and relaunch['releaseQualified'] is False
    assert relaunch['packagedInputsUnchanged'] is True and 'emulatedRuntimeChildRefusal' not in relaunch
    assert 'sourceFreezeFailure' not in relaunch and 'finalObservationFailure' not in relaunch
    assert relaunch['selectedSourceHashesBeforeApp'] == relaunch['selectedSourceHashesAfterFlow']
    source_pins = relaunch['selectedSourceHashesBeforeApp']
    assert len(source_pins) == len({p['path'] for p in source_pins}) == 1972
    for pin in source_pins:
        assert pin['path'] in tracked and sha(REPO / pin['path']) == pin['sha256']
    assert relaunch['pins']['smokeSourceSha256'] == sha(REPO / 'scripts/legacy-agent-host/desktop-packaged-relaunch-smoke.ts')
    peer = relaunch['fixturePins']
    assert peer['provider'] == 'claude' and peer['vendorsAllowed'] is False
    assert peer['runtimeConfigured'] is True and peer['managementConfigured'] is True
    assert len(peer['sources']) == 1
    assert peer['sources'][0]['sha256'] == sha(REPO / 'tools/owned-process-broker/fixtures/claudeProviderPeer.mjs')
    startup = relaunch['packagedStartupObservation']
    assert startup['phase'] == 'complete' and startup['budgetMs'] == 180000
    assert [s['phase'] for s in startup['steps']] == ['binding', 'peer-observation', 'complete']
    assert all(s['remainingMs'] > 0 for s in startup['steps'])
    launch = relaunch['emulatedLaunchStopUiProof']
    assert launch['status'] == 'PASS' and 'emulatedLifecycleUiProof' not in relaunch
    session = launch['source']['session']
    assert session['phase'] == 'closed' and session['custody'] == 'released'
    assert len(session['inputs']) == 1 and session['inputs'][0]['terminal'] == 'succeeded'
    assert session['inputs'][0]['intent']['content'] == 'TEST_UI_BOOT'
    proof = relaunch['packedAppRelaunch']
    assert proof['status'] == 'PASS' and proof['relaunchAttempted'] is True and proof['successorQuitAttempted'] is True
    assert proof['successorNativeCustody'] is False and proof['numericPidSignalsAuthorized'] is False
    assert proof['originalExit'] == {'exitCode': 0, 'signalCode': None, 'HostExitCode': 'unavailable', 'HostSignalCode': 'unavailable'}
    assert proof['originalSessions'] == [session]
    assert proof['leaseAfterOriginalExit'] is None
    ordering = proof['writerOrdering']
    assert ordering['originalHostAbsent'] is True and ordering['originalLease'] == proof['originalLease']
    assert ordering['newExclusiveLease']['pid'] != proof['originalLease']['pid']
    assert ordering['newExclusiveLease']['token'] != proof['originalLease']['token']
    assert proof['successorIdentity']['pid'] != relaunch['app']['pid']
    assert proof['successorIdentity']['observationOnly'] is True
    assert proof['successorIdentity']['executable'] == relaunch['packedCandidate']['executable']
    assert proof['successorBinding']['discovery']['bindings'] == relaunch['discovery']['bindings']
    assert proof['successorBinding']['homePathProof'] == relaunch['homePathProof']
    assert proof['successorBinding']['rendererTarget']['id'] != relaunch['rendererTarget']['id']
    assert proof['successorAbsence'] == {'listenerAbsent': True, 'observedPidAbsent': True,
        'HostPidAbsent': True, 'writerLockAbsent': True, 'exitCode': 'unavailable', 'signalCode': 'unavailable', 'naturalExitQualified': False}
    assert relaunch['cleanup']['remaining'] == [] and relaunch['cleanup']['capturedHostAbsent'] is True
    assert 'cleanupFailure' not in relaunch['cleanup'] and relaunch['beforeHarnessCleanup'] == []
    cleanup = relaunch['emulatedRuntimeCleanup']
    assert cleanup['remaining'] == [] and cleanup['absent'] is True
    effects = cleanup['effects']; inputs_at_end = [e for e in effects if e['event'] == 'input']
    assert inputs_at_end == relaunch['originalInputEffects']
    assert [e['marker'] for e in inputs_at_end] == ['TEST_MODEL_PROBE', 'TEST_UI_BOOT']
    assert len({e['pid'] for e in effects}) == len(cleanup['originalPeerPids'])
    assert set(e['pid'] for e in effects) == set(cleanup['originalPeerPids'])
    assert len([e for e in effects if e['event'] == 'mcp-connected']) == 1
    assert relaunch['finalSentinelCensus'] == []
    assert relaunch['packedCandidate']['capture']['manifestSha256'] == sha(candidate_path)
    assert relaunch['pins']['electronSha256'] == relaunch['packedCandidate']['executableSha256']
    for binding in [relaunch, proof['successorBinding']]:
        assert binding['compiledBundleHashesAfterStartup']['appAsar']['sha256'] == wrapper['appAsarSha256']
    pngs = []
    for png in sorted(directory.rglob('*.png')):
        with Image.open(png) as image:
            assert image.format == 'PNG'; image.verify()
        with Image.open(png) as image: dimensions = list(image.size)
        pngs.append({'path': str(png.relative_to(directory)), 'sha256': sha(png), 'dimensions': dimensions})
    assert len(pngs) == 3
    for key in ['launchScreenshot', 'stoppedScreenshot']:
        screenshot = launch[key]
        png = next(directory.rglob(pathlib.PurePosixPath(screenshot['path']).name))
        assert screenshot['sha256'] == sha(png)
    results.append({'platform': platform, 'jobId': job_id, 'artifactId': artifact_id,
        'zipBytes': archive.stat().st_size, 'zipSha256': sha(archive), 'archiveIntegrity': 'MATCH',
        'wrapperReceipt': 'PASS', 'nativeHost': 'PASS', 'nativeModelRequests': 11, 'cleanHosts': 2,
        'steps': steps, 'nativeElapsedMs': native['elapsedMs'], 'originalAppRelaunch': 'PASS',
        'sourcePinsBeforeAfterAndExactGit': len(source_pins), 'hostSourceFiles': source_count,
        'hostDistFiles': dist_count, 'candidateHostJsCompared': len(host_js), 'providerArchiveBytes': 'MATCH',
        'nativeProcessSourceBytes': 'MATCH', 'osBuild': inputs['osBuild'],
        'finiteOriginalPeerPidsAbsent': len(cleanup['originalPeerPids']), 'inputReplay': False,
        'successorPublicQuitReply': proof['successorQuitReply'], 'successorAbsence': proof['successorAbsence'],
        'successorNativeCustody': False, 'emulatedRuntimeChildRefusal': 'absent',
        'startupCompleteElapsedMs': startup['steps'][-1]['elapsedMs'], 'screenshots': pngs,
        'visualReadback': 'Successor screenshot visually inspected: actual app home and persisted TEST sidebar task render; provider loading state is not claimed as provider readiness.',
        'fileIndex': f'packaged-{platform}-{artifact_id}-files-sha256.json',
        'fileIndexSha256': sha(EVIDENCE / f'packaged-{platform}-{artifact_id}-files-sha256.json')})

result = {'schemaVersion': 1, 'status': 'PASS_DECLARED_TEST_SCOPES', 'sourceHead': HEAD,
    'runId': RUN, 'attempt': 1, 'results': results,
    'terminalSnapshot': terminal_path.name, 'terminalSnapshotSha256': sha(terminal_path),
    'artifactListing': listing_path.name, 'artifactListingSha256': sha(listing_path),
    'verifierSha256': sha(pathlib.Path(__file__)),
    'limitations': ['No native executable, complete package closure, app.asar, TEST peer executable or bundled harness bytes are present in these ZIPs. Such binary pins are original-runner observations, not locally remeasured binaries.',
        'The original reader verified exact packaged closure, admitted process tuple and no source/legacy fallback. This readback validates receipt consistency and available exact source/compiled-JS/provider-archive bytes without reexecuting native or product code.',
        'Automatic successor lifecycle remains observation-only: native custody and natural exit status are not qualified. Public Quit reply was unconfirmed, while observed successor/listener/Host/writer-lock absence was confirmed.',
        'One finite SDK Launch/Stop and automatic app relaunch are qualified; full cold Resume/active Quit, genuine Claude/Codex, vendor authentication and release qualification are excluded.',
        'Native packaged OpenCode Host tools/MCP/Stop/cold Resume is a separate TEST localhost-model scope; desktop journey and coordination remain unqualified there.',
        'Provider loading spinners in successor screenshots are not provider-readiness evidence.']}
output = EVIDENCE / 'packaged-darwin-qualification.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'platforms': len(results), 'sourcePinsEach': 1972,
                  'output': str(output), 'sha256': sha(output)}))
