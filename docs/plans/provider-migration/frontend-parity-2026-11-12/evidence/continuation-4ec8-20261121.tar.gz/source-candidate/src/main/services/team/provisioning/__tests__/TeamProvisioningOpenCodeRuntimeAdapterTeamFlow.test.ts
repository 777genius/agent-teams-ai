import * as fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

import { describe, expect, it, vi } from 'vitest';

import { setClaudeBasePathOverride } from '../../../../utils/pathDecoder';
import { TeamInboxReader } from '../../TeamInboxReader';
import { TeamMetaStore } from '../../TeamMetaStore';
import {
  createOpenCodeTeamThroughRuntimeAdapterFlow,
  launchOpenCodeTeamThroughRuntimeAdapterFlow,
  type OpenCodeRuntimeAdapterTeamFlowPorts,
} from '../TeamProvisioningOpenCodeRuntimeAdapterTeamFlow';

import type { PreparedOpenCodeRuntimeAdapterLaunch } from '../TeamProvisioningOpenCodeRuntimeAdapterPreparation';
import type { TeamRuntimeLanePlan } from '@features/team-runtime-lanes';
import type { TeamCreateRequest, TeamLaunchRequest, TeamTask } from '@shared/types';

function createRequest(overrides: Partial<TeamCreateRequest> = {}): TeamCreateRequest {
  return {
    teamName: 'alpha',
    displayName: 'Alpha',
    description: 'OpenCode team',
    color: 'blue',
    cwd: '/repo',
    prompt: '  build it  ',
    members: [{ name: 'alice', role: 'Engineer', providerId: 'opencode' }],
    providerId: 'opencode',
    providerBackendId: 'adapter',
    model: 'gpt-5',
    effort: 'high',
    skipPermissions: false,
    worktree: 'feature-a',
    extraCliArgs: '--flag',
    limitContext: true,
    ...overrides,
  } as TeamCreateRequest;
}

function launchRequest(overrides: Partial<TeamLaunchRequest> = {}): TeamLaunchRequest {
  return {
    teamName: 'alpha',
    cwd: '/repo',
    providerId: 'opencode',
    providerBackendId: 'adapter',
    model: 'gpt-5',
    effort: 'high',
    ...overrides,
  } as TeamLaunchRequest;
}

function pureOpenCodePlan(members: TeamCreateRequest['members']): TeamRuntimeLanePlan {
  return {
    mode: 'pure_opencode',
    primaryMembers: members,
    allMembers: members,
    sideLanes: [],
  } as TeamRuntimeLanePlan;
}

function memberLanePlan(input: {
  primaryMembers: TeamCreateRequest['members'];
  sideMembers: TeamCreateRequest['members'];
}): TeamRuntimeLanePlan {
  return {
    mode: 'pure_opencode_member_lanes',
    primaryMembers: input.primaryMembers,
    allMembers: [...input.primaryMembers, ...input.sideMembers],
    sideLanes: input.sideMembers.map((member) => ({
      laneId: `secondary:opencode:${member.name}`,
      providerId: 'opencode',
      member: { ...member, providerId: 'opencode' },
    })),
  } as TeamRuntimeLanePlan;
}

function prepared<TRequest extends TeamCreateRequest | TeamLaunchRequest>(params: {
  request: TRequest;
  effectiveMembers?: TeamCreateRequest['members'];
  runtimeLaunchMembers?: TeamCreateRequest['members'];
  lanePlan?: TeamRuntimeLanePlan;
}): PreparedOpenCodeRuntimeAdapterLaunch<TRequest> {
  const effectiveMembers =
    params.effectiveMembers ??
    ([
      { name: 'alice', role: 'Engineer', providerId: 'opencode', cwd: '/repo/alice' },
    ] as TeamCreateRequest['members']);
  return {
    launchRequest: params.request,
    effectiveMembers,
    lanePlan: params.lanePlan ?? pureOpenCodePlan(effectiveMembers),
    runtimeLaunchMembers:
      params.runtimeLaunchMembers ??
      ([
        { name: 'team-lead', role: 'Team Lead', providerId: 'opencode' },
        ...effectiveMembers,
      ] as TeamCreateRequest['members']),
  };
}

function createPorts(
  calls: string[],
  overrides: Partial<OpenCodeRuntimeAdapterTeamFlowPorts> = {}
): OpenCodeRuntimeAdapterTeamFlowPorts {
  return {
    getTeamsBasePathsToProbe: () => [
      { location: 'configured', basePath: '/configured/teams' },
      { location: 'default', basePath: '/default/teams' },
    ],
    getTeamsBasePath: () => {
      calls.push('getTeamsBasePath');
      return '/configured/teams';
    },
    getTasksBasePath: () => {
      calls.push('getTasksBasePath');
      return '/configured/tasks';
    },
    pathExists: async (filePath) => {
      calls.push(`pathExists:${filePath}`);
      return false;
    },
    ensureCwdExists: async (cwd) => {
      calls.push(`ensureCwdExists:${cwd}`);
    },
    mkdir: async (directoryPath) => {
      calls.push(`mkdir:${directoryPath}`);
    },
    claimCreatedTeam: async (teamName) => {
      calls.push(`claimCreatedTeam:${teamName}`);
    },
    nowMs: () => 123,
    writeTeamMeta: async (_teamName, data) => {
      calls.push(`writeTeamMeta:${data.createdAt}:${data.cwd}`);
    },
    writeMembersMeta: async (_teamName, members, options) => {
      const names = members.map((member) => member.name).join(',');
      calls.push(`writeMembersMeta:${names}:${options?.providerBackendId}`);
    },
    writeOpenCodeTeamConfig: async (_request, members) => {
      calls.push(`writeOpenCodeTeamConfig:${members.map((member) => member.name).join(',')}`);
    },
    prepareOpenCodeRuntimeAdapterLaunch: async <
      TRequest extends TeamCreateRequest | TeamLaunchRequest,
    >({
      request,
    }: {
      request: TRequest;
      members: TeamCreateRequest['members'];
    }) => {
      calls.push('prepareOpenCodeRuntimeAdapterLaunch');
      return prepared({ request });
    },
    readTeamConfigRaw: async () => {
      calls.push('readTeamConfigRaw');
      return '{"name":"Alpha"}';
    },
    resolveLaunchExpectedMembers: async (_teamName, _configRaw, leadProviderId) => {
      calls.push(`resolveLaunchExpectedMembers:${leadProviderId ?? 'none'}`);
      return {
        members: [{ name: 'alice', role: 'Engineer', providerId: 'opencode' }],
        source: 'members-meta',
        warning: 'member warning',
      };
    },
    updateConfigProjectPath: async (_teamName, cwd) => {
      calls.push(`updateConfigProjectPath:${cwd}`);
    },
    readExistingTasks: async () => {
      calls.push('readExistingTasks');
      return [{ id: 'task-1', subject: 'Existing task' } as TeamTask];
    },
    warn: (message) => {
      calls.push(`warn:${message}`);
    },
    buildDeterministicLaunchHydrationPrompt: (_request, _members, tasks, includeLead) => {
      calls.push(`buildPrompt:${tasks.length}:${includeLead}`);
      return 'hydrated prompt';
    },
    runOpenCodeWorktreeRootAggregateLaunch: async (input) => {
      const names = input.members.map((member) => member.name).join(',');
      calls.push(`runWorktreeRoot:${names}:${input.prompt}:${input.sourceWarning ?? 'none'}`);
      return { runId: 'worktree-run' };
    },
    runOpenCodeTeamRuntimeAdapterLaunch: async (input) => {
      const names = input.members.map((member) => member.name).join(',');
      calls.push(`runRuntimeAdapter:${names}:${input.prompt}:${input.sourceWarning ?? 'none'}`);
      return { runId: 'adapter-run' };
    },
    ...overrides,
  };
}

describe('OpenCode runtime adapter team flow', () => {
  it.each([
    { name: 'fresh explicit selection', requested: 1, stored: undefined, expected: 1 },
    { name: 'fresh legacy selection', requested: undefined, stored: undefined, expected: undefined },
    { name: 'existing explicit selection', requested: undefined, stored: 1, expected: 1 },
  ] as const)('preserves $name through persisted creation and cold read', async (selection) => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), 'TEST-opencode-create-selection-'));
    setClaudeBasePathOverride(root);
    const request = createRequest({
      teamName: 'TEST-opencode-selection',
      cwd: root,
      model: 'test-legacy/TEST-model',
      skipPermissions: true,
      runtimeSelectionVersion: selection.requested,
    });
    const store = new TeamMetaStore();
    try {
      if (selection.stored) {
        await fs.mkdir(path.join(root, 'teams', request.teamName), { recursive: true });
        await store.writeMeta(request.teamName, {
          cwd: root,
          runtimeSelectionVersion: selection.stored,
          createdAt: 1,
        });
      }
      await expect(
        createOpenCodeTeamThroughRuntimeAdapterFlow(request, vi.fn(), createPorts([], {
          getTeamsBasePathsToProbe: () => [
            { location: 'configured', basePath: path.join(root, 'teams') },
          ],
          getTeamsBasePath: () => path.join(root, 'teams'),
          getTasksBasePath: () => path.join(root, 'tasks'),
          mkdir: (directoryPath) => fs.mkdir(directoryPath, { recursive: true }),
          writeTeamMeta: (teamName, data) => store.writeMeta(teamName, data),
        }))
      ).resolves.toEqual({ runId: 'adapter-run' });
      const persisted = JSON.parse(
        await fs.readFile(path.join(root, 'teams', request.teamName, 'team.meta.json'), 'utf8')
      ) as Record<string, unknown>;
      expect(persisted.runtimeSelectionVersion).toBe(selection.expected);
      expect(await new TeamMetaStore().getMeta(request.teamName)).toMatchObject({
        cwd: root,
        providerId: 'opencode',
        model: 'test-legacy/TEST-model',
        skipPermissions: true,
        runtimeSelectionVersion: selection.expected,
      });
    } finally {
      setClaudeBasePathOverride(null);
      await fs.rm(root, { recursive: true, force: true });
    }
  });

  it.each([false, true])(
    'initializes only fresh inbox history before OpenCode metadata (existing=%s)',
    async (existing) => {
      const claudeRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'TEST-opencode-create-inboxes-'));
      setClaudeBasePathOverride(claudeRoot);
      const inboxReader = new TeamInboxReader();
      const request = createRequest({ teamName: 'TEST-opencode-create', cwd: claudeRoot });
      const writeTeamMeta = vi.fn(async (teamName: string) => {
        const inboxes = fs.readdir(path.join(claudeRoot, 'teams', teamName, 'inboxes'));
        if (existing) {
          await expect(inboxes).rejects.toMatchObject({ code: 'ENOENT' });
        } else {
          await expect(inboxes).resolves.toEqual([]);
        }
        await expect(inboxReader.getMessagesWindow(teamName, { limit: 20 })).resolves.toMatchObject(
          {
            messages: [],
            truncated: false,
            sourceMessageCount: 0,
          }
        );
      });

      try {
        if (existing)
          await fs.mkdir(path.join(claudeRoot, 'teams', request.teamName), { recursive: true });
        await expect(
          createOpenCodeTeamThroughRuntimeAdapterFlow(
            request,
            vi.fn(),
            createPorts([], {
              getTeamsBasePathsToProbe: () => [
                { location: 'configured', basePath: path.join(claudeRoot, 'teams') },
              ],
              getTeamsBasePath: () => path.join(claudeRoot, 'teams'),
              getTasksBasePath: () => path.join(claudeRoot, 'tasks'),
              mkdir: async (directoryPath) => {
                return fs.mkdir(directoryPath, { recursive: true });
              },
              writeTeamMeta,
            })
          )
        ).resolves.toEqual({ runId: 'adapter-run' });
        expect(writeTeamMeta).toHaveBeenCalledTimes(1);
      } finally {
        setClaudeBasePathOverride(null);
        await fs.rm(claudeRoot, { recursive: true, force: true });
      }
    }
  );

  it('persists inherited intent before runtime materialization and keeps explicit same-model choices', async () => {
    const model = 'zai-coding-plan/glm-5.3';
    const request = createRequest({
      model,
      syncModelsWithLead: true,
      members: [
        { name: 'inherit-one' },
        { name: 'inherit-two' },
        { name: 'explicit-same', model },
        { name: 'explicit-other', model: 'zai-coding-plan/glm-5.3-flash' },
      ],
    });
    const writeMembersMeta = vi.fn(async () => undefined);
    await createOpenCodeTeamThroughRuntimeAdapterFlow(
      request,
      vi.fn(),
      createPorts([], {
        writeMembersMeta,
        prepareOpenCodeRuntimeAdapterLaunch: async ({ request: launchRequest, members }) =>
          prepared({
            request: launchRequest,
            effectiveMembers: members.map((member) => ({
              ...member,
              providerId: 'opencode',
              model: member.model ?? model,
              cwd: '/project/synthetic-worktree',
            })),
          }),
      })
    );
    expect(writeMembersMeta).toHaveBeenCalledWith(
      'alpha',
      [
        expect.objectContaining({
          name: 'inherit-one',
          model: undefined,
          providerId: undefined,
          cwd: '/project/synthetic-worktree',
        }),
        expect.objectContaining({ name: 'inherit-two', model: undefined }),
        expect.objectContaining({ name: 'explicit-same', model }),
        expect.objectContaining({ name: 'explicit-other', model: 'zai-coding-plan/glm-5.3-flash' }),
      ],
      { providerBackendId: 'adapter' }
    );
  });

  it('detects duplicate teams across configured and default team bases before preparing launch', async () => {
    const calls: string[] = [];
    const ports = createPorts(calls, {
      pathExists: async (filePath) => {
        calls.push(`pathExists:${filePath}`);
        return filePath === path.join('/default', 'teams', 'alpha', 'config.json');
      },
    });

    await expect(
      createOpenCodeTeamThroughRuntimeAdapterFlow(createRequest(), vi.fn(), ports)
    ).rejects.toThrow('Team already exists (found under /default/teams)');

    expect(calls).toEqual([
      `pathExists:${path.join('/configured', 'teams', 'alpha', 'config.json')}`,
      `pathExists:${path.join('/default', 'teams', 'alpha', 'config.json')}`,
    ]);
  });

  it('creates team directories and metadata before launching the runtime adapter branch', async () => {
    const calls: string[] = [];

    const result = await createOpenCodeTeamThroughRuntimeAdapterFlow(
      createRequest(),
      vi.fn(),
      createPorts(calls)
    );

    expect(result).toEqual({ runId: 'adapter-run' });
    expect(calls).toEqual([
      `pathExists:${path.join('/configured', 'teams', 'alpha', 'config.json')}`,
      `pathExists:${path.join('/default', 'teams', 'alpha', 'config.json')}`,
      'ensureCwdExists:/repo',
      'prepareOpenCodeRuntimeAdapterLaunch',
      'getTeamsBasePath',
      `mkdir:${path.join('/configured', 'teams', 'alpha')}`,
      'getTasksBasePath',
      `mkdir:${path.join('/configured', 'tasks', 'alpha')}`,
      'claimCreatedTeam:alpha',
      'writeTeamMeta:123:/repo',
      'writeMembersMeta:alice:adapter',
      'writeOpenCodeTeamConfig:alice',
      'runRuntimeAdapter:team-lead,alice:build it:none',
    ]);
  });

  it('aborts create before any metadata or runtime launch when the team cannot be claimed', async () => {
    const calls: string[] = [];

    await expect(
      createOpenCodeTeamThroughRuntimeAdapterFlow(
        createRequest(),
        vi.fn(),
        createPorts(calls, {
          claimCreatedTeam: async () => {
            throw new Error('Team "alpha" was not started: TEST claim failure');
          },
        })
      )
    ).rejects.toThrow('was not started');

    expect(calls.some((call) => call.startsWith('writeTeamMeta'))).toBe(false);
    expect(calls.some((call) => call.startsWith('run'))).toBe(false);
  });

  it('routes create with a model-distinct member through the aggregate member-lane branch', async () => {
    const calls: string[] = [];
    const primaryMembers = [
      { name: 'alice', role: 'Engineer', providerId: 'opencode', model: 'gpt-5' },
    ] as TeamCreateRequest['members'];
    const sideMembers = [
      {
        name: 'bob',
        role: 'Reviewer',
        providerId: 'opencode',
        model: 'minimax-m2.5-free',
      },
    ] as TeamCreateRequest['members'];
    const effectiveMembers = [...primaryMembers, ...sideMembers];

    const result = await createOpenCodeTeamThroughRuntimeAdapterFlow(
      createRequest(),
      vi.fn(),
      createPorts(calls, {
        prepareOpenCodeRuntimeAdapterLaunch: async <
          TRequest extends TeamCreateRequest | TeamLaunchRequest,
        >({
          request,
        }: {
          request: TRequest;
          members: TeamCreateRequest['members'];
        }) => {
          calls.push('prepareOpenCodeRuntimeAdapterLaunch');
          return prepared({
            request,
            effectiveMembers,
            runtimeLaunchMembers: [
              { name: 'team-lead', role: 'Team Lead', providerId: 'opencode' },
              { name: 'runtime-only', role: 'Runtime', providerId: 'opencode' },
            ] as TeamCreateRequest['members'],
            lanePlan: memberLanePlan({ primaryMembers, sideMembers }),
          });
        },
      })
    );

    expect(result).toEqual({ runId: 'worktree-run' });
    expect(calls.at(-1)).toBe('runWorktreeRoot:alice,bob:build it:none');
  });

  it('hydrates launch prompts, propagates expected-member warnings, and launches runtime adapter members', async () => {
    const calls: string[] = [];

    const result = await launchOpenCodeTeamThroughRuntimeAdapterFlow(
      launchRequest({ cwd: '/new-repo' }),
      vi.fn(),
      createPorts(calls)
    );

    expect(result).toEqual({ runId: 'adapter-run' });
    expect(calls).toEqual([
      'readTeamConfigRaw',
      'ensureCwdExists:/new-repo',
      'resolveLaunchExpectedMembers:opencode',
      'prepareOpenCodeRuntimeAdapterLaunch',
      'updateConfigProjectPath:/new-repo',
      'readExistingTasks',
      'buildPrompt:1:false',
      'runRuntimeAdapter:team-lead,alice:hydrated prompt:member warning',
    ]);
  });

  it('keeps launch going with an empty task list when task hydration reads fail', async () => {
    const calls: string[] = [];

    const result = await launchOpenCodeTeamThroughRuntimeAdapterFlow(
      launchRequest(),
      vi.fn(),
      createPorts(calls, {
        readExistingTasks: async () => {
          calls.push('readExistingTasks');
          throw new Error('task read failed');
        },
      })
    );

    expect(result).toEqual({ runId: 'adapter-run' });
    expect(calls).toContain(
      'warn:[alpha] Failed to read tasks for OpenCode launch prompt: Error: task read failed'
    );
    expect(calls).toContain('buildPrompt:0:false');
  });

  it('routes launch with a model-distinct member through the aggregate member-lane branch', async () => {
    const calls: string[] = [];
    const primaryMembers = [
      { name: 'alice', role: 'Engineer', providerId: 'opencode', model: 'gpt-5' },
    ] as TeamCreateRequest['members'];
    const sideMembers = [
      {
        name: 'bob',
        role: 'Reviewer',
        providerId: 'opencode',
        model: 'minimax-m2.5-free',
      },
    ] as TeamCreateRequest['members'];
    const effectiveMembers = [...primaryMembers, ...sideMembers];

    const result = await launchOpenCodeTeamThroughRuntimeAdapterFlow(
      launchRequest(),
      vi.fn(),
      createPorts(calls, {
        prepareOpenCodeRuntimeAdapterLaunch: async <
          TRequest extends TeamCreateRequest | TeamLaunchRequest,
        >({
          request,
        }: {
          request: TRequest;
          members: TeamCreateRequest['members'];
        }) => {
          calls.push('prepareOpenCodeRuntimeAdapterLaunch');
          return prepared({
            request,
            effectiveMembers,
            runtimeLaunchMembers: [
              { name: 'team-lead', role: 'Team Lead', providerId: 'opencode' },
              { name: 'runtime-only', role: 'Runtime', providerId: 'opencode' },
            ] as TeamCreateRequest['members'],
            lanePlan: memberLanePlan({ primaryMembers, sideMembers }),
          });
        },
      })
    );

    expect(result).toEqual({ runId: 'worktree-run' });
    expect(calls.at(-1)).toBe('runWorktreeRoot:alice,bob:hydrated prompt:member warning');
  });
});
