export {
  readRetainedOpenDiagnostic,
  type RetainedOpenDiagnosticBinding,
} from './desktop-retained-open-diagnostics.ts';
