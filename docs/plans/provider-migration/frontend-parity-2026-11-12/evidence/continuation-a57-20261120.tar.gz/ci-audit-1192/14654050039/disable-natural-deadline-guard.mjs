import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
registerHooks({ load(url, context, nextLoad) {
  const result = nextLoad(url, context);
  if (!url.endsWith('/dist/process/WindowsTeamProcessCommands.js')) return result;
  const source = typeof result.source === 'string' ? result.source : Buffer.from(result.source).toString('utf8');
  const original = 'const aliveBudget = (deadline) => performance.now() < deadline;';
  assert.equal(source.split(original).length, 2, 'Exact current production deadline guard');
  console.log('TEST mutation only: replace production aliveBudget with true in module loader; no source or dist edits');
  return { ...result, source: source.replace(original, 'const aliveBudget = (_deadline) => true;') };
}});
