import { performance } from 'node:perf_hooks';
const originalNow = performance.now.bind(performance);
let pendingAdvance = false, offsetMs = 0;
Object.defineProperty(performance, 'now', { configurable: true, value() {
  const stack = new Error().stack ?? '';
  if (pendingAdvance) {
    pendingAdvance = false;
    offsetMs += 21;
    console.log('TEST controlled scheduler preemption: +21 ms after original 20 ms deadline sample, before production admission');
  }
  const value = originalNow() + offsetMs;
  if ((stack.split('\n')[2] ?? '').includes('registered-process-commands.test.ts:812:')) pendingAdvance = true;
  return value;
}});
